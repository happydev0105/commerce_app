package com.yeasy.yeasybiz;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

