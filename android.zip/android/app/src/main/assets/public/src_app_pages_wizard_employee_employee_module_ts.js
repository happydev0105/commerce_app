"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_wizard_employee_employee_module_ts"],{

/***/ 84013:
/*!********************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysModule": () => (/* binding */ TranslateDaysModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-days.pipe */ 29069);





let TranslateDaysModule = class TranslateDaysModule {
};
TranslateDaysModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe]
    })
], TranslateDaysModule);



/***/ }),

/***/ 29069:
/*!******************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysPipe": () => (/* binding */ TranslateDaysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TranslateDaysPipe = class TranslateDaysPipe {
    transform(value) {
        const daysTranslated = {
            monday: 'lunes',
            tuesday: 'martes',
            wednesday: 'miércoles',
            thursday: 'jueves',
            friday: 'viernes',
            saturday: 'sábado',
            sunday: 'domingo'
        };
        return daysTranslated[value] || value;
    }
};
TranslateDaysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'translateDays'
    })
], TranslateDaysPipe);



/***/ }),

/***/ 86075:
/*!************************************************************!*\
  !*** ./src/app/core/services/employee/employee.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeService": () => (/* binding */ EmployeeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let EmployeeService = class EmployeeService {
    constructor(http) {
        this.http = http;
    }
    getAllEmployee() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`);
    }
    createEmployee(employee) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    findEmployees(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce/${commerceID}`);
    }
    findEmployeesWithinactives(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-with-inactives/${commerceID}`);
    }
    findEmployeeById(employeeId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${employeeId}`);
    }
    findEmployeeByCommerceAndServices(commerce, services) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-services/${commerce}`, services);
    }
    updateEmployee(employee) {
        return this.http.patch(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    deleteEmployee(uuid) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${uuid}`);
    }
    getAllPermissions() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/permission`);
    }
};
EmployeeService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
EmployeeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], EmployeeService);



/***/ }),

/***/ 38453:
/*!******************************************************************!*\
  !*** ./src/app/pages/wizard/employee/employee-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeePageWizardRoutingModule": () => (/* binding */ EmployeePageWizardRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _employee_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee.page */ 60254);




const routes = [
    {
        path: '',
        component: _employee_page__WEBPACK_IMPORTED_MODULE_0__.EmployeePage
    },
    {
        path: 'employee-item',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_core_transformers_timeTable_transformer_ts-src_app_core_utils_date_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("node_modules_date-fns_esm__lib_toInteger_index_js-node_modules_date-fns_esm_toDate_index_js-s-ec06fc")]).then(__webpack_require__.bind(__webpack_require__, /*! ./employee-detail/employee-detail.module */ 35852)).then((m) => m.EmployeeDetailPageModule)
    }
];
let EmployeePageWizardRoutingModule = class EmployeePageWizardRoutingModule {
};
EmployeePageWizardRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EmployeePageWizardRoutingModule);



/***/ }),

/***/ 73835:
/*!**********************************************************!*\
  !*** ./src/app/pages/wizard/employee/employee.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeePageModule": () => (/* binding */ EmployeePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _employee_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-routing.module */ 38453);
/* harmony import */ var _employee_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./employee.page */ 60254);








let EmployeePageModule = class EmployeePageModule {
};
EmployeePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _employee_routing_module__WEBPACK_IMPORTED_MODULE_1__.EmployeePageWizardRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule
        ],
        declarations: [_employee_page__WEBPACK_IMPORTED_MODULE_2__.EmployeePage]
    })
], EmployeePageModule);



/***/ }),

/***/ 60254:
/*!********************************************************!*\
  !*** ./src/app/pages/wizard/employee/employee.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeePage": () => (/* binding */ EmployeePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _employee_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee.page.html?ngResource */ 40080);
/* harmony import */ var _employee_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee.page.scss?ngResource */ 21417);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);






let EmployeePage = class EmployeePage {
    constructor(navCtrl, employeeService) {
        this.navCtrl = navCtrl;
        this.employeeService = employeeService;
        this.employeeCollection = [];
        this.employeeCollectionFiltered = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllEmployees();
    }
    getAllEmployees() {
        this.employeeService.findEmployees(this.commerceLogged).subscribe(response => {
            response.map(employee => {
                if (!employee.image) {
                    let initials = employee.name.slice(0, 2);
                    if (employee.surname) {
                        initials = `${employee.name.slice(0, 1)}${employee.surname.slice(0, 1)}`;
                    }
                    employee.image = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            });
            this.employeeCollection = response.filter((emp) => emp.isOwner !== true);
            this.employeeCollectionFiltered = this.employeeCollection;
        });
    }
    goToNext() {
        this.navCtrl.navigateForward(['wizard/ready']);
    }
    goToDetail(employee) {
        const navigationExtras = { state: { employee } };
        this.navCtrl.navigateForward(['wizard/employee/employee-item'], navigationExtras);
    }
    goToCreateEmployee() {
        this.navCtrl.navigateForward(['wizard/employee/employee-item']);
    }
};
EmployeePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__.EmployeeService }
];
EmployeePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-employee',
        template: _employee_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeePage);



/***/ }),

/***/ 89470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 46730);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 70847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let HeaderComponent = class HeaderComponent {
    constructor() {
        this.titleCase = true;
    }
    ngOnInit() { }
};
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    backButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titlePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titleCase: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 57185:
/*!************************************************!*\
  !*** ./src/app/shared/header/header.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderModule": () => (/* binding */ HeaderModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component */ 89470);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);






let HeaderModule = class HeaderModule {
};
HeaderModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__.TranslateDaysModule
        ],
        exports: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent]
    })
], HeaderModule);



/***/ }),

/***/ 21417:
/*!*********************************************************************!*\
  !*** ./src/app/pages/wizard/employee/employee.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ".customer-card {\n  padding: 0;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #efefef;\n  padding: 0;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  float: left;\n  position: relative;\n  top: 40%;\n  left: 20%;\n}\n.no-padding {\n  padding: 0;\n}\n.no-border {\n  border: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7QUFDRjtBQUFFO0VBQ0UsbUJBQUE7QUFFSjtBQURJO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0FBR047QUFESTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFHTjtBQURJO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUFHTjtBQUdBO0VBQ0UsVUFBQTtBQUFGO0FBR0E7RUFDRSxTQUFBO0FBQUYiLCJmaWxlIjoiZW1wbG95ZWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbWVyLWNhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgLmN1c3RvbWVyLXJvdyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgLmN1c3RvbWVyLWltYWdlIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzOSwgMjM5LCAyMzkpO1xyXG4gICAgICBwYWRkaW5nOiAwO1xyXG4gICAgfVxyXG4gICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgbWFyZ2luLXRvcDogMTkwJTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmN1c3RvbWVyLWxhYmVsIHtcclxuICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdG9wOiA0MCU7XHJcbiAgICAgIGxlZnQ6IDIwJTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcblxyXG4ubm8tcGFkZGluZyB7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG5cclxuLm5vLWJvcmRlciB7XHJcbiAgYm9yZGVyOiAwO1xyXG59Il19 */";

/***/ }),

/***/ 70847:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0 !important;\n}\n\nion-back-button {\n  --icon-margin-start: 10px;\n  --icon-margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0FBQ0YiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1iYWNrLWJ1dHRvbiB7XHJcbiAgLS1pY29uLW1hcmdpbi1zdGFydDogMTBweDtcclxuICAtLWljb24tbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 40080:
/*!*********************************************************************!*\
  !*** ./src/app/pages/wizard/employee/employee.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [titlePage]=\"'Empleados - Paso 3'\" [backButton]=\"true\"></app-header>\n\n<ion-content>\n  <ion-grid class=\"mb-12\">\n    <ion-row class=\"ion-justify-content-center\">\n      <div class=\"px-8 py-4\" *ngIf=\"employeeCollectionFiltered.length === 0\">\n        <h1 class=\"text-center\">Crea tus empleados</h1>\n        <p>Da de alta a tus empleados</p>\n        <p>Les llegará un email a su correo para que descarguen la app y puedan empezar a trabajar</p>\n        <p>Si no necesitas crear empleados puedes continuar</p>\n      </div>\n      <div *ngIf=\"employeeCollectionFiltered.length === 1\" class=\"p-8\">\n        <h1 class=\"text-center\">Añade a tu plantilla.</h1>\n        <p>¡Genial! Y tienes tu primer empleado creado</p>\n        <p>Si no necesitas crear más empleados puedes continuar</p>\n      </div>\n\n\n    </ion-row>\n    <ion-row class=\"ion-justify-content-center w-full\">\n      <ion-card *ngFor=\"let employee of employeeCollectionFiltered\" button=\"true\" class=\"w-full m-3\" (click)=\"goToDetail(employee)\">\n        <ion-grid class=\"customer-card\">\n          <ion-row class=\"customer-row\">\n            <ion-col class=\"customer-image\" size=\"3\">\n              <img class=\"p-4\" [src]=\"employee.image\" />\n            </ion-col>\n            <ion-col size=\"8\">\n              <ion-label class=\"customer-label\">{{employee.name}} {{employee.surname}}</ion-label>\n            </ion-col>\n            <ion-col size=\"1\">\n              <div class=\"icon-container\">\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>\n\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n <ion-footer class=\"h-20 py-2 bg-white\">\n    <div class=\"px-8 w-full fixed \">\n        <div class=\"grid grid-cols-2 \" >\n          <div>\n            <ion-button (click)=\"goToCreateEmployee()\" expand=\"block\" class=\"btn\">\n          Crear empleado\n        </ion-button>\n          </div>\n          <div >\n            <ion-button (click)=\"goToNext()\" expand=\"block\" class=\"btn\">\n              Continuar\n            </ion-button>\n          </div>\n        </div>\n      </div>\n  </ion-footer>\n";

/***/ }),

/***/ 46730:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button *ngIf=\"backButton\" slot=\"start\" text=\"\" defaultHref=\"tabs/profile\" color=\"dark\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title *ngIf=\"titleCase\">{{titlePage | translateDays | titlecase}}</ion-title>\n    <ion-title *ngIf=\"!titleCase\">{{titlePage | translateDays }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_wizard_employee_employee_module_ts.js.map