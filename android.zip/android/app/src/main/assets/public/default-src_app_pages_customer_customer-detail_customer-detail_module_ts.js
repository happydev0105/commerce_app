"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_customer_customer-detail_customer-detail_module_ts"],{

/***/ 47297:
/*!********************************************************!*\
  !*** ./src/app/core/models/customer/customer.model.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Customer": () => (/* binding */ Customer)
/* harmony export */ });
class Customer {
}


/***/ }),

/***/ 6783:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/customer/customer-detail/customer-detail-routing.module.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerDetailPageRoutingModule": () => (/* binding */ CustomerDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _customer_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-detail.page */ 29579);




const routes = [
    {
        path: '',
        component: _customer_detail_page__WEBPACK_IMPORTED_MODULE_0__.CustomerDetailPage
    },
];
let CustomerDetailPageRoutingModule = class CustomerDetailPageRoutingModule {
};
CustomerDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CustomerDetailPageRoutingModule);



/***/ }),

/***/ 71547:
/*!**************************************************************************!*\
  !*** ./src/app/pages/customer/customer-detail/customer-detail.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerDetailPageModule": () => (/* binding */ CustomerDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/alert/alert.module */ 92563);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _customer_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customer-detail-routing.module */ 6783);
/* harmony import */ var _customer_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./customer-detail.page */ 29579);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);
/* harmony import */ var src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/format-hour/format-hour.module */ 94623);
/* harmony import */ var src_app_shared_pipes_booking_status_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/pipes/booking-status.pipe */ 4218);












let CustomerDetailPageModule = class CustomerDetailPageModule {
};
CustomerDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _customer_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__.CustomerDetailPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.ReactiveFormsModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            _shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__.AlertModule,
            ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_11__.IonIntlTelInputModule,
            src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_4__.FormatHourModule
        ],
        declarations: [_customer_detail_page__WEBPACK_IMPORTED_MODULE_3__.CustomerDetailPage, src_app_shared_pipes_booking_status_pipe__WEBPACK_IMPORTED_MODULE_5__.BookingStatusPipe]
    })
], CustomerDetailPageModule);



/***/ }),

/***/ 29579:
/*!************************************************************************!*\
  !*** ./src/app/pages/customer/customer-detail/customer-detail.page.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerDetailPage": () => (/* binding */ CustomerDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _customer_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-detail.page.html?ngResource */ 99807);
/* harmony import */ var _customer_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-detail.page.scss?ngResource */ 79257);
/* harmony import */ var _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/utils/utils.service */ 73372);
/* harmony import */ var src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/customer/customer.service */ 20161);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _core_models_customer_customer_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../core/models/customer/customer.model */ 47297);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);
/* harmony import */ var src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/booking/booking.service */ 70065);













let CustomerDetailPage = class CustomerDetailPage {
    constructor(router, actionSheetCtrl, formBuilder, customerService, utilsService, activatedRoute, navCtrl, bookingService) {
        this.router = router;
        this.actionSheetCtrl = actionSheetCtrl;
        this.formBuilder = formBuilder;
        this.customerService = customerService;
        this.utilsService = utilsService;
        this.activatedRoute = activatedRoute;
        this.navCtrl = navCtrl;
        this.bookingService = bookingService;
        this.isEdit = false;
        this.title = 'Crear cliente';
        this.defaultImage = '/assets/no-image.jpeg';
        this.customerBookings = [];
        this.phone = {
            dialCode: '+34',
            internationalNumber: '',
            isoCode: 'es',
            nationalNumber: ''
        };
        this.formValue = { phoneNumber: this.phone };
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForms();
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.customer) {
                this.customer = this.router.getCurrentNavigation().extras.state.customer;
                this.title = 'Ficha de cliente';
                this.isEdit = true;
                this.setCustomerValue();
                this.getCustomerBookings(this.commerceLogged, this.customer.uuid);
            }
            if (this.router.getCurrentNavigation().extras.state.isNewPayment) {
                this.isNewPayment = this.router.getCurrentNavigation().extras.state.isNewPayment;
                this.title = 'Crear cliente';
            }
            if (this.router.getCurrentNavigation().extras.state.isNewBooking) {
                this.isNewBooking = this.router.getCurrentNavigation().extras.state.isNewBooking;
                this.title = 'Crear cliente';
            }
        }
        else {
            this.title = 'Crear cliente';
        }
    }
    get phoneNumber() { return this.customerForm.get('phone'); }
    ngOnInit() { }
    initForms() {
        this.customerForm = this.formBuilder.group({
            name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
            lastname: [''],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.email]],
            phone: [this.formValue.phoneNumber,
                [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required,
                    ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_8__.IonIntlTelInputValidators.phone]
            ],
            photo: [''],
        });
    }
    setCustomerValue() {
        const customerPhone = {
            dialCode: '+34',
            internationalNumber: '',
            isoCode: 'es',
            nationalNumber: this.customer.phone
        };
        this.phoneNumber.setValue(customerPhone);
        this.customerForm.get('name').setValue(this.customer.name);
        this.customerForm.get('lastname').setValue(this.customer.lastname);
        this.customerForm.get('email').setValue(this.customer.email);
        this.customerForm.get('photo').setValue(this.customer.photoURL);
    }
    getImage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            const buttons = [
                {
                    text: 'Hacer foto',
                    icon: 'camera',
                    handler: () => { },
                },
                {
                    text: 'Galería',
                    icon: 'image',
                    handler: () => { },
                },
                {
                    text: 'Cancelar',
                    icon: 'close',
                    role: 'destructive',
                    handler: () => { },
                },
            ];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: 'Seleccionar avatar',
                buttons,
            });
            yield actionSheet.present();
        });
    }
    saveCustomer() {
        console.log(this.customerForm);
        const customer = this.createCustomerModel();
        if (this.isEdit) {
            this.customerService.updateCustomer(customer).subscribe((response) => {
                if (response) {
                    this.cancel();
                }
            });
        }
        else {
            this.customerService.saveCustomer(customer).subscribe((response) => {
                if (response) {
                    this.cancel(response);
                }
            });
        }
    }
    createCustomerModel() {
        const customer = new _core_models_customer_customer_model__WEBPACK_IMPORTED_MODULE_4__.Customer();
        if (this.isEdit) {
            customer.uuid = this.customer.uuid;
        }
        customer.name = this.customerForm.get('name').value;
        customer.lastname = this.customerForm.get('lastname').value;
        customer.email = this.customerForm.get('email').value;
        customer.phone = this.customerForm.get('phone').value.nationalNumber;
        customer.password = this.utilsService.generateRandomPassword();
        customer.photoURL = this.customerForm.get('photo').value;
        customer.commerce = this.commerceLogged;
        customer.createdBy = this.commerceLogged;
        return customer;
    }
    getCustomerBookings(commerceUuid, customerUuid) {
        this.bookingService.findBookingsByCommerceAndCustomer(commerceUuid, customerUuid)
            .subscribe((bookings) => {
            this.customerBookings = [...bookings];
        });
    }
    goToBookingDetail(booking) {
        const navigationExtras = {
            relativeTo: this.activatedRoute,
            state: { booking, isFromCustomerPage: true }
        };
        this.navCtrl.navigateForward([`booking/${booking.uuid}`], navigationExtras);
    }
    onFocus(event) {
        event.target.parentElement.classList.add('fill-input');
    }
    onBlur(event) {
        // Si tiene contenido el input no se la quitamos
        if (!event.target.value) {
            event.target.parentElement.classList.remove('fill-input');
        }
    }
    cancel(customer) {
        console.log('isnewbooking', this.isNewBooking);
        if (this.isNewBooking) {
            const navExtra = {
                queryParams: { newCustomer: JSON.stringify(customer) },
                state: { newCustomer: customer },
            };
            this.navCtrl.navigateBack('tabs/home/new-booking', navExtra);
        }
        else if (this.isNewPayment) {
            const navExtra = {
                queryParams: { newCustomer: JSON.stringify(customer) },
                state: { newCustomer: customer },
            };
            this.navCtrl.navigateBack('tabs/payments', navExtra);
        }
        else {
            this.navCtrl.back();
        }
    }
};
CustomerDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ActionSheetController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__.CustomerService },
    { type: _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__.UtilsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_6__.BookingService }
];
CustomerDetailPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_5__.AlertComponent,] }]
};
CustomerDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-customer-detail',
        template: _customer_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customer_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomerDetailPage);



/***/ }),

/***/ 4218:
/*!*****************************************************!*\
  !*** ./src/app/shared/pipes/booking-status.pipe.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingStatusPipe": () => (/* binding */ BookingStatusPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let BookingStatusPipe = class BookingStatusPipe {
    transform(value) {
        value = value.toLowerCase();
        let returnValue = '';
        if (value === 'pending') {
            return returnValue = 'pendiente';
        }
        return value;
    }
};
BookingStatusPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'bookingStatus'
    })
], BookingStatusPipe);



/***/ }),

/***/ 79257:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-detail/customer-detail.page.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = ".edit_profile_main_content {\n  padding: 16px;\n}\n.edit_profile_main_content .user_image {\n  height: 100px;\n  width: 100px;\n  border-radius: 50%;\n  margin: auto;\n  margin-top: 5%;\n  border: 1px solid lightgray;\n}\n.edit_profile_main_content .user_image img {\n  border-radius: 50%;\n  height: 98px;\n  width: 100px;\n}\nion-button {\n  margin: 2%;\n}\nion-label {\n  padding: 0;\n  margin: 0;\n}\n.last-item {\n  padding-bottom: 10px;\n}\n.column-date {\n  margin-top: 2rem;\n  margin-left: 1rem;\n  width: 100%;\n}\nh2, h3 {\n  margin: 0;\n}\nion-badge {\n  margin-bottom: 5px;\n}\n.badge-orange-300 {\n  --background: rgba(251,211,141,1);\n}\n.badge-yellow-300 {\n  --background: rgba(250,240,137,1);\n}\n.badge-red-300 {\n  --background: rgba(254,178,178,1);\n}\n.badge-green-300 {\n  --background: rgba(154,230,180,1);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWVyLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FBQ0o7QUFBSTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFFTjtBQUdBO0VBQ0UsVUFBQTtBQUFGO0FBRUE7RUFDRSxVQUFBO0VBQ0EsU0FBQTtBQUNGO0FBRUE7RUFDRSxvQkFBQTtBQUNGO0FBRUE7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQUNGO0FBRUE7RUFDRSxTQUFBO0FBQ0Y7QUFFQTtFQUNHLGtCQUFBO0FBQ0g7QUFFQTtFQUNFLGlDQUFBO0FBQ0Y7QUFFQTtFQUNFLGlDQUFBO0FBQ0Y7QUFFQTtFQUNFLGlDQUFBO0FBQ0Y7QUFFQTtFQUNFLGlDQUFBO0FBQ0YiLCJmaWxlIjoiY3VzdG9tZXItZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lZGl0X3Byb2ZpbGVfbWFpbl9jb250ZW50IHtcbiAgcGFkZGluZzogMTZweDtcblxuICAudXNlcl9pbWFnZSB7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgaW1nIHtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGhlaWdodDogOThweDtcbiAgICAgIHdpZHRoOiAxMDBweDtcbiAgICB9XG4gIH1cbn1cblxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMiU7XG59XG5pb24tbGFiZWwge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG59XG5cbi5sYXN0LWl0ZW0ge1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuLmNvbHVtbi1kYXRlIHtcbiAgbWFyZ2luLXRvcDogMnJlbTtcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XG4gIHdpZHRoOiAxMDAlO1xufVxuXG5oMixoMyB7XG4gIG1hcmdpbjogMDtcbn1cblxuaW9uLWJhZGdlIHtcbiAgIG1hcmdpbi1ib3R0b206IDVweDtcbn1cblxuLmJhZGdlLW9yYW5nZS0zMDAge1xuICAtLWJhY2tncm91bmQ6IHJnYmEoMjUxLDIxMSwxNDEsMSk7XG59XG5cbi5iYWRnZS15ZWxsb3ctMzAwIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDI1MCwyNDAsMTM3LDEpO1xufVxuXG4uYmFkZ2UtcmVkLTMwMCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgyNTQsMTc4LDE3OCwxKTtcbn1cblxuLmJhZGdlLWdyZWVuLTMwMCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSgxNTQsMjMwLDE4MCwxKTtcbn1cbiJdfQ== */";

/***/ }),

/***/ 99807:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-detail/customer-detail.page.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"title\" [titleCase]=\"false\"></app-header>\n<ion-content>\n  <form [formGroup]=\"customerForm\">\n    <div class=\"edit_profile_main_content\">\n      <div class=\"user_image bg_image\" (click)=\"getImage()\">\n        <img [src]=\"customer?.photoURL || defaultImage\" />\n      </div>\n\n      <ion-item class=\"textbox\" [ngClass]=\"customerForm.controls['name'].value ? 'fill-input' : ''\">\n        <ion-label>Nombre</ion-label>\n        <ion-input class=\"ion-text-right\"  formControlName=\"name\" autocapitalize=\"true\" (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\" type=\"text\" [readonly]=\"customer?.name\" [value]=\"customer?.name\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"customerForm.controls['lastname'].value ? 'fill-input' : ''\">\n        <ion-label>Apellidos</ion-label>\n        <ion-input class=\"ion-text-right\"  formControlName=\"lastname\" autocapitalize=\"true\" (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\" type=\"text\" [readonly]=\"customer?.lastname\" [value]=\"customer?.lastname\">\n        </ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"customerForm.controls['email'].value ? 'fill-input' : ''\">\n        <ion-label>Email</ion-label>\n        <ion-input class=\"ion-text-right\" formControlName=\"email\" (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\" type=\"email\"  [value]=\"customer?.email\" inputmode=\"email\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"customerForm.controls['phone'].value ? 'fill-input' : ''\">\n        <ion-label>Teléfono</ion-label>\n\n        <ion-intl-tel-input class=\"ion-text-right absolute right-[7px] float-right w-1/2 \"\n          [enableAutoCountrySelect]=\"true\" [defaultCountryiso]=\"'es'\" [preferredCountries]=\"['es']\"\n          [modalSearchPlaceholder]=\"'Buscar...'\" [modalCloseText]=\"'Cerrar'\" formControlName=\"phone\"\n          [inputPlaceholder]=\"'600 123 456'\" modalTitle=\"Seleccione país\">\n        </ion-intl-tel-input>\n      </ion-item>\n      <div class=\"px-4\" *ngIf=\"phoneNumber.invalid && phoneNumber.touched\">\n        <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.required\">\n          <p class=\"ion-no-margin\"><sub>El teléfono es requerido</sub></p>\n        </ion-text>\n        <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.phone\">\n          <p class=\"ion-no-margin\"><sub>El teléfono no es válido.</sub></p>\n        </ion-text>\n      </div>\n\n    </div>\n  </form>\n  <div *ngIf=\"isEdit\">\n    <div class=\"px-8\">\n      <p>Historial </p>\n    </div>\n    <ng-container *ngIf=\"customerBookings.length > 0; else noData\">\n      <ion-item *ngFor=\"let booking of customerBookings\" class=\"textbox \" button=\"true\">\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"7\">\n              <ion-badge [ngClass]=\"[\n                booking.status === 'Pendiente' ? 'badge-orange-300' : '',\n                booking.status === 'Pending' ? 'badge-orange-300' : '',\n                booking.status === 'Pendiente de pago' ? 'badge-yellow-300' : '',\n                booking.status === 'Realizada' ? 'badge-green-300' : '',\n                booking.status === 'No asistida' ? 'badge-red-300' : '' ]\">{{booking.status | bookingStatus | uppercase}}\n              </ion-badge>\n              <p class=\"text-sm m-0\">{{booking.service[0].name}} ({{booking.service[0].defaultDuration}}) min</p>\n              <hr>\n              <ion-label class=\"ion-text-wrap\">\n                <p class=\"text-sm\">{{booking.asignedTo.name}} {{booking.asignedTo.surname}}</p>\n              </ion-label>\n            </ion-col>\n            <ion-col size=\"5\" class=\"grid grid-cols-1 content-center text-end\" style=\"border-left: 1px solid #f4f4f4;\">\n\n              <ion-label class=\"text-sm\">{{booking.startsDay | date: 'MMMM':'':'es' | titlecase}}\n                <span class=\"text-sm ion-text-center font-bold\"> {{booking.startsDay | date: 'dd'}}</span>\n              </ion-label>\n              <ion-label class=\"text-sm\">{{booking.startsHour | formatHour}}:{{booking.startsMinute | formatHour}}\n              </ion-label>\n\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-item>\n    </ng-container>\n    <ng-template #noData>\n      <div class=\"p-4\">\n        No hay reservas\n      </div>\n\n    </ng-template>\n  </div>\n\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n\n      <ion-col>\n        <ion-button class=\"btn\" [disabled]=\"!customerForm.valid\" (click)=\"saveCustomer()\" expand=\"block\">\n          Guardar\n        </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_customer_customer-detail_customer-detail_module_ts.js.map