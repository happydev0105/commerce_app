"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_payments_payment-detail_payment-detail_module_ts"],{

/***/ 36032:
/*!********************************************************************************!*\
  !*** ./src/app/pages/payments/payment-detail/payment-detail-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetailPageRoutingModule": () => (/* binding */ PaymentDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _payment_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-detail.page */ 30802);




const routes = [
    {
        path: '',
        component: _payment_detail_page__WEBPACK_IMPORTED_MODULE_0__.PaymentDetailPage
    }
];
let PaymentDetailPageRoutingModule = class PaymentDetailPageRoutingModule {
};
PaymentDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentDetailPageRoutingModule);



/***/ }),

/***/ 95580:
/*!************************************************************************!*\
  !*** ./src/app/pages/payments/payment-detail/payment-detail.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetailPageModule": () => (/* binding */ PaymentDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _payment_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-detail-routing.module */ 36032);
/* harmony import */ var _payment_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-detail.page */ 30802);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);









let PaymentDetailPageModule = class PaymentDetailPageModule {
};
PaymentDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _payment_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.PaymentDetailPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__.HeaderModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_3__.FormatPriceModule
        ],
        declarations: [_payment_detail_page__WEBPACK_IMPORTED_MODULE_1__.PaymentDetailPage]
    })
], PaymentDetailPageModule);



/***/ }),

/***/ 30802:
/*!**********************************************************************!*\
  !*** ./src/app/pages/payments/payment-detail/payment-detail.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetailPage": () => (/* binding */ PaymentDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _payment_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-detail.page.html?ngResource */ 61949);
/* harmony import */ var _payment_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-detail.page.scss?ngResource */ 10373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/payments/payments.service */ 29474);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_services_toast_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/toast/toast.service */ 66791);








let PaymentDetailPage = class PaymentDetailPage {
    constructor(activatedRoute, paymentsService, alertCtrl, toastService, navCtrl) {
        this.activatedRoute = activatedRoute;
        this.paymentsService = paymentsService;
        this.alertCtrl = alertCtrl;
        this.toastService = toastService;
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        this.getIdParam();
    }
    getIdParam() {
        this.activatedRoute.params.subscribe((param) => {
            this.paymentId = param.id;
            this.getPaymentById();
        });
    }
    getPaymentById() {
        this.paymentsService.getPaymentById(this.paymentId).subscribe(response => {
            if (response) {
                this.paymentData = response;
                if (!this.paymentData.customer.photoURL) {
                    let initials = this.paymentData.customer.name.slice(0, 2);
                    if (this.paymentData.customer.lastname) {
                        initials = `${this.paymentData.customer.name.slice(0, 1)}${this.paymentData.customer.lastname.slice(0, 1)}`;
                    }
                    this.paymentData.customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            }
        });
    }
    deletePayment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: '¿Desea eliminar el cobro?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: () => { },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.paymentsService.deletePayment(this.paymentData.uuid).subscribe(response => {
                                if (response) {
                                    this.toastService.presentToast('Cobro eliminado correctamente', true);
                                    this.navCtrl.back();
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    goToDetail(customerSelected) {
        const navigationExtras = {
            state: { customer: customerSelected }
        };
        this.navCtrl.navigateForward(['tabs/customers/customer-detail'], navigationExtras);
    }
    cancel() {
        this.navCtrl.back();
    }
};
PaymentDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_2__.PaymentsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: src_app_core_services_toast_toast_service__WEBPACK_IMPORTED_MODULE_3__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
PaymentDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-payment-detail',
        template: _payment_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payment_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentDetailPage);



/***/ }),

/***/ 10373:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/payments/payment-detail/payment-detail.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.customer-card {\n  padding: 0;\n  max-height: 93.5px;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  display: block;\n  margin-top: 15%;\n  margin-left: 5%;\n}\n.service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\nimg {\n  width: 100%;\n}\n.color-pending {\n  background-color: orange;\n  width: 100%;\n  height: 30vh;\n  margin-top: 0px;\n  position: absolute;\n}\n.color-status {\n  width: 100%;\n  height: 30vh;\n  position: absolute;\n}\n.status {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  margin-top: 45px;\n}\n.status .status-info {\n  font-size: 25px;\n  font-weight: bold;\n}\n.main-content .card {\n  background-color: white;\n  z-index: 9999;\n  position: absolute;\n  top: 100px;\n  width: 100%;\n  border-radius: 30px;\n  padding: 0px 10px;\n}\n.main-content .card .title {\n  display: flex;\n  justify-content: center;\n  font-size: 18px;\n  color: var(--ion-color-primary);\n  margin-top: 3rem;\n}\n.main-content .card .logo {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  margin-top: 20px;\n}\n.main-content .card .logo .logo-name {\n  font-size: 16px;\n  font-weight: bold;\n}\n.main-content .card .logo .logo-info {\n  font-size: 35px;\n  font-weight: bold;\n}\n.main-content .card .text {\n  font-size: 15px;\n  text-align: center;\n  display: flex;\n  justify-content: center;\n  margin-bottom: 20px;\n  color: gray;\n  padding: 10px 20px 0px 20px;\n}\n.main-content .card .textbox {\n  border: 2px solid var(--ion-color-light);\n  border-radius: 15px;\n  font-size: 16px;\n  margin: 10px 14px;\n}\n.main-content .card .textbox ion-input {\n  margin: 2px 0px;\n}\n.main-content .card .textbox ion-label {\n  font-size: 22px;\n  color: var(--ion-color-medium);\n  padding: 0px 10px;\n}\n.main-content .card .textbox img {\n  border-radius: 50%;\n  width: 30px;\n  height: 30px;\n}\n.main-content .card .btn {\n  margin: 15px 14px;\n}\n.main-content .card .login-heading {\n  font-size: 14px;\n  display: flex;\n  justify-content: center;\n  padding: 15px 0px;\n}\n.main-content .card .btn-row ion-row .btn-login {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border: 2px solid var(--ion-color-light);\n  border-radius: 15px;\n  font-size: 16px;\n  font-weight: 600;\n  margin: 10px 0px;\n  padding: 10px 0px;\n}\n.main-content .card .btn-row ion-row .btn-login ion-label {\n  margin: 2px 10px;\n}\n.main-content .card .btn-row ion-row .btn-login img {\n  border-radius: 50%;\n  width: 30px;\n  height: 30px;\n}\n.main-content .card .footer {\n  font-size: 14px;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  align-items: center;\n  padding: 15px 0px;\n  color: var(--ion-color-medium);\n}\n.align-end {\n  text-align: end;\n}\n.editBtn {\n  position: absolute;\n  top: 35px;\n  right: 15px;\n}\n.backBtn {\n  position: absolute;\n  top: 35px;\n  left: 15px;\n  color: #fff;\n}\n.employee-label {\n  font-family: \"product\" !important;\n  font-size: 14px !important;\n  color: #666666 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnQtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUFBaEI7Ozs7Ozs7Q0FBQTtBQVFBO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0FBRUY7QUFERTtFQUNFLG1CQUFBO0FBR0o7QUFESTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFHTjtBQUFJO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUVOO0FBQ0k7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFDTjtBQUdBO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0FBQUY7QUFFRTtFQUNFLG1CQUFBO0FBQUo7QUFFSTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFBTjtBQUdJO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUROO0FBSUk7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUZOO0FBTUE7RUFDRSxXQUFBO0FBSEY7QUFLQTtFQUNFLHdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFGRjtBQUlBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQURGO0FBR0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFBRjtBQUVFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQUo7QUFJRTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBREo7QUFFSTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFFQSwrQkFBQTtFQUNBLGdCQUFBO0FBRE47QUFHSTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQUROO0FBR007RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFEUjtBQUdNO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBRFI7QUFLSTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUVBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0FBSk47QUFPSTtFQUNFLHdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBRUEsaUJBQUE7QUFOTjtBQU9NO0VBQ0UsZUFBQTtBQUxSO0FBT007RUFDRSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSxpQkFBQTtBQUxSO0FBT007RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBTFI7QUFRSTtFQUNFLGlCQUFBO0FBTk47QUFTSTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtBQVBOO0FBWVE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLHdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBVlY7QUFXVTtFQUNFLGdCQUFBO0FBVFo7QUFXVTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFUWjtBQWNJO0VBQ0UsZUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0FBWk47QUFnQkE7RUFDRSxlQUFBO0FBYkY7QUFnQkE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0FBYkY7QUFnQkE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQWJGO0FBZ0JBO0VBQ0UsaUNBQUE7RUFDQSwwQkFBQTtFQUNBLHlCQUFBO0FBYkYiLCJmaWxlIjoicGF5bWVudC1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcbiAgV2Vic2l0ZSA6IGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9cbiAgQXBwIE5hbWUgOiBpb25pYzZUZW1wbGF0ZSBQYWNrXG4gIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcbiAgdGVybXMgZm91bmQgaW4gdGhlIFdlYnNpdGUgaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL2xpY2Vuc2VcbiAgQ29weXJpZ2h0IGFuZCBHb29kIEZhaXRoIFB1cmNoYXNlcnMgwqkgMjAyMS1wcmVzZW50IGJ1bmNoZGV2ZWxvcGVycy5cbiovXG4uY3VzdG9tZXItY2FyZCB7XG4gIHBhZGRpbmc6IDA7XG4gIG1heC1oZWlnaHQ6IDkzLjVweDtcbiAgLmN1c3RvbWVyLXJvdyB7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcblxuICAgIC5jdXN0b21lci1pbWFnZSB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjI4LCAyMjgsIDIyOCk7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgIC5pY29uLWNvbnRhaW5lciB7XG4gICAgICBtYXJnaW4tdG9wOiAxOTAlO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIH1cblxuICAgIC5jdXN0b21lci1sYWJlbCB7XG4gICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgIG1hcmdpbi10b3A6IDE1JTtcbiAgICAgIG1hcmdpbi1sZWZ0OiA1JTtcbiAgICB9XG4gIH1cbn1cbi5zZXJ2aWNlLWNhcmQge1xuICBwYWRkaW5nOiAwO1xuICBtYXgtaGVpZ2h0OiA0My41cHg7XG5cbiAgLnNlcnZpY2Utcm93IHtcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuXG4gICAgLnNlcnZpY2UtaW1hZ2Uge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOCwgMjI4LCAyMjgpO1xuICAgICAgcGFkZGluZzogMDtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG5cbiAgICAuaWNvbi1jb250YWluZXIge1xuICAgICAgbWFyZ2luLXRvcDogMTkwJTtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG5cbiAgICAuc2VydmljZS1sYWJlbCB7XG4gICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgIG1hcmdpbi10b3A6IDMlO1xuICAgICAgbWFyZ2luLWxlZnQ6IDUlO1xuICAgICAgbWFyZ2luLWJvdHRvbTogMyU7XG4gICAgfVxuICB9XG59XG5pbWcge1xuICB3aWR0aDogMTAwJTtcbn1cbi5jb2xvci1wZW5kaW5nIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAzMHZoO1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cbi5jb2xvci1zdGF0dXMge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAzMHZoO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG4uc3RhdHVzIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi10b3A6IDQ1cHg7XG5cbiAgLnN0YXR1cy1pbmZvIHtcbiAgICBmb250LXNpemU6IDI1cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cbn1cbi5tYWluLWNvbnRlbnQge1xuICAuY2FyZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgei1pbmRleDogOTk5OTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAxMDBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAgIHBhZGRpbmc6IDBweCAxMHB4O1xuICAgIC50aXRsZSB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG5cbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICBtYXJnaW4tdG9wOiAzcmVtO1xuICAgIH1cbiAgICAubG9nbyB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG5cbiAgICAgIC5sb2dvLW5hbWUge1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgfVxuICAgICAgLmxvZ28taW5mbyB7XG4gICAgICAgIGZvbnQtc2l6ZTogMzVweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnRleHQge1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgICAgY29sb3I6IGdyYXk7XG4gICAgICBwYWRkaW5nOiAxMHB4IDIwcHggMHB4IDIwcHg7XG4gICAgfVxuXG4gICAgLnRleHRib3gge1xuICAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG5cbiAgICAgIG1hcmdpbjogMTBweCAxNHB4O1xuICAgICAgaW9uLWlucHV0IHtcbiAgICAgICAgbWFyZ2luOiAycHggMHB4O1xuICAgICAgfVxuICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgICAgIHBhZGRpbmc6IDBweCAxMHB4O1xuICAgICAgfVxuICAgICAgaW1nIHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgfVxuICAgIH1cbiAgICAuYnRuIHtcbiAgICAgIG1hcmdpbjogMTVweCAxNHB4O1xuICAgIH1cblxuICAgIC5sb2dpbi1oZWFkaW5nIHtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIHBhZGRpbmc6IDE1cHggMHB4O1xuICAgIH1cblxuICAgIC5idG4tcm93IHtcbiAgICAgIGlvbi1yb3cge1xuICAgICAgICAuYnRuLWxvZ2luIHtcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgIG1hcmdpbjogMTBweCAwcHg7XG4gICAgICAgICAgcGFkZGluZzogMTBweCAwcHg7XG4gICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIG1hcmdpbjogMnB4IDEwcHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgLmZvb3RlciB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgIHBhZGRpbmc6IDE1cHggMHB4O1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICAgIH1cbiAgfVxufVxuLmFsaWduLWVuZCB7XG4gIHRleHQtYWxpZ246IGVuZDtcbn1cblxuLmVkaXRCdG4ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzVweDtcbiAgcmlnaHQ6IDE1cHg7XG59XG5cbi5iYWNrQnRuIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDM1cHg7XG4gIGxlZnQ6IDE1cHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uZW1wbG95ZWUtbGFiZWwge1xuICBmb250LWZhbWlseTogXCJwcm9kdWN0XCIgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjNjY2NjY2ICFpbXBvcnRhbnQ7XG59XG4iXX0= */";

/***/ }),

/***/ 61949:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/payments/payment-detail/payment-detail.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content *ngIf=\"paymentData\">\n  <div class=\"color-status bg-green-300\">\n    <div class=\"backBtn\">\n      <ion-icon name=\"arrow-back\" size=\"large\" (click)=\"cancel()\">\n      </ion-icon>\n    </div>\n    <div class=\"status\">\n      <ion-label class=\"status-info\">Pago realizado</ion-label>\n    </div>\n  </div>\n  <div class=\"main-content\">\n    <div class=\"card\">\n      <div class=\"logo\">\n        <ion-item class=\"textbox\" lines=\"none\">\n          {{paymentData.createdAt | date: 'HH:mm | dd MMM yyyy'}}\n          <!-- <ion-label>|</ion-label>\n          {{paymentData.startsDay | date}} -->\n        </ion-item>\n      </div>\n      <ion-card (click)=\"goToDetail(paymentData?.customer)\" button=\"true\">\n        <ion-grid class=\"customer-card\">\n          <ion-row class=\"customer-row\">\n            <ion-col class=\"customer-image\" size=\"3\">\n              <img [src]=\"paymentData?.customer?.photoURL\" />\n            </ion-col>\n            <ion-col size=\"8\">\n              <ion-label class=\"customer-label\">{{paymentData.customer?.name +'\n                '+paymentData.customer?.lastname}}\n              </ion-label>\n            </ion-col>\n            <ion-col size=\"1\">\n              <div class=\"icon-container\">\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n              </div>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>\n\n      <ng-container *ngFor=\"let service of paymentData.service\">\n        <ion-card button=\"true\">\n          <ion-grid class=\"service-card\">\n            <ion-row class=\"service-row\">\n              <ion-col size=\"0.1\" [style.background-color]=\"service?.color\"></ion-col>\n              <ion-col size=\"11\">\n                <ion-label class=\"service-label\">\n                  {{service.name}} · {{service.price | formatPrice}}\n                </ion-label>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n      </ng-container>\n\n      <ng-container *ngFor=\"let product of paymentData.product\">\n        <ion-card button=\"true\">\n          <ion-grid class=\"service-card\">\n            <ion-row class=\"service-row\">\n              <ion-col size=\"0.1\" style=\"background-color: #000;\"></ion-col>\n              <ion-col size=\"11\">\n                <ion-label class=\"service-label\">\n                  {{product.name}} · {{product.price | formatPrice}}\n                </ion-label>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n      </ng-container>\n\n      <ng-container *ngIf=\"paymentData.employee\">\n        <ion-item class=\"textbox\">\n          <ion-avatar slot=\"start\">\n            <img [src]=\"paymentData.employee.image\" />\n          </ion-avatar>\n          <ion-label class=\"employee-label\">{{paymentData.employee.name}} {{paymentData.employee.surname}}</ion-label>\n        </ion-item>\n      </ng-container>\n\n      <ng-container *ngIf=\"paymentData.method\">\n        <ion-card button=\"true\">\n          <ion-grid class=\"service-card\">\n            <ion-row class=\"service-row p-1\" style=\"align-items: baseline\">\n              <ion-col size=\"5\">\n                <ion-label class=\"service-label\">Método de pago:\n                </ion-label>\n              </ion-col>\n              <ion-col size=\"7\">\n                <ion-label class=\"service-label ion-text-right pr-1\">\n                  {{paymentData.method['label']}}\n                </ion-label>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n      </ng-container>\n    </div>\n  </div>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\" *ngIf=\"paymentData\">\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-end padding-right\">\n      <ion-col>\n        <ion-item>\n          <ion-label>\n            <h3>Total: {{(paymentData.amount + (paymentData.decimals / 100))| formatPrice}} </h3>\n          </ion-label>\n        </ion-item>\n      </ion-col>\n      <ion-col>\n        <ion-button class=\"btn\" expand=\"block\" color=\"danger\" (click)=\"deletePayment()\">\n          Eliminar cobro\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_payments_payment-detail_payment-detail_module_ts.js.map