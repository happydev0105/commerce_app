"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_subscription_subscription_module_ts"],{

/***/ 43197:
/*!********************************************************************!*\
  !*** ./src/app/core/services/subscription/subscription.service.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubscriptionService": () => (/* binding */ SubscriptionService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);




let SubscriptionService = class SubscriptionService {
    constructor(http) {
        this.http = http;
        this.API_URL = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    getByCommerce(commerceId) {
        return this.http.get(`${this.API_URL}/subscription/commerce/${commerceId}`);
    }
    updateSubscription(subscription) {
        return this.http.post(`${this.API_URL}/subscription`, subscription);
    }
};
SubscriptionService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
SubscriptionService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], SubscriptionService);



/***/ }),

/***/ 13537:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/subscription/subscription-routing.module.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubscriptionPageRoutingModule": () => (/* binding */ SubscriptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _subscription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subscription.page */ 38087);




const routes = [
    {
        path: '',
        component: _subscription_page__WEBPACK_IMPORTED_MODULE_0__.SubscriptionPage
    }
];
let SubscriptionPageRoutingModule = class SubscriptionPageRoutingModule {
};
SubscriptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SubscriptionPageRoutingModule);



/***/ }),

/***/ 68916:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/subscription/subscription.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubscriptionPageModule": () => (/* binding */ SubscriptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _subscription_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subscription-routing.module */ 13537);
/* harmony import */ var _subscription_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./subscription.page */ 38087);
/* harmony import */ var src_app_shared_pipes_change_char_for_asterisk_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/pipes/change-char-for-asterisk.pipe */ 37927);









let SubscriptionPageModule = class SubscriptionPageModule {
};
SubscriptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _subscription_routing_module__WEBPACK_IMPORTED_MODULE_1__.SubscriptionPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule
        ],
        declarations: [_subscription_page__WEBPACK_IMPORTED_MODULE_2__.SubscriptionPage, src_app_shared_pipes_change_char_for_asterisk_pipe__WEBPACK_IMPORTED_MODULE_3__.ChangeCharForAsteriskPipe]
    })
], SubscriptionPageModule);



/***/ }),

/***/ 38087:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/subscription/subscription.page.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubscriptionPage": () => (/* binding */ SubscriptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _subscription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subscription.page.html?ngResource */ 51283);
/* harmony import */ var _subscription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subscription.page.scss?ngResource */ 95257);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_services_subscription_subscription_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/services/subscription/subscription.service */ 43197);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);







let SubscriptionPage = class SubscriptionPage {
    constructor(subscriptionService, navCtrl, alertController, authService) {
        this.subscriptionService = subscriptionService;
        this.navCtrl = navCtrl;
        this.alertController = alertController;
        this.authService = authService;
        this.detailsSplitted = [];
        this.viewDetailText = 'Ver detalles';
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.getSubscription();
    }
    ngOnInit() { }
    getSubscription() {
        this.subscriptionService.getByCommerce(this.commerceLogged).subscribe(response => {
            if (response && response.length > 0) {
                this.subscription = response[0];
                this.detailsSplitted = this.subscription.details.split(',');
            }
        });
    }
    onChange(event) {
        !event.detail.value ? this.viewDetailText = 'Ver detalles' : this.viewDetailText = 'Ocultar detalles';
    }
    editAccountNumber() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const editAccountAlert = yield this.alertController.create({
                header: 'Editar nº de cuenta',
                inputs: [
                    {
                        name: 'numberAccount',
                        type: 'text',
                        placeholder: this.subscription.accountNumber,
                        value: this.subscription.accountNumber
                    }
                ],
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'destructive',
                    }, {
                        text: 'Aceptar',
                        handler: (data) => {
                            this.subscription.accountNumber = data.numberAccount;
                            this.subscriptionService.updateSubscription(this.subscription)
                                .subscribe(response => {
                                this.subscription = response;
                            });
                        }
                    }
                ]
            });
            yield editAccountAlert.present();
        });
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/commerce-info'], { replaceUrl: true });
    }
};
SubscriptionPage.ctorParameters = () => [
    { type: _core_services_subscription_subscription_service__WEBPACK_IMPORTED_MODULE_2__.SubscriptionService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService }
];
SubscriptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-subscription',
        template: _subscription_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_subscription_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SubscriptionPage);



/***/ }),

/***/ 37927:
/*!***************************************************************!*\
  !*** ./src/app/shared/pipes/change-char-for-asterisk.pipe.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangeCharForAsteriskPipe": () => (/* binding */ ChangeCharForAsteriskPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let ChangeCharForAsteriskPipe = class ChangeCharForAsteriskPipe {
    transform(value, charsToHide) {
        if (value) {
            let newValue = '';
            const showValue = value.substring(charsToHide); // 2222
            for (let i = 0; i < (value.length - showValue.length); i++) {
                newValue += '*';
            }
            const hideValue = newValue + showValue;
            return hideValue;
        }
        return value;
    }
};
ChangeCharForAsteriskPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'changeCharForAsterisk'
    })
], ChangeCharForAsteriskPipe);



/***/ }),

/***/ 95257:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/subscription/subscription.page.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-list-header {\n  margin-bottom: 20px;\n}\n\n.iconito {\n  height: 12px;\n  width: 12px;\n  border-radius: 50%;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n\n.active {\n  background-color: #0fc00f;\n  animation: pulse 1500ms infinite;\n}\n\n.text-active {\n  color: #0fc00f;\n}\n\n.text-inactive {\n  color: red;\n}\n\n.inactive {\n  background-color: red;\n}\n\n.view-details {\n  width: 50%;\n  margin: 0 auto;\n}\n\n@keyframes pulse {\n  0% {\n    box-shadow: #0fc00f 0 0 0 0;\n  }\n  75% {\n    box-shadow: #ff69b400 0 0 0 16px;\n  }\n}\n\n.f-right {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YnNjcmlwdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0VBQ0EsZ0NBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLFVBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxVQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0U7SUFDRSwyQkFBQTtFQUNGO0VBQ0E7SUFDRSxnQ0FBQTtFQUNGO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0FBQUYiLCJmaWxlIjoic3Vic2NyaXB0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5pY29uaXRvIHtcbiAgaGVpZ2h0OiAxMnB4O1xuICB3aWR0aDogMTJweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG4uYWN0aXZlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE1LCAxOTIsIDE1KTtcbiAgYW5pbWF0aW9uOiBwdWxzZSAxNTAwbXMgaW5maW5pdGU7XG59XG5cbi50ZXh0LWFjdGl2ZSB7XG4gIGNvbG9yOiByZ2IoMTUsIDE5MiwgMTUpO1xufVxuXG4udGV4dC1pbmFjdGl2ZSB7XG4gIGNvbG9yOiByZWQ7XG59XG5cbi5pbmFjdGl2ZSB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbn1cblxuLnZpZXctZGV0YWlscyB7XG4gIHdpZHRoOiA1MCU7XG4gIG1hcmdpbjogMCBhdXRvXG59XG5cbkBrZXlmcmFtZXMgcHVsc2Uge1xuICAwJSB7XG4gICAgYm94LXNoYWRvdzogcmdiKDE1LCAxOTIsIDE1KSAwIDAgMCAwO1xuICB9XG4gIDc1JSB7XG4gICAgYm94LXNoYWRvdzogI2ZmNjliNDAwIDAgMCAwIDE2cHg7XG4gIH1cbn1cblxuLmYtcmlnaHQge1xuICBmbG9hdDogcmlnaHQ7XG59XG4iXX0= */";

/***/ }),

/***/ 51283:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/subscription/subscription.page.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titleCase]=\"false\" [titlePage]=\"'Tu suscripción'\"></app-header>\n\n<ion-content>\n  <ion-card>\n    <ion-item>\n      <div class=\"iconito\" [ngClass]=\"{\n        'active': subscription?.isActive,\n        'active-icon': subscription?.isActive,\n        'inactive': !subscription?.isActive}\"></div>\n      <ion-label [ngClass]=\"{\n        'text-active': subscription?.isActive,\n        'text-inactive': !subscription?.isActive}\">{{subscription?.isActive ? 'Activo' : 'No activo'}}</ion-label>\n    </ion-item>\n\n    <ion-card-header>\n      <ion-card-title>{{subscription?.name}}</ion-card-title>\n      <ion-card-subtitle>Precio: {{subscription?.amount}},{{subscription?.decimals}} €/mes</ion-card-subtitle>\n    </ion-card-header>\n\n\n    <ion-card-content>\n      {{subscription?.description}}\n      <hr>\n      <ion-accordion-group (ionChange)=\"onChange($event)\" inset=\"true\" value=\"details\">\n        <ion-accordion>\n          <ion-item class=\"view-details\" slot=\"header\">\n            <ion-label class=\"no-margin\">{{viewDetailText}}</ion-label>\n          </ion-item>\n          <div slot=\"content\" *ngFor=\"let detail of detailsSplitted\">\n            <ion-list>\n              <ion-item>\n                <ion-icon slot=\"start\" name=\"checkmark-outline\"></ion-icon>\n                <ion-label class=\"service-label\">{{ detail }}</ion-label>\n              </ion-item>\n            </ion-list>\n          </div>\n        </ion-accordion>\n      </ion-accordion-group>\n    </ion-card-content>\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header> Información acerca de tu suscripción </ion-list-header>\n    <ion-item>\n      <ion-label>Fecha de inicio: <ion-note class=\"f-right\" color=\"dark\"> {{subscription?.startsAt | date: 'dd MMM yyyy'}}</ion-note>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>Fecha de finalización: <ion-note class=\"f-right\" color=\"dark\"> {{subscription?.expiresAt | date: 'dd MMM yyyy'}}\n        </ion-note>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>Nº cuenta: <ion-note class=\"f-right\" color=\"dark\">{{subscription?.accountNumber | changeCharForAsterisk:\n          subscription?.accountNumber.length - 4}}</ion-note>\n      </ion-label>\n      <ion-icon slot=\"end\" name=\"create-outline\" (click)=\"editAccountNumber()\"></ion-icon>\n    </ion-item>\n  </ion-list>\n</ion-content>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_subscription_subscription_module_ts.js.map