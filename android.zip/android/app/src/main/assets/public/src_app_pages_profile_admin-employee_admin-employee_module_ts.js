"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_admin-employee_admin-employee_module_ts"],{

/***/ 86075:
/*!************************************************************!*\
  !*** ./src/app/core/services/employee/employee.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeService": () => (/* binding */ EmployeeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let EmployeeService = class EmployeeService {
    constructor(http) {
        this.http = http;
    }
    getAllEmployee() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`);
    }
    createEmployee(employee) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    findEmployees(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce/${commerceID}`);
    }
    findEmployeesWithinactives(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-with-inactives/${commerceID}`);
    }
    findEmployeeById(employeeId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${employeeId}`);
    }
    findEmployeeByCommerceAndServices(commerce, services) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-services/${commerce}`, services);
    }
    updateEmployee(employee) {
        return this.http.patch(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    deleteEmployee(uuid) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${uuid}`);
    }
    getAllPermissions() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/permission`);
    }
};
EmployeeService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
EmployeeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], EmployeeService);



/***/ }),

/***/ 20551:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/admin-employee-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminEmployeePageRoutingModule": () => (/* binding */ AdminEmployeePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _admin_employee_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-employee.page */ 27304);




const routes = [
    {
        path: '',
        component: _admin_employee_page__WEBPACK_IMPORTED_MODULE_0__.AdminEmployeePage
    },
    {
        path: 'employee-detail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_core_transformers_timeTable_transformer_ts-src_app_core_utils_date_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_admin-employee_employee-detail_employee-detail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./employee-detail/employee-detail.module */ 1201)).then(m => m.EmployeeDetailPageModule)
    },
];
let AdminEmployeePageRoutingModule = class AdminEmployeePageRoutingModule {
};
AdminEmployeePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AdminEmployeePageRoutingModule);



/***/ }),

/***/ 17793:
/*!***********************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/admin-employee.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminEmployeePageModule": () => (/* binding */ AdminEmployeePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _admin_employee_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./admin-employee-routing.module */ 20551);
/* harmony import */ var _admin_employee_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./admin-employee.page */ 27304);









let AdminEmployeePageModule = class AdminEmployeePageModule {
};
AdminEmployeePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _admin_employee_routing_module__WEBPACK_IMPORTED_MODULE_2__.AdminEmployeePageRoutingModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_admin_employee_page__WEBPACK_IMPORTED_MODULE_3__.AdminEmployeePage]
    })
], AdminEmployeePageModule);



/***/ }),

/***/ 27304:
/*!*********************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/admin-employee.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminEmployeePage": () => (/* binding */ AdminEmployeePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _admin_employee_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-employee.page.html?ngResource */ 20351);
/* harmony import */ var _admin_employee_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-employee.page.scss?ngResource */ 6286);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/employee/employee.service */ 86075);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);






let AdminEmployeePage = class AdminEmployeePage {
    constructor(navCtrl, employeeService) {
        this.navCtrl = navCtrl;
        this.employeeService = employeeService;
        this.employeeCollection = [];
        this.employeeCollectionFiltered = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllEmployees();
    }
    getAllEmployees() {
        this.employeeService.findEmployeesWithinactives(this.commerceLogged).subscribe(response => {
            response.map(employee => {
                if (!employee.image) {
                    let initials = employee.name.slice(0, 2);
                    if (employee.surname) {
                        initials = `${employee.name.slice(0, 1)}${employee.surname.slice(0, 1)}`;
                    }
                    employee.image = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            });
            this.employeeCollection = response;
            this.employeeCollectionFiltered = this.employeeCollection;
        });
    }
    searchEmployee(event) {
        const value = event.target.value;
        this.employeeCollectionFiltered = this.employeeCollection;
        if (value.length >= 3) {
            this.employeeCollectionFiltered = this.employeeCollectionFiltered.filter(option => option.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    presentModal() { }
    goToDetail(employee) {
        const navigationExtras = { state: { employee } };
        this.navCtrl.navigateForward(['tabs/profile/commerce-info/admin-employee/employee-detail'], navigationExtras);
    }
    goToCreate() {
        this.navCtrl.navigateForward(['tabs/profile/commerce-info/admin-employee/employee-detail']);
    }
};
AdminEmployeePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__.EmployeeService }
];
AdminEmployeePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-admin-employee',
        template: _admin_employee_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_admin_employee_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AdminEmployeePage);



/***/ }),

/***/ 6286:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/admin-employee.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = ".customer-card {\n  padding: 0;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #efefef;\n  padding: 0;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  float: left;\n  position: relative;\n  top: 40%;\n  left: 20%;\n}\nion-content {\n  --background: rgb(255, 255, 255);\n}\nion-item {\n  --inner-border-width: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkbWluLWVtcGxveWVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7QUFDRjtBQUFFO0VBQ0UsbUJBQUE7QUFFSjtBQURJO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0FBR047QUFESTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFHTjtBQURJO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUFHTjtBQUVBO0VBQ0UsZ0NBQUE7QUFDRjtBQUVBO0VBQ0UseUJBQUE7QUFDRiIsImZpbGUiOiJhZG1pbi1lbXBsb3llZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tZXItY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxuICAuY3VzdG9tZXItcm93IHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICAuY3VzdG9tZXItaW1hZ2Uge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjM5LCAyMzksIDIzOSk7XHJcbiAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICB9XHJcbiAgICAuaWNvbi1jb250YWluZXIge1xyXG4gICAgICBtYXJnaW4tdG9wOiAxOTAlO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAuY3VzdG9tZXItbGFiZWwge1xyXG4gICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0b3A6IDQwJTtcclxuICAgICAgbGVmdDogMjAlO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogcmdiKDI1NSwgMjU1LCAyNTUpO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 20351:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/admin-employee.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Empleados'\"></app-header>\n\n<ion-content>\n\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\" >\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-searchbar *ngIf=\"employeeCollectionFiltered.length > 0\" (ionInput)=\"searchEmployee($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n  <ion-grid *ngIf=\"employeeCollectionFiltered.length > 0\" fixed style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray;\">\n    <ion-row>\n      <ion-col size=\"10\" style=\"border-right: 1px solid lightgray;\">\n        <ion-item>\n          <ion-label *ngIf=\"employeeCollectionFiltered.length === 1\">{{employeeCollectionFiltered.length}} EMPLEADO</ion-label>\n          <ion-label *ngIf=\"employeeCollectionFiltered.length > 1\">{{employeeCollectionFiltered.length}} EMPLEADOS</ion-label>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\">\n        <ion-item [disabled]=\"true\">\n          <ion-icon (click)=\"presentModal()\" name=\"options-outline\"></ion-icon>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-card *ngFor=\"let employee of employeeCollectionFiltered\" (click)=\"goToDetail(employee)\" button=\"true\">\n    <ion-grid class=\"customer-card\">\n      <ion-row class=\"customer-row\">\n        <ion-col class=\"customer-image\" size=\"3\">\n          <img class=\"p-4\" [src]=\"employee.image\" />\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"customer-label\">{{employee.name}} {{employee.surname}}</ion-label>\n        </ion-col>\n        <ion-col size=\"1\">\n          <div class=\"icon-container\">\n            <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n  <app-no-data *ngIf=\"employeeCollectionFiltered.length === 0\" [title]=\"'Parece que aún no tienes empleados'\"></app-no-data>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_admin-employee_admin-employee_module_ts.js.map