"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_reviews_reviews_module_ts"],{

/***/ 3398:
/*!********************************************************!*\
  !*** ./src/app/core/services/review/review.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewService": () => (/* binding */ ReviewService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ReviewService = class ReviewService {
    constructor(http) {
        this.http = http;
    }
    getReviewsByCommerce(commerce) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/review/commerce/${commerce}`);
    }
    getReviewsByBooking(booking) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/review/booking/${booking}`);
    }
    getReviewsByCustomer(customer) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/review/customer/${customer}`);
    }
    saveReview(review) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/review/`, review);
    }
    getReviewById(uuid) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/review/${uuid}`);
    }
    saveVote(vote) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}review-votes/`, vote);
    }
};
ReviewService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ReviewService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ReviewService);



/***/ }),

/***/ 24919:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/reviews/reviews-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPageRoutingModule": () => (/* binding */ ReviewsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _reviews_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviews.page */ 49180);




const routes = [
    {
        path: '',
        component: _reviews_page__WEBPACK_IMPORTED_MODULE_0__.ReviewsPage
    },
];
let ReviewsPageRoutingModule = class ReviewsPageRoutingModule {
};
ReviewsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReviewsPageRoutingModule);



/***/ }),

/***/ 34022:
/*!***********************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/reviews/reviews.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPageModule": () => (/* binding */ ReviewsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _reviews_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviews-routing.module */ 24919);
/* harmony import */ var _reviews_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reviews.page */ 49180);
/* harmony import */ var src_app_shared_components_review_card_review_card_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/review-card/review-card.module */ 77125);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/no-data/no-data.module */ 98360);










let ReviewsPageModule = class ReviewsPageModule {
};
ReviewsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _reviews_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReviewsPageRoutingModule,
            src_app_shared_components_review_card_review_card_module__WEBPACK_IMPORTED_MODULE_2__.ReviewCardModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule,
            src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_4__.NoDataModule
        ],
        declarations: [_reviews_page__WEBPACK_IMPORTED_MODULE_1__.ReviewsPage]
    })
], ReviewsPageModule);



/***/ }),

/***/ 49180:
/*!*********************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/reviews/reviews.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPage": () => (/* binding */ ReviewsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviews.page.html?ngResource */ 71941);
/* harmony import */ var _reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reviews.page.scss?ngResource */ 79438);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);
/* harmony import */ var src_app_core_services_review_review_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/review/review.service */ 3398);







let ReviewsPage = class ReviewsPage {
    constructor(reviewService, router, authService) {
        this.reviewService = reviewService;
        this.router = router;
        this.authService = authService;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getReviewsByCommerce(this.commerceLogged);
    }
    getReviewsByCommerce(customer) {
        this.reviewService.getReviewsByCommerce(customer).subscribe((res) => {
            this.reviewCollection = [...res];
        });
    }
};
ReviewsPage.ctorParameters = () => [
    { type: src_app_core_services_review_review_service__WEBPACK_IMPORTED_MODULE_3__.ReviewService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
ReviewsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-reviews',
        template: _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewEncapsulation.None,
        styles: [_reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReviewsPage);



/***/ }),

/***/ 37602:
/*!************************************************************************!*\
  !*** ./src/app/shared/components/review-card/review-card.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewCardComponent": () => (/* binding */ ReviewCardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _review_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-card.component.html?ngResource */ 65195);
/* harmony import */ var _review_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./review-card.component.scss?ngResource */ 25028);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let ReviewCardComponent = class ReviewCardComponent {
    constructor() {
        this.reportEmmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    ngOnChanges(changes) {
        if (changes.review.currentValue !== null) {
            this.calcVotes(changes.review.currentValue.vote);
        }
    }
    isOwner(customerReviewUuid, loggedUserUuid) {
        return customerReviewUuid === loggedUserUuid;
    }
    calcVotes(votes) {
        this.positiveValue = votes.filter((item) => item.type === 'positive').length;
        this.negativeValue = votes.length - this.positiveValue;
    }
    reportEmit(review) {
        this.reportEmmitter.emit(review);
    }
};
ReviewCardComponent.ctorParameters = () => [];
ReviewCardComponent.propDecorators = {
    review: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    reportEmmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
ReviewCardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-review-card',
        template: _review_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_2__.ViewEncapsulation.None,
        styles: [_review_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReviewCardComponent);



/***/ }),

/***/ 77125:
/*!*********************************************************************!*\
  !*** ./src/app/shared/components/review-card/review-card.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewCardModule": () => (/* binding */ ReviewCardModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _review_card_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./review-card.component */ 37602);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var angular_star_rating__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! angular-star-rating */ 96644);







let ReviewCardModule = class ReviewCardModule {
};
ReviewCardModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_review_card_component__WEBPACK_IMPORTED_MODULE_0__.ReviewCardComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            angular_star_rating__WEBPACK_IMPORTED_MODULE_6__.StarRatingModule
        ],
        exports: [_review_card_component__WEBPACK_IMPORTED_MODULE_0__.ReviewCardComponent],
    })
], ReviewCardModule);



/***/ }),

/***/ 79438:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/reviews/reviews.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = ".noClick {\n  pointer-events: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJldmlld3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0csb0JBQUE7QUFDSCIsImZpbGUiOiJyZXZpZXdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ub0NsaWNrIHtcclxuICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 25028:
/*!*************************************************************************************!*\
  !*** ./src/app/shared/components/review-card/review-card.component.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = ".noClick {\n  pointer-events: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJldmlldy1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0csb0JBQUE7QUFDSCIsImZpbGUiOiJyZXZpZXctY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ub0NsaWNrIHtcclxuICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 71941:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/reviews/reviews.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Mis reseñas'\" [titleCase]=\"false\"></app-header>\n\n\n<ion-content>\n  <ng-container *ngIf=\"reviewCollection?.length > 0; else noData\">\n    <section class=\"review-page\">\n      <ng-container *ngFor=\"let review of reviewCollection\">\n        <div class=\"p-4\">\n          <app-review-card [review]=\"review\"></app-review-card>\n          <hr>\n        </div>\n      </ng-container>\n    </section>\n  </ng-container>\n</ion-content>\n<ng-template #noData>\n  <app-no-data [title]=\"'No tienes ninguna reseña por el momento'\" [content]=\"false\"></app-no-data>\n</ng-template>\n";

/***/ }),

/***/ 65195:
/*!*************************************************************************************!*\
  !*** ./src/app/shared/components/review-card/review-card.component.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<section class=\" p-4 shadow-lg bg-white rounded-md\" *ngIf=\"review\">\n  <header >\n    <div class=\"grid grid-cols-12\">\n      <div class=\"col-span-6 grid\">\n        <div>\n          <star-rating class=\"noClick float-left left-0 relative\" [disabled]=\"true\" [starType]=\"'svg'\" staticColor=\"ok\" [rating]=\"review.value\"></star-rating>\n        </div>\n        <div>\n          <div class=\"text-sm \">{{review?.booking?.service[0]?.name}}</div>\n          <div class=\"text-sm \">\n            {{review?.booking?.asignedTo?.name}}\n          </div>\n        </div>\n\n      </div>\n      <div class=\"col-span-6\">\n        <p class=\"text-sm float-right\">{{review?.booking?.customer?.name | titlecase}} · {{review?.createdAt | date}}</p>\n      </div>\n    </div>\n\n  </header>\n  <div class=\"py-2 w-full\">\n    <p>{{review?.review}}</p>\n  </div>\n  <footer>\n    <div class=\"grid grid-cols-12\">\n      <div class=\"col-span-6\">\n        <div class=\"flex align-baseline\">\n          <ion-item class=\"rounded-lg border-2\">\n            <ion-button fill=\"clear\" >\n              <p>{{positiveValue}}</p>\n              <ion-icon slot=\"end\" name=\"thumbs-up\"></ion-icon>\n            </ion-button>\n          </ion-item>\n          <ion-item class=\"rounded-lg border-2\">\n            <ion-button fill=\"clear\">\n              <p>{{negativeValue}}</p>\n              <ion-icon slot=\"end\" name=\"thumbs-down\"></ion-icon>\n            </ion-button>\n          </ion-item>\n        </div>\n\n      </div>\n     <!--  <div class=\"col-span-6\">\n        <ion-item class=\"rounded-lg border-2\">\n\n          <ion-button *ngIf=\"!isOwner(review.customer.uuid, loggedUser)\" fill=\"clear\" class=\"text-center\">Denunciar\n            <ion-icon slot=\"end\" name=\"alert-circle\"></ion-icon>\n          </ion-button>\n           <ion-button  *ngIf=\"isOwner(review.customer.uuid, loggedUser)\" (click)=\"editEmit(review)\"  fill=\"clear\" class=\"text-center\">Editar reseña\n            <ion-icon slot=\"end\" name=\"create-outline\"></ion-icon>\n          </ion-button>\n        </ion-item>\n      </div> -->\n    </div>\n\n\n  </footer>\n</section>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_reviews_reviews_module_ts.js.map