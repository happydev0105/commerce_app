"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_faq_faq_module_ts"],{

/***/ 45821:
/*!**************************************************!*\
  !*** ./src/app/core/services/faq/faq.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqService": () => (/* binding */ FaqService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);




let FaqService = class FaqService {
    constructor(http) {
        this.http = http;
        this.type = 'commerce';
    }
    getAllByCategory(categoryId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/faq/category/${categoryId}`);
    }
    getAllFAQcategories() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/faq-category`);
    }
};
FaqService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
FaqService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], FaqService);



/***/ }),

/***/ 13723:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqPageRoutingModule": () => (/* binding */ FaqPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _faq_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./faq.page */ 23915);




const routes = [
    {
        path: '',
        component: _faq_page__WEBPACK_IMPORTED_MODULE_0__.FaqPage
    },
    {
        path: 'faq-detail',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_faq_faq-detail_faq-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./faq-detail/faq-detail.module */ 70977)).then(m => m.FaqDetailPageModule)
    }
];
let FaqPageRoutingModule = class FaqPageRoutingModule {
};
FaqPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FaqPageRoutingModule);



/***/ }),

/***/ 37404:
/*!*************************************************!*\
  !*** ./src/app/pages/profile/faq/faq.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqPageModule": () => (/* binding */ FaqPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _faq_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./faq-routing.module */ 13723);
/* harmony import */ var _faq_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./faq.page */ 23915);









let FaqPageModule = class FaqPageModule {
};
FaqPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _faq_routing_module__WEBPACK_IMPORTED_MODULE_2__.FaqPageRoutingModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_faq_page__WEBPACK_IMPORTED_MODULE_3__.FaqPage]
    })
], FaqPageModule);



/***/ }),

/***/ 23915:
/*!***********************************************!*\
  !*** ./src/app/pages/profile/faq/faq.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqPage": () => (/* binding */ FaqPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _faq_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./faq.page.html?ngResource */ 90665);
/* harmony import */ var _faq_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./faq.page.scss?ngResource */ 17457);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_services_faq_faq_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/faq/faq.service */ 45821);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);






let FaqPage = class FaqPage {
    constructor(navCtrl, faqService) {
        this.navCtrl = navCtrl;
        this.faqService = faqService;
        this.faqCategoriesCollection = [];
        this.faqCategoriesCollectionFiltered = [];
    }
    ngOnInit() {
        this.getAllFAQCategories();
    }
    getAllFAQCategories() {
        this.faqService.getAllFAQcategories().subscribe(response => {
            this.faqCategoriesCollection = response;
            this.faqCategoriesCollectionFiltered = this.faqCategoriesCollection;
        });
    }
    searchFAQCategory(event) {
        const value = event.target.value;
        this.faqCategoriesCollectionFiltered = this.faqCategoriesCollection;
        if (value.length >= 3) {
            this.faqCategoriesCollectionFiltered = this.faqCategoriesCollectionFiltered.filter(option => option.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    goToDetail(item) {
        const navigationExtras = {
            state: { faqCategorySelected: item }
        };
        this.navCtrl.navigateForward(['tabs/profile/faq/faq-detail'], navigationExtras);
    }
};
FaqPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _core_services_faq_faq_service__WEBPACK_IMPORTED_MODULE_2__.FaqService }
];
FaqPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-faq',
        template: _faq_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_faq_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FaqPage);



/***/ }),

/***/ 17457:
/*!************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmYXEucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 90665:
/*!************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'FAQ'\" [titleCase]=\"false\"></app-header>\n\n<ion-content>\n  <ion-searchbar (ionInput)=\"searchFAQCategory($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n    <ion-list inset=\"true\" lines=\"none\">\n      <ion-item class=\"textbox\" *ngFor=\"let item of faqCategoriesCollectionFiltered\" button=\"true\" (click)=\"goToDetail(item)\">\n        <ion-label class=\"text-base\">{{item.name}}</ion-label>\n      </ion-item>\n    </ion-list>\n\n    <app-no-data *ngIf=\"faqCategoriesCollectionFiltered.length === 0\" [title]=\"'Parece que hay resultados para tu busqueda'\" [content]=\"false\"></app-no-data>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_faq_faq_module_ts.js.map