"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"],{

/***/ 63105:
/*!************************************************************!*\
  !*** ./src/app/core/services/services/services.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesService": () => (/* binding */ ServicesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ServicesService = class ServicesService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findServiceByCommerce(commerce) {
        return this.http.get(`${this.apiUrl}/services/`, {
            params: {
                commerce,
            },
        });
    }
    createService(service) {
        return this.http.post(`${this.apiUrl}/services/`, service);
    }
    deleteService(service) {
        return this.http.delete(`${this.apiUrl}/services/${service.uuid}`);
    }
    findServiceCategoryByCommerce(commerceID) {
        return this.http.get(`${this.apiUrl}/service-category/`, {
            params: {
                commerce: commerceID
            },
        });
    }
    createCategoryService(service) {
        return this.http.post(`${this.apiUrl}/service-category/`, service);
    }
    updateCategoryService(service) {
        return this.http.patch(`${this.apiUrl}/service-category/`, service);
    }
    deleteCategoryService(categoryUuid) {
        return this.http.delete(`${this.apiUrl}/service-category/${categoryUuid}`);
    }
};
ServicesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ServicesService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ServicesService);



/***/ }),

/***/ 43344:
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/service-list/service-list.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceListComponent": () => (/* binding */ ServiceListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _service_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./service-list.component.html?ngResource */ 7459);
/* harmony import */ var _service_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./service-list.component.scss?ngResource */ 61564);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 95472);





let ServiceListComponent = class ServiceListComponent {
    constructor(modalCtrl, navParams, cdr) {
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.cdr = cdr;
        this.serviceCollection = [];
        this.serviceCollectionFiltered = [];
        this.isConfigScreen = false;
        this.selectedServices = [];
        this.showPrice = true;
        this.noclick = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        const servicesAlreadySelected = this.navParams.get('servicesSelected');
        this.showPrice = this.navParams.get('showPrice');
        if (servicesAlreadySelected && servicesAlreadySelected.length > 0) {
            this.selectedServices = servicesAlreadySelected;
            //  this.isChecked();
        }
    }
    onTouchStart() {
        this.noclick = true;
    }
    onTouchMove() {
        this.noclick = true;
        const selection = window.getSelection();
        selection.removeAllRanges();
    }
    onTouchEnd() {
        this.noclick = false;
    }
    ngOnInit() { }
    selectService(service) {
        if (this.isConfigScreen) {
            if (this.selectedServices.some((item) => (item === null || item === void 0 ? void 0 : item.uuid) === (service === null || service === void 0 ? void 0 : service.uuid))) {
                this.selectedServices = this.selectedServices.filter((serv) => serv.uuid !== service.uuid);
            }
            else {
                this.selectedServices.push(service);
            }
        }
        else {
            this.selectedServices.push(service);
        }
        this.isChecked();
        this.cdr.detectChanges();
        if (!this.isConfigScreen) {
            this.dismiss(true);
        }
    }
    isChecked() {
        return this.selectedServices.length === this.serviceCollectionFiltered.length;
    }
    searchCustomer(event) {
        const value = event.target.value;
        this.serviceCollectionFiltered = this.serviceCollection;
        if (value.length >= 3) {
            this.serviceCollectionFiltered = this.serviceCollectionFiltered.filter((customer) => customer.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    setSelectedClass(selectedService) {
        let classToApply = '';
        const findProduct = this.selectedServices.find(item => item.uuid === selectedService.uuid);
        if (findProduct && this.isConfigScreen) {
            classToApply = 'selectedCard';
        }
        return classToApply;
    }
    dismiss(withService) {
        if (withService) {
            this.modalCtrl.dismiss({ service: this.selectedServices });
        }
        else {
            this.modalCtrl.dismiss();
        }
    }
    selectAllServices() {
        if (this.selectedServices.length === this.serviceCollectionFiltered.length) {
            this.selectedServices = [];
        }
        else {
            this.selectedServices = [...this.serviceCollectionFiltered];
            this.checkBox.checked = true;
            if (!this.isConfigScreen) {
                this.dismiss(true);
            }
        }
    }
};
ServiceListComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavParams },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ChangeDetectorRef }
];
ServiceListComponent.propDecorators = {
    checkBox: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['checkBox',] }],
    onTouchStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.HostListener, args: ['window:touchstart', ['$event'],] }],
    onTouchMove: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.HostListener, args: ['window:touchmove', ['$event'],] }],
    onTouchEnd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.HostListener, args: ['window:touchend', ['$event'],] }]
};
ServiceListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-service-list',
        template: _service_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_service_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ServiceListComponent);



/***/ }),

/***/ 61564:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/service-list/service-list.component.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = ".service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2UtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0k7RUFDSSxtQkFBQTtBQUNSO0FBRVE7RUFDSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQVo7QUFHUTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUFEWjtBQUlRO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUZaIiwiZmlsZSI6InNlcnZpY2UtbGlzdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZXJ2aWNlLWNhcmQge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgbWF4LWhlaWdodDogNDMuNXB4O1xuXG4gICAgLnNlcnZpY2Utcm93IHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcblxuXG4gICAgICAgIC5zZXJ2aWNlLWltYWdlIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIH1cblxuICAgICAgICAuaWNvbi1jb250YWluZXIge1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTkwJTtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zZXJ2aWNlLWxhYmVsIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDUlO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMyU7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0= */";

/***/ }),

/***/ 7459:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/service-list/service-list.component.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Servicios</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"dismiss(false)\">\r\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-searchbar\r\n    (ionInput)=\"searchCustomer($event)\"\r\n    showCancelButton=\"focus\"\r\n    placeholder=\"Buscar\"\r\n    cancelButtonText=\"Cancelar\"\r\n    animated\r\n  >\r\n  </ion-searchbar>\r\n\r\n  <ion-grid\r\n    fixed\r\n    style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\"\r\n  >\r\n    <ion-row>\r\n      <ion-col style=\"border-right: 1px solid lightgray\">\r\n        <ion-item>\r\n          <ion-label *ngIf=\"serviceCollectionFiltered.length === 1\"\r\n            >{{ serviceCollectionFiltered.length }} Servicio</ion-label\r\n          >\r\n          <ion-label *ngIf=\"serviceCollectionFiltered.length > 1\"\r\n            >{{ serviceCollectionFiltered.length }} Servicios</ion-label\r\n          >\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-item *ngIf=\"serviceCollectionFiltered.length > 0 && isConfigScreen\">\r\n    <ng-container\r\n      *ngIf=\"\r\n        this.selectedServices.length === this.serviceCollectionFiltered.length;\r\n        else unchecked\r\n      \"\r\n    >\r\n      <ion-label>Seleccionar todos</ion-label>\r\n      <ion-checkbox\r\n        slot=\"start\"\r\n        #checkBox\r\n        [checked]=\"true\"\r\n        (click)=\"selectAllServices()\"\r\n      ></ion-checkbox>\r\n    </ng-container>\r\n    <ng-template #unchecked>\r\n      <ion-label>Seleccionar todos</ion-label>\r\n      <ion-checkbox\r\n        slot=\"start\"\r\n        #checkBox\r\n        [checked]=\"false\"\r\n        (click)=\"selectAllServices()\"\r\n      ></ion-checkbox>\r\n    </ng-template>\r\n  </ion-item>\r\n  <ng-container *ngFor=\"let service of serviceCollectionFiltered\">\r\n    <ion-card\r\n      (click)=\"selectService(service)\"\r\n      button=\"true\"\r\n      [ngClass]=\"setSelectedClass(service)\"\r\n    >\r\n      <ion-grid class=\"service-card\">\r\n        <ion-row class=\"service-row\">\r\n          <ion-col\r\n            size=\"0.1\"\r\n            [style.background-color]=\"service?.color\"\r\n          ></ion-col>\r\n          <ion-col size=\"11\">\r\n            <ion-label class=\"service-label\"\r\n              >{{ service.name }}\r\n              <span *ngIf=\"showPrice\">· {{ service.price | formatPrice }}</span>\r\n              <p>{{ service.defaultDuration }} min</p>\r\n            </ion-label>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n  </ng-container>\r\n  <app-no-data\r\n    *ngIf=\"serviceCollectionFiltered.length === 0\"\r\n    [title]=\"'Parece que aún no tienes servicios creados'\"\r\n    [content]=\"false\"\r\n  ></app-no-data>\r\n</ion-content>\r\n<ion-footer>\r\n  <ion-button\r\n    *ngIf=\"isConfigScreen\"\r\n    [disabled]=\"selectedServices.length < 1\"\r\n    color=\"dark\"\r\n    (click)=\"dismiss(true)\"\r\n    class=\"apply-button\"\r\n    expand=\"block\"\r\n    mode=\"ios\"\r\n  >\r\n    Seleccionar servicio<span *ngIf=\"selectedServices.length > 1\"\r\n      >s ({{ selectedServices.length }})</span\r\n    >\r\n  </ion-button>\r\n</ion-footer>\r\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5.js.map