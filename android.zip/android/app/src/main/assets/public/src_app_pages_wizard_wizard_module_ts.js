"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_wizard_wizard_module_ts"],{

/***/ 16255:
/*!*******************************************************!*\
  !*** ./src/app/pages/wizard/wizard-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardPageRoutingModule": () => (/* binding */ WizardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _wizard_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wizard.page */ 86170);




const routes = [
    {
        path: '',
        component: _wizard_page__WEBPACK_IMPORTED_MODULE_0__.WizardPage
    },
    {
        path: 'timetable',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-src_app_core_transformers_timeTable_transformer_ts-src_app_core_utils_date_service_ts"), __webpack_require__.e("default-node_modules_date-fns_esm_addWeeks_index_js-src_app_shared_components_select-hour_sel-6c40cf"), __webpack_require__.e("common"), __webpack_require__.e("node_modules_date-fns_esm__lib_toInteger_index_js-node_modules_date-fns_esm_toDate_index_js-s-d48073")]).then(__webpack_require__.bind(__webpack_require__, /*! ./timetable/timetable.module */ 97296)).then(m => m.TimetablePageModule)
    },
    {
        path: 'services',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_wizard_services_services_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./services/services.module */ 61523)).then(m => m.ServicesPageModule)
    },
    {
        path: 'employee',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_wizard_employee_employee_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./employee/employee.module */ 73835)).then(m => m.EmployeePageModule)
    },
    {
        path: 'ready',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_wizard_ready_ready_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./ready/ready.module */ 18632)).then(m => m.ReadyPageModule)
    }
];
let WizardPageRoutingModule = class WizardPageRoutingModule {
};
WizardPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WizardPageRoutingModule);



/***/ }),

/***/ 90476:
/*!***********************************************!*\
  !*** ./src/app/pages/wizard/wizard.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardPageModule": () => (/* binding */ WizardPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _wizard_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wizard-routing.module */ 16255);
/* harmony import */ var _wizard_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wizard.page */ 86170);







let WizardPageModule = class WizardPageModule {
};
WizardPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _wizard_routing_module__WEBPACK_IMPORTED_MODULE_0__.WizardPageRoutingModule
        ],
        declarations: [_wizard_page__WEBPACK_IMPORTED_MODULE_1__.WizardPage]
    })
], WizardPageModule);



/***/ }),

/***/ 86170:
/*!*********************************************!*\
  !*** ./src/app/pages/wizard/wizard.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardPage": () => (/* binding */ WizardPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wizard.page.html?ngResource */ 15623);
/* harmony import */ var _wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wizard.page.scss?ngResource */ 60758);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);






let WizardPage = class WizardPage {
    constructor(navCtrl, activatedRoute) {
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getUserName();
    }
    goToNext() {
        this.navCtrl.navigateForward(['timetable'], { relativeTo: this.activatedRoute });
    }
    getUserName() {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.username = `${currentUser.name} ${currentUser.surname}`;
    }
};
WizardPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute }
];
WizardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-wizard',
        template: _wizard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_wizard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WizardPage);



/***/ }),

/***/ 60758:
/*!**********************************************************!*\
  !*** ./src/app/pages/wizard/wizard.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "ion-grid {\n  height: 100%;\n}\n\nion-row {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndpemFyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FBQ0o7O0FBQ0E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUFFSiIsImZpbGUiOiJ3aXphcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWdyaWR7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuaW9uLXJvd3tcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn0iXX0= */";

/***/ }),

/***/ 15623:
/*!**********************************************************!*\
  !*** ./src/app/pages/wizard/wizard.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-center\">\n      <div class=\"px-8 text-center\">\n       <h1>Hola {{username}}</h1>\n       <h2>Vamos a configurar su perfil para poder empezar a trabajar.</h2>\n       <h2>¡Verás que <span class=\"font-bold\">YEASY</span>!</h2>\n      </div>\n      <div class=\"px-8 bottom-8 w-full absolute\">\n        <ion-button (click)=\"goToNext()\" expand=\"block\" class=\"btn\" >\n         Empezar\n        </ion-button>\n      </div>\n    </ion-row>\n   </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_wizard_wizard_module_ts.js.map