"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday_holiday_module_ts"],{

/***/ 5868:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/addDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addDays
 * @category Day Helpers
 * @summary Add the specified number of days to the given date.
 *
 * @description
 * Add the specified number of days to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} - the new date with the days added
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // Add 10 days to 1 September 2014:
 * const result = addDays(new Date(2014, 8, 1), 10)
 * //=> Thu Sep 11 2014 00:00:00
 */

function addDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyAmount);

  if (isNaN(amount)) {
    return new Date(NaN);
  }

  if (!amount) {
    // If 0 days, no-op to avoid changing times in the hour before end of DST
    return date;
  }

  date.setDate(date.getDate() + amount);
  return date;
}

/***/ }),

/***/ 97889:
/*!******************************************************!*\
  !*** ./node_modules/date-fns/esm/constants/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "daysInWeek": () => (/* binding */ daysInWeek),
/* harmony export */   "maxTime": () => (/* binding */ maxTime),
/* harmony export */   "millisecondsInHour": () => (/* binding */ millisecondsInHour),
/* harmony export */   "millisecondsInMinute": () => (/* binding */ millisecondsInMinute),
/* harmony export */   "millisecondsInSecond": () => (/* binding */ millisecondsInSecond),
/* harmony export */   "minTime": () => (/* binding */ minTime),
/* harmony export */   "minutesInHour": () => (/* binding */ minutesInHour),
/* harmony export */   "monthsInQuarter": () => (/* binding */ monthsInQuarter),
/* harmony export */   "monthsInYear": () => (/* binding */ monthsInYear),
/* harmony export */   "quartersInYear": () => (/* binding */ quartersInYear),
/* harmony export */   "secondsInHour": () => (/* binding */ secondsInHour),
/* harmony export */   "secondsInMinute": () => (/* binding */ secondsInMinute)
/* harmony export */ });
/**
 * Days in 1 week.
 *
 * @name daysInWeek
 * @constant
 * @type {number}
 * @default
 */
var daysInWeek = 7;
/**
 * Maximum allowed time.
 *
 * @name maxTime
 * @constant
 * @type {number}
 * @default
 */

var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1000;
/**
 * Milliseconds in 1 minute
 *
 * @name millisecondsInMinute
 * @constant
 * @type {number}
 * @default
 */

var millisecondsInMinute = 60000;
/**
 * Milliseconds in 1 hour
 *
 * @name millisecondsInHour
 * @constant
 * @type {number}
 * @default
 */

var millisecondsInHour = 3600000;
/**
 * Milliseconds in 1 second
 *
 * @name millisecondsInSecond
 * @constant
 * @type {number}
 * @default
 */

var millisecondsInSecond = 1000;
/**
 * Minimum allowed time.
 *
 * @name minTime
 * @constant
 * @type {number}
 * @default
 */

var minTime = -maxTime;
/**
 * Minutes in 1 hour
 *
 * @name minutesInHour
 * @constant
 * @type {number}
 * @default
 */

var minutesInHour = 60;
/**
 * Months in 1 quarter
 *
 * @name monthsInQuarter
 * @constant
 * @type {number}
 * @default
 */

var monthsInQuarter = 3;
/**
 * Months in 1 year
 *
 * @name monthsInYear
 * @constant
 * @type {number}
 * @default
 */

var monthsInYear = 12;
/**
 * Quarters in 1 year
 *
 * @name quartersInYear
 * @constant
 * @type {number}
 * @default
 */

var quartersInYear = 4;
/**
 * Seconds in 1 hour
 *
 * @name secondsInHour
 * @constant
 * @type {number}
 * @default
 */

var secondsInHour = 3600;
/**
 * Seconds in 1 minute
 *
 * @name secondsInMinute
 * @constant
 * @type {number}
 * @default
 */

var secondsInMinute = 60;

/***/ }),

/***/ 68097:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/parseISO/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseISO)
/* harmony export */ });
/* harmony import */ var _constants_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/index.js */ 97889);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);



/**
 * @name parseISO
 * @category Common Helpers
 * @summary Parse ISO string
 *
 * @description
 * Parse the given string in ISO 8601 format and return an instance of Date.
 *
 * Function accepts complete ISO 8601 formats as well as partial implementations.
 * ISO 8601: http://en.wikipedia.org/wiki/ISO_8601
 *
 * If the argument isn't a string, the function cannot parse the string or
 * the values are invalid, it returns Invalid Date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * - The previous `parse` implementation was renamed to `parseISO`.
 *
 *   ```javascript
 *   // Before v2.0.0
 *   parse('2016-01-01')
 *
 *   // v2.0.0 onward
 *   parseISO('2016-01-01')
 *   ```
 *
 * - `parseISO` now validates separate date and time values in ISO-8601 strings
 *   and returns `Invalid Date` if the date is invalid.
 *
 *   ```javascript
 *   parseISO('2018-13-32')
 *   //=> Invalid Date
 *   ```
 *
 * - `parseISO` now doesn't fall back to `new Date` constructor
 *   if it fails to parse a string argument. Instead, it returns `Invalid Date`.
 *
 * @param {String} argument - the value to convert
 * @param {Object} [options] - an object with options.
 * @param {0|1|2} [options.additionalDigits=2] - the additional number of digits in the extended year format
 * @returns {Date} the parsed date in the local time zone
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.additionalDigits` must be 0, 1 or 2
 *
 * @example
 * // Convert string '2014-02-11T11:30:30' to date:
 * const result = parseISO('2014-02-11T11:30:30')
 * //=> Tue Feb 11 2014 11:30:30
 *
 * @example
 * // Convert string '+02014101' to date,
 * // if the additional number of digits in the extended year format is 1:
 * const result = parseISO('+02014101', { additionalDigits: 1 })
 * //=> Fri Apr 11 2014 00:00:00
 */

function parseISO(argument, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var additionalDigits = options.additionalDigits == null ? 2 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.additionalDigits);

  if (additionalDigits !== 2 && additionalDigits !== 1 && additionalDigits !== 0) {
    throw new RangeError('additionalDigits must be 0, 1 or 2');
  }

  if (!(typeof argument === 'string' || Object.prototype.toString.call(argument) === '[object String]')) {
    return new Date(NaN);
  }

  var dateStrings = splitDateString(argument);
  var date;

  if (dateStrings.date) {
    var parseYearResult = parseYear(dateStrings.date, additionalDigits);
    date = parseDate(parseYearResult.restDateString, parseYearResult.year);
  }

  if (!date || isNaN(date.getTime())) {
    return new Date(NaN);
  }

  var timestamp = date.getTime();
  var time = 0;
  var offset;

  if (dateStrings.time) {
    time = parseTime(dateStrings.time);

    if (isNaN(time)) {
      return new Date(NaN);
    }
  }

  if (dateStrings.timezone) {
    offset = parseTimezone(dateStrings.timezone);

    if (isNaN(offset)) {
      return new Date(NaN);
    }
  } else {
    var dirtyDate = new Date(timestamp + time); // js parsed string assuming it's in UTC timezone
    // but we need it to be parsed in our timezone
    // so we use utc values to build date in our timezone.
    // Year values from 0 to 99 map to the years 1900 to 1999
    // so set year explicitly with setFullYear.

    var result = new Date(0);
    result.setFullYear(dirtyDate.getUTCFullYear(), dirtyDate.getUTCMonth(), dirtyDate.getUTCDate());
    result.setHours(dirtyDate.getUTCHours(), dirtyDate.getUTCMinutes(), dirtyDate.getUTCSeconds(), dirtyDate.getUTCMilliseconds());
    return result;
  }

  return new Date(timestamp + time + offset);
}
var patterns = {
  dateTimeDelimiter: /[T ]/,
  timeZoneDelimiter: /[Z ]/i,
  timezone: /([Z+-].*)$/
};
var dateRegex = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/;
var timeRegex = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/;
var timezoneRegex = /^([+-])(\d{2})(?::?(\d{2}))?$/;

function splitDateString(dateString) {
  var dateStrings = {};
  var array = dateString.split(patterns.dateTimeDelimiter);
  var timeString; // The regex match should only return at maximum two array elements.
  // [date], [time], or [date, time].

  if (array.length > 2) {
    return dateStrings;
  }

  if (/:/.test(array[0])) {
    timeString = array[0];
  } else {
    dateStrings.date = array[0];
    timeString = array[1];

    if (patterns.timeZoneDelimiter.test(dateStrings.date)) {
      dateStrings.date = dateString.split(patterns.timeZoneDelimiter)[0];
      timeString = dateString.substr(dateStrings.date.length, dateString.length);
    }
  }

  if (timeString) {
    var token = patterns.timezone.exec(timeString);

    if (token) {
      dateStrings.time = timeString.replace(token[1], '');
      dateStrings.timezone = token[1];
    } else {
      dateStrings.time = timeString;
    }
  }

  return dateStrings;
}

function parseYear(dateString, additionalDigits) {
  var regex = new RegExp('^(?:(\\d{4}|[+-]\\d{' + (4 + additionalDigits) + '})|(\\d{2}|[+-]\\d{' + (2 + additionalDigits) + '})$)');
  var captures = dateString.match(regex); // Invalid ISO-formatted year

  if (!captures) return {
    year: NaN,
    restDateString: ''
  };
  var year = captures[1] ? parseInt(captures[1]) : null;
  var century = captures[2] ? parseInt(captures[2]) : null; // either year or century is null, not both

  return {
    year: century === null ? year : century * 100,
    restDateString: dateString.slice((captures[1] || captures[2]).length)
  };
}

function parseDate(dateString, year) {
  // Invalid ISO-formatted year
  if (year === null) return new Date(NaN);
  var captures = dateString.match(dateRegex); // Invalid ISO-formatted string

  if (!captures) return new Date(NaN);
  var isWeekDate = !!captures[4];
  var dayOfYear = parseDateUnit(captures[1]);
  var month = parseDateUnit(captures[2]) - 1;
  var day = parseDateUnit(captures[3]);
  var week = parseDateUnit(captures[4]);
  var dayOfWeek = parseDateUnit(captures[5]) - 1;

  if (isWeekDate) {
    if (!validateWeekDate(year, week, dayOfWeek)) {
      return new Date(NaN);
    }

    return dayOfISOWeekYear(year, week, dayOfWeek);
  } else {
    var date = new Date(0);

    if (!validateDate(year, month, day) || !validateDayOfYearDate(year, dayOfYear)) {
      return new Date(NaN);
    }

    date.setUTCFullYear(year, month, Math.max(dayOfYear, day));
    return date;
  }
}

function parseDateUnit(value) {
  return value ? parseInt(value) : 1;
}

function parseTime(timeString) {
  var captures = timeString.match(timeRegex);
  if (!captures) return NaN; // Invalid ISO-formatted time

  var hours = parseTimeUnit(captures[1]);
  var minutes = parseTimeUnit(captures[2]);
  var seconds = parseTimeUnit(captures[3]);

  if (!validateTime(hours, minutes, seconds)) {
    return NaN;
  }

  return hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute + seconds * 1000;
}

function parseTimeUnit(value) {
  return value && parseFloat(value.replace(',', '.')) || 0;
}

function parseTimezone(timezoneString) {
  if (timezoneString === 'Z') return 0;
  var captures = timezoneString.match(timezoneRegex);
  if (!captures) return 0;
  var sign = captures[1] === '+' ? -1 : 1;
  var hours = parseInt(captures[2]);
  var minutes = captures[3] && parseInt(captures[3]) || 0;

  if (!validateTimezone(hours, minutes)) {
    return NaN;
  }

  return sign * (hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute);
}

function dayOfISOWeekYear(isoWeekYear, week, day) {
  var date = new Date(0);
  date.setUTCFullYear(isoWeekYear, 0, 4);
  var fourthOfJanuaryDay = date.getUTCDay() || 7;
  var diff = (week - 1) * 7 + day + 1 - fourthOfJanuaryDay;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
} // Validation functions
// February is null to handle the leap year (using ||)


var daysInMonths = [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function isLeapYearIndex(year) {
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}

function validateDate(year, month, date) {
  return month >= 0 && month <= 11 && date >= 1 && date <= (daysInMonths[month] || (isLeapYearIndex(year) ? 29 : 28));
}

function validateDayOfYearDate(year, dayOfYear) {
  return dayOfYear >= 1 && dayOfYear <= (isLeapYearIndex(year) ? 366 : 365);
}

function validateWeekDate(_year, week, day) {
  return week >= 1 && week <= 53 && day >= 0 && day <= 6;
}

function validateTime(hours, minutes, seconds) {
  if (hours === 24) {
    return minutes === 0 && seconds === 0;
  }

  return seconds >= 0 && seconds < 60 && minutes >= 0 && minutes < 60 && hours >= 0 && hours < 25;
}

function validateTimezone(_hours, minutes) {
  return minutes >= 0 && minutes <= 59;
}

/***/ }),

/***/ 49602:
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday/holiday-routing.module.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayPageRoutingModule": () => (/* binding */ HolidayPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _holiday_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./holiday.page */ 90992);




const routes = [
    {
        path: '',
        component: _holiday_page__WEBPACK_IMPORTED_MODULE_0__.HolidayPage
    }
];
let HolidayPageRoutingModule = class HolidayPageRoutingModule {
};
HolidayPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HolidayPageRoutingModule);



/***/ }),

/***/ 30334:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday/holiday.module.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayPageModule": () => (/* binding */ HolidayPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _holiday_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./holiday-routing.module */ 49602);
/* harmony import */ var _holiday_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./holiday.page */ 90992);
/* harmony import */ var _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular-material-components/datetime-picker */ 55923);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/form-field */ 37551);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);











let HolidayPageModule = class HolidayPageModule {
};
HolidayPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _holiday_routing_module__WEBPACK_IMPORTED_MODULE_0__.HolidayPageRoutingModule,
            _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_9__.NgxMatTimepickerModule,
            _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_9__.NgxMatDatetimePickerModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_10__.MatFormFieldModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_2__.AlertModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule
        ],
        declarations: [_holiday_page__WEBPACK_IMPORTED_MODULE_1__.HolidayPage]
    })
], HolidayPageModule);



/***/ }),

/***/ 90992:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday/holiday.page.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayPage": () => (/* binding */ HolidayPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _holiday_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./holiday.page.html?ngResource */ 31522);
/* harmony import */ var _holiday_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./holiday.page.scss?ngResource */ 30397);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! date-fns */ 68097);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! date-fns */ 5868);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! date-fns */ 41766);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! date-fns */ 38902);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! date-fns/locale */ 36956);
/* harmony import */ var src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/non-availability.dto */ 57394);
/* harmony import */ var src_app_core_enums_days_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/enums/days.enum */ 77639);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/non-availability/non-availability.service */ 30371);
/* harmony import */ var src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/timeTable/time-table.service */ 79223);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);


















let HolidayPage = class HolidayPage {
    constructor(fb, dateService, nonAvailabilityService, employeeService, timeTableService, route, activatedRoute, location, authService) {
        this.fb = fb;
        this.dateService = dateService;
        this.nonAvailabilityService = nonAvailabilityService;
        this.employeeService = employeeService;
        this.timeTableService = timeTableService;
        this.route = route;
        this.activatedRoute = activatedRoute;
        this.location = location;
        this.authService = authService;
        this.showPickerDate = false;
        this.isEdit = false;
        this.locale = date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForm();
    }
    get startDay() {
        return this.form.get('startDay');
    }
    get endDay() {
        return this.form.get('endDay');
    }
    get message() {
        return this.form.get('message');
    }
    ngOnInit() {
        this.getParam();
        this.getCommerceTimetableById(this.commerceLogged);
    }
    getParam() {
        this.activatedRoute.params.subscribe((param) => {
            this.employeeService.findEmployeeById(param.id).subscribe((res) => {
                this.employeeSelected = res;
            });
        });
    }
    getCommerceTimetableById(commerceUuid) {
        this.timeTableService.findTimetableOnlyEntityByCommerce(commerceUuid).subscribe((res) => {
            this.commerceTimetable = res;
            console.log('timetable', res);
        });
    }
    dateChangedInit(value) {
        this.startDate = new Date(value);
        this.dateStartValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(value), 'd MMM, yyyy', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"] });
        this.startDay.setValue(this.startDate.toISOString());
        this.endDay.setValue(this.startDate.toISOString());
    }
    dateEndChanged(value) {
        this.endDate = new Date(value);
        this.dateEndValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(value), 'd MMM, yyyy', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"] });
    }
    dismiss() {
        this.datetime.cancel(true);
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    select() {
        this.datetime.confirm(true);
    }
    dismissTime() {
        this.time.cancel(true);
    }
    selectTime() {
        this.time.confirm(true);
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    deleteItem() {
        this.nonAvailabilityService
            .deleteNonAvailabilityById(this.id)
            .subscribe((res) => {
            if (res.affected > 0) {
                this.location.back();
            }
        });
    }
    onSubmit() {
        const nonAvailabilityDto = this.buildNonAvailability();
        nonAvailabilityDto.forEach((item, index) => {
            console.log(index, nonAvailabilityDto.length);
            if (this.isEdit) {
                this.nonAvailabilityService
                    .editNonAvailability(item)
                    .subscribe((res) => {
                    if (res && index === nonAvailabilityDto.length - 1) {
                        this.location.back();
                    }
                });
            }
            else {
                this.nonAvailabilityService
                    .saveNonAvailability(item)
                    .subscribe((res) => {
                    if (res && index === nonAvailabilityDto.length - 1) {
                        this.location.back();
                    }
                });
            }
        });
    }
    ionViewDidLeave() {
    }
    ngOnDestroy() {
        this.form.reset();
    }
    initForm() {
        this.form = this.fb.group({
            startDay: [(0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])(new Date(), 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"] }), _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
            endDay: [(0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_14__["default"])(new Date(), 1), 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_10__["default"] }), _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
        });
    }
    buildNonAvailability() {
        const interval = (0,date_fns__WEBPACK_IMPORTED_MODULE_15__["default"])({ start: this.startDate, end: this.endDate });
        const uniqueID = '_' + Math.random().toString(36).substring(2, 9);
        const dayCollection = [];
        interval.forEach((item) => {
            const weekDay = src_app_core_enums_days_enum__WEBPACK_IMPORTED_MODULE_3__.EDays[(0,date_fns__WEBPACK_IMPORTED_MODULE_16__["default"])(item)];
            const newNonAvailability = new src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_2__.NonAvailabilityDto();
            newNonAvailability.commerce = this.commerceLogged;
            newNonAvailability.employee = this.employeeSelected;
            const startDate = new Date(item);
            newNonAvailability.date = this.dateService.formatDate(startDate);
            if (this.isEdit) {
                newNonAvailability.uuid = this.editItem.uuid;
            }
            const timetable = {
                start: {
                    hour: JSON.parse(this.commerceTimetable[weekDay]).start.hour,
                    minute: JSON.parse(this.commerceTimetable[weekDay]).start.minute,
                },
                end: {
                    hour: JSON.parse(this.commerceTimetable[weekDay]).end.hour,
                    minute: JSON.parse(this.commerceTimetable[weekDay]).end.minute,
                },
            };
            newNonAvailability.timetable = JSON.stringify(timetable);
            newNonAvailability.groupBy = uniqueID;
            newNonAvailability.message = 'Vacaciones';
            dayCollection.push(newNonAvailability);
        });
        return dayCollection;
    }
};
HolidayPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_8__.DateService },
    { type: src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_6__.NonAvailabilityService },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_5__.EmployeeService },
    { type: src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_7__.TimeTableService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_18__.Location },
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService }
];
HolidayPage.propDecorators = {
    datetime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonDatetime,] }],
    time: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonDatetime,] }],
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_9__.AlertComponent,] }]
};
HolidayPage = (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.Component)({
        selector: 'app-holiday',
        template: _holiday_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_holiday_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HolidayPage);



/***/ }),

/***/ 30397:
/*!****************************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday/holiday.page.scss?ngResource ***!
  \****************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob2xpZGF5LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 31522:
/*!****************************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday/holiday.page.html?ngResource ***!
  \****************************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Vacaciones'\"></app-header>\n\n<ion-content fullscreen=\"true\">\n  <form [formGroup]=\"form\" (ngSubmit)=\"onSubmit()\" novalidate>\n\n    <ion-item id=\"open-start-day\" mode=\"ios\" class=\"textbox\" no-lines lines=\"none\">\n      <ion-label mode=\"ios\">Fecha Inicio</ion-label>\n      <ion-input type=\"text\" class=\"ion-text-center\"\n        [value]=\"dateService.formatDateLanguage(form.controls['startDay'].value, locale)\"></ion-input>\n      \n        <ion-modal id=\"open-modal-calendar\" initialBreakpoint=\"0.50\" trigger=\"open-start-day\">\n        <ng-template>\n          <ion-content>\n            <ion-toolbar>\n              <ion-title>Fecha inicio</ion-title>\n              <ion-buttons slot=\"end\">\n                <ion-button color=\"dark\" (click)=\"dismissModal('open-modal-calendar')\">Aceptar</ion-button>\n              </ion-buttons>\n            </ion-toolbar>\n            <ion-datetime #datetime locale=\"es-ES\" first-day-of-week=\"1\" (ionChange)=\"dateChangedInit(datetime.value)\"\n              presentation=\"date\" size=\"cover\" formControlName=\"startDay\">\n            </ion-datetime>\n          </ion-content>\n        </ng-template>\n      </ion-modal>\n    </ion-item>\n    <ion-item id=\"open-end-day\" mode=\"ios\" class=\"textbox\" no-lines lines=\"none\">\n      <ion-label mode=\"ios\">Fecha final</ion-label>\n      <ion-input type=\"text\" class=\"ion-text-center\"\n        [value]=\"dateService.formatDateLanguage(form.controls['endDay'].value, locale)\"></ion-input>\n        \n        <ion-modal id=\"open-end-modal-calendar\" initialBreakpoint=\"0.50\" trigger=\"open-end-day\">\n        <ng-template>\n          <ion-content>\n            <ion-toolbar>\n              <ion-title>Fecha inicio</ion-title>\n              <ion-buttons slot=\"end\">\n                <ion-button color=\"dark\" (click)=\"dismissModal('open-end-modal-calendar')\">Aceptar</ion-button>\n              </ion-buttons>\n            </ion-toolbar>\n            <ion-datetime #datetimeEnd first-day-of-week=\"1\" locale=\"es-ES\" [min]=\"form.controls['startDay'].value\"\n              (ionChange)=\"dateEndChanged(datetimeEnd.value)\" presentation=\"date\" size=\"cover\" formControlName=\"endDay\">\n            </ion-datetime>\n          </ion-content>\n        </ng-template>\n      </ion-modal>\n    </ion-item>\n\n  </form>\n</ion-content>\n<app-alert #deleteAlert (actionEmitter)=\"alertBox($event)\" [title]=\"'¿Desea borrar?'\"></app-alert>\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"isEdit\" (click)=\"openAlert()\">\n        <ion-button class=\"btn\" expand=\"block\">\n          <ion-icon icon=\"trash\"></ion-icon>\n        </ion-button>\n      </ion-col>\n     \n      <ion-col>\n        <ion-button (click)=\"onSubmit()\" [disabled]=\"!form.valid\" class=\"btn\" expand=\"block\">\n          Guardar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday_holiday_module_ts.js.map