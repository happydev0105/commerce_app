"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_shared_components_alert_alert_module_ts"],{

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=src_app_shared_components_alert_alert_module_ts.js.map