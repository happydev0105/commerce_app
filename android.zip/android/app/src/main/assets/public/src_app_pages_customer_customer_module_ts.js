"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_customer_customer_module_ts"],{

/***/ 84013:
/*!********************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysModule": () => (/* binding */ TranslateDaysModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-days.pipe */ 29069);





let TranslateDaysModule = class TranslateDaysModule {
};
TranslateDaysModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe]
    })
], TranslateDaysModule);



/***/ }),

/***/ 29069:
/*!******************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysPipe": () => (/* binding */ TranslateDaysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TranslateDaysPipe = class TranslateDaysPipe {
    transform(value) {
        const daysTranslated = {
            monday: 'lunes',
            tuesday: 'martes',
            wednesday: 'miércoles',
            thursday: 'jueves',
            friday: 'viernes',
            saturday: 'sábado',
            sunday: 'domingo'
        };
        return daysTranslated[value] || value;
    }
};
TranslateDaysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'translateDays'
    })
], TranslateDaysPipe);



/***/ }),

/***/ 20161:
/*!************************************************************!*\
  !*** ./src/app/core/services/customer/customer.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerService": () => (/* binding */ CustomerService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let CustomerService = class CustomerService {
    constructor(http) {
        this.http = http;
    }
    getAllCustomer() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`);
    }
    getAllCustomerByCommerce(commerceId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/commerce/${commerceId}`);
    }
    getAllCustomerByCommerceAndCreatedBy(commerce) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/commerceAndCreatedBy/${commerce}`);
    }
    getCustomersByRecentFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/recent`);
    }
    getCustomersByLoyaltyFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/loyal`);
    }
    getCustomersByNonAttendantFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/non-attendant`);
    }
    getWalkinCustomer() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/walkin/walkin`);
    }
    saveCustomer(customer) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`, customer);
    }
    updateCustomer(customer) {
        return this.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`, customer);
    }
    deleteCustomer(customer) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/${customer.uuid}`);
    }
};
CustomerService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
CustomerService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CustomerService);



/***/ }),

/***/ 83866:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/customer/customer-filter/customer-filter.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerFilterComponent": () => (/* binding */ CustomerFilterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _customer_filter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-filter.component.html?ngResource */ 50391);
/* harmony import */ var _customer_filter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-filter.component.scss?ngResource */ 18594);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);





let CustomerFilterComponent = class CustomerFilterComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.customerFilter = 'faithful';
    }
    ngOnInit() { }
    dismiss(cancel) {
        if (!cancel) {
            this.modalCtrl.dismiss({
                filter: this.customerFilter
            });
        }
        else {
            this.modalCtrl.dismiss();
        }
    }
};
CustomerFilterComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
CustomerFilterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-customer-filter',
        template: _customer_filter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customer_filter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomerFilterComponent);



/***/ }),

/***/ 41880:
/*!***********************************************************!*\
  !*** ./src/app/pages/customer/customer-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerPageRoutingModule": () => (/* binding */ CustomerPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _customer_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer.page */ 72036);




const routes = [
    {
        path: '',
        component: _customer_page__WEBPACK_IMPORTED_MODULE_0__.CustomerPage
    },
    {
        path: 'customer-detail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_pages_customer_customer-detail_customer-detail_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("node_modules_date-fns_esm_addMinutes_index_js-src_app_core_pipes_format-hour_format-hour_modu-3b748c")]).then(__webpack_require__.bind(__webpack_require__, /*! ./customer-detail/customer-detail.module */ 71547)).then(m => m.CustomerDetailPageModule)
    }
];
let CustomerPageRoutingModule = class CustomerPageRoutingModule {
};
CustomerPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CustomerPageRoutingModule);



/***/ }),

/***/ 56921:
/*!***************************************************!*\
  !*** ./src/app/pages/customer/customer.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerPageModule": () => (/* binding */ CustomerPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _customer_filter_customer_filter_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-filter/customer-filter.component */ 83866);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _customer_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customer-routing.module */ 41880);
/* harmony import */ var _customer_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./customer.page */ 72036);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);










let CustomerPageModule = class CustomerPageModule {
};
CustomerPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _customer_routing_module__WEBPACK_IMPORTED_MODULE_2__.CustomerPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_4__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_customer_page__WEBPACK_IMPORTED_MODULE_3__.CustomerPage, _customer_filter_customer_filter_component__WEBPACK_IMPORTED_MODULE_1__.CustomerFilterComponent]
    })
], CustomerPageModule);



/***/ }),

/***/ 72036:
/*!*************************************************!*\
  !*** ./src/app/pages/customer/customer.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerPage": () => (/* binding */ CustomerPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _customer_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer.page.html?ngResource */ 88840);
/* harmony import */ var _customer_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer.page.scss?ngResource */ 57980);
/* harmony import */ var _customer_filter_customer_filter_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customer-filter/customer-filter.component */ 83866);
/* harmony import */ var _core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../core/services/customer/customer.service */ 20161);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);







let CustomerPage = class CustomerPage {
    constructor(customerService, modalController, routerOutlet, navCtrl) {
        this.customerService = customerService;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.navCtrl = navCtrl;
        this.customerCollection = [];
        this.customerCollectionFiltered = [];
        this.showNoData = false;
        this.customerSearch = '';
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllCustomerByCommerceAndCreatedBy();
        this.customerSearch = '';
        this.searchbar.value = '';
    }
    ngOnInit() { }
    getAllCustomerByCommerceAndCreatedBy() {
        this.customerService.getAllCustomerByCommerceAndCreatedBy(this.commerceLogged).subscribe(response => {
            if (response) {
                response.map(customer => {
                    if (!customer.photoURL) {
                        let initials = customer.name.slice(0, 2);
                        if (customer.lastname) {
                            initials = `${customer.name.slice(0, 1)}${customer.lastname.slice(0, 1)}`;
                        }
                        customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                    }
                });
                this.customerCollection = response;
                this.customerCollectionFiltered = this.customerCollection;
                if (this.customerCollection.length === 0) {
                    this.showNoData = true;
                }
            }
        });
    }
    goToDetail(customerSelected) {
        const navigationExtras = { state: { customer: customerSelected } };
        this.navCtrl.navigateForward(['tabs/customers/customer-detail'], navigationExtras);
    }
    searchCustomer(event) {
        const value = event.target.value;
        this.customerSearch = value;
        this.customerCollectionFiltered = this.customerCollection;
        if (value.length >= 3) {
            this.customerCollectionFiltered = this.customerCollectionFiltered.filter(customer => customer.name.toLowerCase().includes(value.toLowerCase()));
            /* if (this.customerCollectionFiltered.length === 0) {
            } */
        }
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _customer_filter_customer_filter_component__WEBPACK_IMPORTED_MODULE_2__.CustomerFilterComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                this.filterCustomers(data.filter);
            }
        });
    }
    filterCustomers(filter) {
        switch (filter) {
            case 'new':
                this.getCustomerByNewFilter();
                break;
            case 'faithful':
                this.getCustomerByLoyaltyFilter();
                break;
            case 'non-attendant':
                this.getCustomerByNonAttendantFilter();
                break;
        }
    }
    getCustomerByNewFilter() {
        this.customerService.getCustomersByRecentFilter().subscribe(response => {
            response.map(customer => {
                if (!customer.photoURL) {
                    let initials = customer.name.slice(0, 2);
                    if (customer.lastname) {
                        initials = `${customer.name.slice(0, 1)}${customer.lastname.slice(0, 1)}`;
                    }
                    customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            });
            this.customerCollection = response;
            this.customerCollectionFiltered = this.customerCollection;
        });
    }
    getCustomerByLoyaltyFilter() {
        this.customerService.getCustomersByLoyaltyFilter().subscribe(response => {
            response.map(customer => {
                if (!customer.photoURL) {
                    let initials = customer.name.slice(0, 2);
                    if (customer.lastname) {
                        initials = `${customer.name.slice(0, 1)}${customer.lastname.slice(0, 1)}`;
                    }
                    customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            });
            this.customerCollection = response;
            this.customerCollectionFiltered = this.customerCollection;
        });
    }
    getCustomerByNonAttendantFilter() {
        this.customerService.getCustomersByNonAttendantFilter().subscribe(response => {
            response.map(customer => {
                if (!customer.photoURL) {
                    let initials = customer.name.slice(0, 2);
                    if (customer.lastname) {
                        initials = `${customer.name.slice(0, 1)}${customer.lastname.slice(0, 1)}`;
                    }
                    customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
            });
            this.customerCollection = response;
            this.customerCollectionFiltered = this.customerCollection;
        });
    }
    goToCreate() {
        const navigationExtras = { state: { createFastCustomer: this.customerSearch } };
        this.navCtrl.navigateForward(['tabs/customers/customer-detail'], navigationExtras);
    }
};
CustomerPage.ctorParameters = () => [
    { type: _core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__.CustomerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRouterOutlet },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
CustomerPage.propDecorators = {
    searchbar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['searchbar', { static: false },] }]
};
CustomerPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-customer',
        template: _customer_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customer_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomerPage);



/***/ }),

/***/ 89470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 46730);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 70847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let HeaderComponent = class HeaderComponent {
    constructor() {
        this.titleCase = true;
    }
    ngOnInit() { }
};
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    backButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titlePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titleCase: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 57185:
/*!************************************************!*\
  !*** ./src/app/shared/header/header.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderModule": () => (/* binding */ HeaderModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component */ 89470);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);






let HeaderModule = class HeaderModule {
};
HeaderModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__.TranslateDaysModule
        ],
        exports: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent]
    })
], HeaderModule);



/***/ }),

/***/ 18594:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-filter/customer-filter.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjdXN0b21lci1maWx0ZXIuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 57980:
/*!**************************************************************!*\
  !*** ./src/app/pages/customer/customer.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".customer-card {\n  padding: 0;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  display: block;\n  margin-top: 15%;\n  margin-left: 5%;\n}\nion-searchbar {\n  --background: rgb(228, 228, 228);\n  --cancel-button-color: black;\n}\nion-item {\n  --inner-border-width: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7QUFDRjtBQUFFO0VBQ0UsbUJBQUE7QUFFSjtBQURJO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUdOO0FBREk7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBR047QUFESTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQUdOO0FBR0E7RUFDRSxnQ0FBQTtFQUNBLDRCQUFBO0FBQUY7QUFHQTtFQUNFLHlCQUFBO0FBQUYiLCJmaWxlIjoiY3VzdG9tZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbWVyLWNhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgLmN1c3RvbWVyLXJvdyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgLmN1c3RvbWVyLWltYWdlIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOCwgMjI4LCAyMjgpO1xyXG4gICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB9XHJcbiAgICAuaWNvbi1jb250YWluZXIge1xyXG4gICAgICBtYXJnaW4tdG9wOiAxOTAlO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAuY3VzdG9tZXItbGFiZWwge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgbWFyZ2luLXRvcDogMTUlO1xyXG4gICAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5cclxuaW9uLXNlYXJjaGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoMjI4LCAyMjgsIDIyOCk7XHJcbiAgLS1jYW5jZWwtYnV0dG9uLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwcHg7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 70847:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0 !important;\n}\n\nion-back-button {\n  --icon-margin-start: 10px;\n  --icon-margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0FBQ0YiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1iYWNrLWJ1dHRvbiB7XHJcbiAgLS1pY29uLW1hcmdpbi1zdGFydDogMTBweDtcclxuICAtLWljb24tbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 50391:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-filter/customer-filter.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Filtros</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss(true)\">\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-radio-group mode=\"md\" [(ngModel)]=\"customerFilter\">\n    <ion-list-header>\n      <ion-label>Filtrar clientes por:</ion-label>\n    </ion-list-header>\n    <ion-item>\n      <ion-label>Nuevos (creado en los últimos 30 días)</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"new\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Fieles (+3 reservas)</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"faithful\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Inasistentes</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"non-attendant\"></ion-radio>\n    </ion-item>\n  </ion-radio-group>\n\n\n</ion-content>\n<ion-footer>\n  <ion-button (click)=\"dismiss(false)\" color=\"dark\" class=\"apply-button\" expand=\"block\" mode=\"ios\" >\n    Aplicar filtros\n  </ion-button>\n</ion-footer>\n";

/***/ }),

/***/ 88840:
/*!**************************************************************!*\
  !*** ./src/app/pages/customer/customer.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"false\" [titlePage]=\"'Clientes'\"></app-header>\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\" >\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-searchbar\n    #searchbar\n    *ngIf=\"!showNoData\"\n    (ionInput)=\"searchCustomer($event)\"\n    showCancelButton=\"focus\"\n    placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\"\n    animated>\n  </ion-searchbar>\n\n  <ion-grid *ngIf=\"!showNoData\"\n    fixed\n    style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\">\n    <ion-row>\n      <ion-col [size]=\"customerCollectionFiltered.length > 0 ? 10 : 12\" style=\"border-right: 1px solid lightgray\">\n        <ion-item>\n          <ion-label *ngIf=\"customerCollectionFiltered.length === 0\">NO SE ENCUENTRAN COINCIDENCIAS</ion-label>\n          <ion-label *ngIf=\"customerCollectionFiltered.length === 1\">{{customerCollectionFiltered.length}} CLIENTE</ion-label>\n          <ion-label *ngIf=\"customerCollectionFiltered.length > 1\">{{customerCollectionFiltered.length}} CLIENTES</ion-label>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\" *ngIf=\"customerCollectionFiltered.length > 0\">\n        <ion-item>\n          <ion-icon (click)=\"presentModal()\" name=\"options-outline\"></ion-icon>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-card\n    *ngFor=\"let customer of customerCollectionFiltered\"\n    (click)=\"goToDetail(customer)\"\n    button=\"true\">\n    <ion-grid class=\"customer-card\">\n      <ion-row class=\"customer-row\">\n        <ion-col class=\"customer-image\" size=\"3\">\n          <img [src]=\"customer.photoURL\" />\n        </ion-col>\n        <ion-col size=\"8\" class=\"p-4 mt-3\">\n          <ion-label >{{\n            customer.name + \" \" + customer.lastname\n          }}</ion-label>\n           <p class=\"\">{{\n            customer.phone\n          }}</p>\n        </ion-col>\n        <ion-col size=\"1\">\n          <div class=\"icon-container\">\n            <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n  <ion-card *ngIf=\"!showNoData && customerCollectionFiltered.length === 0\">\n    <ion-grid class=\"customer-card\">\n      <ion-row class=\"customer-row\">\n        <ion-col size=\"12\">\n          <ion-item class=\"textbox\">\n            <ion-label slot=\"start\">Crear a <b>{{customerSearch}}</b></ion-label>\n            <ion-button (click)=\"goToCreate()\" slot=\"end\" expand=\"block\" fill=\"clear\" shape=\"round\">\n              <ion-icon name=\"add\"></ion-icon>\n            </ion-button>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n  <app-no-data *ngIf=\"showNoData && customerCollectionFiltered.length === 0\" [title]=\"'Parece que aún no tienes clientes'\"></app-no-data>\n</ion-content>\n";

/***/ }),

/***/ 46730:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button *ngIf=\"backButton\" slot=\"start\" text=\"\" defaultHref=\"tabs/profile\" color=\"dark\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title *ngIf=\"titleCase\">{{titlePage | translateDays | titlecase}}</ion-title>\n    <ion-title *ngIf=\"!titleCase\">{{titlePage | translateDays }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_customer_customer_module_ts.js.map