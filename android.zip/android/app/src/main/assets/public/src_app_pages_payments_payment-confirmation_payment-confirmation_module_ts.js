"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_payments_payment-confirmation_payment-confirmation_module_ts"],{

/***/ 54840:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/payments/payment-confirmation/payment-confirmation-routing.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentConfirmationPageRoutingModule": () => (/* binding */ PaymentConfirmationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _payment_confirmation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-confirmation.page */ 48002);




const routes = [
    {
        path: '',
        component: _payment_confirmation_page__WEBPACK_IMPORTED_MODULE_0__.PaymentConfirmationPage
    }
];
let PaymentConfirmationPageRoutingModule = class PaymentConfirmationPageRoutingModule {
};
PaymentConfirmationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentConfirmationPageRoutingModule);



/***/ }),

/***/ 30786:
/*!************************************************************************************!*\
  !*** ./src/app/pages/payments/payment-confirmation/payment-confirmation.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentConfirmationPageModule": () => (/* binding */ PaymentConfirmationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _payment_confirmation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-confirmation-routing.module */ 54840);
/* harmony import */ var _payment_confirmation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-confirmation.page */ 48002);







let PaymentConfirmationPageModule = class PaymentConfirmationPageModule {
};
PaymentConfirmationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _payment_confirmation_routing_module__WEBPACK_IMPORTED_MODULE_0__.PaymentConfirmationPageRoutingModule
        ],
        declarations: [_payment_confirmation_page__WEBPACK_IMPORTED_MODULE_1__.PaymentConfirmationPage]
    })
], PaymentConfirmationPageModule);



/***/ }),

/***/ 48002:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/payments/payment-confirmation/payment-confirmation.page.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentConfirmationPage": () => (/* binding */ PaymentConfirmationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _payment_confirmation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-confirmation.page.html?ngResource */ 24);
/* harmony import */ var _payment_confirmation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-confirmation.page.scss?ngResource */ 78418);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 65485);






let PaymentConfirmationPage = class PaymentConfirmationPage {
    constructor(router, navCtrl) {
        this.router = router;
        this.navCtrl = navCtrl;
        if (this.router.getCurrentNavigation().extras.state) {
            this.paymentData = this.router.getCurrentNavigation().extras.state.payment;
            this.paymentMethod = this.router.getCurrentNavigation().extras.state.paymentMethod;
        }
    }
    ngOnInit() { }
    goHome() {
        this.navCtrl.navigateForward(['tabs/home']);
    }
};
PaymentConfirmationPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
PaymentConfirmationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-payment-confirmation',
        template: _payment_confirmation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewEncapsulation.ShadowDom,
        styles: [_payment_confirmation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentConfirmationPage);



/***/ }),

/***/ 78418:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/payments/payment-confirmation/payment-confirmation.page.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-content, ion-item {\n  --background: rgb(86 197 124);\n  --color: white;\n}\n\n.payment-confirmed {\n  margin-top: 50%;\n  text-align: center;\n}\n\n.payment-confirmed .payment-icon {\n  font-size: 128px;\n}\n\n.payment-confirmed h1, .payment-confirmed h2 {\n  color: white;\n}\n\n.payment-confirmed .filter {\n  filter: invert(1);\n}\n\n.accept-button {\n  margin: 20px 20px 40px 20px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnQtY29uZmlybWF0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDZCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBRUY7O0FBQUU7RUFDRSxnQkFBQTtBQUVKOztBQUFFO0VBQ0UsWUFBQTtBQUVKOztBQUFFO0VBQ0UsaUJBQUE7QUFFSjs7QUFFQTtFQUNFLHNDQUFBO0FBQ0YiLCJmaWxlIjoicGF5bWVudC1jb25maXJtYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQsIGlvbi1pdGVtIHtcclxuICAtLWJhY2tncm91bmQ6IHJnYig4NiAxOTcgMTI0KTtcclxuICAtLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4ucGF5bWVudC1jb25maXJtZWQge1xyXG4gIG1hcmdpbi10b3A6IDUwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gIC5wYXltZW50LWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxMjhweDtcclxuICB9XHJcbiAgaDEsaDIge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICAuZmlsdGVyIHtcclxuICAgIGZpbHRlcjogaW52ZXJ0KDEpO1xyXG4gIH1cclxufVxyXG5cclxuLmFjY2VwdC1idXR0b24ge1xyXG4gIG1hcmdpbjogMjBweCAyMHB4IDQwcHggMjBweCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 24:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/payments/payment-confirmation/payment-confirmation.page.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "\n\n<ion-content fullscreen=\"true\">\n  <div class=\"payment-confirmed\">\n    <ion-icon class=\"filter payment-icon\" src=\"assets/icon/payment-done.svg\"></ion-icon>\n    <h1>Venta confirmada · {{paymentData.amount}}<span *ngIf=\"paymentData.decimals !== 0\">.{{paymentData.decimals}}<span *ngIf=\"paymentData.decimals !== 0 && paymentData.decimals.toString().length == 1 \">0</span> </span>€</h1>\n      <ion-item>\n        <ion-icon slot=\"start\" name=\"person-outline\"></ion-icon>\n        <ion-label>Cliente <p>{{paymentData.customer.name}}</p></ion-label>\n      </ion-item>\n      <ion-item *ngIf=\"paymentData.product && paymentData.product.length > 0\">\n        <ion-icon slot=\"start\" name=\"pricetag-outline\"></ion-icon>\n        <ion-label>Producto<span *ngIf=\"paymentData.product.length > 1\">s</span><p *ngFor=\"let product of paymentData.product\">{{product.name}}</p></ion-label>\n      </ion-item>\n      <ion-item *ngIf=\"paymentData.service && paymentData.service.length > 0\">\n        <ion-icon slot=\"start\" name=\"cut-outline\"></ion-icon>\n        <ion-label>Servicio<span *ngIf=\"paymentData.service.length > 1\">s</span><p *ngFor=\"let service of paymentData.service\">{{service.name}}</p></ion-label>\n      </ion-item>\n      <ion-item>\n        <ion-icon slot=\"start\" name=\"wallet-outline\"></ion-icon>\n        <ion-label>Método de pago <p>{{paymentMethod.label}}</p></ion-label>\n      </ion-item>\n  </div>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-button class=\"btn accept-button\" (click)=\"goHome()\" expand=\"block\">\n          Aceptar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_payments_payment-confirmation_payment-confirmation_module_ts.js.map