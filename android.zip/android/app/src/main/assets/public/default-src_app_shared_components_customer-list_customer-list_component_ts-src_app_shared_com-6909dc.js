"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"],{

/***/ 84013:
/*!********************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysModule": () => (/* binding */ TranslateDaysModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-days.pipe */ 29069);





let TranslateDaysModule = class TranslateDaysModule {
};
TranslateDaysModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe]
    })
], TranslateDaysModule);



/***/ }),

/***/ 29069:
/*!******************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysPipe": () => (/* binding */ TranslateDaysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TranslateDaysPipe = class TranslateDaysPipe {
    transform(value) {
        const daysTranslated = {
            monday: 'lunes',
            tuesday: 'martes',
            wednesday: 'miércoles',
            thursday: 'jueves',
            friday: 'viernes',
            saturday: 'sábado',
            sunday: 'domingo'
        };
        return daysTranslated[value] || value;
    }
};
TranslateDaysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'translateDays'
    })
], TranslateDaysPipe);



/***/ }),

/***/ 20161:
/*!************************************************************!*\
  !*** ./src/app/core/services/customer/customer.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerService": () => (/* binding */ CustomerService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let CustomerService = class CustomerService {
    constructor(http) {
        this.http = http;
    }
    getAllCustomer() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`);
    }
    getAllCustomerByCommerce(commerceId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/commerce/${commerceId}`);
    }
    getAllCustomerByCommerceAndCreatedBy(commerce) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/commerceAndCreatedBy/${commerce}`);
    }
    getCustomersByRecentFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/recent`);
    }
    getCustomersByLoyaltyFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/loyal`);
    }
    getCustomersByNonAttendantFilter() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/filter/non-attendant`);
    }
    getWalkinCustomer() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/walkin/walkin`);
    }
    saveCustomer(customer) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`, customer);
    }
    updateCustomer(customer) {
        return this.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer`, customer);
    }
    deleteCustomer(customer) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/customer/${customer.uuid}`);
    }
};
CustomerService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
CustomerService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], CustomerService);



/***/ }),

/***/ 57396:
/*!**********************************************************!*\
  !*** ./src/app/core/services/product/product.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductService": () => (/* binding */ ProductService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);




let ProductService = class ProductService {
    constructor(http) {
        this.http = http;
    }
    getAll() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`);
    }
    getByCommerce(commerceId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product/${commerceId}`);
    }
    create(product) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`, product);
    }
    update(product) {
        return this.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`, product);
    }
    deleteProduct(uuid) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product/${uuid}`);
    }
};
ProductService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProductService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProductService);



/***/ }),

/***/ 19708:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/customer-list/customer-list.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerListComponent": () => (/* binding */ CustomerListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _customer_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-list.component.html?ngResource */ 78286);
/* harmony import */ var _customer_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-list.component.scss?ngResource */ 51382);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/customer/customer.service */ 20161);







let CustomerListComponent = class CustomerListComponent {
    constructor(customerService, activatedRoute, modalCtrl, navCtrl) {
        this.customerService = customerService;
        this.activatedRoute = activatedRoute;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.customerCollection = [];
        this.customerCollectionFiltered = [];
        this.customerSearch = '';
        this.showNoData = false;
        this.isNewBooking = false;
        this.isNewPayment = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.customerSearch = '';
        this.searchbar.value = '';
    }
    ngOnInit() {
        this.getAllCustomerByCommerceAndCreatedBy();
    }
    getAllCustomerByCommerceAndCreatedBy() {
        this.customerService.getAllCustomerByCommerceAndCreatedBy(this.commerceLogged).subscribe((res) => {
            if (res) {
                res.map((customer) => {
                    if (!customer.photoURL) {
                        let initials = customer.name.slice(0, 2);
                        if (customer.lastname) {
                            initials = `${customer.name.slice(0, 1)}${customer.lastname.slice(0, 1)}`;
                        }
                        customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                    }
                });
                this.customerCollection = res;
                this.customerCollectionFiltered = this.customerCollection;
                if (this.customerCollection.length === 0) {
                    this.showNoData = true;
                }
            }
        });
    }
    selectCustomer(item) {
        this.selectedCustomer = item;
        this.dismiss();
    }
    searchCustomer(event) {
        const value = event.target.value;
        this.customerSearch = value;
        this.customerCollectionFiltered = this.customerCollection;
        if (value.length >= 3) {
            this.customerCollectionFiltered = this.customerCollectionFiltered.filter((customer) => customer.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    goToCreate() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.modalCtrl.dismiss();
            if (this.isNewBooking) {
                const navigationExtras = {
                    state: { createFastCustomer: '', isNewBooking: this.isNewBooking, isNewPayment: this.isNewPayment }
                };
                this.navCtrl.navigateForward(['tabs/home/new-booking/customer-detail'], navigationExtras);
            }
            else if (this.isNewPayment) {
                const navigationExtras = {
                    state: { createFastCustomer: '', isNewBooking: this.isNewBooking, isNewPayment: this.isNewPayment }
                };
                this.navCtrl.navigateForward(['tabs/payments/customer-detail'], navigationExtras);
            }
        });
    }
    dismiss() {
        this.modalCtrl.dismiss({
            customer: this.selectedCustomer
        });
    }
};
CustomerListComponent.ctorParameters = () => [
    { type: src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__.CustomerService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
CustomerListComponent.propDecorators = {
    searchbar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['searchbar', { static: false },] }]
};
CustomerListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-customer-list',
        template: _customer_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customer_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomerListComponent);



/***/ }),

/***/ 53957:
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/product-list/product-list.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductListComponent": () => (/* binding */ ProductListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _product_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-list.component.html?ngResource */ 23130);
/* harmony import */ var _product_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-list.component.scss?ngResource */ 8545);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/product/product.service */ 57396);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);







let ProductListComponent = class ProductListComponent {
    constructor(productService, modalCtrl, navParams, authService) {
        this.productService = productService;
        this.modalCtrl = modalCtrl;
        this.navParams = navParams;
        this.authService = authService;
        this.productCollection = [];
        this.productCollectionFiltered = [];
        this.selectedProduct = [];
        this.qtySelected = [];
        this.productSelected = [];
        this.qtyProductCollection = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        const productsAlreadySelected = this.navParams.get('productSelected');
        if (productsAlreadySelected.length > 0) {
            this.selectedProduct = productsAlreadySelected;
        }
    }
    ngOnInit() {
        this.getAllProducts();
    }
    getAllProducts() {
        ;
        this.productService.getByCommerce(this.commerceLogged).subscribe(response => {
            this.productCollection = response;
            this.productCollectionFiltered = this.productCollection;
            this.productCollectionFiltered.forEach(product => {
                this.qtyProductCollection.push(this.generateQtyArray(product));
            });
        });
    }
    searchProduct(event) {
        const value = event.target.value;
        this.productCollectionFiltered = this.productCollection;
        if (value.length >= 3) {
            this.productCollectionFiltered = this.productCollectionFiltered.filter((product) => product.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    dismiss(withProduct) {
        withProduct ? this.modalCtrl.dismiss(this.productSelected) : this.modalCtrl.dismiss();
    }
    onChangeValue(event, product, indexProduct) {
        const qty = event.detail.value;
        const productSelected = this.productCollection.find(item => item.uuid === product.uuid);
        const cardFromProduct = document.getElementById(`card_${indexProduct}`);
        if (qty !== 0) {
            productSelected.qty = qty;
            this.productSelected.push(productSelected);
            cardFromProduct.classList.add('fill-input');
        }
        else {
            const productIndex = this.productSelected.findIndex(item => item.uuid === product.uuid);
            if (productIndex !== -1) {
                this.productSelected.splice(productIndex, 1);
            }
            if (cardFromProduct.classList.contains('fill-input')) {
                cardFromProduct.classList.remove('fill-input');
            }
        }
    }
    generateQtyArray(product) {
        const qtyArray = [];
        for (let i = 0; i <= product.qty; i++)
            qtyArray.push(i);
        return qtyArray;
    }
    setSelectedClass(selectedProduct) {
        let classToApply = '';
        const findProduct = this.selectedProduct.find(item => item.uuid === selectedProduct.uuid);
        if (findProduct) {
            classToApply = 'fill-input';
        }
        return classToApply;
    }
    selectProduct(product) {
        const select = document.getElementById(product.uuid);
        if (select) {
            select.open();
        }
    }
    setSelectOptionValue(product) {
        if (this.selectedProduct.length > 0) {
            const findProduct = this.selectedProduct.find(item => item.uuid === product.uuid);
            if (findProduct) {
                return findProduct.qty;
            }
        }
        return 0;
    }
};
ProductListComponent.ctorParameters = () => [
    { type: src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_2__.ProductService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavParams },
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService }
];
ProductListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-product-list',
        template: _product_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProductListComponent);



/***/ }),

/***/ 89470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 46730);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 70847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let HeaderComponent = class HeaderComponent {
    constructor() {
        this.titleCase = true;
    }
    ngOnInit() { }
};
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    backButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titlePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titleCase: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 57185:
/*!************************************************!*\
  !*** ./src/app/shared/header/header.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderModule": () => (/* binding */ HeaderModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component */ 89470);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);






let HeaderModule = class HeaderModule {
};
HeaderModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__.TranslateDaysModule
        ],
        exports: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent]
    })
], HeaderModule);



/***/ }),

/***/ 51382:
/*!*****************************************************************************************!*\
  !*** ./src/app/shared/components/customer-list/customer-list.component.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = ".customer-card {\n  padding: 0;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  display: block;\n  margin-top: 15%;\n  margin-left: 5%;\n}\nion-searchbar {\n  --background: rgb(228, 228, 228);\n  --cancel-button-color: black;\n}\nion-item {\n  --inner-border-width: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWVyLWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxVQUFBO0FBQ0o7QUFDSTtFQUNJLG1CQUFBO0FBQ1I7QUFDUTtFQUNJLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFDWjtBQUVRO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQUFaO0FBR1E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFEWjtBQU1BO0VBQ0ksZ0NBQUE7RUFDQSw0QkFBQTtBQUhKO0FBTUE7RUFDSSx5QkFBQTtBQUhKIiwiZmlsZSI6ImN1c3RvbWVyLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tZXItY2FyZCB7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG5cclxuICAgIC5jdXN0b21lci1yb3cge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcblxyXG4gICAgICAgIC5jdXN0b21lci1pbWFnZSB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTkwJTtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmN1c3RvbWVyLWxhYmVsIHtcclxuICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1JTtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuaW9uLXNlYXJjaGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgIC0tY2FuY2VsLWJ1dHRvbi1jb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwcHg7XHJcbn1cclxuXHJcbiJdfQ== */";

/***/ }),

/***/ 8545:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/product-list/product-list.component.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = ".product-card {\n  padding-bottom: 10px;\n  padding: 0;\n  max-height: 43.5px;\n}\n.product-card .product-row {\n  border-radius: 15px;\n}\n.product-card .product-row .product-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.product-card .product-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.product-card .product-row .product-label {\n  display: block;\n  margin-top: 5%;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\n.product-card .product-row .select-label {\n  display: none;\n}\n.product-card .product-row .qty-select {\n  width: 100%;\n  padding: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBQ0Y7QUFBRTtFQUNFLG1CQUFBO0FBRUo7QUFESTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFHTjtBQURJO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUdOO0FBREk7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUdOO0FBREk7RUFDRSxhQUFBO0FBR047QUFESTtFQUNFLFdBQUE7RUFDQSxVQUFBO0FBR04iLCJmaWxlIjoicHJvZHVjdC1saXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2R1Y3QtY2FyZCB7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICBwYWRkaW5nOiAwO1xuICBtYXgtaGVpZ2h0OiA0My41cHg7XG4gIC5wcm9kdWN0LXJvdyB7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcbiAgICAucHJvZHVjdC1pbWFnZSB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjI4LCAyMjgsIDIyOCk7XG4gICAgICBwYWRkaW5nOiAwO1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cbiAgICAuaWNvbi1jb250YWluZXIge1xuICAgICAgbWFyZ2luLXRvcDogMTkwJTtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG4gICAgLnByb2R1Y3QtbGFiZWwge1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICAgIG1hcmdpbi1sZWZ0OiA1JTtcbiAgICAgIG1hcmdpbi1ib3R0b206IDMlO1xuICAgIH1cbiAgICAuc2VsZWN0LWxhYmVsIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuICAgIC5xdHktc2VsZWN0IHtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgcGFkZGluZzogMDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */";

/***/ }),

/***/ 70847:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0 !important;\n}\n\nion-back-button {\n  --icon-margin-start: 10px;\n  --icon-margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0FBQ0YiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1iYWNrLWJ1dHRvbiB7XHJcbiAgLS1pY29uLW1hcmdpbi1zdGFydDogMTBweDtcclxuICAtLWljb24tbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 78286:
/*!*****************************************************************************************!*\
  !*** ./src/app/shared/components/customer-list/customer-list.component.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Clientes</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-searchbar\n    #searchbar\n    (ionInput)=\"searchCustomer($event)\"\n    showCancelButton=\"focus\"\n    placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\"\n    animated\n  ></ion-searchbar>\n\n  <ion-grid\n    fixed\n    style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\"\n  >\n    <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-label\n            >{{ customerCollectionFiltered.length }} Clientes</ion-label\n          >\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid><ng-container >\n      <ion-grid class=\"customer-card\">\n        <ion-row class=\"customer-row\">\n          <ion-col size=\"12\">\n            <ion-item (click)=\"goToCreate()\" class=\"textbox\">\n              <ion-label slot=\"start\">Crear nuevo cliente</ion-label>\n              <ion-button  slot=\"end\" expand=\"block\" fill=\"clear\" shape=\"round\">\n                <ion-icon name=\"add\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n  </ng-container>\n  <ng-container *ngFor=\"let customer of customerCollectionFiltered\">\n    <ion-card\n      (click)=\"selectCustomer(customer)\"\n      button=\"true\"\n      [ngClass]=\"customer.uuid === selectedCustomer?.uuid ? 'selectedCard' : ''\"\n    >\n      <ion-grid class=\"customer-card\">\n        <ion-row class=\"customer-row\">\n          <ion-col class=\"customer-image\" size=\"3\">\n            <img [src]=\"customer.photoURL\" />\n          </ion-col>\n          <ion-col size=\"8\" class=\"p-4 mt-3\">\n            <ion-label >{{\n              customer.name + \" \" + customer.lastname\n            }}</ion-label>\n             <p class=\"\">{{\n              customer.phone\n            }}</p>\n          </ion-col>\n          <ion-col size=\"1\"> </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n\n  </ng-container>\n\n</ion-content>\n<!-- <ion-footer>\n  <ion-button\n    [disabled]=\"selectedCustomer === undefined\"\n    color=\"dark\"\n    (click)=\"dismiss()\"\n    class=\"apply-button\"\n    expand=\"block\"\n    mode=\"ios\"\n  >\n    Seleccionar cliente\n  </ion-button>\n</ion-footer> -->\n";

/***/ }),

/***/ 23130:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/product-list/product-list.component.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Productos</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss(false)\">\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-searchbar (ionInput)=\"searchProduct($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n  <ion-grid fixed style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\">\n    <ion-row>\n      <ion-col style=\"border-right: 1px solid lightgray\">\n        <ion-item>\n          <ion-label *ngIf=\"productCollectionFiltered.length === 1\">{{ productCollectionFiltered.length }} Producto</ion-label>\n          <ion-label *ngIf=\"productCollectionFiltered.length > 1\">{{ productCollectionFiltered.length }} Productos</ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ng-container *ngFor=\"let product of productCollectionFiltered; let i = index\">\n    <ion-card button=\"true\" class=\"card\" button=\"true\" [ngClass]=\"setSelectedClass(product)\" id=\"{{'card_'+i}}\">\n      <ion-grid class=\"product-card\">\n        <ion-row class=\"product-row\">\n          <ion-col size=\"0.1\" class=\"black\"></ion-col>\n          <ion-col class=\"no-padding\">\n            <ion-item>\n              <ion-label class=\"service-label\">\n                {{ product?.name }} · {{ product.price + \" €\" }}\n              </ion-label>\n               <ion-select [id]=\"product.uuid\" [value]=\"setSelectOptionValue(product)\" (ionChange)=\"onChangeValue($event, product, i)\" okText=\"Aceptar\" cancelText=\"Cancelar\">\n                <ion-select-option *ngFor=\"let unit of qtyProductCollection[i]\" [value]=\"unit\">{{unit}}</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </ng-container>\n  <app-no-data *ngIf=\"productCollectionFiltered.length === 0\" [title]=\"'Parece que aún no tienes productos'\" [content]=\"false\"></app-no-data>\n</ion-content>\n<ion-footer>\n  <ion-button [disabled]=\"productSelected.length === 0\" color=\"dark\" (click)=\"dismiss(true)\" class=\"apply-button\"\n    expand=\"block\" mode=\"ios\">\n    Seleccionar producto<span *ngIf=\"productSelected.length > 1\">s ({{productSelected.length}})</span>\n  </ion-button>\n</ion-footer>\n";

/***/ }),

/***/ 46730:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button *ngIf=\"backButton\" slot=\"start\" text=\"\" defaultHref=\"tabs/profile\" color=\"dark\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title *ngIf=\"titleCase\">{{titlePage | translateDays | titlecase}}</ion-title>\n    <ion-title *ngIf=\"!titleCase\">{{titlePage | translateDays }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc.js.map