"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_support_support-ticket_support-ticket_module_ts"],{

/***/ 13721:
/*!******************************************************!*\
  !*** ./src/app/core/models/comment/comment.model.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TicketComment": () => (/* binding */ TicketComment)
/* harmony export */ });
class TicketComment {
}


/***/ }),

/***/ 30578:
/*!****************************************************!*\
  !*** ./src/app/core/models/ticket/ticket.model.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ticket": () => (/* binding */ Ticket)
/* harmony export */ });
class Ticket {
}


/***/ }),

/***/ 75345:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/profile/support/support-ticket/support-ticket-routing.module.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportTicketPageRoutingModule": () => (/* binding */ SupportTicketPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _support_ticket_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-ticket.page */ 51239);




const routes = [
    {
        path: '',
        component: _support_ticket_page__WEBPACK_IMPORTED_MODULE_0__.SupportTicketPage
    }
];
let SupportTicketPageRoutingModule = class SupportTicketPageRoutingModule {
};
SupportTicketPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SupportTicketPageRoutingModule);



/***/ }),

/***/ 68800:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/profile/support/support-ticket/support-ticket.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportTicketPageModule": () => (/* binding */ SupportTicketPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _support_ticket_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-ticket-routing.module */ 75345);
/* harmony import */ var _support_ticket_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./support-ticket.page */ 51239);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);








let SupportTicketPageModule = class SupportTicketPageModule {
};
SupportTicketPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _support_ticket_routing_module__WEBPACK_IMPORTED_MODULE_0__.SupportTicketPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__.HeaderModule
        ],
        declarations: [_support_ticket_page__WEBPACK_IMPORTED_MODULE_1__.SupportTicketPage]
    })
], SupportTicketPageModule);



/***/ }),

/***/ 51239:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/profile/support/support-ticket/support-ticket.page.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportTicketPage": () => (/* binding */ SupportTicketPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _support_ticket_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support-ticket.page.html?ngResource */ 66789);
/* harmony import */ var _support_ticket_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./support-ticket.page.scss?ngResource */ 44232);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_models_comment_comment_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/models/comment/comment.model */ 13721);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var src_app_core_models_ticket_ticket_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/ticket/ticket.model */ 30578);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_app_core_models_enums_ticket_status_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/enums/ticket-status.enum */ 5594);
/* harmony import */ var src_app_core_services_support_support_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/support/support.service */ 76423);











let SupportTicketPage = class SupportTicketPage {
    constructor(router, formBuilder, supportService, navCtrl) {
        this.router = router;
        this.formBuilder = formBuilder;
        this.supportService = supportService;
        this.navCtrl = navCtrl;
        this.title = 'Crear nuevo ticket';
        this.isNew = true;
        this.commentContent = '';
        this.typeCollection = [
            {
                label: 'general'
            },
            {
                label: 'fallo en la aplicación'
            },
            {
                label: 'otro'
            }
        ];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        if (this.router.getCurrentNavigation().extras.state) {
            this.currentTicket = this.router.getCurrentNavigation().extras.state.ticket;
            this.title = 'Gestionar ticket';
            this.isNew = false;
        }
    }
    get type() {
        return this.ticketForm.get('type');
    }
    get description() {
        return this.ticketForm.get('description');
    }
    ngOnInit() {
        this.initForms();
    }
    initForms() {
        this.ticketForm = this.formBuilder.group({
            type: [{ value: this.currentTicket ? this.currentTicket.type : '', disabled: this.currentTicket }, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            description: [{ value: this.currentTicket ? this.currentTicket.description : '', disabled: this.currentTicket }, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
        });
    }
    saveTicket() {
        const newTicket = this.createTicket();
        this.supportService.createNewTicket(newTicket).subscribe(response => {
            if (response) {
                this.isNew = false;
                this.title = 'Gestionar ticket';
                this.currentTicket = response;
                this.type.disable({ onlySelf: true });
                this.description.disable({ onlySelf: true });
                const newTicketComment = this.createDefaultSupportCommentTicket();
                this.sendComment(newTicketComment);
            }
        });
    }
    createComment() {
        const newComment = new _core_models_comment_comment_model__WEBPACK_IMPORTED_MODULE_2__.TicketComment();
        newComment.content = this.commentContent;
        newComment.from = 'commerce';
        newComment.ticket = this.currentTicket.uuid;
        newComment.createdAt = new Date();
        newComment.updatedAt = new Date();
        this.sendComment(newComment);
    }
    sendComment(newComment) {
        this.supportService.createNewComment(newComment).subscribe(response => {
            if (response) {
                this.currentTicket.comments.push(response);
                this.commentContent = '';
            }
        });
    }
    createTicket() {
        const newTicket = new src_app_core_models_ticket_ticket_model__WEBPACK_IMPORTED_MODULE_3__.Ticket();
        newTicket.commerce = this.commerceLogged;
        newTicket.type = this.type.value;
        newTicket.description = this.description.value;
        newTicket.status = src_app_core_models_enums_ticket_status_enum__WEBPACK_IMPORTED_MODULE_4__.TicketStatus.PENDING;
        newTicket.comments = [];
        newTicket.createdAt = new Date();
        newTicket.updatedAt = new Date();
        return newTicket;
    }
    createDefaultSupportCommentTicket() {
        const defaultSupportCommentTicket = new _core_models_comment_comment_model__WEBPACK_IMPORTED_MODULE_2__.TicketComment();
        defaultSupportCommentTicket.content = 'Buenas, gracias por contactar con el servicio técnico. Nos pondremos en contacto contigo mediante este ticket con la mayor brevedad posible. Gracias';
        defaultSupportCommentTicket.from = 'manager';
        defaultSupportCommentTicket.ticket = this.currentTicket.uuid;
        defaultSupportCommentTicket.createdAt = new Date();
        defaultSupportCommentTicket.updatedAt = new Date();
        return defaultSupportCommentTicket;
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/support'], { replaceUrl: true });
    }
};
SupportTicketPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: src_app_core_services_support_support_service__WEBPACK_IMPORTED_MODULE_5__.SupportService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController }
];
SupportTicketPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-support-ticket',
        template: _support_ticket_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_support_ticket_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SupportTicketPage);



/***/ }),

/***/ 44232:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/profile/support/support-ticket/support-ticket.page.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ".textbox ion-label {\n  padding: 0px 0px;\n}\n\n.textbox .correct-possition {\n  padding-top: 10px;\n  margin-left: -5px;\n}\n\n.group-message {\n  margin: 0px 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cHBvcnQtdGlja2V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtBQUNGIiwiZmlsZSI6InN1cHBvcnQtdGlja2V0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50ZXh0Ym94IGlvbi1sYWJlbCB7XG4gIHBhZGRpbmc6IDBweCAwcHg7XG59XG5cbi50ZXh0Ym94IC5jb3JyZWN0LXBvc3NpdGlvbiB7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogLTVweDtcbn1cblxuLmdyb3VwLW1lc3NhZ2Uge1xuICBtYXJnaW46IDBweCAxNHB4O1xufVxuIl19 */";

/***/ }),

/***/ 66789:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/profile/support/support-ticket/support-ticket.page.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"title\"></app-header>\n\n<ion-content>\n  <form [formGroup]=\"ticketForm\">\n    <ion-item class=\"textbox\" no-lines lines=\"none\">\n      <ion-label>Categoría</ion-label>\n      <ion-select #type formControlName=\"type\" cancelText=\"Cancelar\" okText=\"Aceptar\">\n        <ion-select-option *ngFor=\"let type of typeCollection\" [value]=\"type.label\">{{type.label | titlecase}}\n        </ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"textbox\" no-lines lines=\"none\">\n      <ion-grid>\n        <ion-row>\n          <ion-label class=\"correct-possition\">\n            Descripción\n          </ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-textarea ngDefaultControl formControlName=\"description\" type=\"text\"\n            placeholder=\"Describe tu problema de forma precisa aquí\" autocapitalize=\"true\">\n          </ion-textarea>\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </form>\n  <ion-grid *ngIf=\"currentTicket?.comments.length > 0\">\n    <hr>\n    <ion-row style=\"margin: 0px 14px;\">\n      <ion-col size=\"12\">\n        <h2 style=\"margin: 0;\">Conversación con el soporte técnico</h2>\n      </ion-col>\n    </ion-row>\n    <ion-row *ngFor=\"let comment of currentTicket.comments; let i = index\">\n      <ion-col size=\"12\">\n        <ion-item class=\"textbox\"\n          [ngClass]=\"currentTicket.comments[i].from === 'commerce'\n              && (currentTicket.comments[i - 1] && currentTicket.comments[i - 1].from === 'commerce'\n              || (currentTicket.comments[i + 1] && currentTicket.comments[i + 1].from === 'commerce')) ? 'group-message' : ''\">\n          <ion-icon *ngIf=\"comment.from === 'manager'\" slot=\"start\" size=\"large\" name=\"chatbubble-outline\"></ion-icon>\n          <ion-icon *ngIf=\"comment.from === 'commerce'\" slot=\"end\" size=\"large\" name=\"chatbubbles-outline\"></ion-icon>\n          <ion-label class=\"ion-text-wrap\">\n            {{comment.content}}\n            <br>\n            <hr>\n            <ion-note slot=\"end\">{{comment.createdAt | date: 'dd MMM yyyy • HH:mm:ss'}}</ion-note>\n          </ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n\n<ion-footer>\n  <ion-item *ngIf=\"!isNew && currentTicket?.status !== 'finished'\" class=\"textbox\">\n    <ion-textarea maxRows=\"4\" placeholder=\"Escribe aquí tu respuesta...\" [(ngModel)]=\"commentContent\" autocapitalize=\"true\"></ion-textarea>\n    <ion-icon name=\"paper-plane\" slot=\"end\" (click)=\"createComment()\"></ion-icon>\n  </ion-item>\n\n  <ion-grid *ngIf=\"isNew\">\n    <ion-row>\n      <ion-col\n       ><ion-button [disabled]=\"ticketForm.invalid\" (click)=\"saveTicket()\" class=\"btn\" expand=\"block\">\n         Crear ticket\n       </ion-button>\n     </ion-col>\n     </ion-row>\n </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_support_support-ticket_support-ticket_module_ts.js.map