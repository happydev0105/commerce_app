"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_core_pipes_format-hour_format-hour_module_ts-src_app_core_services_utils_utils_service_ts"],{

/***/ 5868:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/addDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addDays
 * @category Day Helpers
 * @summary Add the specified number of days to the given date.
 *
 * @description
 * Add the specified number of days to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} - the new date with the days added
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // Add 10 days to 1 September 2014:
 * const result = addDays(new Date(2014, 8, 1), 10)
 * //=> Thu Sep 11 2014 00:00:00
 */

function addDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyAmount);

  if (isNaN(amount)) {
    return new Date(NaN);
  }

  if (!amount) {
    // If 0 days, no-op to avoid changing times in the hour before end of DST
    return date;
  }

  date.setDate(date.getDate() + amount);
  return date;
}

/***/ }),

/***/ 37584:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/addWeeks/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addWeeks)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addWeeks
 * @category Week Helpers
 * @summary Add the specified number of weeks to the given date.
 *
 * @description
 * Add the specified number of week to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of weeks to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the weeks added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 4 weeks to 1 September 2014:
 * const result = addWeeks(new Date(2014, 8, 1), 4)
 * //=> Mon Sep 29 2014 00:00:00
 */

function addWeeks(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  var days = amount * 7;
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, days);
}

/***/ }),

/***/ 19040:
/*!***************************************************************!*\
  !*** ./node_modules/date-fns/esm/eachWeekOfInterval/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eachWeekOfInterval)
/* harmony export */ });
/* harmony import */ var _addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../addWeeks/index.js */ 37584);
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




/**
 * @name eachWeekOfInterval
 * @category Interval Helpers
 * @summary Return the array of weeks within the specified time interval.
 *
 * @description
 * Return the array of weeks within the specified time interval.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Interval} interval - the interval. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @returns {Date[]} the array with starts of weeks from the week of the interval start to the week of the interval end
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be 0, 1, ..., 6
 * @throws {RangeError} The start of an interval cannot be after its end
 * @throws {RangeError} Date in interval cannot be `Invalid Date`
 *
 * @example
 * // Each week within interval 6 October 2014 - 23 November 2014:
 * var result = eachWeekOfInterval({
 *   start: new Date(2014, 9, 6),
 *   end: new Date(2014, 10, 23)
 * })
 * //=> [
 * //   Sun Oct 05 2014 00:00:00,
 * //   Sun Oct 12 2014 00:00:00,
 * //   Sun Oct 19 2014 00:00:00,
 * //   Sun Oct 26 2014 00:00:00,
 * //   Sun Nov 02 2014 00:00:00,
 * //   Sun Nov 09 2014 00:00:00,
 * //   Sun Nov 16 2014 00:00:00,
 * //   Sun Nov 23 2014 00:00:00
 * // ]
 */

function eachWeekOfInterval(dirtyInterval, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var interval = dirtyInterval || {};
  var startDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.start);
  var endDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.end);
  var endTime = endDate.getTime(); // Throw an exception if start date is after end date or if any date is `Invalid Date`

  if (!(startDate.getTime() <= endTime)) {
    throw new RangeError('Invalid interval');
  }

  var startDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(startDate, options);
  var endDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(endDate, options); // Some timezones switch DST at midnight, making start of day unreliable in these timezones, 3pm is a safe bet

  startDateWeek.setHours(15);
  endDateWeek.setHours(15);
  endTime = endDateWeek.getTime();
  var weeks = [];
  var currentWeek = startDateWeek;

  while (currentWeek.getTime() <= endTime) {
    currentWeek.setHours(0);
    weeks.push((0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(currentWeek));
    currentWeek = (0,_addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(currentWeek, 1);
    currentWeek.setHours(15);
  }

  return weeks;
}

/***/ }),

/***/ 94623:
/*!**************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourModule": () => (/* binding */ FormatHourModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./format-hour.pipe */ 70653);





let FormatHourModule = class FormatHourModule {
};
FormatHourModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe]
    })
], FormatHourModule);



/***/ }),

/***/ 70653:
/*!************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.pipe.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourPipe": () => (/* binding */ FormatHourPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let FormatHourPipe = class FormatHourPipe {
    transform(hour) {
        if (hour === null || hour === undefined || hour === '') {
            return '';
        }
        ;
        let value = '';
        if (hour === 0 || hour === '0') {
            value = '00';
            return value;
        }
        if (hour && hour.toString().length === 1) {
            value = `0${hour.toString()}`;
            return value;
        }
        return '' + hour;
    }
};
FormatHourPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formatHour'
    })
], FormatHourPipe);



/***/ }),

/***/ 73372:
/*!******************************************************!*\
  !*** ./src/app/core/services/utils/utils.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UtilsService": () => (/* binding */ UtilsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! date-fns */ 19040);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns/locale */ 36956);




let UtilsService = class UtilsService {
    constructor() { }
    calculateToday() {
        const actualDate = new Date();
        const day = actualDate.getDate();
        const month = actualDate.getMonth() + 1;
        const monthFormatted = month.toString().length === 1 ? `0${month}` : month;
        const dayFormatted = day.toString().length === 1 ? `0${day}` : day;
        const year = actualDate.getFullYear();
        const actualDateFormatted = `${year}-${monthFormatted}-${dayFormatted}`;
        return actualDateFormatted;
    }
    capitalizeFirstLetter(text) {
        if (text.length >= 1) {
            const capitalize = text.charAt(0).toUpperCase();
            text = text.replace(text.charAt(0), capitalize);
        }
        return text;
    }
    generateRandomPassword() {
        const chars = '0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const passwordLength = 12;
        let password = '';
        for (let i = 0; i <= passwordLength; i++) {
            const randomNumber = Math.floor(Math.random() * chars.length);
            password += chars.substring(randomNumber, randomNumber + 1);
        }
        return password;
    }
    getAllDaysInMonth(year, month) {
        const date = new Date(year, month, 1);
        const dates = [];
        while (date.getMonth() === month) {
            const evaluateDay = new Date(date).getDate();
            dates.push({
                text: evaluateDay.toString(),
                value: evaluateDay,
            });
            if ((month === 3 || month === 5 || month === 8 || month === 10) && (evaluateDay === 30)) {
                dates.push({
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            if (month === 1 && evaluateDay === 28) {
                dates.push({
                    text: '29',
                    value: 29,
                    disabled: true
                }, {
                    text: '30',
                    value: 30,
                    disabled: true
                }, {
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            date.setDate(date.getDate() + 1);
        }
        return dates;
    }
    getAllWeeks() {
        const weekFormatted = [];
        const result = (0,date_fns__WEBPACK_IMPORTED_MODULE_0__["default"])({
            start: new Date(2022, 0, 2),
            end: new Date(2023, 0, 1)
        }, { weekStartsOn: 1 });
        result.forEach((week, index) => {
            if (result[index + 1]) {
                const weekItem = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] }) + ' ' + (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index + 1], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] });
                weekFormatted.push([weekItem, index + 1]);
            }
        });
        return weekFormatted;
    }
    getAllMonthsInYear() {
        const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        const monthCollection = [];
        months.forEach((month, index) => monthCollection.push({
            text: month,
            value: index + 1
        }));
        return monthCollection;
    }
    getYearsFromYeasyInit() {
        const yeasyYearInit = 2021;
        const currentDate = new Date();
        const actualYear = currentDate.getFullYear();
        const differenceYears = yeasyYearInit - actualYear;
        const yearCollection = [];
        if (differenceYears === 0) {
            return [{ text: '2022', value: 2022 }];
        }
        for (let i = differenceYears; i <= differenceYears; i++) {
            yearCollection.push({
                text: (yeasyYearInit - i).toString(),
                value: yeasyYearInit - i
            });
        }
        return yearCollection;
    }
    generateHours(start, end) {
        const hours = [];
        if (typeof start === 'string') {
            start = Number.parseInt(start, 10);
        }
        if (typeof end === 'string') {
            end = Number.parseInt(end, 10);
        }
        for (let i = start; i <= end; i++) {
            const hour = i.toString();
            hours.push(hour);
        }
        return hours;
    }
    generateMinutes() {
        const availableMinutes = 60;
        const minutes = [];
        for (let i = 0; i < availableMinutes; i += 5) {
            const minute = i.toString();
            minutes.push(minute);
        }
        return minutes;
    }
    transformHourStringIntoMinutes(hour) {
        let duration = 0;
        const hours = Number.parseInt(hour.split(':')[0], 10);
        const minutes = Number.parseInt(hour.split(':')[1], 10);
        duration += (hours * 60) + minutes;
        return duration;
    }
};
UtilsService.ctorParameters = () => [];
UtilsService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], UtilsService);



/***/ })

}]);
//# sourceMappingURL=src_app_core_pipes_format-hour_format-hour_module_ts-src_app_core_services_utils_utils_service_ts.js.map