"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_booking-manager_new-booking_new-booking_module_ts"],{

/***/ 47504:
/*!************************************************!*\
  !*** ./node_modules/date-fns/esm/add/index.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ add)
/* harmony export */ });
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _addMonths_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../addMonths/index.js */ 25277);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);






/**
 * @name add
 * @category Common Helpers
 * @summary Add the specified years, months, weeks, days, hours, minutes and seconds to the given date.
 *
 * @description
 * Add the specified years, months, weeks, days, hours, minutes and seconds to the given date.
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Duration} duration - the object with years, months, weeks, days, hours, minutes and seconds to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 *
 * | Key            | Description                        |
 * |----------------|------------------------------------|
 * | years          | Amount of years to be added        |
 * | months         | Amount of months to be added       |
 * | weeks          | Amount of weeks to be added        |
 * | days           | Amount of days to be added         |
 * | hours          | Amount of hours to be added        |
 * | minutes        | Amount of minutes to be added      |
 * | seconds        | Amount of seconds to be added      |
 *
 * All values default to 0
 *
 * @returns {Date} the new date with the seconds added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add the following duration to 1 September 2014, 10:19:50
 * const result = add(new Date(2014, 8, 1, 10, 19, 50), {
 *   years: 2,
 *   months: 9,
 *   weeks: 1,
 *   days: 7,
 *   hours: 5,
 *   minutes: 9,
 *   seconds: 30,
 * })
 * //=> Thu Jun 15 2017 15:29:20
 */
function add(dirtyDate, duration) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  if (!duration || typeof duration !== 'object') return new Date(NaN);
  var years = duration.years ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.years) : 0;
  var months = duration.months ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.months) : 0;
  var weeks = duration.weeks ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.weeks) : 0;
  var days = duration.days ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.days) : 0;
  var hours = duration.hours ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.hours) : 0;
  var minutes = duration.minutes ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.minutes) : 0;
  var seconds = duration.seconds ? (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(duration.seconds) : 0; // Add years and months

  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate);
  var dateWithMonths = months || years ? (0,_addMonths_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(date, months + years * 12) : date; // Add weeks and days

  var dateWithDays = days || weeks ? (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_4__["default"])(dateWithMonths, days + weeks * 7) : dateWithMonths; // Add days, hours, minutes and seconds

  var minutesToAdd = minutes + hours * 60;
  var secondsToAdd = seconds + minutesToAdd * 60;
  var msToAdd = secondsToAdd * 1000;
  var finalDate = new Date(dateWithDays.getTime() + msToAdd);
  return finalDate;
}

/***/ }),

/***/ 61535:
/*!******************************************************!*\
  !*** ./node_modules/date-fns/esm/formatISO/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ formatISO)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/addLeadingZeros/index.js */ 24362);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name formatISO
 * @category Common Helpers
 * @summary Format the date according to the ISO 8601 standard (https://support.sas.com/documentation/cdl/en/lrdict/64316/HTML/default/viewer.htm#a003169814.htm).
 *
 * @description
 * Return the formatted date string in ISO 8601 format. Options may be passed to control the parts and notations of the date.
 *
 * @param {Date|Number} date - the original date
 * @param {Object} [options] - an object with options.
 * @param {'extended'|'basic'} [options.format='extended'] - if 'basic', hide delimiters between date and time values.
 * @param {'complete'|'date'|'time'} [options.representation='complete'] - format date, time with local time zone, or both.
 * @returns {String} the formatted date string (in local time zone)
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `date` must not be Invalid Date
 * @throws {RangeError} `options.format` must be 'extended' or 'basic'
 * @throws {RangeError} `options.represenation` must be 'date', 'time' or 'complete'
 *
 * @example
 * // Represent 18 September 2019 in ISO 8601 format (local time zone is UTC):
 * const result = formatISO(new Date(2019, 8, 18, 19, 0, 52))
 * //=> '2019-09-18T19:00:52Z'
 *
 * @example
 * // Represent 18 September 2019 in ISO 8601, short format (local time zone is UTC):
 * const result = formatISO(new Date(2019, 8, 18, 19, 0, 52), { format: 'basic' })
 * //=> '20190918T190052'
 *
 * @example
 * // Represent 18 September 2019 in ISO 8601 format, date only:
 * const result = formatISO(new Date(2019, 8, 18, 19, 0, 52), { representation: 'date' })
 * //=> '2019-09-18'
 *
 * @example
 * // Represent 18 September 2019 in ISO 8601 format, time only (local time zone is UTC):
 * const result = formatISO(new Date(2019, 8, 18, 19, 0, 52), { representation: 'time' })
 * //=> '19:00:52Z'
 */

function formatISO(date, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var originalDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(date);

  if (isNaN(originalDate.getTime())) {
    throw new RangeError('Invalid time value');
  }

  var format = !(options !== null && options !== void 0 && options.format) ? 'extended' : String(options.format);
  var representation = !(options !== null && options !== void 0 && options.representation) ? 'complete' : String(options.representation);

  if (format !== 'extended' && format !== 'basic') {
    throw new RangeError("format must be 'extended' or 'basic'");
  }

  if (representation !== 'date' && representation !== 'time' && representation !== 'complete') {
    throw new RangeError("representation must be 'date', 'time', or 'complete'");
  }

  var result = '';
  var tzOffset = '';
  var dateDelimiter = format === 'extended' ? '-' : '';
  var timeDelimiter = format === 'extended' ? ':' : ''; // Representation is either 'date' or 'complete'

  if (representation !== 'time') {
    var day = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getDate(), 2);
    var month = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getMonth() + 1, 2);
    var year = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getFullYear(), 4); // yyyyMMdd or yyyy-MM-dd.

    result = "".concat(year).concat(dateDelimiter).concat(month).concat(dateDelimiter).concat(day);
  } // Representation is either 'time' or 'complete'


  if (representation !== 'date') {
    // Add the timezone.
    var offset = originalDate.getTimezoneOffset();

    if (offset !== 0) {
      var absoluteOffset = Math.abs(offset);
      var hourOffset = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Math.floor(absoluteOffset / 60), 2);
      var minuteOffset = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(absoluteOffset % 60, 2); // If less than 0, the sign is +, because it is ahead of time.

      var sign = offset < 0 ? '+' : '-';
      tzOffset = "".concat(sign).concat(hourOffset, ":").concat(minuteOffset);
    } else {
      tzOffset = 'Z';
    }

    var hour = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getHours(), 2);
    var minute = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getMinutes(), 2);
    var second = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getSeconds(), 2); // If there's also date, separate it with time with 'T'

    var separator = result === '' ? '' : 'T'; // Creates a time string consisting of hour, minute, and second, separated by delimiters, if defined.

    var time = [hour, minute, second].join(timeDelimiter); // HHmmss or HH:mm:ss.

    result = "".concat(result).concat(separator).concat(time).concat(tzOffset);
  }

  return result;
}

/***/ }),

/***/ 68097:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/parseISO/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseISO)
/* harmony export */ });
/* harmony import */ var _constants_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/index.js */ 97889);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);



/**
 * @name parseISO
 * @category Common Helpers
 * @summary Parse ISO string
 *
 * @description
 * Parse the given string in ISO 8601 format and return an instance of Date.
 *
 * Function accepts complete ISO 8601 formats as well as partial implementations.
 * ISO 8601: http://en.wikipedia.org/wiki/ISO_8601
 *
 * If the argument isn't a string, the function cannot parse the string or
 * the values are invalid, it returns Invalid Date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * - The previous `parse` implementation was renamed to `parseISO`.
 *
 *   ```javascript
 *   // Before v2.0.0
 *   parse('2016-01-01')
 *
 *   // v2.0.0 onward
 *   parseISO('2016-01-01')
 *   ```
 *
 * - `parseISO` now validates separate date and time values in ISO-8601 strings
 *   and returns `Invalid Date` if the date is invalid.
 *
 *   ```javascript
 *   parseISO('2018-13-32')
 *   //=> Invalid Date
 *   ```
 *
 * - `parseISO` now doesn't fall back to `new Date` constructor
 *   if it fails to parse a string argument. Instead, it returns `Invalid Date`.
 *
 * @param {String} argument - the value to convert
 * @param {Object} [options] - an object with options.
 * @param {0|1|2} [options.additionalDigits=2] - the additional number of digits in the extended year format
 * @returns {Date} the parsed date in the local time zone
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.additionalDigits` must be 0, 1 or 2
 *
 * @example
 * // Convert string '2014-02-11T11:30:30' to date:
 * const result = parseISO('2014-02-11T11:30:30')
 * //=> Tue Feb 11 2014 11:30:30
 *
 * @example
 * // Convert string '+02014101' to date,
 * // if the additional number of digits in the extended year format is 1:
 * const result = parseISO('+02014101', { additionalDigits: 1 })
 * //=> Fri Apr 11 2014 00:00:00
 */

function parseISO(argument, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var additionalDigits = options.additionalDigits == null ? 2 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.additionalDigits);

  if (additionalDigits !== 2 && additionalDigits !== 1 && additionalDigits !== 0) {
    throw new RangeError('additionalDigits must be 0, 1 or 2');
  }

  if (!(typeof argument === 'string' || Object.prototype.toString.call(argument) === '[object String]')) {
    return new Date(NaN);
  }

  var dateStrings = splitDateString(argument);
  var date;

  if (dateStrings.date) {
    var parseYearResult = parseYear(dateStrings.date, additionalDigits);
    date = parseDate(parseYearResult.restDateString, parseYearResult.year);
  }

  if (!date || isNaN(date.getTime())) {
    return new Date(NaN);
  }

  var timestamp = date.getTime();
  var time = 0;
  var offset;

  if (dateStrings.time) {
    time = parseTime(dateStrings.time);

    if (isNaN(time)) {
      return new Date(NaN);
    }
  }

  if (dateStrings.timezone) {
    offset = parseTimezone(dateStrings.timezone);

    if (isNaN(offset)) {
      return new Date(NaN);
    }
  } else {
    var dirtyDate = new Date(timestamp + time); // js parsed string assuming it's in UTC timezone
    // but we need it to be parsed in our timezone
    // so we use utc values to build date in our timezone.
    // Year values from 0 to 99 map to the years 1900 to 1999
    // so set year explicitly with setFullYear.

    var result = new Date(0);
    result.setFullYear(dirtyDate.getUTCFullYear(), dirtyDate.getUTCMonth(), dirtyDate.getUTCDate());
    result.setHours(dirtyDate.getUTCHours(), dirtyDate.getUTCMinutes(), dirtyDate.getUTCSeconds(), dirtyDate.getUTCMilliseconds());
    return result;
  }

  return new Date(timestamp + time + offset);
}
var patterns = {
  dateTimeDelimiter: /[T ]/,
  timeZoneDelimiter: /[Z ]/i,
  timezone: /([Z+-].*)$/
};
var dateRegex = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/;
var timeRegex = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/;
var timezoneRegex = /^([+-])(\d{2})(?::?(\d{2}))?$/;

function splitDateString(dateString) {
  var dateStrings = {};
  var array = dateString.split(patterns.dateTimeDelimiter);
  var timeString; // The regex match should only return at maximum two array elements.
  // [date], [time], or [date, time].

  if (array.length > 2) {
    return dateStrings;
  }

  if (/:/.test(array[0])) {
    timeString = array[0];
  } else {
    dateStrings.date = array[0];
    timeString = array[1];

    if (patterns.timeZoneDelimiter.test(dateStrings.date)) {
      dateStrings.date = dateString.split(patterns.timeZoneDelimiter)[0];
      timeString = dateString.substr(dateStrings.date.length, dateString.length);
    }
  }

  if (timeString) {
    var token = patterns.timezone.exec(timeString);

    if (token) {
      dateStrings.time = timeString.replace(token[1], '');
      dateStrings.timezone = token[1];
    } else {
      dateStrings.time = timeString;
    }
  }

  return dateStrings;
}

function parseYear(dateString, additionalDigits) {
  var regex = new RegExp('^(?:(\\d{4}|[+-]\\d{' + (4 + additionalDigits) + '})|(\\d{2}|[+-]\\d{' + (2 + additionalDigits) + '})$)');
  var captures = dateString.match(regex); // Invalid ISO-formatted year

  if (!captures) return {
    year: NaN,
    restDateString: ''
  };
  var year = captures[1] ? parseInt(captures[1]) : null;
  var century = captures[2] ? parseInt(captures[2]) : null; // either year or century is null, not both

  return {
    year: century === null ? year : century * 100,
    restDateString: dateString.slice((captures[1] || captures[2]).length)
  };
}

function parseDate(dateString, year) {
  // Invalid ISO-formatted year
  if (year === null) return new Date(NaN);
  var captures = dateString.match(dateRegex); // Invalid ISO-formatted string

  if (!captures) return new Date(NaN);
  var isWeekDate = !!captures[4];
  var dayOfYear = parseDateUnit(captures[1]);
  var month = parseDateUnit(captures[2]) - 1;
  var day = parseDateUnit(captures[3]);
  var week = parseDateUnit(captures[4]);
  var dayOfWeek = parseDateUnit(captures[5]) - 1;

  if (isWeekDate) {
    if (!validateWeekDate(year, week, dayOfWeek)) {
      return new Date(NaN);
    }

    return dayOfISOWeekYear(year, week, dayOfWeek);
  } else {
    var date = new Date(0);

    if (!validateDate(year, month, day) || !validateDayOfYearDate(year, dayOfYear)) {
      return new Date(NaN);
    }

    date.setUTCFullYear(year, month, Math.max(dayOfYear, day));
    return date;
  }
}

function parseDateUnit(value) {
  return value ? parseInt(value) : 1;
}

function parseTime(timeString) {
  var captures = timeString.match(timeRegex);
  if (!captures) return NaN; // Invalid ISO-formatted time

  var hours = parseTimeUnit(captures[1]);
  var minutes = parseTimeUnit(captures[2]);
  var seconds = parseTimeUnit(captures[3]);

  if (!validateTime(hours, minutes, seconds)) {
    return NaN;
  }

  return hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute + seconds * 1000;
}

function parseTimeUnit(value) {
  return value && parseFloat(value.replace(',', '.')) || 0;
}

function parseTimezone(timezoneString) {
  if (timezoneString === 'Z') return 0;
  var captures = timezoneString.match(timezoneRegex);
  if (!captures) return 0;
  var sign = captures[1] === '+' ? -1 : 1;
  var hours = parseInt(captures[2]);
  var minutes = captures[3] && parseInt(captures[3]) || 0;

  if (!validateTimezone(hours, minutes)) {
    return NaN;
  }

  return sign * (hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute);
}

function dayOfISOWeekYear(isoWeekYear, week, day) {
  var date = new Date(0);
  date.setUTCFullYear(isoWeekYear, 0, 4);
  var fourthOfJanuaryDay = date.getUTCDay() || 7;
  var diff = (week - 1) * 7 + day + 1 - fourthOfJanuaryDay;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
} // Validation functions
// February is null to handle the leap year (using ||)


var daysInMonths = [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function isLeapYearIndex(year) {
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}

function validateDate(year, month, date) {
  return month >= 0 && month <= 11 && date >= 1 && date <= (daysInMonths[month] || (isLeapYearIndex(year) ? 29 : 28));
}

function validateDayOfYearDate(year, dayOfYear) {
  return dayOfYear >= 1 && dayOfYear <= (isLeapYearIndex(year) ? 366 : 365);
}

function validateWeekDate(_year, week, day) {
  return week >= 1 && week <= 53 && day >= 0 && day <= 6;
}

function validateTime(hours, minutes, seconds) {
  if (hours === 24) {
    return minutes === 0 && seconds === 0;
  }

  return seconds >= 0 && seconds < 60 && minutes >= 0 && minutes < 60 && hours >= 0 && hours < 25;
}

function validateTimezone(_hours, minutes) {
  return minutes >= 0 && minutes <= 59;
}

/***/ }),

/***/ 72766:
/*!*****************************************!*\
  !*** ./src/app/core/dto/booking.dto.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingDto": () => (/* binding */ BookingDto)
/* harmony export */ });
class BookingDto {
}


/***/ }),

/***/ 94623:
/*!**************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourModule": () => (/* binding */ FormatHourModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./format-hour.pipe */ 70653);





let FormatHourModule = class FormatHourModule {
};
FormatHourModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe]
    })
], FormatHourModule);



/***/ }),

/***/ 70653:
/*!************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.pipe.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourPipe": () => (/* binding */ FormatHourPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let FormatHourPipe = class FormatHourPipe {
    transform(hour) {
        if (hour === null || hour === undefined || hour === '') {
            return '';
        }
        ;
        let value = '';
        if (hour === 0 || hour === '0') {
            value = '00';
            return value;
        }
        if (hour && hour.toString().length === 1) {
            value = `0${hour.toString()}`;
            return value;
        }
        return '' + hour;
    }
};
FormatHourPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formatHour'
    })
], FormatHourPipe);



/***/ }),

/***/ 96095:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/booking-manager/new-booking/new-booking-routing.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewBookingPageRoutingModule": () => (/* binding */ NewBookingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _new_booking_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-booking.page */ 41490);




const routes = [
    {
        path: '',
        component: _new_booking_page__WEBPACK_IMPORTED_MODULE_0__.NewBookingPage
    },
    {
        path: 'customer-detail',
        loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_pages_customer_customer-detail_customer-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../../customer/customer-detail/customer-detail.module */ 71547)).then(m => m.CustomerDetailPageModule)
    }
];
let NewBookingPageRoutingModule = class NewBookingPageRoutingModule {
};
NewBookingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NewBookingPageRoutingModule);



/***/ }),

/***/ 41072:
/*!*************************************************************************!*\
  !*** ./src/app/pages/booking-manager/new-booking/new-booking.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewBookingPageModule": () => (/* binding */ NewBookingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_time_selector_time_selector_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/time-selector/time-selector.module */ 57504);
/* harmony import */ var swiper_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! swiper/angular */ 22767);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _new_booking_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-booking-routing.module */ 96095);
/* harmony import */ var _new_booking_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./new-booking.page */ 41490);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var src_app_shared_components_customer_list_customer_list_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/customer-list/customer-list.module */ 47469);
/* harmony import */ var src_app_shared_components_product_list_product_list_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/product-list/product-list.module */ 68478);
/* harmony import */ var src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/pipes/format-hour/format-hour.module */ 94623);














let NewBookingPageModule = class NewBookingPageModule {
};
NewBookingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
            _new_booking_routing_module__WEBPACK_IMPORTED_MODULE_2__.NewBookingPageRoutingModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_4__.AlertModule,
            src_app_shared_components_customer_list_customer_list_module__WEBPACK_IMPORTED_MODULE_5__.CustomerListModule,
            src_app_shared_components_product_list_product_list_module__WEBPACK_IMPORTED_MODULE_6__.ProductListModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            swiper_angular__WEBPACK_IMPORTED_MODULE_13__.SwiperModule,
            _shared_components_time_selector_time_selector_module__WEBPACK_IMPORTED_MODULE_0__.TimeSelectorModule,
            src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_7__.FormatHourModule
        ],
        declarations: [_new_booking_page__WEBPACK_IMPORTED_MODULE_3__.NewBookingPage],
    })
], NewBookingPageModule);



/***/ }),

/***/ 41490:
/*!***********************************************************************!*\
  !*** ./src/app/pages/booking-manager/new-booking/new-booking.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewBookingPage": () => (/* binding */ NewBookingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _new_booking_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-booking.page.html?ngResource */ 21242);
/* harmony import */ var _new_booking_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-booking.page.scss?ngResource */ 73396);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! date-fns */ 68097);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! date-fns */ 60745);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! date-fns */ 86118);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! date-fns */ 33719);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! date-fns */ 61535);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! date-fns */ 47504);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! date-fns/locale */ 36956);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 33646);
/* harmony import */ var src_app_core_dto_booking_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/booking.dto */ 72766);
/* harmony import */ var src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/booking/booking.service */ 70065);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/non-availability/non-availability.service */ 30371);
/* harmony import */ var src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/services/services.service */ 63105);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var src_app_shared_components_customer_list_customer_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/customer-list/customer-list.component */ 19708);
/* harmony import */ var src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/components/service-list/service-list.component */ 43344);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash */ 85566);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/customer/customer.service */ 20161);
/* harmony import */ var src_app_core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/utils/utils.service */ 73372);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! swiper */ 50314);



/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable max-len */




















swiper__WEBPACK_IMPORTED_MODULE_14__["default"].use([swiper__WEBPACK_IMPORTED_MODULE_14__.EffectCoverflow, swiper__WEBPACK_IMPORTED_MODULE_14__.Pagination]);
let NewBookingPage = class NewBookingPage {
    constructor(fb, employeeService, dateService, nonAvailabilityService, activatedRoute, modalController, routerOutlet, serviceService, bookingService, router, navCtrl, customerService, utilsService) {
        this.fb = fb;
        this.employeeService = employeeService;
        this.dateService = dateService;
        this.nonAvailabilityService = nonAvailabilityService;
        this.activatedRoute = activatedRoute;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.serviceService = serviceService;
        this.bookingService = bookingService;
        this.router = router;
        this.navCtrl = navCtrl;
        this.customerService = customerService;
        this.utilsService = utilsService;
        this.showPickerDate = false;
        this.employeeCollection = [];
        this.employeeCollectionOriginal = [];
        this.serviceCollection = [];
        this.serviceCollectionOriginal = [];
        this.latestServiceCollection = [];
        this.serviceSelected = [];
        this.startDate = new Date();
        this.isEdit = false;
        this.totalPrice = '0 €';
        this.locale = date_fns_locale__WEBPACK_IMPORTED_MODULE_15__["default"];
        this.actualDate = new Date();
        this.duration = 0;
        this.isAvailable = true;
        this.isWalkinClient = false;
        this.hourCollection = [];
        this.minuteCollection = [];
        this.hourStartSelected = '00';
        this.minuteStartSelected = '00';
        this.hourEndSelected = '';
        this.minuteEndSelected = '';
        this.hourCollection = this.utilsService.generateHours(0, 24);
        this.minuteCollection = this.utilsService.generateMinutes();
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        /*  this.subscriptionCollection = router..subscribe(event => {
           if (router.getCurrentNavigation()?.extras.state?.newCustomer) {
             this.customerSelected = this.router.getCurrentNavigation().extras.state.newCustomer;
           }
         }); */
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.bookingData) {
                this.bookingData = this.router.getCurrentNavigation().extras.state.bookingData;
                console.log(this.bookingData);
                this.stringHour = this.bookingData.selectedHour.hours + ':' + this.bookingData.selectedHour.minutes;
                /*   this.checkAvailability(); */
            }
            if (this.router.getCurrentNavigation().extras.state.newCustomer) {
                this.customerSelected = this.router.getCurrentNavigation().extras.state.newCustomer;
            }
            this.selectedDay = this.router.getCurrentNavigation().extras.state.selectedDay;
        }
        this.initForm();
        this.getWalkinCustomer();
    }
    get startDay() {
        return this.form.get('startDay');
    }
    get startHour() {
        return this.form.get('startHour');
    }
    get endHour() {
        return this.form.get('endHour');
    }
    get message() {
        return this.form.get('message');
    }
    get employee() {
        return this.form.get('employee');
    }
    get customer() {
        return this.form.get('customer');
    }
    get note() {
        return this.form.get('note');
    }
    get service() {
        return this.form.get('service');
    }
    onTouchMove() {
        const selection = window.getSelection();
        selection.removeAllRanges();
    }
    ionViewWillEnter() {
        console.log(this.activatedRoute.snapshot.queryParams);
        if (this.activatedRoute.snapshot.queryParams.newCustomer) {
            this.customerSelected = JSON.parse(this.activatedRoute.snapshot.queryParams.newCustomer);
        }
        this.concatRequiredRequest(this.commerceLogged);
    }
    ngOnInit() {
    }
    getParam() {
        if (this.activatedRoute.snapshot.params.id) {
            this.title = 'Editar reserva';
            this.activatedRoute.params.subscribe((res) => {
                this.id = res.id;
                this.findBookingByID(this.id);
                this.isEdit = true;
            });
        }
        else {
            this.title = 'Crear reserva';
            this.serviceSelected = [];
            this.initForm();
        }
    }
    getWalkinCustomer() {
        this.customerService.getWalkinCustomer().subscribe(res => this.walkinClient = res);
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_shared_components_customer_list_customer_list_component__WEBPACK_IMPORTED_MODULE_9__.CustomerListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    isNewBooking: true
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data && data.customer !== undefined) {
                this.customerSelected = data.customer;
                this.customer.setValue(`${this.customerSelected.name} ${this.customerSelected.lastname}`);
                this.checkLastService(this.commerceLogged, this.customerSelected.uuid);
                this.checkAvailability();
            }
        });
    }
    checkLastService(commerce, customer) {
        this.latestServiceCollection = [];
        this.bookingService.findLastBookingByCommerceAndCustomer(commerce, customer)
            .subscribe((res) => {
            if (res) {
                const findEmployee = this.employeeCollection.find(employee => employee.uuid === this.employee.value);
                if (findEmployee) {
                    const lastService = res.service.filter(service => findEmployee.services.some(item => item.uuid === service.uuid));
                    this.latestServiceCollection = [...lastService];
                }
            }
        });
    }
    addLatestService() {
        this.serviceSelected = [...this.latestServiceCollection];
        this.calcTotalPriceService(this.serviceSelected);
        this.discount();
        this.calculateEndHour();
        this.checkAvailability();
    }
    concatRequiredRequest(commerce) {
        (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.forkJoin)([
            this.findEmployeeCollection(commerce),
            this.findServiceCollection(commerce),
        ]).subscribe((res) => {
            this.serviceCollection = res[1];
            this.serviceCollectionOriginal = res[1];
            this.employeeCollectionOriginal = res[0].filter(employee => employee.services && employee.services.length > 0);
            this.employeeCollection = res[0].filter(employee => employee.services && employee.services.length > 0);
            this.employeeCollectionOriginal = [...this.employeeCollection];
            if (this.bookingData) {
                this.selectedEmployee(this.bookingData.employee.uuid);
            }
            this.getParam();
        });
    }
    findBookingByID(bookingID) {
        this.bookingService
            .findBookingById(bookingID)
            .subscribe((res) => {
            const dateSplit = res.startsDay.split('-');
            const date = new Date(parseInt(dateSplit[0], 10), parseInt(dateSplit[1], 10) - 1, parseInt(dateSplit[2], 10), res.startsHour, res.startsMinute);
            this.startDay.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(date, 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_15__["default"] }));
            this.selectedDay = this.startDay.value;
            this.startHour.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(new Date(2022, 1, 1, res.startsHour, res.startsMinute), 'HH:mm'));
            this.customer.setValue(`${res.customer.name} ${res.customer.lastname}`);
            this.customerSelected = res.customer;
            this.selectedEmployee(res.asignedTo.uuid);
            this.service.setValue(res.service);
            this.serviceSelected = [...res.service];
            this.selectedService(res.service);
            this.message.setValue(res.message);
            this.note.setValue(res.note);
            this.endHour.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_19__["default"])(date, res.duration), 'HH:mm'));
        });
    }
    findEmployeeCollection(commerce) {
        return this.employeeService.findEmployees(commerce);
    }
    findServiceCollection(commerce) {
        return this.serviceService.findServiceByCommerce(commerce);
    }
    dateChanged(value) {
        this.startDate = new Date(value);
        this.dateValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(value), 'd MMM, yyyy');
        this.checkAvailability();
    }
    timeChanged(value) {
        this.timeValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(value), 'HH:mm ');
        this.checkAvailability();
    }
    dismiss() {
        this.datetime.cancel(true);
    }
    select() {
        this.datetime.confirm(true);
    }
    dismissTime() {
        this.time.cancel(true);
    }
    selectTime() {
        this.time.confirm(true);
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/home'], { replaceUrl: true });
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    onChangeStartHour(event) {
        if (event !== undefined) {
            const hourSelected = event;
            if ((hourSelected === null || hourSelected === void 0 ? void 0 : hourSelected.length) > 0) {
                this.startHour.setValue(hourSelected.split(':')[0] + ':' + hourSelected.split(':')[1]);
                if (this.bookingData) {
                    this.bookingData.selectedHour.hours = Number.parseInt(hourSelected.split(':')[0], 10);
                    this.bookingData.selectedHour.minutes = Number.parseInt(hourSelected.split(':')[1], 10);
                }
                if (this.serviceSelected.length > 0) {
                    const newDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_19__["default"])(new Date(2022, 1, 1, parseInt(hourSelected.split(':')[0], 10), parseInt(hourSelected.split(':')[1], 10)), this.calcTotalDurationService(this.serviceSelected));
                    const endHour = (0,date_fns__WEBPACK_IMPORTED_MODULE_21__["default"])(newDate) + ':' + (0,date_fns__WEBPACK_IMPORTED_MODULE_22__["default"])(newDate);
                    this.endHour.setValue(endHour);
                }
            }
        }
        this.checkAvailability();
    }
    onChangeEndHour(event) {
        if (event.detail.value.includes('T') || event.detail.value.includes('Z')) {
            event.detail.value = (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(new Date(event.detail.value), 'HH:mm');
        }
        this.endHour.setValue(event.detail.value);
        this.calculateTimeBetweenEndAndStart();
        this.checkAvailability();
    }
    calcTotalPriceService(service) {
        let price = 0;
        service.forEach((item) => {
            price = price + item.price;
        });
        return price;
    }
    calcTotalDurationService(service) {
        let duration = 0;
        service.forEach((item) => {
            duration = duration + item.defaultDuration;
        });
        return duration;
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    deleteItem() {
        this.nonAvailabilityService
            .deleteNonAvailabilityById(this.id)
            .subscribe((res) => {
            if (res.affected > 0) {
                this.cancel();
            }
        });
    }
    onSubmit() {
        const requestCalls = [];
        let tempEndHour = new Date();
        this.serviceSelected.forEach((service, index) => {
            const newBooking = new src_app_core_dto_booking_dto__WEBPACK_IMPORTED_MODULE_2__.BookingDto();
            newBooking.commerce = this.commerceLogged;
            newBooking.customer = this.isWalkinClient ? this.walkinClient : this.customerSelected;
            newBooking.service = [service];
            newBooking.asignedTo = this.employee.value;
            newBooking.duration = this.duration > 0 ? this.duration : service.defaultDuration;
            newBooking.week = (0,date_fns__WEBPACK_IMPORTED_MODULE_23__["default"])(new Date(this.startDay.value), { weekStartsOn: 1, firstWeekContainsDate: 4 });
            newBooking.startsDay = this.dateService.formatDate(new Date(this.startDay.value));
            newBooking.message = this.message.value;
            newBooking.note = this.note.value;
            newBooking.paymentSettedUuid = '';
            if (index === 0) {
                newBooking.startsHour = this.bookingData ? this.bookingData.selectedHour.hours : parseInt(this.startHour.value.split(':')[0], 10);
                newBooking.startsMinute = this.bookingData ? this.bookingData.selectedHour.minutes : parseInt(this.startHour.value.split(':')[1], 10);
                tempEndHour = (0,date_fns__WEBPACK_IMPORTED_MODULE_19__["default"])(new Date(2022, 1, 1, newBooking.startsHour, newBooking.startsMinute), service.defaultDuration);
            }
            else {
                newBooking.startsHour = (0,date_fns__WEBPACK_IMPORTED_MODULE_21__["default"])(tempEndHour);
                newBooking.startsMinute = (0,date_fns__WEBPACK_IMPORTED_MODULE_22__["default"])(tempEndHour);
                tempEndHour = (0,date_fns__WEBPACK_IMPORTED_MODULE_19__["default"])(new Date(2022, 1, 1, newBooking.startsHour, newBooking.startsMinute), service.defaultDuration);
            }
            if (this.isEdit) {
                if (index === 0) {
                    newBooking.uuid = this.id;
                    requestCalls.push(this.bookingService.updateBooking(newBooking));
                }
                else {
                    newBooking.status = 'Pendiente';
                    requestCalls.push(this.bookingService.saveBooking(newBooking));
                }
            }
            else {
                newBooking.status = 'Pendiente';
                requestCalls.push(this.bookingService.saveBooking(newBooking));
            }
        });
        (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.forkJoin)(requestCalls).subscribe(responses => {
            if (responses) {
                this.cancel();
            }
        });
    }
    selectedEmployee(employeeId) {
        this.employee.setValue(employeeId);
        if (this.customerSelected) {
            this.checkLastService(this.commerceLogged, this.customerSelected.uuid);
        }
        this.setServiceByEmployee(employeeId);
        // this.checkCanDoSelectedService();
        this.checkAvailability();
    }
    setServiceByEmployee(employeeID) {
        const employee = this.employeeCollection.find((emp) => emp.uuid === employeeID);
        if (employee) {
            this.serviceCollection = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.intersectionBy)(this.serviceCollectionOriginal, employee.services, 'uuid');
        }
    }
    checkCanDoSelectedService() {
        const findEmployee = this.employeeCollection.find(employee => employee.uuid === this.employee.value);
        if (findEmployee && this.serviceSelected.length > 0) {
            this.serviceSelected = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.intersectionBy)(findEmployee.services, this.serviceSelected, 'uuid');
        }
    }
    calculateTimeBetweenEndAndStart() {
        const hourStartSplitted = this.startHour.value.split(':');
        const hourEndSplitted = this.endHour.value.split(':');
        const year = this.actualDate.getFullYear();
        const month = this.actualDate.getMonth();
        const day = this.actualDate.getDate();
        const hourStart = parseInt(hourStartSplitted[0], 10);
        const minuteStart = parseInt(hourStartSplitted[1], 10);
        const hourEnd = parseInt(hourEndSplitted[0], 10);
        const minuteEnd = parseInt(hourEndSplitted[1], 10);
        const fechaInicio = new Date(year, month, day, hourStart, minuteStart);
        const fechaFin = new Date(year, month, day, hourEnd, minuteEnd);
        const difference = new Date(fechaFin.getTime() - fechaInicio.getTime());
        const differenceTimeInMinutes = ((difference.getHours() - 1) * 60) + difference.getMinutes();
        this.duration = differenceTimeInMinutes;
    }
    selectedService(value) {
        this.calcTotalPriceService(value);
        this.checkAvailability();
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    presentServiceModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            const serviceCollectionSelected = [...this.serviceSelected];
            const modal = yield this.modalController.create({
                component: src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_10__.ServiceListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: { servicesSelected: serviceCollectionSelected, showPrice: true, serviceCollectionFiltered: this.serviceCollection, serviceCollection: this.serviceCollection }
            });
            yield modal.present();
            yield modal.onDidDismiss().then((res) => {
                var _a, _b, _c, _d;
                if (((_b = (_a = res === null || res === void 0 ? void 0 : res.data) === null || _a === void 0 ? void 0 : _a.service) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                    this.serviceSelected = res.data.service;
                    this.setEmployeeCollectionBySelectedService(this.serviceSelected);
                    this.calcTotalPriceService(this.serviceSelected);
                    this.discount();
                    this.calculateEndHour();
                    this.checkAvailability();
                }
                else if (((_d = (_c = res === null || res === void 0 ? void 0 : res.data) === null || _c === void 0 ? void 0 : _c.service) === null || _d === void 0 ? void 0 : _d.length) > 0 && this.serviceSelected.length === 0) {
                    this.employeeCollection = [...this.employeeCollectionOriginal];
                }
            });
        });
    }
    setEmployeeCollectionBySelectedService(service) {
        const employeeCollection = [];
        this.employeeCollectionOriginal.forEach((emp) => {
            const isAvailable = (0,lodash__WEBPACK_IMPORTED_MODULE_11__.intersectionBy)(emp.services, service, 'uuid');
            if (isAvailable.length === service.length) {
                employeeCollection.push(emp);
            }
        });
        this.employeeCollection = [];
        this.employeeCollection = [...employeeCollection];
    }
    checkAvailability() {
        // date, hour, minute, employee, servicesDuration, serviceCollection
        let date;
        if (this.isEdit) {
            date = this.dateService.formatDate(new Date(this.selectedDay));
        }
        else {
            date = this.dateService.formatDate(this.bookingData ? this.bookingData.selectedDay.date : new Date(this.selectedDay));
        }
        const hour = parseInt(this.startHour.value.split(':')[0], 10);
        const minute = parseInt(this.startHour.value.split(':')[1], 10);
        const employee = this.employee.value;
        const duration = this.calcTotalDurationService(this.serviceSelected);
        const services = this.serviceSelected;
        if (date && hour && employee && duration && services) {
            this.bookingService.getAvailabilityPerEmployee(date, hour, minute, employee, duration, services).subscribe((res) => {
                this.isAvailable = res;
            });
        }
    }
    calculateEndHour() {
        const dateSplit = this.startDay.value.split('-');
        const hourSplit = this.startHour.value.split(':');
        const date = new Date(parseInt(dateSplit[0], 10), parseInt(dateSplit[1], 10) - 1, parseInt(dateSplit[2], 10), parseInt(hourSplit[0], 10), parseInt(hourSplit[1], 10));
        date.setMinutes(date.getMinutes() + this.calcTotalDurationService(this.serviceSelected));
        const endHour = this.dateService.addZeroToMinutesAndHours(date.getHours() + ':' + date.getMinutes());
        endHour === this.startHour.value ? this.endHour.setValue('') : this.endHour.setValue(endHour);
    }
    discount() {
        let totalprize = this.calcTotalPriceService(this.serviceSelected)
            ? this.calcTotalPriceService(this.serviceSelected)
            : 0;
        totalprize = totalprize;
        return totalprize;
    }
    ionViewWillLeave() {
        this.customerSelected = null;
        this.latestServiceCollection = null;
        this.serviceSelected = [];
    }
    ngOnDestroy() {
        this.customerSelected = null;
    }
    getHourAndMinute(date) {
        const hour = (0,date_fns__WEBPACK_IMPORTED_MODULE_21__["default"])(date);
        const minute = (0,date_fns__WEBPACK_IMPORTED_MODULE_22__["default"])(date);
        return this.dateService.addZeroToMinutes(hour + ':' + minute);
    }
    setMinEndHour() {
        let hourSplitted = '';
        hourSplitted = this.startHour.value.split(':');
        const year = this.actualDate.getFullYear();
        const month = this.actualDate.getMonth();
        const day = this.actualDate.getDate();
        const hour = parseInt(hourSplitted[0], 10);
        const minute = parseInt(hourSplitted[1], 10);
        const dateFormatted = (0,date_fns__WEBPACK_IMPORTED_MODULE_24__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_25__["default"])(new Date(year, month, day, hour, minute), {
            minutes: 5
        }), { representation: 'time' });
        return dateFormatted;
    }
    initForm() {
        this.form = this.fb.group({
            startDay: [this.bookingData ? (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(this.bookingData.selectedDay.date, 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_15__["default"] }) : this.selectedDay, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.Validators.required],
            startHour: [this.bookingData
                    ? (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(new Date(2022, 1, 1, this.bookingData.selectedHour.hours, this.bookingData.selectedHour.minutes), 'HH:mm')
                    : (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])(new Date(), 'HH:mm'), _angular_forms__WEBPACK_IMPORTED_MODULE_26__.Validators.required],
            endHour: [this.serviceSelected.length === 0 ? '' : this.calculateEndHour(), _angular_forms__WEBPACK_IMPORTED_MODULE_26__.Validators.required],
            service: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_26__.Validators.required],
            message: [''],
            note: [''],
            employee: [this.bookingData ? this.bookingData.employee.uuid : '', _angular_forms__WEBPACK_IMPORTED_MODULE_26__.Validators.required],
            customer: [''],
        });
    }
    deleteService(service) {
        const serviceIndex = this.serviceSelected.findIndex(item => item.uuid === service.uuid);
        this.serviceSelected.splice(serviceIndex, 1);
        this.serviceSelected.length === 0 ? this.endHour.setValue('') : this.calculateEndHour();
        if (this.serviceSelected.length === 0) {
            this.employeeCollection = [...this.employeeCollectionOriginal];
            this.serviceCollection = [...this.serviceCollectionOriginal];
            if (this.employee.value) {
                this.selectedEmployee(this.employee.value);
            }
        }
        else {
            this.setEmployeeCollectionBySelectedService(this.serviceSelected);
        }
    }
    onChangeCheckbox(event) {
        this.isWalkinClient = event.detail.checked;
    }
    setSelectedStartHour(hourSelected) {
        this.startHour.setValue(hourSelected);
        this.onChangeStartHour(hourSelected);
    }
    setSelectedEndHour(hourSelected) {
        this.endHour.setValue(hourSelected);
        this.calculateTimeBetweenEndAndStart();
    }
};
NewBookingPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_26__.FormBuilder },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_4__.EmployeeService },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_7__.DateService },
    { type: src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_5__.NonAvailabilityService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_27__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_28__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_28__.IonRouterOutlet },
    { type: src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_6__.ServicesService },
    { type: src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_3__.BookingService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_27__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_28__.NavController },
    { type: src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_12__.CustomerService },
    { type: src_app_core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_13__.UtilsService }
];
NewBookingPage.propDecorators = {
    datetime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_28__.IonDatetime,] }],
    time: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_28__.IonDatetime,] }],
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_8__.AlertComponent,] }],
    onTouchMove: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_29__.HostListener, args: ['touchmove', ['$event'],] }]
};
NewBookingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.Component)({
        selector: 'app-new-booking',
        template: _new_booking_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_new_booking_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NewBookingPage);



/***/ }),

/***/ 47469:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/customer-list/customer-list.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerListModule": () => (/* binding */ CustomerListModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _customer_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-list.component */ 19708);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let CustomerListModule = class CustomerListModule {
};
CustomerListModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_customer_list_component__WEBPACK_IMPORTED_MODULE_0__.CustomerListComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule],
        exports: [_customer_list_component__WEBPACK_IMPORTED_MODULE_0__.CustomerListComponent],
    })
], CustomerListModule);



/***/ }),

/***/ 68478:
/*!***********************************************************************!*\
  !*** ./src/app/shared/components/product-list/product-list.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductListModule": () => (/* binding */ ProductListModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _product_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-list.component */ 53957);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);






let ProductListModule = class ProductListModule {
};
ProductListModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_product_list_component__WEBPACK_IMPORTED_MODULE_1__.ProductListComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule, src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule],
        exports: [_product_list_component__WEBPACK_IMPORTED_MODULE_1__.ProductListComponent],
    })
], ProductListModule);



/***/ }),

/***/ 73396:
/*!************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/new-booking/new-booking.page.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = ".textbox ion-label {\n  padding: 0px 0px;\n}\n\n.textbox .correct-possition {\n  padding-top: 10px;\n  margin-left: -5px;\n}\n\n.padding-right {\n  padding-right: 10px;\n}\n\n.service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n\n.service-card .service-row {\n  border-radius: 15px;\n}\n\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n\n.service-card .service-row .service-label {\n  margin: 0 !important;\n  display: block;\n  margin-top: 3%;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\n\n.customer-card {\n  padding: 0;\n}\n\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n\n.customer-card .customer-row .customer-image {\n  padding: 0;\n  height: 100%;\n}\n\n.customer-card .customer-row .icon-container {\n  margin-top: 170%;\n  text-align: center;\n}\n\n.customer-card .customer-row .customer-label {\n  display: block;\n  margin-top: 14%;\n  margin-left: 5%;\n}\n\nion-datetime {\n  background-color: white;\n}\n\n.date-item {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n.no-padding {\n  padding: 0;\n}\n\nion-checkbox {\n  --size: 24px;\n  margin-right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy1ib29raW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxtQkFBQTtBQUVGOztBQUNBO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0FBRUY7O0FBQUU7RUFDRSxtQkFBQTtBQUVKOztBQUFJO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUVOOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUNOOztBQUVJO0VBQ0Usb0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUFOOztBQUlBO0VBQ0UsVUFBQTtBQURGOztBQUVFO0VBQ0UsbUJBQUE7QUFBSjs7QUFDSTtFQUNFLFVBQUE7RUFDQSxZQUFBO0FBQ047O0FBQ0k7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBQ047O0FBQ0k7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFDTjs7QUFHQTtFQUNFLHVCQUFBO0FBQUY7O0FBR0E7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUdBO0VBQ0UsVUFBQTtBQUFGOztBQUdBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUFBRiIsImZpbGUiOiJuZXctYm9va2luZy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dGJveCBpb24tbGFiZWwge1xyXG4gIHBhZGRpbmc6IDBweCAwcHg7XHJcbn1cclxuXHJcbi50ZXh0Ym94IC5jb3JyZWN0LXBvc3NpdGlvbiB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IC01cHg7XHJcbn1cclxuLnBhZGRpbmctcmlnaHQge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbi5zZXJ2aWNlLWNhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgbWF4LWhlaWdodDogNDMuNXB4O1xyXG5cclxuICAuc2VydmljZS1yb3cge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuXHJcbiAgICAuc2VydmljZS1pbWFnZSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE5MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgICAuc2VydmljZS1sYWJlbCB7XHJcbiAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgbWFyZ2luLXRvcDogMyU7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMyU7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5jdXN0b21lci1jYXJkIHtcclxuICBwYWRkaW5nOiAwO1xyXG4gIC5jdXN0b21lci1yb3cge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgIC5jdXN0b21lci1pbWFnZSB7XHJcbiAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgIH1cclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE3MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5jdXN0b21lci1sYWJlbCB7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBtYXJnaW4tdG9wOiAxNCU7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW9uLWRhdGV0aW1lIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmRhdGUtaXRlbSB7XHJcbiAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgbWFyZ2luLXJpZ2h0OiAwO1xyXG59XHJcblxyXG4ubm8tcGFkZGluZyB7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG5cclxuaW9uLWNoZWNrYm94IHtcclxuICAtLXNpemU6IDI0cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAwO1xyXG59XHJcblxyXG4iXX0= */";

/***/ }),

/***/ 21242:
/*!************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/new-booking/new-booking.page.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"title\"></app-header>\r\n\r\n<ion-content fullscreen=\"true\" [scrollEvents]=\"true\">\r\n  <form [formGroup]=\"form\" (ngSubmit)=\"onSubmit()\" novalidate>\r\n    <ion-card button=\"true\" [disabled]=\"isWalkinClient\">\r\n      <ion-input\r\n        ngDefaultControl\r\n        type=\"hidden\"\r\n        formControlName=\"customer\"\r\n        class=\"ion-text-right\"\r\n      ></ion-input>\r\n      <ion-grid class=\"customer-card\" (click)=\"presentModal()\">\r\n        <ion-row class=\"customer-row\">\r\n          <ion-col class=\"customer-image\" size=\"3\">\r\n            <img class=\"p-4\" src=\"assets/no-image.jpeg\" />\r\n          </ion-col>\r\n          <ion-col size=\"8\">\r\n            <ion-label *ngIf=\"!customerSelected\" class=\"customer-label\"\r\n              >Selecciona cliente</ion-label\r\n            >\r\n            <ion-label *ngIf=\"customerSelected\" class=\"customer-label\"\r\n              >{{customerSelected.name +'\r\n              '+customerSelected.lastname}}</ion-label\r\n            >\r\n          </ion-col>\r\n          <ion-col size=\"1\">\r\n            <div class=\"icon-container\">\r\n              <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n            </div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n    <ion-item class=\"textbox\">\r\n      <ion-label slot=\"start\">Cliente sin cita previa</ion-label>\r\n      <ion-checkbox\r\n        slot=\"end\"\r\n        (ionChange)=\"onChangeCheckbox($event)\"\r\n      ></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item\r\n      style=\"margin-bottom: 0\"\r\n      *ngIf=\"latestServiceCollection?.length > 0\"\r\n      (click)=\"addLatestService()\"\r\n      class=\"textbox\"\r\n      no-lines\r\n      lines=\"none\"\r\n    >\r\n      <ion-label class=\"no-padding\"\r\n        >Repetir último servicio: {{latestServiceCollection[0].name}}</ion-label\r\n      >\r\n      <ion-button fill=\"clear\">\r\n        <ion-icon name=\"refresh-outline\" slot=\"end\"></ion-icon>\r\n      </ion-button>\r\n    </ion-item>\r\n    <ion-grid fixed class=\"no-padding\">\r\n      <ion-row class=\"no-padding\">\r\n        <ion-col class=\"no-padding\" size=\"12\">\r\n          <ion-item\r\n            style=\"margin-bottom: 0\"\r\n            (click)=\"presentServiceModal()\"\r\n            class=\"textbox\"\r\n            no-lines\r\n            lines=\"none\"\r\n          >\r\n            <ion-label class=\"no-padding\">Añadir servicio</ion-label>\r\n            <ion-button fill=\"clear\">\r\n              <ion-icon slot=\"end\" name=\"add\"></ion-icon>\r\n            </ion-button>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <ng-container *ngFor=\"let service of serviceSelected\">\r\n      <ion-card button=\"true\">\r\n        <ion-grid class=\"service-card\">\r\n          <ion-row class=\"service-row\">\r\n            <ion-col\r\n              size=\"0.1\"\r\n              [style.background-color]=\"service?.color\"\r\n            ></ion-col>\r\n            <ion-col class=\"no-padding\">\r\n              <ion-item>\r\n                <ion-label class=\"service-label\">\r\n                  <span>{{ service.name }} · {{ service.price + \" €\" }}</span>\r\n                  <!-- <p>14:45 - 15:15 · 30 min</p> -->\r\n                </ion-label>\r\n                <ion-button fill=\"clear\" (click)=\"deleteService(service)\">\r\n                  <ion-icon slot=\"end\" name=\"trash-outline\"></ion-icon>\r\n                </ion-button>\r\n              </ion-item>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-card>\r\n    </ng-container>\r\n\r\n    <div class=\"p-0\" id=\"open-start-days\">\r\n      <ion-item mode=\"ios\" class=\"textbox\">\r\n        <ion-label mode=\"ios\" class=\"w-full max-w-none\"\r\n          >Fecha Inicio\r\n          <span class=\"float-right\"\r\n            >{{dateService.formatDateLanguage(form.controls['startDay'].value,\r\n            locale)}}</span\r\n          >\r\n        </ion-label>\r\n        <ion-input\r\n          type=\"hidden\"\r\n          class=\"hidden\"\r\n          [value]=\"dateService.formatDateLanguage(form.controls['startDay'].value, locale)\"\r\n        ></ion-input>\r\n        <ion-modal\r\n          id=\"open-modal-calendar\"\r\n          initialBreakpoint=\"0.50\"\r\n          trigger=\"open-start-days\"\r\n        >\r\n          <ng-template>\r\n            <ion-content>\r\n              <ion-toolbar>\r\n                <ion-title>Fecha inicio</ion-title>\r\n              </ion-toolbar>\r\n              <ion-datetime\r\n                #datetime\r\n                first-day-of-week=\"1\"\r\n                locale=\"es-ES\"\r\n                (ionChange)=\"dateChanged(datetime.value)\"\r\n                presentation=\"date\"\r\n                size=\"cover\"\r\n                formControlName=\"startDay\"\r\n              >\r\n              </ion-datetime>\r\n            </ion-content>\r\n          </ng-template>\r\n        </ion-modal>\r\n      </ion-item>\r\n    </div>\r\n\r\n    <ion-grid class=\"p-0\">\r\n      <ion-row class=\"textbox\">\r\n        <ion-col class=\"p-0\" id=\"start-hour\">\r\n          <ion-item class=\"date-item border-r-2\">\r\n            <ion-label class=\"w-full max-w-none\"\r\n              >Hora inicio\r\n              <span class=\"float-right\"\r\n                >{{form.controls['startHour'].value.split(':')[0] |\r\n                formatHour}}:{{form.controls['startHour'].value.split(':')[1] |\r\n                formatHour}}</span\r\n              ></ion-label\r\n            >\r\n            <ion-input\r\n              type=\"hidden\"\r\n              class=\"ion-text-right\"\r\n              [value]=\"form.controls['startHour'].value \"\r\n            >\r\n            </ion-input>\r\n            <ion-modal\r\n              id=\"start-hour-modal\"\r\n              initialBreakpoint=\"0.5\"\r\n              backdropBreakpoint=\"0.5\"\r\n              trigger=\"start-hour\"\r\n            >\r\n              <ng-template>\r\n                <ion-content>\r\n                  <ion-toolbar>\r\n                    <ion-title>Hora inicio</ion-title>\r\n                    <ion-buttons slot=\"end\">\r\n                      <ion-button\r\n                        color=\"dark\"\r\n                        (click)=\"dismissModal('start-hour-modal')\"\r\n                        >Aceptar</ion-button\r\n                      >\r\n                    </ion-buttons>\r\n                  </ion-toolbar>\r\n                  <app-time-selector\r\n                    [availableStartHour]=\"'0'\"\r\n                    [availableEndHour]=\"'23'\"\r\n                    [initialHour]=\"startHour.value.split(':')[0]\"\r\n                    [initialMinutes]=\"startHour.value.split(':')[1]\"\r\n                    (hourSelectedEmitter)=\"setSelectedStartHour($event)\"\r\n                  >\r\n                  </app-time-selector>\r\n                </ion-content>\r\n              </ng-template>\r\n            </ion-modal>\r\n          </ion-item>\r\n        </ion-col>\r\n\r\n        <ion-col class=\"p-0\" id=\"end-hour\">\r\n          <ion-item class=\"date-item\">\r\n            <ion-label class=\"w-full max-w-none\"\r\n              >Hora final\r\n              <span class=\"float-right\"\r\n                >{{form.controls['endHour'].value.split(':')[0] |\r\n                formatHour}}:{{form.controls['endHour'].value.split(':')[1] |\r\n                formatHour}}</span\r\n              ></ion-label\r\n            >\r\n            <ion-input\r\n              type=\"hidden\"\r\n              class=\"ion-text-right\"\r\n              [value]=\"form.controls['endHour'].value \"\r\n            >\r\n            </ion-input>\r\n            <ion-modal\r\n              id=\"end-hour-modal\"\r\n              class=\"modal-no-scroll\"\r\n              initialBreakpoint=\"0.5\"\r\n              backdropBreakpoint=\"0.5\"\r\n              trigger=\"end-hour\"\r\n            >\r\n              <ng-template>\r\n                <ion-content>\r\n                  <ion-toolbar>\r\n                    <ion-title>Hora final</ion-title>\r\n                    <ion-buttons slot=\"end\">\r\n                      <ion-button\r\n                        color=\"dark\"\r\n                        (click)=\"dismissModal('end-hour-modal')\"\r\n                        >Aceptar</ion-button\r\n                      >\r\n                    </ion-buttons>\r\n                  </ion-toolbar>\r\n                  <app-time-selector\r\n                    [availableStartHour]=\"'0'\"\r\n                    [availableEndHour]=\"'23'\"\r\n                    [initialHour]=\"endHour.value.split(':')[0]\"\r\n                    [initialMinutes]=\"endHour.value.split(':')[1]\"\r\n                    (hourSelectedEmitter)=\"setSelectedEndHour($event)\"\r\n                  >\r\n                  </app-time-selector>\r\n                </ion-content>\r\n              </ng-template>\r\n            </ion-modal>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-item\r\n      class=\"textbox\"\r\n      no-lines\r\n      lines=\"none\"\r\n      *ngIf=\"employeeCollection?.length > 0\"\r\n    >\r\n      <ion-label>Selecciona un empleado</ion-label>\r\n      <ion-select\r\n        #employee\r\n        formControlName=\"employee\"\r\n        interface=\"action-sheet\"\r\n        (ionChange)=\"selectedEmployee(employee.value)\"\r\n        cancelText=\"Cancelar\"\r\n      >\r\n        <ion-select-option\r\n          *ngFor=\"let employee of employeeCollection\"\r\n          [value]=\"employee.uuid\"\r\n          >{{employee.name}}\r\n        </ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n    <ng-container *ngIf=\"!isAvailable\">\r\n      <div class=\"px-8\">\r\n        <p class=\"text-red-300\">\r\n          El empleado elegido tiene ocupada la hora seleccionada\r\n        </p>\r\n      </div>\r\n    </ng-container>\r\n    <ion-item mode=\"ios\" class=\"textbox\" no-lines lines=\"none\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-label class=\"correct-possition\" mode=\"ios\">Nota </ion-label>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-textarea\r\n            mode=\"ios\"\r\n            ngDefaultControl\r\n            formControlName=\"note\"\r\n            type=\"text\"\r\n            placeholder=\"Solo visible para el comercio\"\r\n            autocapitalize=\"true\"\r\n          ></ion-textarea>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-item mode=\"ios\" class=\"textbox\" no-lines lines=\"none\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-label class=\"correct-possition\" mode=\"ios\">Mensaje</ion-label>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-textarea\r\n            mode=\"ios\"\r\n            ngDefaultControl\r\n            autocapitalize=\"true\"\r\n            formControlName=\"message\"\r\n            type=\"text\"\r\n            placeholder=\"Mensaje para el cliente\"\r\n          ></ion-textarea>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n  </form>\r\n  <ion-grid>\r\n    <ion-row\r\n      class=\"ion-justify-content-end padding-right\"\r\n      *ngIf=\"totalPrice !== '0 €'\"\r\n    >\r\n      <ion-item>\r\n        <h3 class=\"ion-text-end\" [innerText]=\"totalPrice\"></h3>\r\n      </ion-item>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col *ngIf=\"isEdit\" (click)=\"openAlert()\">\r\n        <ion-button class=\"btn\" expand=\"block\">\r\n          <ion-icon icon=\"trash\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n      <ion-col>\r\n        <ion-button\r\n          (click)=\"onSubmit()\"\r\n          [disabled]=\"serviceSelected.length < 1 || !form.controls['employee'].value\"\r\n          class=\"btn\"\r\n          expand=\"block\"\r\n        >\r\n          Guardar\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n<app-alert\r\n  #deleteAlert\r\n  (actionEmitter)=\"alertBox($event)\"\r\n  [title]=\"'¿Desea borrar?'\"\r\n></app-alert>\r\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_booking-manager_new-booking_new-booking_module_ts.js.map