"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday-list_module_ts"],{

/***/ 65061:
/*!*************************************************************!*\
  !*** ./src/app/core/models/holidays/holiday-range.model.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayRange": () => (/* binding */ HolidayRange)
/* harmony export */ });
class HolidayRange {
}


/***/ }),

/***/ 30371:
/*!****************************************************************************!*\
  !*** ./src/app/core/services/non-availability/non-availability.service.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonAvailabilityService": () => (/* binding */ NonAvailabilityService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let NonAvailabilityService = class NonAvailabilityService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findAllNonAvailabilityByDay(commerce, date) {
        return this.http.get(`${this.apiUrl}/non-availability`, {
            params: {
                commerce,
                date,
            },
        });
    }
    findAllNonAvailabilityByWeek(commerce, week) {
        return this.http.get(`${this.apiUrl}/non-availability/weekly`, {
            params: {
                week,
                commerce,
            },
        });
    }
    saveNonAvailability(nonAvailability) {
        return this.http.post(`${this.apiUrl}/non-availability`, nonAvailability);
    }
    editNonAvailability(nonAvailability) {
        return this.http.patch(`${this.apiUrl}/non-availability`, nonAvailability);
    }
    getNonAvailabilityById(id) {
        return this.http.get(`${this.apiUrl}/non-availability/${id}`);
    }
    getHolidaysByEmployee(id) {
        return this.http.get(`${this.apiUrl}/non-availability/holidays/${id}`);
    }
    getHolidaysByCode(holydayCode) {
        return this.http.get(`${this.apiUrl}/non-availability/holidaysCode/${holydayCode}`);
    }
    deleteNonAvailabilityById(id) {
        return this.http.delete(`${this.apiUrl}/non-availability/${id}`);
    }
    deleteHolidayById(id) {
        return this.http.delete(`${this.apiUrl}/non-availability/holiday/${id}`);
    }
};
NonAvailabilityService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
NonAvailabilityService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], NonAvailabilityService);



/***/ }),

/***/ 43997:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday-list-routing.module.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayListPageRoutingModule": () => (/* binding */ HolidayListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _holiday_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./holiday-list.page */ 80595);




const routes = [
    {
        path: '',
        component: _holiday_list_page__WEBPACK_IMPORTED_MODULE_0__.HolidayListPage
    },
    {
        path: 'holiday/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday_holiday_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./holiday/holiday.module */ 30334)).then(m => m.HolidayPageModule)
    },
];
let HolidayListPageRoutingModule = class HolidayListPageRoutingModule {
};
HolidayListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HolidayListPageRoutingModule);



/***/ }),

/***/ 60210:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday-list.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayListPageModule": () => (/* binding */ HolidayListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _holiday_list_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./holiday-list-routing.module */ 43997);
/* harmony import */ var _holiday_list_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./holiday-list.page */ 80595);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/no-data/no-data.module */ 98360);










let HolidayListPageModule = class HolidayListPageModule {
};
HolidayListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _holiday_list_routing_module__WEBPACK_IMPORTED_MODULE_1__.HolidayListPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__.AlertModule,
            src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_4__.NoDataModule
        ],
        declarations: [_holiday_list_page__WEBPACK_IMPORTED_MODULE_2__.HolidayListPage]
    })
], HolidayListPageModule);



/***/ }),

/***/ 80595:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday-list.page.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HolidayListPage": () => (/* binding */ HolidayListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _holiday_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./holiday-list.page.html?ngResource */ 58410);
/* harmony import */ var _holiday_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./holiday-list.page.scss?ngResource */ 60268);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! date-fns/locale */ 36956);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76027);
/* harmony import */ var src_app_core_models_holidays_holiday_range_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/holidays/holiday-range.model */ 65061);
/* harmony import */ var src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/non-availability/non-availability.service */ 30371);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);












let HolidayListPage = class HolidayListPage {
    constructor(navCtrl, nonAvaService, activatedRoute) {
        this.navCtrl = navCtrl;
        this.nonAvaService = nonAvaService;
        this.activatedRoute = activatedRoute;
        this.employeeCollection = [];
        this.$removeItem = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject(null);
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.holidaysCollection = [];
    }
    ionViewWillEnter() {
        this.holidaysCollection = [];
    }
    ngOnInit() {
        this.getParam();
    }
    getParam() {
        this.activatedRoute.params.subscribe((param) => {
            this.employeeID = param.id;
            this.getAllHolydayGroupsByEmployee(this.employeeID);
        });
    }
    getAllHolydayGroupsByEmployee(uuid) {
        this.nonAvaService.getHolidaysByEmployee(uuid).subscribe((res) => {
            res.forEach((item) => {
                this.getAllDayByHolidayGroup(item.groupBy);
            });
        });
    }
    getAllDayByHolidayGroup(holydayCode) {
        this.nonAvaService.getHolidaysByCode(holydayCode).subscribe((res) => {
            const mapped = res.filter((item) => item.date = (0,date_fns__WEBPACK_IMPORTED_MODULE_6__["default"])(new Date(item.date), 'dd MMMM yyyy', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }));
            const newHolydayRange = new src_app_core_models_holidays_holiday_range_model__WEBPACK_IMPORTED_MODULE_2__.HolidayRange();
            newHolydayRange.groupBy = holydayCode;
            newHolydayRange.first = mapped[0];
            newHolydayRange.last = mapped[res.length - 1];
            newHolydayRange.range = res;
            this.holidaysCollection.push(newHolydayRange);
            console.log(this.holidaysCollection);
        });
    }
    goToCreate() {
        this.navCtrl.navigateForward([`holiday/${this.employeeID}`], { relativeTo: this.activatedRoute });
    }
    removeHolidayRange(item) {
        this.nonAvaService.deleteHolidayById(item.groupBy).subscribe(res => {
            this.holidaysCollection = [];
            this.getParam();
        });
    }
    openAlert(item) {
        this.$removeItem.next(item);
        this.deleteAlert.presentAlertConfirm();
    }
    alertBox(confirm) {
        if (confirm) {
            this.removeHolidayRange(this.$removeItem.value);
        }
        else {
            this.$removeItem.next(null);
        }
    }
};
HolidayListPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_3__.NonAvailabilityService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute }
];
HolidayListPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_4__.AlertComponent,] }]
};
HolidayListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-holiday-list',
        template: _holiday_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_holiday_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HolidayListPage);



/***/ }),

/***/ 60268:
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday-list.page.scss?ngResource ***!
  \*************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob2xpZGF5LWxpc3QucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 58410:
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/holiday-list/holiday-list.page.html?ngResource ***!
  \*************************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Vacaciones'\"></app-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\" >\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ng-container *ngIf=\"holidaysCollection.length > 0; else noData\">\n  <ng-container *ngFor=\"let item of holidaysCollection\">\n    <ion-card class=\"textbox no-border\" >\n    <ion-grid class=\"service-card\">\n      <ion-row>\n       \n        <ion-col>\n          <ion-item>\n            <ion-label class=\"service-label no-padding\">\n            {{item.first.date  }} - {{item.last.date}}\n            </ion-label>\n              <ion-icon icon=\"trash\" (click)=\"openAlert(item)\"></ion-icon>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n  </ng-container>\n  </ng-container>\n\n</ion-content>\n<app-alert #deleteAlert [title]=\"'¿Desea borrar este empleado?'\" (actionEmitter)=\"alertBox($event)\"></app-alert>\n<ng-template #noData>\n <app-no-data [title]=\"'No hay vacaciones creadas'\" [content]=\"true\"></app-no-data>\n</ng-template>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday-list_module_ts.js.map