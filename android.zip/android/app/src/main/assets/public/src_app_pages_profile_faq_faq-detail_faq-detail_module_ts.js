"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_faq_faq-detail_faq-detail_module_ts"],{

/***/ 39841:
/*!***************************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-detail/faq-detail-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqDetailPageRoutingModule": () => (/* binding */ FaqDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _faq_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./faq-detail.page */ 16780);




const routes = [
    {
        path: '',
        component: _faq_detail_page__WEBPACK_IMPORTED_MODULE_0__.FaqDetailPage
    }
];
let FaqDetailPageRoutingModule = class FaqDetailPageRoutingModule {
};
FaqDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FaqDetailPageRoutingModule);



/***/ }),

/***/ 70977:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-detail/faq-detail.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqDetailPageModule": () => (/* binding */ FaqDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _faq_detail_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./faq-detail-routing.module */ 39841);
/* harmony import */ var _faq_detail_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./faq-detail.page */ 16780);








let FaqDetailPageModule = class FaqDetailPageModule {
};
FaqDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _faq_detail_routing_module__WEBPACK_IMPORTED_MODULE_1__.FaqDetailPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule
        ],
        declarations: [_faq_detail_page__WEBPACK_IMPORTED_MODULE_2__.FaqDetailPage]
    })
], FaqDetailPageModule);



/***/ }),

/***/ 16780:
/*!*****************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-detail/faq-detail.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FaqDetailPage": () => (/* binding */ FaqDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _faq_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./faq-detail.page.html?ngResource */ 98367);
/* harmony import */ var _faq_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./faq-detail.page.scss?ngResource */ 66554);
/* harmony import */ var _core_services_faq_faq_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/services/faq/faq.service */ 45821);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);






let FaqDetailPage = class FaqDetailPage {
    constructor(router, faqService) {
        this.router = router;
        this.faqService = faqService;
        this.faqCollection = [];
        this.faqCollectionFiltered = [];
        if (this.router.getCurrentNavigation().extras.state) {
            this.faqCategorySelected = this.router.getCurrentNavigation().extras.state.faqCategorySelected;
            this.getFAQByCategory();
        }
    }
    ngOnInit() {
    }
    getFAQByCategory() {
        this.faqService.getAllByCategory(this.faqCategorySelected.uuid).subscribe(response => {
            this.faqCollection = response;
            this.faqCollectionFiltered = this.faqCollection;
        });
    }
    searchFAQ(event) {
        const value = event.target.value;
        this.faqCollectionFiltered = this.faqCollection;
        if (value.length >= 3) {
            this.faqCollectionFiltered = this.faqCollectionFiltered.filter(option => {
                if (option.content.toLowerCase().includes(value.toLowerCase()) ||
                    option.topic.toLowerCase().includes(value.toLowerCase())) {
                    return option;
                }
            });
            // Filtra si hay tags que coinciden con la búsqueda
            this.faqCollection.forEach(faq => {
                faq.tag.forEach(item => {
                    if (item.name.toLowerCase().includes(value.toLowerCase())) {
                        if (!this.faqCollectionFiltered.includes(faq)) {
                            this.faqCollectionFiltered.push(faq);
                        }
                    }
                });
            });
        }
    }
};
FaqDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _core_services_faq_faq_service__WEBPACK_IMPORTED_MODULE_2__.FaqService }
];
FaqDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-faq-detail',
        template: _faq_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_faq_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FaqDetailPage);



/***/ }),

/***/ 66554:
/*!******************************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-detail/faq-detail.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmYXEtZGV0YWlsLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 98367:
/*!******************************************************************************!*\
  !*** ./src/app/pages/profile/faq/faq-detail/faq-detail.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titleCase]=\"false\" [titlePage]=\"'FAQ - ' + faqCategorySelected.name\">\n</app-header>\n\n<ion-content>\n  <ion-searchbar (ionInput)=\"searchFAQ($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n  <ion-accordion-group *ngFor=\"let faq of faqCollectionFiltered\" [value]=\"faq.topic\">\n    <ion-accordion >\n      <ion-item class=\"textbox\" slot=\"header\">\n        <ion-icon name=\"information-circle\" slot=\"start\"></ion-icon>\n        <ion-label>{{faq.topic}}</ion-label>\n      </ion-item>\n      <div slot=\"content\">\n        <ion-card>\n          <ion-card-content>\n            {{faq.content}}\n          </ion-card-content>\n        </ion-card>\n      </div>\n    </ion-accordion>\n  </ion-accordion-group>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_faq_faq-detail_faq-detail_module_ts.js.map