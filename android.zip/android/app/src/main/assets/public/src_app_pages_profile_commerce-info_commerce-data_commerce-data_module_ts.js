"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_commerce-data_commerce-data_module_ts"],{

/***/ 28299:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-data/commerce-data-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceDataPageRoutingModule": () => (/* binding */ CommerceDataPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _commerce_data_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commerce-data.page */ 49945);




const routes = [
    {
        path: '',
        component: _commerce_data_page__WEBPACK_IMPORTED_MODULE_0__.CommerceDataPage
    },
    {
        path: 'select-hour',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-node_modules_date-fns_esm_addWeeks_index_js-src_app_shared_components_select-hour_sel-6c40cf")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../../../shared/components/select-hour/select-hour.module */ 17711)).then((m) => m.SelectHourPageModule)
    }
];
let CommerceDataPageRoutingModule = class CommerceDataPageRoutingModule {
};
CommerceDataPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CommerceDataPageRoutingModule);



/***/ }),

/***/ 48820:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-data/commerce-data.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceDataPageModule": () => (/* binding */ CommerceDataPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _commerce_data_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commerce-data-routing.module */ 28299);
/* harmony import */ var _commerce_data_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commerce-data.page */ 49945);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);











let CommerceDataPageModule = class CommerceDataPageModule {
};
CommerceDataPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _commerce_data_routing_module__WEBPACK_IMPORTED_MODULE_0__.CommerceDataPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__.HeaderModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__.AlertModule,
            ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__.IonIntlTelInputModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_4__.TranslateDaysModule
        ],
        declarations: [_commerce_data_page__WEBPACK_IMPORTED_MODULE_1__.CommerceDataPage]
    })
], CommerceDataPageModule);



/***/ }),

/***/ 49945:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-data/commerce-data.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceDataPage": () => (/* binding */ CommerceDataPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _commerce_data_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commerce-data.page.html?ngResource */ 22268);
/* harmony import */ var _commerce_data_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commerce-data.page.scss?ngResource */ 33458);
/* harmony import */ var src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/timeTable/time-table.service */ 79223);
/* harmony import */ var src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/transformers/timeTable.transformer */ 27312);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _core_services_commerce_commerce_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../../core/services/commerce/commerce.service */ 4696);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);












let CommerceDataPage = class CommerceDataPage {
    constructor(navCtrl, commerceService, formBuilder, actionSheetCtrl, dateService, timeTableService, activatedRoute) {
        this.navCtrl = navCtrl;
        this.commerceService = commerceService;
        this.formBuilder = formBuilder;
        this.actionSheetCtrl = actionSheetCtrl;
        this.dateService = dateService;
        this.timeTableService = timeTableService;
        this.activatedRoute = activatedRoute;
        this.defaultImage = '';
        this.timetableText = 'Ver horario';
        this.weekDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        this.phone = {
            dialCode: '+34',
            internationalNumber: '',
            isoCode: 'es',
            nationalNumber: ''
        };
        this.formValue = { phoneNumber: this.phone };
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.getCommerceData();
        this.initForms();
        this.timeTableService.updateHourday$.subscribe(response => {
            this.setDefaultHours(response);
        });
    }
    get phoneNumber() { return this.commerceForm.get('phone'); }
    ngOnInit() { }
    getCommerceData() {
        this.commerceService.getCommerceInfoById(this.currentUser.commerce).subscribe(response => {
            var _a;
            this.commerce = response;
            this.setDefaultHours(this.commerce.timetable);
            if (this.commerce) {
                const customerPhone = {
                    dialCode: '+34',
                    internationalNumber: '',
                    isoCode: 'es',
                    nationalNumber: (_a = this.commerce) === null || _a === void 0 ? void 0 : _a.phone
                };
                this.phoneNumber.setValue(customerPhone);
            }
        });
    }
    initForms() {
        this.initCommerceForm();
        this.initTimeTableForm();
    }
    initCommerceForm() {
        this.commerceForm = this.formBuilder.group({
            name: [this.commerce ? this.commerce.name : '', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            phone: [this.formValue.phoneNumber,
                [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required,
                    ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_7__.IonIntlTelInputValidators.phone]
            ],
            email: [{ value: this.commerce ? this.commerce.email : '' }, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            description: [this.commerce ? this.commerce.description : ''],
            address: [this.commerce ? this.commerce.address : '', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            province: [this.commerce ? this.commerce.province : '', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            city: [this.commerce ? this.commerce.city : '', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            municipality: [this.commerce ? this.commerce.municipality : '', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            postCode: [this.commerce ? this.commerce.postCode : '', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(5)]]
        });
    }
    initTimeTableForm() {
        this.timeTableForm = this.formBuilder.group({
            monday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimemonday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimemonday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            tuesday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimetuesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimetuesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            wednesday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimewednesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimewednesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            thursday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimethursday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimethursday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            friday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimefriday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimefriday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            saturday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimesaturday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimesaturday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            sunday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            checkinTimesunday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            departureTimesunday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
        });
    }
    setDefaultHours(timetable) {
        this.schedule = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_3__.TimeTableTransformer.toRangeTable(timetable);
        for (const day in this.schedule) {
            const checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].start.hour}:${this.schedule[day].start.minute}`);
            const departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].end.hour}:${this.schedule[day].end.minute}`);
            if (this.schedule[day].rest) {
                const checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.start.hour}:${this.schedule[day].rest.start.minute}`);
                const departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.end.hour}:${this.schedule[day].rest.end.minute}`);
                this.timeTableForm.get(`checkinTime${day}`).setValue(`${checkinHour}-${checkinRestHour} | ${departureRestHour}-${departureHour}`);
                this.timeTableForm.get(`departureTime${day}`).setValue('');
            }
            else {
                this.timeTableForm.get(`checkinTime${day}`).setValue(`${checkinHour}-`);
                this.timeTableForm.get(`departureTime${day}`).setValue(departureHour);
            }
            this.timeTableForm.get(day).setValue(!checkinHour.includes('null') ? true : false);
        }
        this.schedule.uuid = timetable.uuid;
    }
    onFocus(event) {
        event.target.parentElement.classList.add('fill-input');
    }
    onBlur(event) {
        if (!event.target.value) {
            event.target.parentElement.classList.remove('fill-input');
        }
    }
    selectImage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const buttons = [
                {
                    text: 'Hacer foto',
                    icon: 'camera',
                    handler: () => { },
                },
                {
                    text: 'Galería',
                    icon: 'image',
                    handler: () => { },
                },
                {
                    text: 'Cancelar',
                    icon: 'close',
                    role: 'destructive',
                    handler: () => { },
                },
            ];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: 'Seleccionar imagen',
                buttons,
            });
            yield actionSheet.present();
        });
    }
    saveCommerce() {
        this.commerce.name = this.commerceForm.get('name').value;
        this.commerce.phone = this.phoneNumber.value.nationalNumber;
        this.commerce.description = this.commerceForm.get('description').value;
        this.commerce.address = this.commerceForm.get('address').value;
        this.commerce.province = this.commerceForm.get('province').value;
        this.commerce.municipality = this.commerceForm.get('municipality').value;
        this.commerce.city = this.commerceForm.get('city').value;
        this.commerce.postCode = this.commerceForm.get('postCode').value;
        this.commerceService.saveCommerce(this.commerce).subscribe(response => {
            if (response) {
                this.cancel();
            }
        });
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/commerce-info'], { replaceUrl: true });
    }
    goToConfigureSchedule(day) {
        const timetableId = this.schedule.uuid;
        const scheduleDay = {
            checkinHour: this.timeTableForm.get(`checkinTime${day}`).value,
            departureHour: this.timeTableForm.get(`departureTime${day}`).value,
            checkinRestHour: '',
            departureRestHour: ''
        };
        if (this.schedule[day].rest) {
            scheduleDay.checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].start.hour}:${this.schedule[day].start.minute}`);
            scheduleDay.departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].end.hour}:${this.schedule[day].end.minute}`);
            scheduleDay.checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.start.hour}:${this.schedule[day].rest.start.minute}`);
            ;
            scheduleDay.departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.end.hour}:${this.schedule[day].rest.end.minute}`);
            ;
        }
        const navigationExtras = {
            state: { day, scheduleDay, timetableId, isCommerce: true },
            relativeTo: this.activatedRoute
        };
        this.navCtrl.navigateForward(['select-hour'], navigationExtras);
    }
    changeAccordion(event) {
        this.timetableText = event.detail.value ? 'Ocultar horario' : 'Ver horario';
    }
};
CommerceDataPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController },
    { type: _core_services_commerce_commerce_service__WEBPACK_IMPORTED_MODULE_5__.CommerceService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ActionSheetController },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__.DateService },
    { type: src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_2__.TimeTableService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute }
];
CommerceDataPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-commerce-data',
        template: _commerce_data_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_commerce_data_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CommerceDataPage);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 33458:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-data/commerce-data.page.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = ".edit_profile_main_content {\n  padding: 0px 16px 16px 16px;\n}\n.edit_profile_main_content .user_image {\n  height: 100px;\n  width: 100px;\n  border-radius: 50%;\n  margin: auto;\n  margin-top: 5%;\n  border: 1px solid lightgray;\n}\n.edit_profile_main_content .user_image img {\n  border-radius: 50%;\n  height: 98px;\n  width: 100px;\n}\n.hour-list {\n  margin-top: 0 !important;\n  box-shadow: none !important;\n  border-bottom: 1px solid gray !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1lcmNlLWRhdGEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMkJBQUE7QUFDRjtBQUNFO0VBQ0UsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7QUFDSjtBQUFJO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQUVOO0FBR0E7RUFDRSx3QkFBQTtFQUNBLDJCQUFBO0VBQ0Esd0NBQUE7QUFBRiIsImZpbGUiOiJjb21tZXJjZS1kYXRhLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lZGl0X3Byb2ZpbGVfbWFpbl9jb250ZW50IHtcbiAgcGFkZGluZzogMHB4IDE2cHggMTZweCAxNnB4O1xuXG4gIC51c2VyX2ltYWdlIHtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDUlO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICBpbWcge1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgaGVpZ2h0OiA5OHB4O1xuICAgICAgd2lkdGg6IDEwMHB4O1xuICAgIH1cbiAgfVxufVxuXG4uaG91ci1saXN0IHtcbiAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmF5ICFpbXBvcnRhbnQ7XG59XG4iXX0= */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 22268:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-data/commerce-data.page.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Datos del negocio'\"></app-header>\n\n<ion-content>\n <div class=\"edit_profile_main_content\">\n    <form [formGroup]=\"commerceForm\">\n\n      <div class=\"user_image\" (click)=\"selectImage()\">\n        <img [src]=\"commerce ? commerce.logo : defaultImage\">\n      </div>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['name'].value ? 'fill-input' : ''\">\n        <ion-label>Nombre</ion-label>\n        <ion-input formControlName=\"name\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n          [value]=\"commerce?.name\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['email'].value ? 'fill-input' : ''\">\n        <ion-label>Email</ion-label>\n        <ion-input formControlName=\"email\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"email\"\n          [value]=\"commerce?.email\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['phone'].value ? 'fill-input' : ''\">\n        <ion-label>Teléfono</ion-label>\n         <ion-intl-tel-input\n            class=\"ion-text-right absolute right-[7px] float-right w-1/2 \"\n             [enableAutoCountrySelect]=\"true\"\n          [defaultCountryiso]=\"'es'\"\n          [preferredCountries]=\"['es']\"\n          [modalSearchPlaceholder]=\"'Buscar...'\"\n          [modalCloseText]=\"'Cerrar'\"\n               formControlName=\"phone\"\n           [inputPlaceholder]=\"'600 123 456'\"\n           modalTitle=\"Seleccione país\"\n     ></ion-intl-tel-input>\n      </ion-item>\n<div class=\"px-4\" *ngIf=\"phoneNumber.invalid && phoneNumber.touched\">\n    <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.required\">\n      <p class=\"ion-no-margin\"><sub>El teléfono es requerido</sub></p>\n    </ion-text>\n    <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.phone\">\n      <p class=\"ion-no-margin\"><sub>El teléfono no es válido.</sub></p>\n    </ion-text>\n  </div>\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['address'].value ? 'fill-input' : ''\">\n        <ion-label>Dirección</ion-label>\n        <ion-input formControlName=\"address\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n          [value]=\"commerce?.address\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n         <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['municipality'].value ? 'fill-input' : ''\">\n        <ion-label>Localidad</ion-label>\n        <ion-input formControlName=\"municipality\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n          [value]=\"commerce?.municipality\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['city'].value ? 'fill-input' : ''\">\n        <ion-label>Ciudad</ion-label>\n        <ion-input formControlName=\"city\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n          [value]=\"commerce?.city\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['province'].value ? 'fill-input' : ''\">\n        <ion-label>Provincia</ion-label>\n        <ion-input formControlName=\"province\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n          [value]=\"commerce?.province\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['postCode'].value ? 'fill-input' : ''\">\n        <ion-label>Código postal</ion-label>\n        <ion-input formControlName=\"postCode\"  (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"number\"\n          [value]=\"commerce?.postCode\" autocapitalize=\"true\" class=\"ion-text-right\" inputmode=\"numeric\"></ion-input>\n      </ion-item>\n\n      <ion-item class=\"textbox\" [ngClass]=\"commerceForm.controls['description'].value ? 'fill-input' : ''\">\n        <ion-label>Descripción</ion-label>\n        <ion-textarea autoGrow=\"true\"  [placeholder]=\"'Breve descripción de tu negocio (recomendado)'\" formControlName=\"description\"\n          (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\"\n          [value]=\"commerce?.description\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-textarea>\n      </ion-item>\n    </form>\n\n    <ion-accordion-group (ionChange)=\"changeAccordion($event)\">\n      <ion-accordion value=\"timetable\">\n        <ion-item class=\"textbox\" slot=\"header\">\n          <ion-label>{{timetableText}}</ion-label>\n        </ion-item>\n\n        <form [formGroup]=\"timeTableForm\" slot=\"content\">\n          <ion-grid fixed>\n            <ion-list>\n              <ion-row *ngFor=\"let day of weekDays\" (click)=\"goToConfigureSchedule(day)\">\n                <ion-item class=\"textbox hour-list w-full\">\n                  <ion-col class=\"no-padding\" size=\"3\">\n                    <ion-label class=\"no-padding\">{{day | translateDays | titlecase}}</ion-label>\n                  </ion-col>\n                  <ion-col size=\"8\">\n                    <ion-label *ngIf=\"timeTableForm.controls[day].value\">\n                      {{timeTableForm.controls['checkinTime'+day].value\n                      }}{{timeTableForm.controls['departureTime'+day].value }}\n                    </ion-label>\n                    <ion-label *ngIf=\"!timeTableForm.controls[day].value\">\n                      Cerrado\n                    </ion-label>\n                  </ion-col>\n                  <ion-col size=\"1\">\n                    <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n                  </ion-col>\n                </ion-item>\n              </ion-row>\n            </ion-list>\n          </ion-grid>\n        </form>\n      </ion-accordion>\n    </ion-accordion-group>\n  </div>\n</ion-content>\n\n\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n\n      <ion-col>\n        <ion-button [disabled]=\"!commerceForm.valid\" (click)=\"saveCommerce()\" class=\"btn\" expand=\"block\">\n          Guardar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_commerce-data_commerce-data_module_ts.js.map