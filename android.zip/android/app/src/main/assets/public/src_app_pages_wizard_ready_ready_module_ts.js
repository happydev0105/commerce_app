"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_wizard_ready_ready_module_ts"],{

/***/ 64446:
/*!************************************************************!*\
  !*** ./src/app/pages/wizard/ready/ready-routing.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReadyPageRoutingModule": () => (/* binding */ ReadyPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ready_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ready.page */ 12977);




const routes = [
    {
        path: '',
        component: _ready_page__WEBPACK_IMPORTED_MODULE_0__.ReadyPage
    }
];
let ReadyPageRoutingModule = class ReadyPageRoutingModule {
};
ReadyPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReadyPageRoutingModule);



/***/ }),

/***/ 18632:
/*!****************************************************!*\
  !*** ./src/app/pages/wizard/ready/ready.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReadyPageModule": () => (/* binding */ ReadyPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _ready_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ready-routing.module */ 64446);
/* harmony import */ var _ready_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ready.page */ 12977);







let ReadyPageModule = class ReadyPageModule {
};
ReadyPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ready_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReadyPageRoutingModule
        ],
        declarations: [_ready_page__WEBPACK_IMPORTED_MODULE_1__.ReadyPage]
    })
], ReadyPageModule);



/***/ }),

/***/ 12977:
/*!**************************************************!*\
  !*** ./src/app/pages/wizard/ready/ready.page.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReadyPage": () => (/* binding */ ReadyPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ready_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ready.page.html?ngResource */ 69134);
/* harmony import */ var _ready_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ready.page.scss?ngResource */ 54441);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 65485);





let ReadyPage = class ReadyPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() { }
    goHome() {
        localStorage.setItem('wizard', 'true');
        this.router.navigate(['']);
    }
};
ReadyPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ReadyPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ready',
        template: _ready_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ready_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReadyPage);



/***/ }),

/***/ 54441:
/*!***************************************************************!*\
  !*** ./src/app/pages/wizard/ready/ready.page.scss?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "ion-content, ion-item {\n  --background: rgb(86 197 124);\n  --color: white;\n}\n\n.payment-confirmed {\n  margin-top: 50%;\n  text-align: center;\n}\n\n.payment-confirmed .payment-icon {\n  font-size: 128px;\n}\n\n.payment-confirmed h1, .payment-confirmed h2 {\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlYWR5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDZCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBRUY7O0FBQUU7RUFDRSxnQkFBQTtBQUVKOztBQUFFO0VBQ0UsWUFBQTtBQUVKIiwiZmlsZSI6InJlYWR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50LCBpb24taXRlbSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiByZ2IoODYgMTk3IDEyNCk7XHJcbiAgLS1jb2xvcjogd2hpdGU7XHJcbn1cclxuLnBheW1lbnQtY29uZmlybWVkIHtcclxuICBtYXJnaW4tdG9wOiA1MCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAucGF5bWVudC1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMTI4cHg7XHJcbiAgfVxyXG4gIGgxLGgyIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiBcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 69134:
/*!***************************************************************!*\
  !*** ./src/app/pages/wizard/ready/ready.page.html?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "<ion-content fullscreen=\"true\" center text-center>\n  <div class=\"payment-confirmed\">\n    <ion-icon class=\"filter payment-icon\" name=\"checkmark-circle-outline\"></ion-icon>\n    <h1>¡Configuración realizada!</h1>\n    <p>Ya puedes comenzar a gestionar tu negocio.</p>\n  </div>\n  <div class=\"w-full absolute bottom-4\">\n    <ion-button (click)=\"goHome()\" class=\"btn apply-button \" expand=\"block\">\n      Aceptar\n    </ion-button>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_wizard_ready_ready_module_ts.js.map