"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_payment-methods_payment-methods_module_ts"],{

/***/ 83907:
/*!*************************************************************************!*\
  !*** ./src/app/core/services/payment-method/payments-method.service.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsMethodService": () => (/* binding */ PaymentsMethodService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let PaymentsMethodService = class PaymentsMethodService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findPaymentMethodByCommerce(commerce) {
        return this.http.get(`${this.apiUrl}/payments-methods/commerce/${commerce}`);
    }
    createMethod(dto) {
        return this.http.post(`${this.apiUrl}/payments-methods`, dto);
    }
    deleteMethod(uuid) {
        return this.http.delete(`${this.apiUrl}/payments-methods/${uuid}`);
    }
};
PaymentsMethodService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PaymentsMethodService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PaymentsMethodService);



/***/ }),

/***/ 61646:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-methods-routing.module.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodsPageRoutingModule": () => (/* binding */ PaymentMethodsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _payment_methods_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-methods.page */ 46960);




const routes = [
    {
        path: '',
        component: _payment_methods_page__WEBPACK_IMPORTED_MODULE_0__.PaymentMethodsPage
    },
    {
        path: 'payment-method-item',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_commerce-info_payment-methods_payment-method-item_payment-method-item_m-087f2d").then(__webpack_require__.bind(__webpack_require__, /*! ./payment-method-item/payment-method-item.module */ 49748)).then(m => m.PaymentMethodItemPageModule)
    }
];
let PaymentMethodsPageRoutingModule = class PaymentMethodsPageRoutingModule {
};
PaymentMethodsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentMethodsPageRoutingModule);



/***/ }),

/***/ 15364:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-methods.module.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodsPageModule": () => (/* binding */ PaymentMethodsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _payment_methods_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-methods-routing.module */ 61646);
/* harmony import */ var _payment_methods_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payment-methods.page */ 46960);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);









let PaymentMethodsPageModule = class PaymentMethodsPageModule {
};
PaymentMethodsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _payment_methods_routing_module__WEBPACK_IMPORTED_MODULE_1__.PaymentMethodsPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_payment_methods_page__WEBPACK_IMPORTED_MODULE_2__.PaymentMethodsPage]
    })
], PaymentMethodsPageModule);



/***/ }),

/***/ 46960:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-methods.page.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodsPage": () => (/* binding */ PaymentMethodsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _payment_methods_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-methods.page.html?ngResource */ 87948);
/* harmony import */ var _payment_methods_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-methods.page.scss?ngResource */ 69417);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/payment-method/payments-method.service */ 83907);







let PaymentMethodsPage = class PaymentMethodsPage {
    constructor(navCtrl, activatedRoute, methodService) {
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
        this.methodService = methodService;
        this.methodCollection = [];
        this.methodCollectionFiltered = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllMethods();
    }
    getAllMethods() {
        this.methodService.findPaymentMethodByCommerce(this.commerceLogged).subscribe((response) => {
            this.methodCollection = response;
            this.methodCollectionFiltered = this.methodCollection;
        });
    }
    searchMethod(event) {
        const value = event.target.value;
        this.methodCollectionFiltered = this.methodCollection;
        if (value.length >= 3) {
            this.methodCollectionFiltered = this.methodCollectionFiltered.filter(option => option.label.toLowerCase().includes(value.toLowerCase()));
        }
    }
    goToDetail(method) {
        const navigationExtras = { state: { method }, relativeTo: this.activatedRoute };
        this.navCtrl.navigateForward(['payment-method-item'], navigationExtras);
    }
    goToCreate() {
        this.navCtrl.navigateForward(['payment-method-item'], { relativeTo: this.activatedRoute });
    }
};
PaymentMethodsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_2__.PaymentsMethodService }
];
PaymentMethodsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-payment-methods',
        template: _payment_methods_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payment_methods_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentMethodsPage);



/***/ }),

/***/ 69417:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-methods.page.scss?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXltZW50LW1ldGhvZHMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 87948:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-methods.page.html?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Métodos de pago'\"></app-header>\n\n<ion-content>\n\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-searchbar *ngIf=\"methodCollectionFiltered.length > 0\"  (ionInput)=\"searchMethod($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n  <ion-grid *ngIf=\"methodCollectionFiltered.length > 0\" fixed style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray;\">\n    <ion-row>\n      <ion-col size=\"10\">\n        <ion-item>\n          <ion-label\n            [innerText]=\"methodCollectionFiltered.length < 2 && methodCollectionFiltered.length > 0 ? methodCollectionFiltered.length + ' elemento' : methodCollectionFiltered.length + ' elementos'\">\n          </ion-label>\n        </ion-item>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n  <ion-card class=\"textbox no-border\" *ngFor=\"let method of methodCollectionFiltered\" (click)=\"goToDetail(method)\">\n    <ion-grid class=\"service-card\">\n      <ion-row>\n        <ion-col size=\"0.1\" style.background-color=\"black\"></ion-col>\n        <ion-col>\n          <ion-item button=\"true\">\n            <ion-label class=\"service-label no-padding\">\n              {{method.label}}\n            </ion-label>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n  <app-no-data  *ngIf=\"methodCollectionFiltered.length === 0\" [title]=\"'Parece que aún no has añadido métodos de pago'\"></app-no-data>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_payment-methods_payment-methods_module_ts.js.map