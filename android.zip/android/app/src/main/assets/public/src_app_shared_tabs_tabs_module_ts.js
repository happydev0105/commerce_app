"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_shared_tabs_tabs_module_ts"],{

/***/ 72888:
/*!*************************************************************!*\
  !*** ./node_modules/@capacitor/app/dist/esm/definitions.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 98119:
/*!*******************************************************!*\
  !*** ./node_modules/@capacitor/app/dist/esm/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "App": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 16594);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 72888);

const App = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('App', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_app_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 34500)).then(m => new m.AppWeb()),
});




/***/ }),

/***/ 71317:
/*!****************************************************!*\
  !*** ./src/app/shared/tabs/tabs-routing.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page */ 30766);




const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_0__.TabsPage,
        children: [
            {
                path: 'home',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_addMonths_index_js-node_modules_date-fns_esm_constants_inde-b27e6a"), __webpack_require__.e("default-node_modules_gsap_Draggable_js-node_modules_gsap_index_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_booking-manager_booking-manager_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../pages/booking-manager/booking-manager.module */ 78505)).then((m) => m.BookingManagerPageModule),
            },
            {
                path: 'customers',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_customer_customer_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../pages/customer/customer.module */ 56921)).then((m) => m.CustomerPageModule),
            },
            {
                path: 'payments',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"), __webpack_require__.e("default-src_app_pages_payments_payments_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_core_models_payments_payments_model_ts-src_app_core_services_payments_payments_servic-6e1bd8")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../pages/payments/payments.module */ 15795)).then((m) => m.PaymentsPageModule),
            },
            {
                path: 'profile',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_profile_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../pages/profile/profile.module */ 88558)).then((m) => m.ProfilePageModule),
            },
            {
                path: '',
                redirectTo: '/tabs/home',
                pathMatch: 'full',
            },
        ],
    },
    {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full',
    },
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 78717:
/*!********************************************!*\
  !*** ./src/app/shared/tabs/tabs.module.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageModule": () => (/* binding */ TabsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-routing.module */ 71317);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ 30766);







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__.TabsPageRoutingModule
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_1__.TabsPage]
    })
], TabsPageModule);



/***/ }),

/***/ 30766:
/*!******************************************!*\
  !*** ./src/app/shared/tabs/tabs.page.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPage": () => (/* binding */ TabsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page.html?ngResource */ 9713);
/* harmony import */ var _tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.scss?ngResource */ 37218);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/app */ 98119);









let TabsPage = class TabsPage {
    constructor(authService, router, platform, alertController, location) {
        this.authService = authService;
        this.router = router;
        this.platform = platform;
        this.alertController = alertController;
        this.location = location;
        this.lastTimeBackPress = 0;
        this.timePeriodToExit = 2000;
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }
    ngOnInit() {
        this.backButtonEvent();
    }
    setCurrentTab() {
        this.selectedTab = this.tabs.getSelected();
        this.router.navigate([`tabs/${this.tabs.getSelected()}`], { replaceUrl: true });
    }
    backButtonEvent() {
        this.platform.backButton.subscribeWithPriority(0, (event) => {
            if (this.router.url === '/tabs/profile'
                || this.router.url === '/tabs/payments'
                || this.router.url === '/tabs/customers') {
                this.router.navigate(['/tabs/home']);
            }
            else if (this.router.url === '/tabs/home') {
                this.presentAlertConfirm();
            }
            else {
                this.location.back();
            }
        });
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                // header: 'Confirm!',
                message: '¿Desea salir de Yeasy?',
                buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => { }
                    }, {
                        text: 'Salir',
                        handler: () => {
                            _capacitor_app__WEBPACK_IMPORTED_MODULE_3__.App.exitApp();
                        }
                    }]
            });
            yield alert.present();
        });
    }
};
TabsPage.ctorParameters = () => [
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.Location }
];
TabsPage.propDecorators = {
    routerOutlets: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChildren, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRouterOutlet,] }],
    tabs: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['tabs', { static: false },] }]
};
TabsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-tabs',
        template: _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TabsPage);



/***/ }),

/***/ 37218:
/*!*******************************************************!*\
  !*** ./src/app/shared/tabs/tabs.page.scss?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "ion-tab-bar {\n  --background: black;\n}\n\nion-tab-button {\n  --color-selected: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLHVCQUFBO0FBQ0YiLCJmaWxlIjoidGFicy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdGFiLWJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBibGFjaztcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gIC0tY29sb3Itc2VsZWN0ZWQ6IHdoaXRlO1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 9713:
/*!*******************************************************!*\
  !*** ./src/app/shared/tabs/tabs.page.html?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "<ion-tabs #tabs (ionTabsDidChange)=\"setCurrentTab()\">\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"calendar-outline\"></ion-icon>\n      <ion-label *ngIf=\"selectedTab === 'home'\">Reservas</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button *ngIf=\"authService.checkPermission('gestion_clientes')\" tab=\"customers\">\n      <ion-icon name=\"people-outline\"></ion-icon>\n      <ion-label *ngIf=\"selectedTab === 'customers'\">Clientes</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button *ngIf=\"authService.checkPermission('ventas')\" tab=\"payments\">\n      <ion-icon name=\"file-tray-full-outline\"></ion-icon>\n      <ion-label *ngIf=\"selectedTab === 'payments'\">Venta</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"profile\">\n      <ion-icon name=\"person-outline\"></ion-icon>\n      <ion-label *ngIf=\"selectedTab === 'profile'\">My Yeasy</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_shared_tabs_tabs_module_ts.js.map