"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_products_product-item_product-item_module_ts"],{

/***/ 5868:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/addDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addDays
 * @category Day Helpers
 * @summary Add the specified number of days to the given date.
 *
 * @description
 * Add the specified number of days to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} - the new date with the days added
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // Add 10 days to 1 September 2014:
 * const result = addDays(new Date(2014, 8, 1), 10)
 * //=> Thu Sep 11 2014 00:00:00
 */

function addDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyAmount);

  if (isNaN(amount)) {
    return new Date(NaN);
  }

  if (!amount) {
    // If 0 days, no-op to avoid changing times in the hour before end of DST
    return date;
  }

  date.setDate(date.getDate() + amount);
  return date;
}

/***/ }),

/***/ 37584:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/addWeeks/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addWeeks)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addWeeks
 * @category Week Helpers
 * @summary Add the specified number of weeks to the given date.
 *
 * @description
 * Add the specified number of week to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of weeks to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the weeks added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 4 weeks to 1 September 2014:
 * const result = addWeeks(new Date(2014, 8, 1), 4)
 * //=> Mon Sep 29 2014 00:00:00
 */

function addWeeks(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  var days = amount * 7;
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, days);
}

/***/ }),

/***/ 19040:
/*!***************************************************************!*\
  !*** ./node_modules/date-fns/esm/eachWeekOfInterval/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eachWeekOfInterval)
/* harmony export */ });
/* harmony import */ var _addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../addWeeks/index.js */ 37584);
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




/**
 * @name eachWeekOfInterval
 * @category Interval Helpers
 * @summary Return the array of weeks within the specified time interval.
 *
 * @description
 * Return the array of weeks within the specified time interval.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Interval} interval - the interval. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @returns {Date[]} the array with starts of weeks from the week of the interval start to the week of the interval end
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be 0, 1, ..., 6
 * @throws {RangeError} The start of an interval cannot be after its end
 * @throws {RangeError} Date in interval cannot be `Invalid Date`
 *
 * @example
 * // Each week within interval 6 October 2014 - 23 November 2014:
 * var result = eachWeekOfInterval({
 *   start: new Date(2014, 9, 6),
 *   end: new Date(2014, 10, 23)
 * })
 * //=> [
 * //   Sun Oct 05 2014 00:00:00,
 * //   Sun Oct 12 2014 00:00:00,
 * //   Sun Oct 19 2014 00:00:00,
 * //   Sun Oct 26 2014 00:00:00,
 * //   Sun Nov 02 2014 00:00:00,
 * //   Sun Nov 09 2014 00:00:00,
 * //   Sun Nov 16 2014 00:00:00,
 * //   Sun Nov 23 2014 00:00:00
 * // ]
 */

function eachWeekOfInterval(dirtyInterval, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var interval = dirtyInterval || {};
  var startDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.start);
  var endDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.end);
  var endTime = endDate.getTime(); // Throw an exception if start date is after end date or if any date is `Invalid Date`

  if (!(startDate.getTime() <= endTime)) {
    throw new RangeError('Invalid interval');
  }

  var startDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(startDate, options);
  var endDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(endDate, options); // Some timezones switch DST at midnight, making start of day unreliable in these timezones, 3pm is a safe bet

  startDateWeek.setHours(15);
  endDateWeek.setHours(15);
  endTime = endDateWeek.getTime();
  var weeks = [];
  var currentWeek = startDateWeek;

  while (currentWeek.getTime() <= endTime) {
    currentWeek.setHours(0);
    weeks.push((0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(currentWeek));
    currentWeek = (0,_addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(currentWeek, 1);
    currentWeek.setHours(15);
  }

  return weeks;
}

/***/ }),

/***/ 2020:
/*!****************************************************!*\
  !*** ./src/app/core/models/product/product.dto.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDto": () => (/* binding */ ProductDto)
/* harmony export */ });
class ProductDto {
}


/***/ }),

/***/ 73372:
/*!******************************************************!*\
  !*** ./src/app/core/services/utils/utils.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UtilsService": () => (/* binding */ UtilsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! date-fns */ 19040);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns/locale */ 36956);




let UtilsService = class UtilsService {
    constructor() { }
    calculateToday() {
        const actualDate = new Date();
        const day = actualDate.getDate();
        const month = actualDate.getMonth() + 1;
        const monthFormatted = month.toString().length === 1 ? `0${month}` : month;
        const dayFormatted = day.toString().length === 1 ? `0${day}` : day;
        const year = actualDate.getFullYear();
        const actualDateFormatted = `${year}-${monthFormatted}-${dayFormatted}`;
        return actualDateFormatted;
    }
    capitalizeFirstLetter(text) {
        if (text.length >= 1) {
            const capitalize = text.charAt(0).toUpperCase();
            text = text.replace(text.charAt(0), capitalize);
        }
        return text;
    }
    generateRandomPassword() {
        const chars = '0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const passwordLength = 12;
        let password = '';
        for (let i = 0; i <= passwordLength; i++) {
            const randomNumber = Math.floor(Math.random() * chars.length);
            password += chars.substring(randomNumber, randomNumber + 1);
        }
        return password;
    }
    getAllDaysInMonth(year, month) {
        const date = new Date(year, month, 1);
        const dates = [];
        while (date.getMonth() === month) {
            const evaluateDay = new Date(date).getDate();
            dates.push({
                text: evaluateDay.toString(),
                value: evaluateDay,
            });
            if ((month === 3 || month === 5 || month === 8 || month === 10) && (evaluateDay === 30)) {
                dates.push({
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            if (month === 1 && evaluateDay === 28) {
                dates.push({
                    text: '29',
                    value: 29,
                    disabled: true
                }, {
                    text: '30',
                    value: 30,
                    disabled: true
                }, {
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            date.setDate(date.getDate() + 1);
        }
        return dates;
    }
    getAllWeeks() {
        const weekFormatted = [];
        const result = (0,date_fns__WEBPACK_IMPORTED_MODULE_0__["default"])({
            start: new Date(2022, 0, 2),
            end: new Date(2023, 0, 1)
        }, { weekStartsOn: 1 });
        result.forEach((week, index) => {
            if (result[index + 1]) {
                const weekItem = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] }) + ' ' + (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index + 1], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] });
                weekFormatted.push([weekItem, index + 1]);
            }
        });
        return weekFormatted;
    }
    getAllMonthsInYear() {
        const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        const monthCollection = [];
        months.forEach((month, index) => monthCollection.push({
            text: month,
            value: index + 1
        }));
        return monthCollection;
    }
    getYearsFromYeasyInit() {
        const yeasyYearInit = 2021;
        const currentDate = new Date();
        const actualYear = currentDate.getFullYear();
        const differenceYears = yeasyYearInit - actualYear;
        const yearCollection = [];
        if (differenceYears === 0) {
            return [{ text: '2022', value: 2022 }];
        }
        for (let i = differenceYears; i <= differenceYears; i++) {
            yearCollection.push({
                text: (yeasyYearInit - i).toString(),
                value: yeasyYearInit - i
            });
        }
        return yearCollection;
    }
    generateHours(start, end) {
        const hours = [];
        if (typeof start === 'string') {
            start = Number.parseInt(start, 10);
        }
        if (typeof end === 'string') {
            end = Number.parseInt(end, 10);
        }
        for (let i = start; i <= end; i++) {
            const hour = i.toString();
            hours.push(hour);
        }
        return hours;
    }
    generateMinutes() {
        const availableMinutes = 60;
        const minutes = [];
        for (let i = 0; i < availableMinutes; i += 5) {
            const minute = i.toString();
            minutes.push(minute);
        }
        return minutes;
    }
    transformHourStringIntoMinutes(hour) {
        let duration = 0;
        const hours = Number.parseInt(hour.split(':')[0], 10);
        const minutes = Number.parseInt(hour.split(':')[1], 10);
        duration += (hours * 60) + minutes;
        return duration;
    }
};
UtilsService.ctorParameters = () => [];
UtilsService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], UtilsService);



/***/ }),

/***/ 40874:
/*!************************************************************************************!*\
  !*** ./src/app/pages/profile/products/product-item/product-item-routing.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductItemPageRoutingModule": () => (/* binding */ ProductItemPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _product_item_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-item.page */ 70781);




const routes = [
    {
        path: '',
        component: _product_item_page__WEBPACK_IMPORTED_MODULE_0__.ProductItemPage
    }
];
let ProductItemPageRoutingModule = class ProductItemPageRoutingModule {
};
ProductItemPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductItemPageRoutingModule);



/***/ }),

/***/ 94374:
/*!****************************************************************************!*\
  !*** ./src/app/pages/profile/products/product-item/product-item.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductItemPageModule": () => (/* binding */ ProductItemPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _product_item_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./product-item-routing.module */ 40874);
/* harmony import */ var _product_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-item.page */ 70781);









let ProductItemPageModule = class ProductItemPageModule {
};
ProductItemPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _product_item_routing_module__WEBPACK_IMPORTED_MODULE_2__.ProductItemPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__.AlertModule
        ],
        declarations: [_product_item_page__WEBPACK_IMPORTED_MODULE_3__.ProductItemPage]
    })
], ProductItemPageModule);



/***/ }),

/***/ 70781:
/*!**************************************************************************!*\
  !*** ./src/app/pages/profile/products/product-item/product-item.page.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductItemPage": () => (/* binding */ ProductItemPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _product_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-item.page.html?ngResource */ 31851);
/* harmony import */ var _product_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-item.page.scss?ngResource */ 18638);
/* harmony import */ var _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../core/services/utils/utils.service */ 73372);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_models_product_product_dto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../../core/models/product/product.dto */ 2020);
/* harmony import */ var src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/product/product.service */ 57396);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);











let ProductItemPage = class ProductItemPage {
    constructor(formBuilder, router, productService, navCtrl, utilsService) {
        this.formBuilder = formBuilder;
        this.router = router;
        this.productService = productService;
        this.navCtrl = navCtrl;
        this.utilsService = utilsService;
        this.isEdit = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForms();
        if (this.router.getCurrentNavigation().extras.state) {
            this.product = this.router.getCurrentNavigation().extras.state.product;
            this.name.setValue(this.product.name);
            this.price.setValue(this.product.price);
            this.description.setValue(this.product.description);
            this.reference.setValue(this.product.reference);
            this.qty.setValue(this.product.qty);
            this.isEdit = true;
            this.title = 'Editar producto';
        }
        else {
            this.title = 'Crear producto';
        }
    }
    get name() {
        return this.productForm.get('name');
    }
    get reference() {
        return this.productForm.get('reference');
    }
    get price() {
        return this.productForm.get('price');
    }
    get description() {
        return this.productForm.get('description');
    }
    get qty() {
        return this.productForm.get('qty');
    }
    ngOnInit() {
    }
    initForms() {
        this.productForm = this.formBuilder.group({
            name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
            reference: [''],
            price: [, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.min(1)]],
            qty: [, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.min(1)]],
            description: ['']
        });
    }
    submit() {
        const productDto = new _core_models_product_product_dto__WEBPACK_IMPORTED_MODULE_3__.ProductDto();
        productDto.name = this.name.value;
        productDto.reference = this.reference.value;
        productDto.price = this.price.value;
        productDto.description = this.description.value;
        productDto.commerce = this.commerceLogged;
        productDto.qty = this.qty.value;
        productDto.decimal = 0;
        if (this.isEdit) {
            productDto.uuid = this.product.uuid;
            this.productService.update(productDto).subscribe(res => {
                if (res) {
                    this.cancel();
                }
            });
        }
        else {
            this.productService.create(productDto).subscribe(res => {
                if (res) {
                    this.cancel();
                }
            });
        }
    }
    onFocus(event) {
        event.target.parentElement.classList.add('fill-input');
    }
    onBlur(event) {
        // Si tiene contenido el input no se la quitamos
        if (!event.target.value) {
            event.target.parentElement.classList.remove('fill-input');
        }
    }
    onChange(event) {
        if (event.detail.value) {
            const qtyParsed = Number.parseInt(event.detail.value);
            if (qtyParsed !== NaN) {
                this.productForm.get('qty').setValue(qtyParsed.toString());
            }
        }
    }
    formatPrice(event) {
        let price = event.detail.value;
        if (price) {
            if (price.includes('.')) {
                const index = price.indexOf('.');
                price = price.substring(0, index + 3);
            }
            this.productForm.get('price').setValue(price);
        }
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/products'], { replaceUrl: true });
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    deleteItem() {
        this.productService.deleteProduct(this.product.uuid).subscribe((res) => {
            if (res.affected > 0) {
                this.cancel();
            }
        });
    }
};
ProductItemPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_4__.ProductService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__.UtilsService }
];
ProductItemPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_5__.AlertComponent,] }]
};
ProductItemPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-product-item',
        template: _product_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProductItemPage);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 18638:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/profile/products/product-item/product-item.page.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9kdWN0LWl0ZW0ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 31851:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/profile/products/product-item/product-item.page.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [titlePage]=\"title\" [backButton]=\"true\"></app-header>\n\n<ion-content>\n  <div class=\"edit_profile_main_content\">\n    <form [formGroup]=\"productForm\">\n\n    <ion-item class=\"textbox\" [ngClass]=\"productForm.controls['name'].value ? 'fill-input' : ''\">\n      <ion-label>Nombre</ion-label>\n      <ion-input formControlName=\"name\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n        [value]=\"product?.name\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n    </ion-item>\n\n    <ion-item class=\"textbox\" [ngClass]=\"productForm.controls['reference'].value ? 'fill-input' : ''\">\n      <ion-label>Referencia</ion-label>\n      <ion-input formControlName=\"reference\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n        [value]=\"product?.reference\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n    </ion-item>\n\n    <ion-item class=\"textbox\" [ngClass]=\"productForm.controls['description'].value ? 'fill-input' : ''\">\n      <ion-label>Descripción</ion-label>\n      <ion-input formControlName=\"description\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"text\"\n        [value]=\"product?.description\" autocapitalize=\"true\" class=\"ion-text-right\"></ion-input>\n    </ion-item>\n\n    <ion-item class=\"textbox\" [ngClass]=\"productForm.controls['price'].value ? 'fill-input' : ''\">\n      <ion-label>Precio</ion-label>\n      <ion-input formControlName=\"price\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"number\"\n         (ionChange)=\"formatPrice($event)\" [value]=\"product?.price\" class=\"ion-text-right\" inputmode=\"decimal\" placeholder=\"0\"></ion-input>\n    </ion-item>\n\n    <ion-item class=\"textbox\" [ngClass]=\"productForm.controls['qty'].value ? 'fill-input' : ''\">\n      <ion-label>Unidades</ion-label>\n      <ion-input formControlName=\"qty\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\" type=\"number\"\n        (ionChange)=\"onChange($event)\" [value]=\"product?.qty\" class=\"ion-text-right\" inputmode=\"numeric\" placeholder=\"0\"></ion-input>\n    </ion-item>\n\n  </form>\n  </div>\n\n</ion-content>\n<app-alert #deleteAlert [title]=\"'¿Desea borrar este producto?'\" (actionEmitter)=\"alertBox($event)\"></app-alert>\n<ion-footer class=\"ion-no-border\">\n<ion-grid>\n  <ion-row>\n    <ion-col *ngIf=\"isEdit\" (click)=\"openAlert()\"\n      ><ion-button class=\"btn\" expand=\"block\">\n        <ion-icon icon=\"trash\"></ion-icon>\n      </ion-button>\n    </ion-col>\n\n    <ion-col\n      ><ion-button class=\"btn\" [disabled]=\"!productForm.valid\" (click)=\"submit()\" expand=\"block\">\n        Guardar\n      </ion-button>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n</ion-footer>\n";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_products_product-item_product-item_module_ts.js.map