"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_services_services_module_ts"],{

/***/ 63105:
/*!************************************************************!*\
  !*** ./src/app/core/services/services/services.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesService": () => (/* binding */ ServicesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ServicesService = class ServicesService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findServiceByCommerce(commerce) {
        return this.http.get(`${this.apiUrl}/services/`, {
            params: {
                commerce,
            },
        });
    }
    createService(service) {
        return this.http.post(`${this.apiUrl}/services/`, service);
    }
    deleteService(service) {
        return this.http.delete(`${this.apiUrl}/services/${service.uuid}`);
    }
    findServiceCategoryByCommerce(commerceID) {
        return this.http.get(`${this.apiUrl}/service-category/`, {
            params: {
                commerce: commerceID
            },
        });
    }
    createCategoryService(service) {
        return this.http.post(`${this.apiUrl}/service-category/`, service);
    }
    updateCategoryService(service) {
        return this.http.patch(`${this.apiUrl}/service-category/`, service);
    }
    deleteCategoryService(categoryUuid) {
        return this.http.delete(`${this.apiUrl}/service-category/${categoryUuid}`);
    }
};
ServicesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ServicesService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ServicesService);



/***/ }),

/***/ 95946:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/services/services-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesPageRoutingModule": () => (/* binding */ ServicesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _services_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services.page */ 91278);




const routes = [
    {
        path: '',
        component: _services_page__WEBPACK_IMPORTED_MODULE_0__.ServicesPage
    },
    {
        path: 'service-item',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-node_modules_date-fns_esm_addWeeks_index_js-src_app_pages_profile_services_services-i-1231f4"), __webpack_require__.e("src_app_pages_profile_services_services-item_services-item_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./services-item/services-item.module */ 27838)).then(m => m.ServicesItemPageModule)
    },
];
let ServicesPageRoutingModule = class ServicesPageRoutingModule {
};
ServicesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ServicesPageRoutingModule);



/***/ }),

/***/ 90514:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/services/services.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesPageModule": () => (/* binding */ ServicesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _services_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services-routing.module */ 95946);
/* harmony import */ var _services_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services.page */ 91278);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);










let ServicesPageModule = class ServicesPageModule {
};
ServicesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _services_routing_module__WEBPACK_IMPORTED_MODULE_1__.ServicesPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_4__.FormatPriceModule
        ],
        declarations: [_services_page__WEBPACK_IMPORTED_MODULE_2__.ServicesPage]
    })
], ServicesPageModule);



/***/ }),

/***/ 91278:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/services/services.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesPage": () => (/* binding */ ServicesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _services_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services.page.html?ngResource */ 2957);
/* harmony import */ var _services_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services.page.scss?ngResource */ 14236);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_core_dto_serviceCategory_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/serviceCategory.dto */ 89162);
/* harmony import */ var src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/services/services.service */ 63105);








let ServicesPage = class ServicesPage {
    constructor(navCtrl, servService, activatedRoute) {
        this.navCtrl = navCtrl;
        this.servService = servService;
        this.activatedRoute = activatedRoute;
        this.serviceCollection = [];
        this.serviceCollectionFiltered = [];
        this.isCategoryModalOpen = false;
        this.totalServices = 0;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.totalServices = 0;
        this.getAllServices();
    }
    getAllServices() {
        this.servService.findServiceCategoryByCommerce(this.commerceLogged).subscribe((response) => {
            this.serviceCollection = response;
            this.serviceCollectionFiltered = this.serviceCollection;
            this.serviceCollectionFiltered.forEach(category => this.totalServices += category.services.length);
        });
    }
    searchEmployee(event) {
        const value = event.target.value;
        this.serviceCollectionFiltered = this.serviceCollection;
        const x = this.serviceCollectionFiltered.reduce((acc, it) => [...acc, ...it.services], []);
        if (value.length >= 3) {
            const y = x.filter((item) => {
                if (item.name.toLowerCase().includes(value.toLowerCase())) {
                    return item;
                }
            });
        }
    }
    goToDetail(service) {
        const navigationExtras = { relativeTo: this.activatedRoute, state: { service } };
        this.navCtrl.navigateForward(['service-item'], navigationExtras);
    }
    goToCreate() {
        this.navCtrl.navigateForward(['service-item'], { relativeTo: this.activatedRoute });
    }
    editCategory(category) {
        this.newCategory = category;
        this.isCategoryModalOpen = true;
    }
    createNewCategory() {
        const newCategoryDto = new src_app_core_dto_serviceCategory_dto__WEBPACK_IMPORTED_MODULE_2__.ServiceCategoryDto();
        newCategoryDto.name = this.newCategory.name;
        newCategoryDto.uuid = this.newCategory.uuid;
        newCategoryDto.services = this.newCategory.services;
        newCategoryDto.commerce = this.commerceLogged;
        this.servService.updateCategoryService(newCategoryDto).subscribe((res) => {
            this.isCategoryModalOpen = false;
            this.getAllServices();
        });
    }
    deleteCategory() {
        this.servService.deleteCategoryService(this.newCategory.uuid).subscribe((res) => {
            this.isCategoryModalOpen = false;
            this.getAllServices();
        });
    }
};
ServicesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_3__.ServicesService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute }
];
ServicesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-services',
        template: _services_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_services_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ServicesPage);



/***/ }),

/***/ 14236:
/*!**********************************************************************!*\
  !*** ./src/app/pages/profile/services/services.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0;\n  --border-style: none;\n}\n\n.service-card {\n  padding: 0;\n}\n\n.service-card .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n\n.service-card .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n\n.service-card .service-label {\n  display: block;\n  margin-bottom: 3%;\n}\n\n.no-padding {\n  padding: 0;\n}\n\n.no-border {\n  border: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0Esb0JBQUE7QUFDRjs7QUFFQTtFQUNFLFVBQUE7QUFDRjs7QUFDRTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFDSjs7QUFFRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFHRTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtBQURKOztBQUtBO0VBQ0UsVUFBQTtBQUZGOztBQUtBO0VBQ0UsU0FBQTtBQUZGIiwiZmlsZSI6InNlcnZpY2VzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAtLWJvcmRlci13aWR0aDogMDtcclxuICAtLWJvcmRlci1zdHlsZTogbm9uZTtcclxufVxyXG5cclxuLnNlcnZpY2UtY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxuXHJcbiAgLnNlcnZpY2UtaW1hZ2Uge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOCwgMjI4LCAyMjgpO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICB9XHJcblxyXG4gIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICBtYXJnaW4tdG9wOiAxOTAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgLnNlcnZpY2UtbGFiZWwge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAzJTtcclxuICB9XHJcbn1cclxuXHJcbi5uby1wYWRkaW5nIHtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ubm8tYm9yZGVyIHtcclxuICBib3JkZXI6IDA7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 2957:
/*!**********************************************************************!*\
  !*** ./src/app/pages/profile/services/services.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Servicios'\"></app-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <!--   <ion-searchbar *ngIf=\"serviceCollectionFiltered.length > 0\"\n    (ionInput)=\"searchEmployee($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar> -->\n\n  <ion-grid\n    *ngIf=\"serviceCollectionFiltered.length > 0 \"\n    class=\"mb-4\"\n    fixed\n    style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\"\n  >\n    <ion-row>\n      <ion-col size=\"10\">\n        <ion-item>\n          <ion-label\n            [innerText]=\"totalServices < 2 && totalServices> 0 ? totalServices+ ' servicio' : totalServices+ ' servicios'\"\n          >\n          </ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ng-container *ngFor=\"let category of serviceCollectionFiltered\">\n    <div class=\"flex align-baseline justify-between px-8 pt-4\">\n      <p class=\"text-base\">{{category.name}}</p>\n      <ion-icon\n        *ngIf=\"category.name !== 'Otros servicios'\"\n        class=\"h-4 w-4\"\n        name=\"create-outline\"\n        (click)=\"editCategory(category)\"\n      ></ion-icon>\n    </div>\n    <ion-card\n      class=\"textbox no-border m-0\"\n      *ngFor=\"let service of category.services; let i = index\"\n    >\n      <ion-grid\n        class=\"service-card\"\n        *ngIf=\"!service.isDeleted\"\n        (click)=\"goToDetail(service)\"\n      >\n        <ion-row>\n          <ion-col\n            size=\"0.1\"\n            [style.background-color]=\"service?.color\"\n          ></ion-col>\n          <ion-col>\n            <ion-item button=\"true\">\n              <ion-label class=\"service-label no-padding\">\n                {{service.name}} · {{service.price | formatPrice}}\n                <p>{{service.defaultDuration}} min</p>\n              </ion-label>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </ng-container>\n\n  <app-no-data\n    *ngIf=\"serviceCollectionFiltered.length === 0\"\n    [title]=\"'Parece que aún no tienes ningún servicio creado'\"\n  ></app-no-data>\n</ion-content>\n<ion-modal [isOpen]=\"isCategoryModalOpen\" initialBreakpoint=\"0.35\">\n  <ng-template>\n    <ion-header>\n      <ion-toolbar>\n        <ion-title>Editar categoría</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content class=\"ion-padding\">\n      <ion-item class=\"textbox\" [ngClass]=\"newCategory ? 'fill-input' : ''\">\n        <ion-label>Nombre</ion-label>\n        <ion-input\n          #catName\n          type=\"text\"\n          [(ngModel)]=\"newCategory.name\"\n          autocapitalize=\"true\"\n        ></ion-input>\n      </ion-item>\n      <div class=\"grid grid-cols-2 gap-4\">\n        <ion-button\n          class=\"btn\"\n          [disabled]=\"!catName.value\"\n          (click)=\"deleteCategory()\"\n          expand=\"block\"\n        >\n          Borrar\n        </ion-button>\n        <ion-button\n          class=\"btn\"\n          [disabled]=\"!catName.value\"\n          (click)=\"createNewCategory()\"\n          expand=\"block\"\n        >\n          Editar\n        </ion-button>\n      </div>\n    </ion-content>\n  </ng-template>\n</ion-modal>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_services_services_module_ts.js.map