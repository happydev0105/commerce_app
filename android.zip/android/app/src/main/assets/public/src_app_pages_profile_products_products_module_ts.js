"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_products_products_module_ts"],{

/***/ 57396:
/*!**********************************************************!*\
  !*** ./src/app/core/services/product/product.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductService": () => (/* binding */ ProductService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);




let ProductService = class ProductService {
    constructor(http) {
        this.http = http;
    }
    getAll() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`);
    }
    getByCommerce(commerceId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product/${commerceId}`);
    }
    create(product) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`, product);
    }
    update(product) {
        return this.http.put(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product`, product);
    }
    deleteProduct(uuid) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/product/${uuid}`);
    }
};
ProductService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProductService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProductService);



/***/ }),

/***/ 79345:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/products/products-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPageRoutingModule": () => (/* binding */ ProductsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./products.page */ 23489);




const routes = [
    {
        path: '',
        component: _products_page__WEBPACK_IMPORTED_MODULE_0__.ProductsPage
    },
    {
        path: 'product-item',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("src_app_pages_profile_products_product-item_product-item_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./product-item/product-item.module */ 94374)).then(m => m.ProductItemPageModule)
    }
];
let ProductsPageRoutingModule = class ProductsPageRoutingModule {
};
ProductsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProductsPageRoutingModule);



/***/ }),

/***/ 39205:
/*!***********************************************************!*\
  !*** ./src/app/pages/profile/products/products.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPageModule": () => (/* binding */ ProductsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _products_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./products-routing.module */ 79345);
/* harmony import */ var _products_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./products.page */ 23489);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);









let ProductsPageModule = class ProductsPageModule {
};
ProductsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _products_routing_module__WEBPACK_IMPORTED_MODULE_1__.ProductsPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_products_page__WEBPACK_IMPORTED_MODULE_2__.ProductsPage]
    })
], ProductsPageModule);



/***/ }),

/***/ 23489:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/products/products.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductsPage": () => (/* binding */ ProductsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _products_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./products.page.html?ngResource */ 65);
/* harmony import */ var _products_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./products.page.scss?ngResource */ 11600);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/product/product.service */ 57396);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);






let ProductsPage = class ProductsPage {
    constructor(navCtrl, productService) {
        this.navCtrl = navCtrl;
        this.productService = productService;
        this.productCollection = [];
        this.productCollectionFiltered = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ngOnInit() {
        this.getProductsByCommerce();
    }
    getProductsByCommerce() {
        this.productService.getByCommerce(this.commerceLogged).subscribe(response => {
            this.productCollection = response;
            this.productCollectionFiltered = this.productCollection;
        });
    }
    searchProduct(event) {
        const value = event.target.value;
        this.productCollectionFiltered = this.productCollection;
        if (value.length >= 3) {
            this.productCollectionFiltered = this.productCollectionFiltered.filter(product => product.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    goToDetail(product) {
        const navigationExtras = { replaceUrl: true, state: { product } };
        this.navCtrl.navigateForward(['tabs/profile/products/product-item'], navigationExtras);
    }
    goToCreate() {
        this.navCtrl.navigateForward(['tabs/profile/products/product-item'], { replaceUrl: true });
    }
};
ProductsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: src_app_core_services_product_product_service__WEBPACK_IMPORTED_MODULE_2__.ProductService }
];
ProductsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-products',
        template: _products_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_products_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProductsPage);



/***/ }),

/***/ 11600:
/*!**********************************************************************!*\
  !*** ./src/app/pages/profile/products/products.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3RzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQ0U7RUFDRSxtQkFBQTtBQUNKO0FBRUk7RUFDRSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQU47QUFHSTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFETjtBQUlJO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFGSiIsImZpbGUiOiJwcm9kdWN0cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VydmljZS1jYXJkIHtcbiAgcGFkZGluZzogMDtcbiAgbWF4LWhlaWdodDogNDMuNXB4O1xuXG4gIC5zZXJ2aWNlLXJvdyB7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcblxuXG4gICAgLnNlcnZpY2UtaW1hZ2Uge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOCwgMjI4LCAyMjgpO1xuICAgICAgcGFkZGluZzogMDtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG5cbiAgICAuaWNvbi1jb250YWluZXIge1xuICAgICAgbWFyZ2luLXRvcDogMTkwJTtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG5cbiAgICAuc2VydmljZS1sYWJlbCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgbWFyZ2luLXRvcDogMyU7XG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xuICAgIG1hcmdpbi1ib3R0b206IDMlO1xuICAgIH1cbiAgfVxufVxuIl19 */";

/***/ }),

/***/ 65:
/*!**********************************************************************!*\
  !*** ./src/app/pages/profile/products/products.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Productos'\"></app-header>\n\n<ion-content>\n\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-searchbar *ngIf=\"productCollectionFiltered.length > 0\" (ionInput)=\"searchProduct($event)\" showCancelButton=\"focus\" placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\" animated></ion-searchbar>\n\n  <ion-grid *ngIf=\"productCollectionFiltered.length > 0\"\n    fixed style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray;\">\n    <ion-row>\n      <ion-col size=\"10\">\n        <ion-item>\n          <ion-label\n            [innerText]=\"productCollectionFiltered.length < 2 && productCollectionFiltered.length > 0 ? productCollectionFiltered.length + ' producto' : productCollectionFiltered.length + ' productos'\">\n          </ion-label>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-item *ngFor=\"let product of productCollectionFiltered\" (click)=\"goToDetail(product)\" button=\"true\"\n    class=\"textbox\">\n    <ion-button fill=\"clear\">\n      <ion-icon slot=\"start\" name=\"pricetag-outline\"></ion-icon>\n    </ion-button>\n    <ion-label class=\"service-label\">\n      {{product.name}} · {{product.price + ' €'}}\n    </ion-label>\n  </ion-item>\n\n  <app-no-data *ngIf=\"productCollectionFiltered.length === 0\" [title]=\"'Parece que aún no has añadido ningún producto'\"></app-no-data>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_products_products_module_ts.js.map