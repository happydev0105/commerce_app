"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_payment-methods_payment-method-item_payment-method-item_m-087f2d"],{

/***/ 70528:
/*!************************************************!*\
  !*** ./src/app/core/dto/payment-method.dto.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodDto": () => (/* binding */ PaymentMethodDto)
/* harmony export */ });
class PaymentMethodDto {
}


/***/ }),

/***/ 5726:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-method-item/payment-method-item-routing.module.ts ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodItemPageRoutingModule": () => (/* binding */ PaymentMethodItemPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _payment_method_item_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-method-item.page */ 94364);




const routes = [
    {
        path: '',
        component: _payment_method_item_page__WEBPACK_IMPORTED_MODULE_0__.PaymentMethodItemPage
    }
];
let PaymentMethodItemPageRoutingModule = class PaymentMethodItemPageRoutingModule {
};
PaymentMethodItemPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentMethodItemPageRoutingModule);



/***/ }),

/***/ 49748:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-method-item/payment-method-item.module.ts ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodItemPageModule": () => (/* binding */ PaymentMethodItemPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _payment_method_item_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-method-item-routing.module */ 5726);
/* harmony import */ var _payment_method_item_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-method-item.page */ 94364);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);









let PaymentMethodItemPageModule = class PaymentMethodItemPageModule {
};
PaymentMethodItemPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _payment_method_item_routing_module__WEBPACK_IMPORTED_MODULE_0__.PaymentMethodItemPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__.HeaderModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__.AlertModule
        ],
        declarations: [_payment_method_item_page__WEBPACK_IMPORTED_MODULE_1__.PaymentMethodItemPage]
    })
], PaymentMethodItemPageModule);



/***/ }),

/***/ 94364:
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-method-item/payment-method-item.page.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethodItemPage": () => (/* binding */ PaymentMethodItemPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _payment_method_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-method-item.page.html?ngResource */ 82295);
/* harmony import */ var _payment_method_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-method-item.page.scss?ngResource */ 61633);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_dto_payment_method_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/payment-method.dto */ 70528);
/* harmony import */ var src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/payment-method/payments-method.service */ 83907);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);










let PaymentMethodItemPage = class PaymentMethodItemPage {
    constructor(fb, router, methodService, navCtrl) {
        this.fb = fb;
        this.router = router;
        this.methodService = methodService;
        this.navCtrl = navCtrl;
        this.isEdit = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForm();
        if (this.router.getCurrentNavigation().extras.state) {
            this.method = this.router.getCurrentNavigation().extras.state.method;
            this.label.setValue(this.method.label);
            this.isEdit = true;
            this.title = 'Editar método de pago';
        }
        else {
            this.title = 'Crear método de pago';
        }
    }
    get label() {
        return this.methodForm.get('label');
    }
    ngOnInit() {
    }
    initForm() {
        this.methodForm = this.fb.group({
            label: [this.method ? this.method.label : '', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
        });
    }
    onFocus(event) {
        event.target.parentElement.classList.add('fill-input');
    }
    onBlur(event) {
        // Si tiene contenido el input no se la quitamos
        if (!event.target.value) {
            event.target.parentElement.classList.remove('fill-input');
        }
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    submit() {
        const methodDto = new src_app_core_dto_payment_method_dto__WEBPACK_IMPORTED_MODULE_2__.PaymentMethodDto();
        methodDto.commerce = { uuid: this.commerceLogged };
        methodDto.label = this.label.value;
        if (this.isEdit) {
            methodDto.uuid = this.method.uuid;
        }
        this.methodService.createMethod(methodDto).subscribe((res) => {
            if (res) {
                this.cancel();
            }
        });
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/commerce-info/payment-methods'], { replaceUrl: true });
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    deleteItem() {
        this.methodService.deleteMethod(this.method.uuid).subscribe((res) => {
            if (res.affected > 0) {
                this.cancel();
            }
        });
    }
};
PaymentMethodItemPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_3__.PaymentsMethodService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController }
];
PaymentMethodItemPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_4__.AlertComponent,] }]
};
PaymentMethodItemPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-payment-method-item',
        template: _payment_method_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payment_method_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentMethodItemPage);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 61633:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-method-item/payment-method-item.page.scss?ngResource ***!
  \**************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXltZW50LW1ldGhvZC1pdGVtLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 82295:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/payment-methods/payment-method-item/payment-method-item.page.html?ngResource ***!
  \**************************************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"title\"></app-header>\n\n<ion-content>\n  <div class=\"edit_profile_main_content\">\n    <form [formGroup]=\"methodForm\">\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"methodForm.controls['label'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Nombre</ion-label>\n        <ion-input\n          formControlName=\"label\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"text\"\n          [value]=\"method?.label\"\n          autocapitalize=\"true\"\n        ></ion-input>\n      </ion-item>\n    </form>\n  </div>\n</ion-content>\n<app-alert\n  #deleteAlert\n  (actionEmitter)=\"alertBox($event)\"\n  [title]=\"'¿Desea borrar este método de pago?'\"\n></app-alert>\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"isEdit\" (click)=\"openAlert()\"\n        ><ion-button class=\"btn\" expand=\"block\">\n          <ion-icon icon=\"trash\"></ion-icon>\n        </ion-button>\n      </ion-col>\n\n      <ion-col\n        ><ion-button\n          class=\"btn\"\n          [disabled]=\"!methodForm.valid\"\n          (click)=\"submit()\"\n          expand=\"block\"\n        >\n          Guardar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_payment-methods_payment-method-item_payment-method-item_m-087f2d.js.map