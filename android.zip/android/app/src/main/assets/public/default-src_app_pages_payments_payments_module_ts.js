"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_payments_payments_module_ts"],{

/***/ 14085:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/getTime/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getTime)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getTime
 * @category Timestamp Helpers
 * @summary Get the milliseconds timestamp of the given date.
 *
 * @description
 * Get the milliseconds timestamp of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the timestamp
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Get the timestamp of 29 February 2012 11:45:05.123:
 * const result = getTime(new Date(2012, 1, 29, 11, 45, 5, 123))
 * //=> 1330515905123
 */

function getTime(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var timestamp = date.getTime();
  return timestamp;
}

/***/ }),

/***/ 86075:
/*!************************************************************!*\
  !*** ./src/app/core/services/employee/employee.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeService": () => (/* binding */ EmployeeService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let EmployeeService = class EmployeeService {
    constructor(http) {
        this.http = http;
    }
    getAllEmployee() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`);
    }
    createEmployee(employee) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    findEmployees(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce/${commerceID}`);
    }
    findEmployeesWithinactives(commerceID) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-with-inactives/${commerceID}`);
    }
    findEmployeeById(employeeId) {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${employeeId}`);
    }
    findEmployeeByCommerceAndServices(commerce, services) {
        return this.http.post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/commerce-services/${commerce}`, services);
    }
    updateEmployee(employee) {
        return this.http.patch(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee`, employee);
    }
    deleteEmployee(uuid) {
        return this.http.delete(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/employee/${uuid}`);
    }
    getAllPermissions() {
        return this.http.get(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api}/permission`);
    }
};
EmployeeService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
EmployeeService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], EmployeeService);



/***/ }),

/***/ 83907:
/*!*************************************************************************!*\
  !*** ./src/app/core/services/payment-method/payments-method.service.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsMethodService": () => (/* binding */ PaymentsMethodService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let PaymentsMethodService = class PaymentsMethodService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findPaymentMethodByCommerce(commerce) {
        return this.http.get(`${this.apiUrl}/payments-methods/commerce/${commerce}`);
    }
    createMethod(dto) {
        return this.http.post(`${this.apiUrl}/payments-methods`, dto);
    }
    deleteMethod(uuid) {
        return this.http.delete(`${this.apiUrl}/payments-methods/${uuid}`);
    }
};
PaymentsMethodService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PaymentsMethodService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PaymentsMethodService);



/***/ }),

/***/ 66568:
/*!***********************************************************!*\
  !*** ./src/app/pages/payments/payments-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsPageRoutingModule": () => (/* binding */ PaymentsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _payments_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payments.page */ 42061);




const routes = [
    {
        path: '',
        component: _payments_page__WEBPACK_IMPORTED_MODULE_0__.PaymentsPage
    },
    {
        path: 'customer-detail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_pages_customer_customer-detail_customer-detail_module_ts"), __webpack_require__.e("src_app_core_pipes_format-hour_format-hour_module_ts-src_app_core_services_utils_utils_service_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../customer/customer-detail/customer-detail.module */ 71547)).then(m => m.CustomerDetailPageModule)
    },
    {
        path: 'payment-detail/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_pages_payments_payment-detail_payment-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./payment-detail/payment-detail.module */ 95580)).then(m => m.PaymentDetailPageModule)
    }
];
let PaymentsPageRoutingModule = class PaymentsPageRoutingModule {
};
PaymentsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PaymentsPageRoutingModule);



/***/ }),

/***/ 15795:
/*!***************************************************!*\
  !*** ./src/app/pages/payments/payments.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsPageModule": () => (/* binding */ PaymentsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../shared/components/alert/alert.module */ 92563);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _payments_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payments-routing.module */ 66568);
/* harmony import */ var _payments_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./payments.page */ 42061);
/* harmony import */ var src_app_shared_components_service_list_service_list_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/service-list/service-list.module */ 12664);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);











let PaymentsPageModule = class PaymentsPageModule {
};
PaymentsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _payments_routing_module__WEBPACK_IMPORTED_MODULE_2__.PaymentsPageRoutingModule,
            src_app_shared_components_service_list_service_list_module__WEBPACK_IMPORTED_MODULE_4__.ServiceListModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            _shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__.AlertModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_5__.FormatPriceModule
        ],
        declarations: [_payments_page__WEBPACK_IMPORTED_MODULE_3__.PaymentsPage],
    })
], PaymentsPageModule);



/***/ }),

/***/ 42061:
/*!*************************************************!*\
  !*** ./src/app/pages/payments/payments.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsPage": () => (/* binding */ PaymentsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _payments_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payments.page.html?ngResource */ 18198);
/* harmony import */ var _payments_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payments.page.scss?ngResource */ 75730);
/* harmony import */ var _shared_components_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../shared/components/product-list/product-list.component */ 53957);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/payments/payments.model */ 3145);
/* harmony import */ var src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/payments/payments.service */ 29474);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_shared_components_customer_list_customer_list_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/customer-list/customer-list.component */ 19708);
/* harmony import */ var src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/service-list/service-list.component */ 43344);
/* harmony import */ var src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/booking/booking.service */ 70065);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 3571);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 76327);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 53886);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 3012);
/* harmony import */ var src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/payment-method/payments-method.service */ 83907);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/services/services.service */ 63105);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! date-fns */ 33719);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! date-fns */ 14085);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/customer/customer.service */ 20161);





















let PaymentsPage = class PaymentsPage {
    constructor(fb, modalController, routerOutlet, dateService, paymentService, bookingService, methodService, employeeService, navCtrl, serviceService, route, customerService) {
        this.fb = fb;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.dateService = dateService;
        this.paymentService = paymentService;
        this.bookingService = bookingService;
        this.methodService = methodService;
        this.employeeService = employeeService;
        this.navCtrl = navCtrl;
        this.serviceService = serviceService;
        this.route = route;
        this.customerService = customerService;
        this.productSelected = [];
        this.serviceSelected = [];
        this.serviceCollection = [];
        this.paymentMethodCollection = [];
        this.employeeCollection = [];
        this.totalPrice = 0;
        this.discountValue = 0;
        this.discountValueNeto = 0;
        this.amountValue = 0;
        this.showModal = false;
        this.isFromBooking = false;
        this.isInvalid = false;
        this.isWalkinClient = false;
        this.isSubmitted = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForm();
        this.getWalkinCustomer();
    }
    get customer() {
        return this.form.get('customer');
    }
    get amount() {
        return this.form.get('amount');
    }
    get employee() {
        return this.form.get('employee');
    }
    get payMethod() {
        return this.form.get('payMethod');
    }
    ionViewWillEnter() {
        var _a;
        this.resetFields();
        this.getAllMethods();
        this.findEmployeeCollection(this.commerceLogged);
        this.getAllService();
        if (this.route.snapshot.queryParams.payment) {
            this.initForm();
            const payment = JSON.parse(this.route.snapshot.queryParams.payment);
            this.customer.setValue(`${payment === null || payment === void 0 ? void 0 : payment.customer.name} ${payment === null || payment === void 0 ? void 0 : payment.customer.lastname}`);
            this.serviceSelected = [...payment.service];
            this.isFromBooking = true;
            this.booking = payment.booking;
            this.customerSelected = payment.customer;
            this.commerceLogged = payment.commerce;
            if (payment.service && payment.service.length > 0) {
                this.totalPrice = this.totalPrice + this.calcTotalPriceService(this.serviceSelected);
            }
            else {
                this.amount.setValue(payment.amount + (payment.decimals / 100));
            }
        }
        else {
            const empLogged = JSON.parse(localStorage.getItem('currentUser'));
            this.selectedEmployee(empLogged.uuid);
        }
        if (this.route.snapshot.queryParams.newCustomer) {
            this.customerSelected = JSON.parse(this.route.snapshot.queryParams.newCustomer);
            this.customer.setValue(`${(_a = this.customerSelected) === null || _a === void 0 ? void 0 : _a.name} ${this.customerSelected.lastname}`);
        }
    }
    ngOnInit() {
    }
    getWalkinCustomer() {
        this.customerService.getWalkinCustomer().subscribe(res => this.walkinClient = res);
    }
    getAllService() {
        this.serviceService
            .findServiceByCommerce(this.commerceLogged)
            .subscribe((res) => {
            this.serviceCollection = res;
        });
    }
    getAllMethods() {
        this.methodService.findPaymentMethodByCommerce(this.commerceLogged).subscribe((response) => {
            this.paymentMethodCollection = response;
        });
    }
    selectedEmployee(employeeId) {
        this.employee.setValue(employeeId);
        this.employeeSelected = this.employeeCollection.find(employee => employee.uuid === employeeId);
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_shared_components_customer_list_customer_list_component__WEBPACK_IMPORTED_MODULE_6__.CustomerListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    isNewPayment: true
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data && data.customer !== undefined) {
                this.customerSelected = data.customer;
                this.customer.setValue(`${this.customerSelected.name} ${this.customerSelected.lastname}`);
                console.log(this.customer);
            }
        });
    }
    presentServiceModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_7__.ServiceListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    servicesSelected: this.serviceSelected, showPrice: true,
                    serviceCollectionFiltered: this.serviceCollection, serviceCollection: this.serviceCollection
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data && data.service.length > 0) {
                this.serviceSelected = data.service;
                this.calcTotalPrice();
            }
        });
    }
    presentProductModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _shared_components_product_list_product_list_component__WEBPACK_IMPORTED_MODULE_2__.ProductListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: { productSelected: this.productSelected }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!data) {
                this.productSelected = [];
            }
            this.productSelected = this.productSelected.filter(item => item !== undefined);
            this.calcTotalPrice();
        });
    }
    calcTotalPriceService(service) {
        let price = 0;
        service.forEach((item) => {
            price = price + item.price;
        });
        return price;
    }
    calcTotalPriceProduct(product) {
        let price = 0;
        product.forEach((item) => {
            price = price + (item.price * item.qty);
        });
        return price;
    }
    selectedMethod(value) {
        this.payMethod.setValue(value);
    }
    onSubmit() {
        console.log(this.form);
        if (this.payMethod.value === '') {
            this.paymethod.open();
            this.payMethod.valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.first)()).subscribe((res) => {
                this.isSubmitted = true;
                if (this.form.valid) {
                    const newPayment = new src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_3__.PaymentDto();
                    if (this.totalPrice.toString().includes('.')) {
                        newPayment.amount = parseInt(this.totalPrice.toString().split('.')[0], 10);
                        newPayment.decimals = parseInt(this.totalPrice.toString().split('.')[1], 10);
                        if (this.totalPrice.toString().split('.')[1].length === 1) {
                            newPayment.decimals = newPayment.decimals * 10;
                        }
                    }
                    else {
                        newPayment.amount = this.totalPrice;
                        newPayment.decimals = 0;
                    }
                    newPayment.product = this.productSelected;
                    newPayment.service = this.serviceSelected;
                    newPayment.date = this.dateService.formatDate(new Date());
                    newPayment.week = (0,date_fns__WEBPACK_IMPORTED_MODULE_16__["default"])(new Date(), { weekStartsOn: 1, firstWeekContainsDate: 4 });
                    newPayment.discount = this.discountValue;
                    newPayment.commerce = this.commerceLogged;
                    newPayment.method = this.payMethod.value;
                    newPayment.customer = this.customerSelected === null ? this.walkinClient : this.customerSelected;
                    if (this.booking) {
                        newPayment.booking = this.booking;
                        this.booking.status = 'Realizada';
                        newPayment.bookingSettedUuid = this.booking.uuid;
                        this.concatSubmitRequest(newPayment, this.booking);
                    }
                    else {
                        newPayment.booking = null;
                        newPayment.bookingSettedUuid = 'noBooking_' + (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(new Date());
                        newPayment.employee = this.employeeSelected;
                        this.savePayment(newPayment).subscribe(response => {
                            if (response) {
                                this.confirmPayment(response);
                            }
                        });
                    }
                }
                else {
                    this.isInvalid = true;
                }
            });
        }
        else {
            this.isSubmitted = true;
            const newPayment = new src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_3__.PaymentDto();
            if (this.totalPrice.toString().includes('.')) {
                newPayment.amount = parseInt(this.totalPrice.toString().split('.')[0], 10);
                newPayment.decimals = parseInt(this.totalPrice.toString().split('.')[1], 10);
                if (newPayment.decimals.toString().length === 1) {
                    newPayment.decimals = newPayment.decimals * 10;
                }
            }
            else {
                newPayment.amount = this.totalPrice;
                newPayment.decimals = 0;
            }
            newPayment.product = this.productSelected;
            newPayment.service = this.serviceSelected;
            newPayment.date = this.dateService.formatDate(new Date());
            newPayment.week = (0,date_fns__WEBPACK_IMPORTED_MODULE_16__["default"])(new Date(), { weekStartsOn: 1, firstWeekContainsDate: 4 });
            newPayment.discount = this.discountValue;
            newPayment.commerce = this.commerceLogged;
            newPayment.method = this.payMethod.value;
            newPayment.customer = this.customerSelected === null ? this.walkinClient : this.customerSelected;
            if (this.booking) {
                newPayment.booking = this.booking;
                newPayment.bookingSettedUuid = this.booking.uuid;
                this.booking.status = 'Realizada';
                this.concatSubmitRequest(newPayment, this.booking);
            }
            else {
                newPayment.booking = null;
                newPayment.bookingSettedUuid = 'noBooking_' + (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(new Date());
                this.savePayment(newPayment).subscribe(response => {
                    if (response) {
                        this.confirmPayment(response);
                    }
                });
            }
        }
    }
    findEmployeeCollection(commerce) {
        this.employeeService.findEmployees(commerce).subscribe(employees => {
            this.employeeCollection = [...employees];
        });
    }
    savePayment(payment) {
        return this.paymentService
            .savePaymentByCommerce(payment);
    }
    updateBooking(booking) {
        return this.bookingService.updateBookingPayment(booking);
    }
    concatSubmitRequest(payment, book) {
        this.savePayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_18__.switchMap)((payload) => {
            console.log({ payload });
            book.paymentSettedUuid = payload.uuid;
            const pay = new src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_3__.PaymentDto();
            pay.amount = payload.amount;
            pay.booking = payload.booking;
            pay.bookingSettedUuid = payload.bookingSettedUuid;
            pay.commerce = payload.commerce;
            pay.customer = payload.customer;
            pay.date = payload.date;
            pay.decimals = payload.decimals;
            pay.discount = payload.discount;
            pay.employee = payload.employee;
            pay.isDeleted = payload.isDeleted;
            pay.product = payload.product;
            pay.uuid = payload.uuid;
            pay.week = payload.week;
            book.payment = pay;
            console.log(book);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.combineLatest)([(0,rxjs__WEBPACK_IMPORTED_MODULE_20__.of)(payload), this.updateBooking(book)]);
        })).subscribe((res) => this.confirmPayment(res[0]));
        /*  forkJoin([this.savePayment(payment), this.updateBooking(book)]).subscribe((res: [IPayment, IBooking]) => {
           this.confirmPayment(res[0]);
         }); */
    }
    confirmPayment(payment) {
        const paymentMethodSelected = this.paymentMethodCollection.find(item => item.uuid === payment.method);
        this.route.snapshot.queryParams = {};
        this.navCtrl.navigateForward(['payment-confirmation'], { state: { payment, paymentMethod: paymentMethodSelected } });
        this.resetFields();
    }
    changeAmount(event) {
        let price = event.detail.value;
        if (price) {
            if (price.includes('.')) {
                const index = price.indexOf('.');
                price = price.substring(0, index + 3);
            }
            this.amountValue = Number.parseFloat(price);
            this.calcTotalPrice();
        }
        else {
            this.amountValue = 0;
            this.calcTotalPrice();
        }
    }
    calcTotalPrice() {
        this.totalPrice =
            (this.calcTotalPriceProduct(this.productSelected)) +
                (this.calcTotalPriceService(this.serviceSelected)) +
                (this.amountValue - this.discountValueNeto);
        if (this.discountValue > 0) {
            const fixedTotalPrice = (this.totalPrice - (this.totalPrice * (this.discountValue / 100))).toFixed(2);
            this.totalPrice = parseFloat(fixedTotalPrice);
        }
        if (this.totalPrice < 0) {
            this.totalPrice = 0;
        }
    }
    inputDiscountPercent(event) {
        if (event.target.value > 100) {
            event.target.value = 100;
        }
        else if (event.target.value < 0) {
            event.target.value = 0;
        }
        this.discountValue = event.target.value;
        this.calcTotalPrice();
    }
    inputDiscount(event) {
        if (event.target.value < 0) {
            event.target.value = 0;
        }
        this.discountValueNeto = event.target.value;
        this.calcTotalPrice();
    }
    deleteProduct(product) {
        const productIndex = this.productSelected.findIndex(item => item.uuid === product.uuid);
        this.productSelected.splice(productIndex, 1);
        this.calcTotalPrice();
    }
    deleteService(service) {
        const serviceIndex = this.serviceSelected.findIndex(item => item.uuid === service.uuid);
        this.serviceSelected.splice(serviceIndex, 1);
        this.calcTotalPrice();
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    alertBox(value) {
        if (value) {
            this.resetFields();
            this.navCtrl.navigateForward(['tabs/payments'], { replaceUrl: true });
        }
    }
    onChangeCheckbox(event) {
        this.isWalkinClient = event.detail.checked;
    }
    initForm() {
        this.form = this.fb.group({
            customer: [''],
            employee: [''],
            amount: [],
            payMethod: [''],
        });
    }
    resetFields() {
        this.initForm();
        this.customerSelected = null;
        this.serviceSelected = [];
        this.productSelected = [];
        this.totalPrice = 0;
        this.amountValue = 0;
        this.discountValue = 0;
        this.discountValueNeto = 0;
        this.isInvalid = false;
    }
};
PaymentsPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonRouterOutlet },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_5__.DateService },
    { type: src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_4__.PaymentsService },
    { type: src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_8__.BookingService },
    { type: src_app_core_services_payment_method_payments_method_service__WEBPACK_IMPORTED_MODULE_9__.PaymentsMethodService },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_12__.EmployeeService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.NavController },
    { type: src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_11__.ServicesService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute },
    { type: src_app_core_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_13__.CustomerService }
];
PaymentsPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_10__.AlertComponent,] }],
    paymethod: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_24__.ViewChild, args: ['paymethod',] }]
};
PaymentsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_24__.Component)({
        selector: 'app-payments',
        template: _payments_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_payments_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PaymentsPage);



/***/ }),

/***/ 12664:
/*!***********************************************************************!*\
  !*** ./src/app/shared/components/service-list/service-list.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceListModule": () => (/* binding */ ServiceListModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);
/* harmony import */ var _no_data_no_data_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _service_list_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./service-list.component */ 43344);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 95472);







let ServiceListModule = class ServiceListModule {
};
ServiceListModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_service_list_component__WEBPACK_IMPORTED_MODULE_2__.ServiceListComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _no_data_no_data_module__WEBPACK_IMPORTED_MODULE_1__.NoDataModule, src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_0__.FormatPriceModule],
        exports: [_service_list_component__WEBPACK_IMPORTED_MODULE_2__.ServiceListComponent],
    })
], ServiceListModule);



/***/ }),

/***/ 75730:
/*!**************************************************************!*\
  !*** ./src/app/pages/payments/payments.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-bottom: 3%;\n  font-size: 14px;\n  color: #666;\n}\n.no-padding {\n  padding: 0;\n}\n.stacked-item {\n  margin-top: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheW1lbnRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0k7RUFDSSxtQkFBQTtBQUNSO0FBQ1E7RUFDSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQ1o7QUFFUTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUFBWjtBQUdRO0VBQ0ksY0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FBRFo7QUFNQTtFQUNFLFVBQUE7QUFIRjtBQU1BO0VBQ0UsYUFBQTtBQUhGIiwiZmlsZSI6InBheW1lbnRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZXJ2aWNlLWNhcmQge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgbWF4LWhlaWdodDogNDMuNXB4O1xuXG4gICAgLnNlcnZpY2Utcm93IHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcblxuICAgICAgICAuc2VydmljZS1pbWFnZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjI4LCAyMjgsIDIyOCk7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB9XG5cbiAgICAgICAgLmljb24tY29udGFpbmVyIHtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE5MCU7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAuc2VydmljZS1sYWJlbCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDMlO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMyU7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBjb2xvcjogIzY2NjtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLm5vLXBhZGRpbmcge1xuICBwYWRkaW5nOiAwO1xufVxuXG4uc3RhY2tlZC1pdGVtIHtcbiAgbWFyZ2luLXRvcDogMDtcbn1cblxuXG4iXX0= */";

/***/ }),

/***/ 18198:
/*!**************************************************************!*\
  !*** ./src/app/pages/payments/payments.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"isFromBooking\" [titlePage]=\"'Venta'\"></app-header>\r\n\r\n<ion-content>\r\n  <form [formGroup]=\"form\" novalidate>\r\n    <ion-item\r\n      [disabled]=\"isWalkinClient\"\r\n      class=\"textbox h-20 flex\"\r\n      (click)=\"presentModal()\"\r\n      no-lines\r\n      lines=\"none\"\r\n      button=\"true\"\r\n    >\r\n      <ion-label>Cliente <span class=\"text-red-400\">*</span></ion-label>\r\n      <ion-input\r\n        ngDefaultControl\r\n        type=\"text\"\r\n        formControlName=\"customer\"\r\n        class=\"ion-text-right\"\r\n        readonly\r\n      ></ion-input>\r\n    </ion-item>\r\n    <ng-container\r\n      *ngIf=\"!customer?.valid && customer?.errors!['required'] && isSubmitted\"\r\n    >\r\n      <p class=\"px-8 text-red-400\">Este campo es requerido</p>\r\n    </ng-container>\r\n    <ion-item class=\"textbox\">\r\n      <ion-label slot=\"start\">Cliente sin cita previa</ion-label>\r\n      <ion-checkbox\r\n        slot=\"end\"\r\n        (ionChange)=\"onChangeCheckbox($event)\"\r\n      ></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item\r\n      [hidden]=\"isFromBooking\"\r\n      class=\"textbox\"\r\n      no-lines\r\n      lines=\"none\"\r\n      *ngIf=\"employeeCollection?.length > 0\"\r\n    >\r\n      <ion-label>Selecciona un empleado</ion-label>\r\n      <ion-select\r\n        #employee\r\n        class=\"mr-8\"\r\n        formControlName=\"employee\"\r\n        interface=\"action-sheet\"\r\n        (ionChange)=\"selectedEmployee(employee.value)\"\r\n        cancelText=\"Cancelar\"\r\n      >\r\n        <ion-select-option\r\n          *ngFor=\"let employee of employeeCollection\"\r\n          [value]=\"employee.uuid\"\r\n          >{{employee.name}}\r\n        </ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n    <ng-container\r\n      *ngIf=\"!employee?.valid && employee?.errors['required'] && isSubmitted &&!isFromBooking\"\r\n    >\r\n      <p class=\"px-8 text-red-400\">Este campo es requerido</p>\r\n    </ng-container>\r\n    <ion-item\r\n      [hidden]=\"isFromBooking\"\r\n      [ngClass]=\"isFromBooking ? '' : 'flex'\"\r\n      class=\"textbox h-20\"\r\n      no-lines\r\n      lines=\"none\"\r\n    >\r\n      <ion-label>€ <span class=\"text-red-400\">*</span></ion-label>\r\n      <ion-input\r\n        ngDefaultControl\r\n        type=\"number\"\r\n        formControlName=\"amount\"\r\n        placeholder=\"0\"\r\n        (ionChange)=\"changeAmount($event)\"\r\n        class=\"ion-text-right\"\r\n        inputmode=\"decimal\"\r\n      ></ion-input>\r\n    </ion-item>\r\n    <ion-item class=\"textbox h-20 flex\" no-lines lines=\"none\">\r\n      <ion-label>Desc. neto</ion-label>\r\n      <ion-input\r\n        ngDefaultControl\r\n        (ionInput)=\"inputDiscount($event)\"\r\n        type=\"number\"\r\n        [value]=\"discountValueNeto\"\r\n        class=\"ion-text-right\"\r\n        inputmode=\"numeric\"\r\n        placeholder=\"0\"\r\n      ></ion-input>\r\n    </ion-item>\r\n    <ion-item class=\"textbox h-20 flex\" no-lines lines=\"none\">\r\n      <ion-label>Método de pago <span class=\"text-red-400\">*</span></ion-label>\r\n      <ion-select\r\n        #paymethod\r\n        formControlName=\"payMethod\"\r\n        cancelText=\"Cancelar\"\r\n        interface=\"action-sheet\"\r\n        (ionChange)=\"selectedMethod(paymethod.value)\"\r\n      >\r\n        <ion-select-option\r\n          *ngFor=\"let method of paymentMethodCollection\"\r\n          [value]=\"method.uuid\"\r\n          >{{method.label}}</ion-select-option\r\n        >\r\n      </ion-select>\r\n    </ion-item>\r\n  </form>\r\n  <ng-container *ngFor=\"let service of serviceSelected\">\r\n    <ion-card button=\"true\">\r\n      <ion-grid class=\"service-card\">\r\n        <ion-row class=\"service-row\">\r\n          <ion-col size=\"0.1\" [style.background]=\"service.color\"></ion-col>\r\n          <ion-col class=\"no-padding\">\r\n            <ion-item>\r\n              <ion-label class=\"service-label\"\r\n                >{{ service.name }} · {{ service.price + \" €\" }}</ion-label\r\n              >\r\n              <ion-button fill=\"clear\" (click)=\"deleteService(service)\">\r\n                <ion-icon slot=\"end\" name=\"trash-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n  </ng-container>\r\n  <ng-container *ngFor=\"let product of productSelected\">\r\n    <ion-card button=\"true\">\r\n      <ion-grid class=\"service-card\">\r\n        <ion-row class=\"service-row\">\r\n          <ion-col size=\"0.1\" class=\"black\"></ion-col>\r\n          <ion-col class=\"no-padding\">\r\n            <ion-item>\r\n              <ion-label class=\"service-label\">\r\n                {{ product?.name }} · {{ product?.price * product?.qty + \" €\" }}\r\n                - {{product?.qty}} unidad{{product?.qty > 1 ? 'es' :\r\n                ''}}</ion-label\r\n              >\r\n              <ion-button fill=\"clear\" (click)=\"deleteProduct(product)\">\r\n                <ion-icon slot=\"end\" name=\"trash-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n  </ng-container>\r\n  <ion-grid class=\"no-padding\">\r\n    <ion-row style=\"align-items: center\">\r\n      <ion-col size=\"6\" class=\"no-padding\">\r\n        <ion-item (click)=\"presentServiceModal()\" class=\"textbox\">\r\n          <ion-label class=\"no-padding\">Añadir servicio</ion-label>\r\n          <ion-button fill=\"clear\">\r\n            <ion-icon slot=\"end\" name=\"add\"></ion-icon>\r\n          </ion-button>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"6\" class=\"no-padding\">\r\n        <ion-item class=\"textbox\" no-lines lines=\"none\">\r\n          <ion-label class=\"no-padding\">Desc. %</ion-label>\r\n          <ion-input\r\n            ngDefaultControl\r\n            (ionInput)=\"inputDiscountPercent($event)\"\r\n            type=\"number\"\r\n            class=\"ion-text-right\"\r\n            inputmode=\"numeric\"\r\n            placeholder=\"0\"\r\n          ></ion-input>\r\n        </ion-item>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\" class=\"no-padding\">\r\n        <ion-item class=\"textbox stacked-item\" (click)=\"presentProductModal()\">\r\n          <ion-label class=\"no-padding\">Añadir producto</ion-label>\r\n          <ion-button fill=\"clear\">\r\n            <ion-icon slot=\"end\" name=\"add\"></ion-icon>\r\n          </ion-button>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  <ion-item class=\"textbox h-20 flex\" no-lines lines=\"none\">\r\n    <ion-label class=\"no-padding\">Total</ion-label>\r\n    <ion-input\r\n      ngDefaultControl\r\n      [(ngModel)]=\"totalPrice\"\r\n      type=\"number\"\r\n      class=\"ion-text-right\"\r\n      inputmode=\"numeric\"\r\n      placeholder=\"0\"\r\n    ></ion-input>\r\n  </ion-item>\r\n</ion-content>\r\n<app-alert\r\n  #deleteAlert\r\n  (actionEmitter)=\"alertBox($event)\"\r\n  [title]=\"'¿Desea cancelar la venta?'\"\r\n  [message]=\"'Se perderán todos los cambios realizados'\"\r\n></app-alert>\r\n<ion-footer class=\"ion-no-border\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-button (click)=\"openAlert()\" class=\"btn\" expand=\"block\">\r\n          Cancelar\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-button (click)=\"onSubmit()\" class=\"btn\" expand=\"block\">\r\n          {{totalPrice | formatPrice}} · Continuar\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-footer>\r\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_payments_payments_module_ts.js.map