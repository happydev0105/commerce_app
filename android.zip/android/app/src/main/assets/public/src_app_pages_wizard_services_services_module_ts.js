"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_wizard_services_services_module_ts"],{

/***/ 84013:
/*!********************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysModule": () => (/* binding */ TranslateDaysModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-days.pipe */ 29069);





let TranslateDaysModule = class TranslateDaysModule {
};
TranslateDaysModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe]
    })
], TranslateDaysModule);



/***/ }),

/***/ 29069:
/*!******************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysPipe": () => (/* binding */ TranslateDaysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TranslateDaysPipe = class TranslateDaysPipe {
    transform(value) {
        const daysTranslated = {
            monday: 'lunes',
            tuesday: 'martes',
            wednesday: 'miércoles',
            thursday: 'jueves',
            friday: 'viernes',
            saturday: 'sábado',
            sunday: 'domingo'
        };
        return daysTranslated[value] || value;
    }
};
TranslateDaysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'translateDays'
    })
], TranslateDaysPipe);



/***/ }),

/***/ 63105:
/*!************************************************************!*\
  !*** ./src/app/core/services/services/services.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesService": () => (/* binding */ ServicesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ServicesService = class ServicesService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    findServiceByCommerce(commerce) {
        return this.http.get(`${this.apiUrl}/services/`, {
            params: {
                commerce,
            },
        });
    }
    createService(service) {
        return this.http.post(`${this.apiUrl}/services/`, service);
    }
    deleteService(service) {
        return this.http.delete(`${this.apiUrl}/services/${service.uuid}`);
    }
    findServiceCategoryByCommerce(commerceID) {
        return this.http.get(`${this.apiUrl}/service-category/`, {
            params: {
                commerce: commerceID
            },
        });
    }
    createCategoryService(service) {
        return this.http.post(`${this.apiUrl}/service-category/`, service);
    }
    updateCategoryService(service) {
        return this.http.patch(`${this.apiUrl}/service-category/`, service);
    }
    deleteCategoryService(categoryUuid) {
        return this.http.delete(`${this.apiUrl}/service-category/${categoryUuid}`);
    }
};
ServicesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ServicesService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], ServicesService);



/***/ }),

/***/ 52660:
/*!******************************************************************!*\
  !*** ./src/app/pages/wizard/services/services-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesPageRoutingModule": () => (/* binding */ ServicesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _services_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services.page */ 18170);




const routes = [
    {
        path: '',
        component: _services_page__WEBPACK_IMPORTED_MODULE_0__.ServicesWizardPage
    },
    {
        path: 'service-item',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-node_modules_date-fns_esm_addWeeks_index_js-src_app_pages_profile_services_services-i-1231f4"), __webpack_require__.e("node_modules_date-fns_esm__lib_toInteger_index_js-src_app_core_services_utils_utils_service_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../profile/services/services-item/services-item-routing.module */ 90053))
            .then((m) => m.ServicesItemPageRoutingModule)
    }
];
let ServicesPageRoutingModule = class ServicesPageRoutingModule {
};
ServicesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ServicesPageRoutingModule);



/***/ }),

/***/ 61523:
/*!**********************************************************!*\
  !*** ./src/app/pages/wizard/services/services.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesPageModule": () => (/* binding */ ServicesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _services_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services-routing.module */ 52660);
/* harmony import */ var _services_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services.page */ 18170);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);









let ServicesPageModule = class ServicesPageModule {
};
ServicesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _services_routing_module__WEBPACK_IMPORTED_MODULE_1__.ServicesPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_3__.FormatPriceModule
        ],
        declarations: [_services_page__WEBPACK_IMPORTED_MODULE_2__.ServicesWizardPage]
    })
], ServicesPageModule);



/***/ }),

/***/ 18170:
/*!********************************************************!*\
  !*** ./src/app/pages/wizard/services/services.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServicesWizardPage": () => (/* binding */ ServicesWizardPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _services_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services.page.html?ngResource */ 57621);
/* harmony import */ var _services_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services.page.scss?ngResource */ 3673);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_core_dto_serviceCategory_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/serviceCategory.dto */ 89162);
/* harmony import */ var src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/services/services.service */ 63105);








let ServicesWizardPage = class ServicesWizardPage {
    constructor(navCtrl, activatedRoute, servService) {
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
        this.servService = servService;
        this.serviceCollection = [];
        this.serviceCollectionFiltered = [];
        this.isCategoryModalOpen = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllServices();
    }
    getAllServices() {
        this.servService.findServiceCategoryByCommerce(this.commerceLogged).subscribe((response) => {
            this.serviceCollection = response;
            this.serviceCollectionFiltered = this.serviceCollection;
            this.service = response.reduce((acc, it) => [...acc, ...it.services], []);
        });
    }
    goToNext() {
        this.navCtrl.navigateForward(['wizard/employee']);
    }
    goToDetail(service) {
        const navigationExtras = { relativeTo: this.activatedRoute, state: { service, isFromWizard: true } };
        this.navCtrl.navigateForward(['service-item'], navigationExtras);
    }
    goToCreate() {
        this.navCtrl.navigateForward(['service-item'], { relativeTo: this.activatedRoute });
    }
    editCategory(category) {
        this.newCategory = category;
        this.isCategoryModalOpen = true;
    }
    createNewCategory() {
        const newCategoryDto = new src_app_core_dto_serviceCategory_dto__WEBPACK_IMPORTED_MODULE_2__.ServiceCategoryDto();
        newCategoryDto.name = this.newCategory.name;
        newCategoryDto.uuid = this.newCategory.uuid;
        newCategoryDto.services = this.newCategory.services;
        newCategoryDto.commerce = this.commerceLogged;
        this.servService.updateCategoryService(newCategoryDto).subscribe((res) => {
            this.isCategoryModalOpen = false;
        });
    }
};
ServicesWizardPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_3__.ServicesService }
];
ServicesWizardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-services',
        template: _services_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_services_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ServicesWizardPage);



/***/ }),

/***/ 89470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 46730);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 70847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let HeaderComponent = class HeaderComponent {
    constructor() {
        this.titleCase = true;
    }
    ngOnInit() { }
};
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    backButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titlePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titleCase: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 57185:
/*!************************************************!*\
  !*** ./src/app/shared/header/header.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderModule": () => (/* binding */ HeaderModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component */ 89470);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);






let HeaderModule = class HeaderModule {
};
HeaderModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__.TranslateDaysModule
        ],
        exports: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent]
    })
], HeaderModule);



/***/ }),

/***/ 3673:
/*!*********************************************************************!*\
  !*** ./src/app/pages/wizard/services/services.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ".service-card {\n  padding: 0;\n}\n.service-card .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-bottom: 3%;\n}\n.no-padding {\n  padding: 0;\n}\n.no-border {\n  border: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZpY2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7QUFDRjtBQUNFO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUNKO0FBRUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBQUo7QUFHRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFESjtBQUtBO0VBQ0UsVUFBQTtBQUZGO0FBS0E7RUFDRSxTQUFBO0FBRkYiLCJmaWxlIjoic2VydmljZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlcnZpY2UtY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxuXHJcbiAgLnNlcnZpY2UtaW1hZ2Uge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIyOCwgMjI4LCAyMjgpO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICB9XHJcblxyXG4gIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICBtYXJnaW4tdG9wOiAxOTAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgLnNlcnZpY2UtbGFiZWwge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tdG9wOiAzJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDMlO1xyXG4gIH1cclxufVxyXG5cclxuLm5vLXBhZGRpbmcge1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5uby1ib3JkZXIge1xyXG4gIGJvcmRlcjogMDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 70847:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0 !important;\n}\n\nion-back-button {\n  --icon-margin-start: 10px;\n  --icon-margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0FBQ0YiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1iYWNrLWJ1dHRvbiB7XHJcbiAgLS1pY29uLW1hcmdpbi1zdGFydDogMTBweDtcclxuICAtLWljb24tbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 57621:
/*!*********************************************************************!*\
  !*** ./src/app/pages/wizard/services/services.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [titlePage]=\"'Servicios - Paso 2'\" [backButton]=\"true\"></app-header>\n\n<ion-content>\n  <ion-grid class=\"mb-12\">\n    <ion-row class=\"ion-justify-content-center\">\n      <div class=\"px-8 py-4\" *ngIf=\"service?.length === 0\">\n        <h1 class=\"text-center\">Servicios de tu negocio</h1>\n        <p>Ahora necesitamos crear los servicios que prestas en tu negocio.</p>\n        <p>\n          Los servicios se pueden gestionar desde la sección \"Servicios\" del\n          menu MyYeasy\n        </p>\n      </div>\n      <div *ngIf=\"service?.length === 1\" class=\"px-8 py-8\">\n        <h1 class=\"text-center\">¡Genial! Ya has creado tu primer servicio.</h1>\n        <p>Ahora puedes crear más servicios o continuar con la configuración</p>\n      </div>\n\n      <div>\n        <ng-container *ngFor=\"let category of serviceCollectionFiltered\">\n          <div\n            class=\"flex align-baseline justify-between px-8 pt-4\"\n            *ngIf=\"category.services.length > 0\"\n          >\n            <p class=\"text-base\">{{category.name}}</p>\n            <ion-icon\n              class=\"h-4 w-4\"\n              name=\"create-outline\"\n              (click)=\"editCategory(category)\"\n            ></ion-icon>\n          </div>\n          <ion-card\n            class=\"textbox no-border m-0\"\n            *ngFor=\"let service of category.services; let i = index\"\n          >\n            <ion-grid\n              class=\"service-card\"\n              *ngIf=\"!service.isDeleted\"\n              (click)=\"goToDetail(service)\"\n            >\n              <ion-row>\n                <ion-col\n                  size=\"0.1\"\n                  [style.background-color]=\"service?.color\"\n                ></ion-col>\n                <ion-col>\n                  <ion-item button=\"true\">\n                    <ion-label class=\"service-label no-padding\">\n                      {{service.name}} · {{service.defaultDuration}} min ·\n                      {{service.price | formatPrice}}\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card>\n        </ng-container>\n      </div>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n<ion-footer class=\"h-20 py-2 bg-white\">\n  <div class=\"px-8 w-full fixed\">\n    <div\n      class=\"grid\"\n      [ngClass]=\"service?.length > 0 ? 'grid-cols-2' : 'grid-cols-1'\"\n    >\n      <div>\n        <ion-button (click)=\"goToCreate()\" expand=\"block\" class=\"btn\">\n          Crear servicio\n        </ion-button>\n      </div>\n      <div *ngIf=\"service?.length > 0\">\n        <ion-button (click)=\"goToNext()\" expand=\"block\" class=\"btn\">\n          Continuar\n        </ion-button>\n      </div>\n    </div>\n  </div>\n</ion-footer>\n<ion-modal [isOpen]=\"isCategoryModalOpen\" initialBreakpoint=\"0.35\">\n  <ng-template>\n    <ion-header>\n      <ion-toolbar>\n        <ion-title>Editar categoría</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content class=\"ion-padding\">\n      <ion-item class=\"textbox\" [ngClass]=\"newCategory ? 'fill-input' : ''\">\n        <ion-label>Nombre</ion-label>\n        <ion-input\n          #catName\n          type=\"text\"\n          [(ngModel)]=\"newCategory.name\"\n          autocapitalize=\"true\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-button\n        class=\"btn\"\n        [disabled]=\"!catName.value\"\n        (click)=\"createNewCategory()\"\n        expand=\"block\"\n      >\n        Editar\n      </ion-button>\n    </ion-content>\n  </ng-template>\n</ion-modal>\n";

/***/ }),

/***/ 46730:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button *ngIf=\"backButton\" slot=\"start\" text=\"\" defaultHref=\"tabs/profile\" color=\"dark\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title *ngIf=\"titleCase\">{{titlePage | translateDays | titlecase}}</ion-title>\n    <ion-title *ngIf=\"!titleCase\">{{titlePage | translateDays }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_wizard_services_services_module_ts.js.map