"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_admin-employee_employee-detail_select-role_select-role_module_ts"],{

/***/ 34988:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/select-role/select-role-routing.module.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectRolePageRoutingModule": () => (/* binding */ SelectRolePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _select_role_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./select-role.page */ 47753);




const routes = [
    {
        path: '',
        component: _select_role_page__WEBPACK_IMPORTED_MODULE_0__.SelectRolePage
    }
];
let SelectRolePageRoutingModule = class SelectRolePageRoutingModule {
};
SelectRolePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SelectRolePageRoutingModule);



/***/ }),

/***/ 92883:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/select-role/select-role.module.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectRolePageModule": () => (/* binding */ SelectRolePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _select_role_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./select-role-routing.module */ 34988);
/* harmony import */ var _select_role_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./select-role.page */ 47753);








let SelectRolePageModule = class SelectRolePageModule {
};
SelectRolePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _select_role_routing_module__WEBPACK_IMPORTED_MODULE_1__.SelectRolePageRoutingModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule
        ],
        declarations: [_select_role_page__WEBPACK_IMPORTED_MODULE_2__.SelectRolePage]
    })
], SelectRolePageModule);



/***/ }),

/***/ 47753:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/select-role/select-role.page.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectRolePage": () => (/* binding */ SelectRolePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _select_role_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./select-role.page.html?ngResource */ 68167);
/* harmony import */ var _select_role_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./select-role.page.scss?ngResource */ 87114);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../../../core/models/enums/role.enum */ 89121);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);



/* eslint-disable guard-for-in */






let SelectRolePage = class SelectRolePage {
    constructor(router, formBuilder, employeeService, alertController, navCtrl) {
        this.router = router;
        this.formBuilder = formBuilder;
        this.employeeService = employeeService;
        this.alertController = alertController;
        this.navCtrl = navCtrl;
        this.selectedRole = { name: 'Empleado', value: 'empleado' };
        this.isWizard = false;
        this.permissionCollection = [];
        this.initForms();
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.employee) {
                this.employee = this.router.getCurrentNavigation().extras.state.employee;
                if (this.employee.role === _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.PERSONALIZADO) {
                    this.setPersonalizedPermissions();
                }
            }
            if (this.router.getCurrentNavigation().extras.state.isWizard) {
                this.isWizard = true;
            }
            if (this.router.getCurrentNavigation().extras.state.selectedRole) {
                this.selectedRole = this.router.getCurrentNavigation().extras.state.selectedRole;
            }
        }
        this.getAllPermissions();
    }
    ngOnInit() { }
    getAllPermissions() {
        if (sessionStorage.getItem('permission')) {
            this.permissionCollection = JSON.parse(sessionStorage.getItem('permission'));
        }
        else {
            this.employeeService.getAllPermissions().subscribe(response => {
                this.permissionCollection = response;
                this.permissionCollection.map((permission, index) => {
                    if (index === 0) {
                        permission.roles = ['empleado_basico', 'empleado', 'recepcionista', 'gerente'];
                    }
                    else if (index > 0 && index < 3) {
                        permission.roles = ['empleado', 'recepcionista', 'gerente'];
                    }
                    else if (index >= 3 && index < 6) {
                        permission.roles = ['recepcionista', 'gerente'];
                    }
                    else if (index >= 6) {
                        permission.roles = ['gerente'];
                    }
                });
                sessionStorage.setItem('permission', JSON.stringify(this.permissionCollection));
            });
        }
    }
    initForms() {
        this.roleForm = this.formBuilder.group({
            calendario: [false],
            gestion_clientes: [false],
            ventas: [false],
            promociones: [false],
            reseñas: [false],
            gestion_empleados: [false],
            estadisticas: [false],
            configuracion: [false]
        });
    }
    setPersonalizedPermissions() {
        if (this.employee.permissions.length > 0) {
            this.employee.permissions.forEach(permission => {
                this.roleForm.get(permission.name).setValue(true);
            });
        }
    }
    showRoleInfo(event, value) {
        this.setRole(value);
    }
    onChangePermission(event) {
        const role = event.detail.value;
        this.setRole(role);
    }
    selectRadio(name, value) {
        this.setRole(value);
        this.selectedRole = { name, value };
    }
    setRole(role) {
        switch (role) {
            case 'empleado_basico':
                this.selectedRole = { name: 'Empleado básico', value: _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.EMPLEADO_BASICO };
                if (this.employee) {
                    this.employee.role = _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.EMPLEADO_BASICO;
                }
                break;
            case 'empleado':
                this.selectedRole = { name: 'Empleado', value: _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.EMPLEADO };
                if (this.employee) {
                    this.employee.role = _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.EMPLEADO;
                }
                break;
            case 'recepcionista':
                this.selectedRole = { name: 'Recepcionista', value: _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.RECEPCIONISTA };
                if (this.employee) {
                    this.employee.role = _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.RECEPCIONISTA;
                }
                break;
            case 'gerente':
                this.selectedRole = { name: 'Gerente', value: _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.GERENTE };
                if (this.employee) {
                    this.employee.role = _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.GERENTE;
                }
                break;
            case 'personalizado':
                this.selectedRole = { name: 'Personalizado', value: _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.PERSONALIZADO };
                if (this.employee) {
                    this.employee.role = _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.PERSONALIZADO;
                }
                break;
        }
    }
    goBack() {
        const tempPermission = [];
        if (this.selectedRole.value === _core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_3__.EmployeeRole.PERSONALIZADO) {
            for (const field in this.roleForm.controls) {
                const control = this.roleForm.get(field);
                if (control.value) {
                    tempPermission.push(this.permissionCollection.filter(item => item.name === field));
                }
            }
        }
        else {
            this.permissionCollection.forEach(permission => {
                if (permission.roles.includes(this.selectedRole.value)) {
                    tempPermission.push(permission);
                }
            });
        }
        const navigationExtras = { state: null };
        localStorage.setItem('selectedRole', JSON.stringify(this.selectedRole));
        localStorage.setItem('selectedPermission', JSON.stringify(tempPermission.flat()));
        if (tempPermission.length === 0) {
            this.showNoPermissionsSelected();
        }
        else {
            if (this.isWizard) {
                this.navCtrl.navigateBack(['wizard/employee/employee-item'], navigationExtras);
            }
            else {
                this.navCtrl.navigateBack(['tabs/profile/commerce-info/admin-employee/employee-detail'], navigationExtras);
            }
        }
    }
    showNoPermissionsSelected() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Atención',
                message: 'No has elegido ningún permiso. Por favor selecciona uno antes de continuar',
                buttons: ['Aceptar'],
                backdropDismiss: false
            });
            yield alert.present();
        });
    }
    selectAllPermissions(event) {
        for (const field in this.roleForm.controls) {
            const control = this.roleForm.get(field);
            control.setValue(!event.target.checked);
        }
    }
};
SelectRolePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__.EmployeeService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController }
];
SelectRolePage.propDecorators = {
    checkBox: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['checkBox',] }]
};
SelectRolePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-select-role',
        template: _select_role_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_select_role_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SelectRolePage);



/***/ }),

/***/ 87114:
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/select-role/select-role.page.scss?ngResource ***!
  \***********************************************************************************************************/
/***/ ((module) => {

module.exports = ".full-opacity {\n  opacity: 1 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1yb2xlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0YiLCJmaWxlIjoic2VsZWN0LXJvbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZ1bGwtb3BhY2l0eSB7XG4gIG9wYWNpdHk6IDEgIWltcG9ydGFudDtcbn1cbiJdfQ== */";

/***/ }),

/***/ 68167:
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/select-role/select-role.page.html?ngResource ***!
  \***********************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header\n  [backButton]=\"false\"\n  [titleCase]=\"false\"\n  [titlePage]=\"'Nivel de permiso'\"\n>\n</app-header>\n\n<ion-content>\n  <ion-list>\n    <ion-radio-group\n      [value]=\"employee?.role || selectedRole.value\"\n      (ionChange)=\"onChangePermission($event)\"\n    >\n      <ion-list-header>\n        <ion-label>Elige el nivel de permiso</ion-label>\n      </ion-list-header>\n\n      <ion-item\n        class=\"textbox\"\n        (click)=\"selectRadio('Empleado Básico','empleado_basico')\"\n      >\n        <ion-label>Empleado Básico</ion-label>\n        <ion-radio slot=\"start\" value=\"empleado_basico\"></ion-radio>\n        <ion-button\n          id=\"empleado_basico\"\n          (click)=\"showRoleInfo($event, 'empleado_basico')\"\n          expand=\"block\"\n          fill=\"clear\"\n          shape=\"round\"\n        >\n          <ion-icon name=\"help-circle-outline\" slot=\"end\"></ion-icon>\n        </ion-button>\n      </ion-item>\n\n      <ion-item class=\"textbox\" (click)=\"selectRadio('Empleado','empleado')\">\n        <ion-label>Empleado</ion-label>\n        <ion-radio slot=\"start\" value=\"empleado\"></ion-radio>\n        <ion-button\n          id=\"empleado\"\n          (click)=\"showRoleInfo($event, 'empleado')\"\n          expand=\"block\"\n          fill=\"clear\"\n          shape=\"round\"\n        >\n          <ion-icon name=\"help-circle-outline\" slot=\"end\"></ion-icon>\n        </ion-button>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        (click)=\"selectRadio('Empleado','recepcionista')\"\n      >\n        <ion-label>Recepcionista</ion-label>\n        <ion-radio slot=\"start\" value=\"recepcionista\"></ion-radio>\n        <ion-button\n          id=\"recepcionista\"\n          (click)=\"showRoleInfo($event, 'recepcionista')\"\n          expand=\"block\"\n          fill=\"clear\"\n          shape=\"round\"\n        >\n          <ion-icon name=\"help-circle-outline\" slot=\"end\"></ion-icon>\n        </ion-button>\n      </ion-item>\n\n      <ion-item class=\"textbox\" (click)=\"selectRadio('Gerente','gerente')\">\n        <ion-label>Gerente</ion-label>\n        <ion-radio slot=\"start\" value=\"gerente\"></ion-radio>\n        <ion-button\n          id=\"gerente\"\n          (click)=\"showRoleInfo($event, 'gerente')\"\n          expand=\"block\"\n          fill=\"clear\"\n          shape=\"round\"\n        >\n          <ion-icon name=\"help-circle-outline\" slot=\"end\"></ion-icon>\n        </ion-button>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        (click)=\"selectRadio('Personalizado','personalizado')\"\n      >\n        <ion-label>Personalizado</ion-label>\n        <ion-radio slot=\"start\" value=\"personalizado\"></ion-radio>\n        <ion-button\n          id=\"personalized\"\n          (click)=\"showRoleInfo($event, 'personalizado')\"\n          expand=\"block\"\n          fill=\"clear\"\n          shape=\"round\"\n        >\n          <ion-icon name=\"help-circle-outline\" slot=\"end\"></ion-icon>\n        </ion-button>\n      </ion-item>\n    </ion-radio-group>\n  </ion-list>\n\n  <ion-modal trigger=\"empleado_basico\" initialBreakpoint=\"0.70\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-list-header>Empleado básico</ion-list-header>\n          <br />\n          <ion-item *ngFor=\"let permission of permissionCollection\">\n            <ion-label class=\"full-opacity\"\n              >{{permission.description}}</ion-label\n            >\n            <ion-checkbox\n              color=\"dark\"\n              [checked]=\"permission?.roles?.includes(selectedRole.value)\"\n              disabled\n              slot=\"start\"\n            ></ion-checkbox>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <ion-modal trigger=\"empleado\" initialBreakpoint=\"0.50\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-list-header>Empleado</ion-list-header>\n          <br />\n          <ion-item *ngFor=\"let permission of permissionCollection\">\n            <ion-label class=\"full-opacity\"\n              >{{permission.description}}</ion-label\n            >\n            <ion-checkbox\n              color=\"dark\"\n              [checked]=\"permission?.roles?.includes(selectedRole.value)\"\n              disabled\n              slot=\"start\"\n            ></ion-checkbox>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <ion-modal trigger=\"recepcionista\" initialBreakpoint=\"0.50\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-list-header>Recepcionista</ion-list-header>\n          <br />\n          <ion-item *ngFor=\"let permission of permissionCollection\">\n            <ion-label class=\"full-opacity\"\n              >{{permission.description}}</ion-label\n            >\n            <ion-checkbox\n              color=\"dark\"\n              [checked]=\"permission?.roles?.includes(selectedRole.value)\"\n              disabled\n              slot=\"start\"\n            ></ion-checkbox>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <ion-modal trigger=\"gerente\" initialBreakpoint=\"0.50\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-list-header>Gerente</ion-list-header>\n          <br />\n          <ion-item *ngFor=\"let permission of permissionCollection\">\n            <ion-label class=\"full-opacity\"\n              >{{permission.description}}</ion-label\n            >\n            <ion-checkbox\n              color=\"dark\"\n              [checked]=\"permission?.roles?.includes(selectedRole.value)\"\n              disabled\n              slot=\"start\"\n            ></ion-checkbox>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <ion-modal trigger=\"personalized\" initialBreakpoint=\"0.50\">\n    <ng-template>\n      <ion-content>\n        <form [formGroup]=\"roleForm\">\n          <ion-list>\n            <ion-list-header>Personalizado</ion-list-header>\n            <br />\n            <ion-item>\n              <ion-label>Seleccionar todos</ion-label>\n              <ion-checkbox\n                mode=\"md\"\n                slot=\"start\"\n                #checkBox\n                (click)=\"selectAllPermissions($event)\"\n              ></ion-checkbox>\n            </ion-item>\n            <ion-item *ngFor=\"let permission of permissionCollection\">\n              <ion-label class=\"full-opacity\"\n                >{{permission.description}}</ion-label\n              >\n              <ion-checkbox\n                [formControlName]=\"permission.name\"\n                color=\"dark\"\n                slot=\"start\"\n              ></ion-checkbox>\n            </ion-item>\n          </ion-list>\n        </form>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <ion-button (click)=\"goBack()\" class=\"btn\" expand=\"block\">\n          Aceptar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_admin-employee_employee-detail_select-role_select-role_module_ts.js.map