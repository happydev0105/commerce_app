"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_booking-manager_non-availability_non-availability_module_ts"],{

/***/ 18627:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/addHours/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addHours)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addMilliseconds/index.js */ 78089);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



var MILLISECONDS_IN_HOUR = 3600000;
/**
 * @name addHours
 * @category Hour Helpers
 * @summary Add the specified number of hours to the given date.
 *
 * @description
 * Add the specified number of hours to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of hours to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the hours added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 2 hours to 10 July 2014 23:00:00:
 * const result = addHours(new Date(2014, 6, 10, 23, 0), 2)
 * //=> Fri Jul 11 2014 01:00:00
 */

function addHours(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, amount * MILLISECONDS_IN_HOUR);
}

/***/ }),

/***/ 68097:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/parseISO/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseISO)
/* harmony export */ });
/* harmony import */ var _constants_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/index.js */ 97889);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);



/**
 * @name parseISO
 * @category Common Helpers
 * @summary Parse ISO string
 *
 * @description
 * Parse the given string in ISO 8601 format and return an instance of Date.
 *
 * Function accepts complete ISO 8601 formats as well as partial implementations.
 * ISO 8601: http://en.wikipedia.org/wiki/ISO_8601
 *
 * If the argument isn't a string, the function cannot parse the string or
 * the values are invalid, it returns Invalid Date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * - The previous `parse` implementation was renamed to `parseISO`.
 *
 *   ```javascript
 *   // Before v2.0.0
 *   parse('2016-01-01')
 *
 *   // v2.0.0 onward
 *   parseISO('2016-01-01')
 *   ```
 *
 * - `parseISO` now validates separate date and time values in ISO-8601 strings
 *   and returns `Invalid Date` if the date is invalid.
 *
 *   ```javascript
 *   parseISO('2018-13-32')
 *   //=> Invalid Date
 *   ```
 *
 * - `parseISO` now doesn't fall back to `new Date` constructor
 *   if it fails to parse a string argument. Instead, it returns `Invalid Date`.
 *
 * @param {String} argument - the value to convert
 * @param {Object} [options] - an object with options.
 * @param {0|1|2} [options.additionalDigits=2] - the additional number of digits in the extended year format
 * @returns {Date} the parsed date in the local time zone
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.additionalDigits` must be 0, 1 or 2
 *
 * @example
 * // Convert string '2014-02-11T11:30:30' to date:
 * const result = parseISO('2014-02-11T11:30:30')
 * //=> Tue Feb 11 2014 11:30:30
 *
 * @example
 * // Convert string '+02014101' to date,
 * // if the additional number of digits in the extended year format is 1:
 * const result = parseISO('+02014101', { additionalDigits: 1 })
 * //=> Fri Apr 11 2014 00:00:00
 */

function parseISO(argument, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var additionalDigits = options.additionalDigits == null ? 2 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.additionalDigits);

  if (additionalDigits !== 2 && additionalDigits !== 1 && additionalDigits !== 0) {
    throw new RangeError('additionalDigits must be 0, 1 or 2');
  }

  if (!(typeof argument === 'string' || Object.prototype.toString.call(argument) === '[object String]')) {
    return new Date(NaN);
  }

  var dateStrings = splitDateString(argument);
  var date;

  if (dateStrings.date) {
    var parseYearResult = parseYear(dateStrings.date, additionalDigits);
    date = parseDate(parseYearResult.restDateString, parseYearResult.year);
  }

  if (!date || isNaN(date.getTime())) {
    return new Date(NaN);
  }

  var timestamp = date.getTime();
  var time = 0;
  var offset;

  if (dateStrings.time) {
    time = parseTime(dateStrings.time);

    if (isNaN(time)) {
      return new Date(NaN);
    }
  }

  if (dateStrings.timezone) {
    offset = parseTimezone(dateStrings.timezone);

    if (isNaN(offset)) {
      return new Date(NaN);
    }
  } else {
    var dirtyDate = new Date(timestamp + time); // js parsed string assuming it's in UTC timezone
    // but we need it to be parsed in our timezone
    // so we use utc values to build date in our timezone.
    // Year values from 0 to 99 map to the years 1900 to 1999
    // so set year explicitly with setFullYear.

    var result = new Date(0);
    result.setFullYear(dirtyDate.getUTCFullYear(), dirtyDate.getUTCMonth(), dirtyDate.getUTCDate());
    result.setHours(dirtyDate.getUTCHours(), dirtyDate.getUTCMinutes(), dirtyDate.getUTCSeconds(), dirtyDate.getUTCMilliseconds());
    return result;
  }

  return new Date(timestamp + time + offset);
}
var patterns = {
  dateTimeDelimiter: /[T ]/,
  timeZoneDelimiter: /[Z ]/i,
  timezone: /([Z+-].*)$/
};
var dateRegex = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/;
var timeRegex = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/;
var timezoneRegex = /^([+-])(\d{2})(?::?(\d{2}))?$/;

function splitDateString(dateString) {
  var dateStrings = {};
  var array = dateString.split(patterns.dateTimeDelimiter);
  var timeString; // The regex match should only return at maximum two array elements.
  // [date], [time], or [date, time].

  if (array.length > 2) {
    return dateStrings;
  }

  if (/:/.test(array[0])) {
    timeString = array[0];
  } else {
    dateStrings.date = array[0];
    timeString = array[1];

    if (patterns.timeZoneDelimiter.test(dateStrings.date)) {
      dateStrings.date = dateString.split(patterns.timeZoneDelimiter)[0];
      timeString = dateString.substr(dateStrings.date.length, dateString.length);
    }
  }

  if (timeString) {
    var token = patterns.timezone.exec(timeString);

    if (token) {
      dateStrings.time = timeString.replace(token[1], '');
      dateStrings.timezone = token[1];
    } else {
      dateStrings.time = timeString;
    }
  }

  return dateStrings;
}

function parseYear(dateString, additionalDigits) {
  var regex = new RegExp('^(?:(\\d{4}|[+-]\\d{' + (4 + additionalDigits) + '})|(\\d{2}|[+-]\\d{' + (2 + additionalDigits) + '})$)');
  var captures = dateString.match(regex); // Invalid ISO-formatted year

  if (!captures) return {
    year: NaN,
    restDateString: ''
  };
  var year = captures[1] ? parseInt(captures[1]) : null;
  var century = captures[2] ? parseInt(captures[2]) : null; // either year or century is null, not both

  return {
    year: century === null ? year : century * 100,
    restDateString: dateString.slice((captures[1] || captures[2]).length)
  };
}

function parseDate(dateString, year) {
  // Invalid ISO-formatted year
  if (year === null) return new Date(NaN);
  var captures = dateString.match(dateRegex); // Invalid ISO-formatted string

  if (!captures) return new Date(NaN);
  var isWeekDate = !!captures[4];
  var dayOfYear = parseDateUnit(captures[1]);
  var month = parseDateUnit(captures[2]) - 1;
  var day = parseDateUnit(captures[3]);
  var week = parseDateUnit(captures[4]);
  var dayOfWeek = parseDateUnit(captures[5]) - 1;

  if (isWeekDate) {
    if (!validateWeekDate(year, week, dayOfWeek)) {
      return new Date(NaN);
    }

    return dayOfISOWeekYear(year, week, dayOfWeek);
  } else {
    var date = new Date(0);

    if (!validateDate(year, month, day) || !validateDayOfYearDate(year, dayOfYear)) {
      return new Date(NaN);
    }

    date.setUTCFullYear(year, month, Math.max(dayOfYear, day));
    return date;
  }
}

function parseDateUnit(value) {
  return value ? parseInt(value) : 1;
}

function parseTime(timeString) {
  var captures = timeString.match(timeRegex);
  if (!captures) return NaN; // Invalid ISO-formatted time

  var hours = parseTimeUnit(captures[1]);
  var minutes = parseTimeUnit(captures[2]);
  var seconds = parseTimeUnit(captures[3]);

  if (!validateTime(hours, minutes, seconds)) {
    return NaN;
  }

  return hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute + seconds * 1000;
}

function parseTimeUnit(value) {
  return value && parseFloat(value.replace(',', '.')) || 0;
}

function parseTimezone(timezoneString) {
  if (timezoneString === 'Z') return 0;
  var captures = timezoneString.match(timezoneRegex);
  if (!captures) return 0;
  var sign = captures[1] === '+' ? -1 : 1;
  var hours = parseInt(captures[2]);
  var minutes = captures[3] && parseInt(captures[3]) || 0;

  if (!validateTimezone(hours, minutes)) {
    return NaN;
  }

  return sign * (hours * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInHour + minutes * _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute);
}

function dayOfISOWeekYear(isoWeekYear, week, day) {
  var date = new Date(0);
  date.setUTCFullYear(isoWeekYear, 0, 4);
  var fourthOfJanuaryDay = date.getUTCDay() || 7;
  var diff = (week - 1) * 7 + day + 1 - fourthOfJanuaryDay;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
} // Validation functions
// February is null to handle the leap year (using ||)


var daysInMonths = [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function isLeapYearIndex(year) {
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}

function validateDate(year, month, date) {
  return month >= 0 && month <= 11 && date >= 1 && date <= (daysInMonths[month] || (isLeapYearIndex(year) ? 29 : 28));
}

function validateDayOfYearDate(year, dayOfYear) {
  return dayOfYear >= 1 && dayOfYear <= (isLeapYearIndex(year) ? 366 : 365);
}

function validateWeekDate(_year, week, day) {
  return week >= 1 && week <= 53 && day >= 0 && day <= 6;
}

function validateTime(hours, minutes, seconds) {
  if (hours === 24) {
    return minutes === 0 && seconds === 0;
  }

  return seconds >= 0 && seconds < 60 && minutes >= 0 && minutes < 60 && hours >= 0 && hours < 25;
}

function validateTimezone(_hours, minutes) {
  return minutes >= 0 && minutes <= 59;
}

/***/ }),

/***/ 84013:
/*!********************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysModule": () => (/* binding */ TranslateDaysModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./translate-days.pipe */ 29069);





let TranslateDaysModule = class TranslateDaysModule {
};
TranslateDaysModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_translate_days_pipe__WEBPACK_IMPORTED_MODULE_0__.TranslateDaysPipe]
    })
], TranslateDaysModule);



/***/ }),

/***/ 29069:
/*!******************************************************************!*\
  !*** ./src/app/core/pipes/translate-days/translate-days.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TranslateDaysPipe": () => (/* binding */ TranslateDaysPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TranslateDaysPipe = class TranslateDaysPipe {
    transform(value) {
        const daysTranslated = {
            monday: 'lunes',
            tuesday: 'martes',
            wednesday: 'miércoles',
            thursday: 'jueves',
            friday: 'viernes',
            saturday: 'sábado',
            sunday: 'domingo'
        };
        return daysTranslated[value] || value;
    }
};
TranslateDaysPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'translateDays'
    })
], TranslateDaysPipe);



/***/ }),

/***/ 68521:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/non-availability/non-availability-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonAvailabilityPageRoutingModule": () => (/* binding */ NonAvailabilityPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _non_availability_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./non-availability.page */ 33270);




const routes = [
    {
        path: '',
        component: _non_availability_page__WEBPACK_IMPORTED_MODULE_0__.NonAvailabilityPage
    }
];
let NonAvailabilityPageRoutingModule = class NonAvailabilityPageRoutingModule {
};
NonAvailabilityPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NonAvailabilityPageRoutingModule);



/***/ }),

/***/ 87308:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/booking-manager/non-availability/non-availability.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonAvailabilityPageModule": () => (/* binding */ NonAvailabilityPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _non_availability_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./non-availability-routing.module */ 68521);
/* harmony import */ var _non_availability_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./non-availability.page */ 33270);
/* harmony import */ var _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular-material-components/datetime-picker */ 55923);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/form-field */ 37551);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var _shared_components_time_selector_time_selector_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../shared/components/time-selector/time-selector.module */ 57504);












let NonAvailabilityPageModule = class NonAvailabilityPageModule {
};
NonAvailabilityPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _non_availability_routing_module__WEBPACK_IMPORTED_MODULE_1__.NonAvailabilityPageRoutingModule,
            _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_10__.NgxMatTimepickerModule,
            _angular_material_components_datetime_picker__WEBPACK_IMPORTED_MODULE_10__.NgxMatDatetimePickerModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_11__.MatFormFieldModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_3__.AlertModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule,
            _shared_components_time_selector_time_selector_module__WEBPACK_IMPORTED_MODULE_4__.TimeSelectorModule
        ],
        declarations: [_non_availability_page__WEBPACK_IMPORTED_MODULE_2__.NonAvailabilityPage],
    })
], NonAvailabilityPageModule);



/***/ }),

/***/ 33270:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/booking-manager/non-availability/non-availability.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonAvailabilityPage": () => (/* binding */ NonAvailabilityPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _non_availability_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./non-availability.page.html?ngResource */ 63442);
/* harmony import */ var _non_availability_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./non-availability.page.scss?ngResource */ 99398);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! date-fns */ 68097);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! date-fns */ 18627);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! date-fns */ 33719);
/* harmony import */ var src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/dto/non-availability.dto */ 57394);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/non-availability/non-availability.service */ 30371);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! date-fns/locale */ 36956);














let NonAvailabilityPage = class NonAvailabilityPage {
    constructor(fb, employeeService, dateService, nonAvailabilityService, activatedRoute, router, navCtrl, cdr) {
        this.fb = fb;
        this.employeeService = employeeService;
        this.dateService = dateService;
        this.nonAvailabilityService = nonAvailabilityService;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.navCtrl = navCtrl;
        this.cdr = cdr;
        this.showPickerDate = false;
        this.employeeCollection = [];
        this.isEdit = false;
        this.locale = date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"];
        this.noclick = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.bookingData) {
                this.nonAvailabilityData = this.router.getCurrentNavigation().extras.state.bookingData;
            }
            this.selectedDay = this.router.getCurrentNavigation().extras.state.selectedDay;
        }
    }
    get startDay() {
        return this.form.get('startDay');
    }
    get startHour() {
        return this.form.get('startHour');
    }
    get endHour() {
        return this.form.get('endHour');
    }
    get message() {
        return this.form.get('message');
    }
    get employee() {
        return this.form.get('employee');
    }
    onTouchStart() {
        this.noclick = true;
    }
    onTouchMove() {
        this.noclick = true;
        const selection = window.getSelection();
        selection.removeAllRanges();
    }
    onTouchEnd() {
        this.noclick = false;
    }
    ionViewWillEnter() {
        this.findEmployeeCollection(this.commerceLogged);
    }
    ngOnInit() {
        this.cdr.detectChanges();
        this.title = 'Crear reserva de tiempo';
    }
    getParam() {
        if (this.activatedRoute.snapshot.params.id) {
            this.title = 'Editar reserva de tiempo';
            this.activatedRoute.params.subscribe((res) => {
                this.id = res.id;
                this.nonAvailabilityService
                    .getNonAvailabilityById(res.id)
                    .subscribe((nonAva) => {
                    this.editItem = nonAva;
                    this.isEdit = true;
                    const dateSplit = nonAva.date.split('-');
                    const timetable = JSON.parse(nonAva.timetable);
                    const date = new Date(parseInt(dateSplit[0], 10), parseInt(dateSplit[1], 10) - 1, parseInt(dateSplit[2], 10), timetable.start.hour, timetable.start.minute);
                    const enddate = new Date(parseInt(dateSplit[0], 10), parseInt(dateSplit[1], 10) - 1, parseInt(dateSplit[2], 10), timetable.end.hour, timetable.end.minute);
                    this.startDay.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(date, 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }));
                    this.startHour.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(date, 'HH:mm'));
                    this.endHour.setValue((0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(enddate, 'HH:mm'));
                    this.dateChanged(date.toJSON());
                    this.timeChanged(enddate.toJSON());
                    this.selectedEmployee(nonAva.employee.uuid);
                    this.message.setValue(nonAva.message);
                });
            });
        }
        else {
            this.title = 'Crear reserva de tiempo';
        }
    }
    findEmployeeCollection(commerce) {
        this.employeeService
            .findEmployees(commerce)
            .subscribe((res) => {
            this.employeeCollection = res;
            this.getParam();
            this.initForm();
            this.cdr.detectChanges();
        });
    }
    dateChanged(value) {
        this.dateValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_9__["default"])(value), 'HH:mm  d MMM, yyyy');
    }
    timeChanged(value) {
        this.timeValue = (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_9__["default"])(value), 'HH:mm ');
    }
    dismiss() {
        this.datetime.cancel(true);
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    select() {
        this.datetime.confirm(true);
    }
    dismissTime() {
        this.time.cancel(true);
    }
    selectTime() {
        this.time.confirm(true);
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/home'], { replaceUrl: true });
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    deleteItem() {
        this.nonAvailabilityService
            .deleteNonAvailabilityById(this.id)
            .subscribe((res) => {
            if (res.affected > 0) {
                this.cancel();
            }
        });
    }
    onSubmit() {
        const nonAvailabilityDto = this.buildNonAvailability();
        if (this.isEdit) {
            this.nonAvailabilityService
                .editNonAvailability(nonAvailabilityDto)
                .subscribe((res) => {
                if (res) {
                    this.cancel();
                }
            });
        }
        else {
            this.nonAvailabilityService
                .saveNonAvailability(nonAvailabilityDto)
                .subscribe((res) => {
                if (res) {
                    this.cancel();
                }
            });
        }
    }
    onChangeStartHour(event) {
        if (event !== undefined) {
            const hourSelected = event;
            if ((hourSelected === null || hourSelected === void 0 ? void 0 : hourSelected.length) > 0) {
                this.startHour.setValue(hourSelected.split(':')[0] + ':' + hourSelected.split(':')[1]);
            }
        }
    }
    onChangeEndHour(event) {
        if (event !== undefined) {
            const hourSelected = event.split('T')[1];
            if ((hourSelected === null || hourSelected === void 0 ? void 0 : hourSelected.length) > 0) {
                this.endHour.setValue(hourSelected.split(':')[0] + ':' + hourSelected.split(':')[1]);
            }
        }
    }
    selectedEmployee(value) {
        this.employee.setValue(value);
    }
    ionViewDidLeave() {
        console.log('leave');
        this.cancel();
    }
    ngOnDestroy() {
        this.form.reset();
    }
    setSelectedStartHour(hourSelected) {
        this.startHour.setValue(hourSelected);
        this.onChangeStartHour(hourSelected);
    }
    setSelectedEndHour(hourSelected) {
        this.endHour.setValue(hourSelected);
        //this.calculateTimeBetweenEndAndStart();
    }
    initForm() {
        this.form = this.fb.group({
            startDay: [
                this.nonAvailabilityData ?
                    (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(new Date(this.nonAvailabilityData.selectedDay.date), 'yyyy-MM-dd', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }) :
                    this.selectedDay, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required
            ],
            startHour: [
                this.nonAvailabilityData ?
                    (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(new Date(2022, 1, 1, this.nonAvailabilityData.selectedHour.hours, this.nonAvailabilityData.selectedHour.minutes), 'HH:mm', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }) :
                    (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])(new Date(), 'HH:mm', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }),
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required
            ],
            endHour: [
                this.nonAvailabilityData ?
                    (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])(new Date(2022, 1, 1, this.nonAvailabilityData.selectedHour.hours, this.nonAvailabilityData.selectedHour.minutes), 1), 'HH:mm', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }) :
                    (0,date_fns__WEBPACK_IMPORTED_MODULE_8__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_11__["default"])(new Date(), 1), 'HH:mm', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_7__["default"] }),
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required
            ],
            message: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required],
            employee: [this.nonAvailabilityData ? this.nonAvailabilityData.employee.uuid : '', _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required],
        });
        console.log(this.startDay);
    }
    buildNonAvailability() {
        const newNonAvailability = new src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_2__.NonAvailabilityDto();
        newNonAvailability.commerce = this.commerceLogged;
        newNonAvailability.employee = this.employee.value;
        newNonAvailability.week = (0,date_fns__WEBPACK_IMPORTED_MODULE_12__["default"])(new Date(this.startDay.value), { weekStartsOn: 1, firstWeekContainsDate: 4 });
        const startDate = new Date(this.startDay.value);
        newNonAvailability.date = this.dateService.formatDate(startDate);
        if (this.isEdit) {
            newNonAvailability.uuid = this.editItem.uuid;
        }
        const timetable = {
            start: {
                hour: parseInt(this.startHour.value.split(':')[0], 10),
                minute: parseInt(this.startHour.value.split(':')[1], 10),
            },
            end: {
                hour: parseInt(this.endHour.value.split(':')[0], 10),
                minute: parseInt(this.endHour.value.split(':')[1], 10),
            },
        };
        newNonAvailability.timetable = JSON.stringify(timetable);
        newNonAvailability.message = this.message.value;
        return newNonAvailability;
    }
};
NonAvailabilityPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_4__.EmployeeService },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_3__.DateService },
    { type: src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_5__.NonAvailabilityService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectorRef }
];
NonAvailabilityPage.propDecorators = {
    datetime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonDatetime,] }],
    time: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonDatetime,] }],
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_6__.AlertComponent,] }],
    onTouchStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.HostListener, args: ['window:touchstart', ['$event'],] }],
    onTouchMove: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.HostListener, args: ['window:touchmove', ['$event'],] }],
    onTouchEnd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.HostListener, args: ['window:touchend', ['$event'],] }]
};
NonAvailabilityPage = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-non-availability',
        template: _non_availability_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ChangeDetectionStrategy.OnPush,
        styles: [_non_availability_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NonAvailabilityPage);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 89470:
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 46730);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 70847);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let HeaderComponent = class HeaderComponent {
    constructor() {
        this.titleCase = true;
    }
    ngOnInit() { }
};
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    backButton: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titlePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    titleCase: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 57185:
/*!************************************************!*\
  !*** ./src/app/shared/header/header.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderModule": () => (/* binding */ HeaderModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component */ 89470);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);






let HeaderModule = class HeaderModule {
};
HeaderModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_1__.TranslateDaysModule
        ],
        exports: [_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent]
    })
], HeaderModule);



/***/ }),

/***/ 99398:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/non-availability/non-availability.page.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "ion-datetime {\n  background-color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vbi1hdmFpbGFiaWxpdHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7QUFDRiIsImZpbGUiOiJub24tYXZhaWxhYmlsaXR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1kYXRldGltZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 70847:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --border-width: 0 !important;\n}\n\nion-back-button {\n  --icon-margin-start: 10px;\n  --icon-margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0FBQ0YiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1iYWNrLWJ1dHRvbiB7XHJcbiAgLS1pY29uLW1hcmdpbi1zdGFydDogMTBweDtcclxuICAtLWljb24tbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 63442:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/non-availability/non-availability.page.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"title\"></app-header>\r\n\r\n<ion-content fullscreen=\"true\">\r\n  <form\r\n    [formGroup]=\"form\"\r\n    (ngSubmit)=\"onSubmit()\"\r\n    *ngIf=\"employeeCollection.length > 0\"\r\n    novalidate\r\n  >\r\n    <ion-item class=\"textbox\" no-lines lines=\"none\">\r\n      <ion-label>Empleado</ion-label>\r\n      <ion-select\r\n        #employee\r\n        formControlName=\"employee\"\r\n        interface=\"action-sheet\"\r\n        (ionChange)=\"selectedEmployee(employee.value)\"\r\n      >\r\n        <ion-select-option\r\n          *ngFor=\"let employee of employeeCollection\"\r\n          [value]=\"employee.uuid\"\r\n          >{{employee.name}}\r\n        </ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n\r\n    <div class=\"p-0\" id=\"open-start-date\">\r\n      <ion-item class=\"textbox\">\r\n        <ion-label class=\"w-full max-w-none\"\r\n          >Fecha Inicio\r\n          <span class=\"float-right\"\r\n            >{{dateService.formatDateLanguage(startDay.value, locale)}}</span\r\n          >\r\n        </ion-label>\r\n        <ion-input\r\n          type=\"hidden\"\r\n          class=\"hidden\"\r\n          [value]=\"dateService.formatDateLanguage(startDay.value, locale)\"\r\n        ></ion-input>\r\n        <ion-modal\r\n          id=\"open-modal-calendar\"\r\n          initialBreakpoint=\"0.50\"\r\n          trigger=\"open-start-date\"\r\n        >\r\n          <ng-template>\r\n            <ion-content>\r\n              <ion-toolbar>\r\n                <ion-title>Fecha inicio</ion-title>\r\n              </ion-toolbar>\r\n              <ion-datetime\r\n                #datetime\r\n                first-day-of-week=\"1\"\r\n                locale=\"es-ES\"\r\n                (ionChange)=\"dateChanged(datetime.value)\"\r\n                presentation=\"date\"\r\n                size=\"cover\"\r\n                formControlName=\"startDay\"\r\n              >\r\n              </ion-datetime>\r\n            </ion-content>\r\n          </ng-template>\r\n        </ion-modal>\r\n      </ion-item>\r\n    </div>\r\n    <ion-item class=\"textbox\" no-lines lines=\"none\" id=\"start-hour\">\r\n      <ion-label>Hora inicio</ion-label>\r\n      <ion-input\r\n        type=\"text\"\r\n        class=\"ion-text-right\"\r\n        [value]=\"form.controls['startHour'].value \"\r\n      >\r\n      </ion-input>\r\n      <ion-modal\r\n        id=\"start-hour-modal\"\r\n        initialBreakpoint=\"0.5\"\r\n        backdropBreakpoint=\"0.5\"\r\n        trigger=\"start-hour\"\r\n      >\r\n        <ng-template>\r\n          <ion-content>\r\n            <ion-toolbar>\r\n              <ion-title>Hora inicio</ion-title>\r\n              <ion-buttons slot=\"end\">\r\n                <ion-button\r\n                  color=\"dark\"\r\n                  (click)=\"dismissModal('start-hour-modal')\"\r\n                  >Aceptar</ion-button\r\n                >\r\n              </ion-buttons>\r\n            </ion-toolbar>\r\n            <app-time-selector\r\n              [availableStartHour]=\"'0'\"\r\n              [availableEndHour]=\"'23'\"\r\n              [initialHour]=\"startHour.value.split(':')[0]\"\r\n              [initialMinutes]=\"startHour.value.split(':')[1]\"\r\n              (hourSelectedEmitter)=\"setSelectedStartHour($event)\"\r\n            >\r\n            </app-time-selector>\r\n          </ion-content>\r\n        </ng-template>\r\n      </ion-modal>\r\n    </ion-item>\r\n    <ion-item class=\"textbox\" no-lines lines=\"none\" id=\"end-hour\">\r\n      <ion-label>Hora final</ion-label>\r\n      <ion-input\r\n        type=\"text\"\r\n        class=\"ion-text-right\"\r\n        [value]=\"form.controls['endHour'].value \"\r\n      >\r\n      </ion-input>\r\n      <ion-modal\r\n        id=\"end-hour-modal\"\r\n        initialBreakpoint=\"0.5\"\r\n        backdropBreakpoint=\"0.5\"\r\n        trigger=\"end-hour\"\r\n      >\r\n        <ng-template>\r\n          <ion-content>\r\n            <ion-toolbar>\r\n              <ion-title>Hora final</ion-title>\r\n              <ion-buttons slot=\"end\">\r\n                <ion-button\r\n                  color=\"dark\"\r\n                  (click)=\"dismissModal('end-hour-modal')\"\r\n                  >Aceptar</ion-button\r\n                >\r\n              </ion-buttons>\r\n            </ion-toolbar>\r\n            <app-time-selector\r\n              [availableStartHour]=\"'0'\"\r\n              [availableEndHour]=\"'23'\"\r\n              [initialHour]=\"endHour.value.split(':')[0]\"\r\n              [initialMinutes]=\"endHour.value.split(':')[1]\"\r\n              (hourSelectedEmitter)=\"setSelectedEndHour($event)\"\r\n            >\r\n            </app-time-selector>\r\n          </ion-content>\r\n        </ng-template>\r\n      </ion-modal>\r\n    </ion-item>\r\n    <ion-item class=\"textbox\" no-lines lines=\"none\">\r\n      <ion-label>Motivo</ion-label>\r\n      <ion-input\r\n        class=\"ion-text-right\"\r\n        autocapitalize=\"true\"\r\n        ngDefaultControl\r\n        formControlName=\"message\"\r\n        type=\"text\"\r\n      ></ion-input>\r\n    </ion-item>\r\n  </form>\r\n</ion-content>\r\n\r\n<app-alert\r\n  #deleteAlert\r\n  (actionEmitter)=\"alertBox($event)\"\r\n  [title]=\"'¿Desea borrar?'\"\r\n></app-alert>\r\n<ion-footer class=\"ion-no-border\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col *ngIf=\"isEdit\" (click)=\"openAlert()\">\r\n        <ion-button class=\"btn\" expand=\"block\">\r\n          <ion-icon icon=\"trash\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-button (click)=\"cancel()\" class=\"btn\" expand=\"block\">\r\n          Cancelar\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-button (click)=\"onSubmit()\" class=\"btn\" expand=\"block\">\r\n          Guardar\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-footer>\r\n";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ }),

/***/ 46730:
/*!****************************************************************!*\
  !*** ./src/app/shared/header/header.component.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button *ngIf=\"backButton\" slot=\"start\" text=\"\" defaultHref=\"tabs/profile\" color=\"dark\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title *ngIf=\"titleCase\">{{titlePage | translateDays | titlecase}}</ion-title>\n    <ion-title *ngIf=\"!titleCase\">{{titlePage | translateDays }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_booking-manager_non-availability_non-availability_module_ts.js.map