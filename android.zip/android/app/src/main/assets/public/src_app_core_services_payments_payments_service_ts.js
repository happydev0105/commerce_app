"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_core_services_payments_payments_service_ts"],{

/***/ 29474:
/*!************************************************************!*\
  !*** ./src/app/core/services/payments/payments.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsService": () => (/* binding */ PaymentsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let PaymentsService = class PaymentsService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    savePaymentByCommerce(paymentDto) {
        return this.http.post(`${this.apiUrl}/payments/`, paymentDto);
    }
    deletePayment(paymentId) {
        return this.http.delete(`${this.apiUrl}/payments/${paymentId}`);
    }
    getPaymentById(paymentId) {
        return this.http.get(`${this.apiUrl}/payments/${paymentId}`);
    }
};
PaymentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PaymentsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], PaymentsService);



/***/ })

}]);
//# sourceMappingURL=src_app_core_services_payments_payments_service_ts.js.map