"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_support_support_module_ts"],{

/***/ 5594:
/*!*********************************************************!*\
  !*** ./src/app/core/models/enums/ticket-status.enum.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TicketStatus": () => (/* binding */ TicketStatus)
/* harmony export */ });
var TicketStatus;
(function (TicketStatus) {
    TicketStatus["PENDING"] = "pending";
    TicketStatus["IN_PROGRESS"] = "in_progress";
    TicketStatus["FINISHED"] = "finished";
})(TicketStatus || (TicketStatus = {}));


/***/ }),

/***/ 76423:
/*!**********************************************************!*\
  !*** ./src/app/core/services/support/support.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportService": () => (/* binding */ SupportService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let SupportService = class SupportService {
    constructor(http) {
        this.http = http;
        this.API_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    getTicketsByCommerce(commerceId) {
        return this.http.get(`${this.API_URL}/ticket/commerce/${commerceId}`);
    }
    createNewTicket(ticket) {
        return this.http.post(`${this.API_URL}/ticket`, ticket);
    }
    createNewComment(comment) {
        return this.http.post(`${this.API_URL}/comment`, comment);
    }
};
SupportService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
SupportService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], SupportService);



/***/ }),

/***/ 51471:
/*!*****************************************************************!*\
  !*** ./src/app/pages/profile/support/support-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportPageRoutingModule": () => (/* binding */ SupportPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _support_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support.page */ 92751);




const routes = [
    {
        path: '',
        component: _support_page__WEBPACK_IMPORTED_MODULE_0__.SupportPage
    },
    {
        path: 'support-ticket',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_support_support-ticket_support-ticket_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./support-ticket/support-ticket.module */ 68800)).then(m => m.SupportTicketPageModule)
    }
];
let SupportPageRoutingModule = class SupportPageRoutingModule {
};
SupportPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SupportPageRoutingModule);



/***/ }),

/***/ 19117:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/support/support.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportPageModule": () => (/* binding */ SupportPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _support_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./support-routing.module */ 51471);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _support_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./support.page */ 92751);
/* harmony import */ var src_app_shared_pipes_ticket_status_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/pipes/ticket-status.pipe */ 97401);
/* harmony import */ var _ticket_filter_ticket_filter_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ticket-filter/ticket-filter.component */ 3566);











let SupportPageModule = class SupportPageModule {
};
SupportPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _support_routing_module__WEBPACK_IMPORTED_MODULE_1__.SupportPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_2__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule
        ],
        declarations: [_support_page__WEBPACK_IMPORTED_MODULE_3__.SupportPage, src_app_shared_pipes_ticket_status_pipe__WEBPACK_IMPORTED_MODULE_4__.TicketStatusPipe, _ticket_filter_ticket_filter_component__WEBPACK_IMPORTED_MODULE_5__.TicketFilterComponent]
    })
], SupportPageModule);



/***/ }),

/***/ 92751:
/*!*******************************************************!*\
  !*** ./src/app/pages/profile/support/support.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SupportPage": () => (/* binding */ SupportPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _support_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./support.page.html?ngResource */ 57004);
/* harmony import */ var _support_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./support.page.scss?ngResource */ 70867);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ticket_filter_ticket_filter_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ticket-filter/ticket-filter.component */ 3566);
/* harmony import */ var src_app_core_models_enums_ticket_status_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/enums/ticket-status.enum */ 5594);
/* harmony import */ var src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/auth/auth.service */ 57990);
/* harmony import */ var src_app_core_services_support_support_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/support/support.service */ 76423);









let SupportPage = class SupportPage {
    constructor(supportService, navCtrl, modalController, routerOutlet, authService) {
        this.supportService = supportService;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.authService = authService;
        this.ticketCollection = [];
        this.ticketCollectionFiltered = [];
        this.filterApplied = 'all';
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.getAllTickets();
    }
    ngOnInit() { }
    getAllTickets() {
        this.supportService.getTicketsByCommerce(this.commerceLogged).subscribe(response => {
            this.ticketCollectionFiltered = response;
            this.ticketCollection = this.ticketCollectionFiltered.filter(ticket => ticket.status !== src_app_core_models_enums_ticket_status_enum__WEBPACK_IMPORTED_MODULE_3__.TicketStatus.FINISHED);
        });
    }
    goToCreate() {
        this.navCtrl.navigateForward(['tabs/profile/support/support-ticket']);
    }
    goToDetail(ticket) {
        const navigationExtras = {
            state: { ticket },
        };
        this.navCtrl.navigateForward(['tabs/profile/support/support-ticket'], navigationExtras);
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _ticket_filter_ticket_filter_component__WEBPACK_IMPORTED_MODULE_2__.TicketFilterComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                backdropDismiss: false,
                componentProps: {
                    filterApplied: this.filterApplied
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                this.filterApplied = data.filter;
                if (data.filter === 'all') {
                    this.ticketCollection = this.ticketCollectionFiltered;
                }
                else {
                    this.ticketCollection = this.ticketCollectionFiltered.filter(ticket => ticket.status === this.filterApplied);
                }
            }
            else {
                this.ticketCollection = this.ticketCollectionFiltered;
            }
        });
    }
};
SupportPage.ctorParameters = () => [
    { type: src_app_core_services_support_support_service__WEBPACK_IMPORTED_MODULE_5__.SupportService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRouterOutlet },
    { type: src_app_core_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService }
];
SupportPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-support',
        template: _support_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_support_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SupportPage);



/***/ }),

/***/ 3566:
/*!********************************************************************************!*\
  !*** ./src/app/pages/profile/support/ticket-filter/ticket-filter.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TicketFilterComponent": () => (/* binding */ TicketFilterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _ticket_filter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ticket-filter.component.html?ngResource */ 84270);
/* harmony import */ var _ticket_filter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ticket-filter.component.scss?ngResource */ 18703);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 95472);





let TicketFilterComponent = class TicketFilterComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.ticketStatusFilter = '';
    }
    ngOnInit() {
        this.ticketStatusFilter = this.filterApplied ? this.filterApplied : 'pending';
    }
    dismiss(cancel) {
        cancel ? this.modalCtrl.dismiss() : this.modalCtrl.dismiss({ filter: this.ticketStatusFilter });
    }
};
TicketFilterComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
TicketFilterComponent.propDecorators = {
    filterApplied: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
TicketFilterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-ticket-filter',
        template: _ticket_filter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ticket_filter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TicketFilterComponent);



/***/ }),

/***/ 97401:
/*!****************************************************!*\
  !*** ./src/app/shared/pipes/ticket-status.pipe.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TicketStatusPipe": () => (/* binding */ TicketStatusPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TicketStatusPipe = class TicketStatusPipe {
    transform(value) {
        const translatedStatus = {
            pending: 'pendiente',
            in_progress: 'en progreso',
            finished: 'finalizado'
        };
        return translatedStatus[value];
    }
};
TicketStatusPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'ticketStatus'
    })
], TicketStatusPipe);



/***/ }),

/***/ 70867:
/*!********************************************************************!*\
  !*** ./src/app/pages/profile/support/support.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "h2 {\n  margin: 0;\n}\n\n.icon-option {\n  margin-top: -25px;\n  margin-right: 10px;\n}\n\n.orange-500 {\n  color: #f97316;\n}\n\n.green-300 {\n  color: #86efac;\n}\n\n.yellow-300 {\n  color: #fde047;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cHBvcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGIiwiZmlsZSI6InN1cHBvcnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDIge1xuICBtYXJnaW46IDA7XG59XG5cbi5pY29uLW9wdGlvbiB7XG4gIG1hcmdpbi10b3A6IC0yNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5vcmFuZ2UtNTAwIHtcbiAgY29sb3I6IHJnYigyNDkgMTE1IDIyKTtcbn1cblxuLmdyZWVuLTMwMCB7XG4gIGNvbG9yOiByZ2IoMTM0IDIzOSAxNzIpO1xufVxuXG4ueWVsbG93LTMwMCB7XG4gIGNvbG9yOiByZ2IoMjUzIDIyNCA3MSk7XG59XG4iXX0= */";

/***/ }),

/***/ 18703:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/profile/support/ticket-filter/ticket-filter.component.scss?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0aWNrZXQtZmlsdGVyLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 57004:
/*!********************************************************************!*\
  !*** ./src/app/pages/profile/support/support.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Soporte'\"></app-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\" >\n    <ion-fab-button color=\"dark\" (click)=\"goToCreate()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <ion-grid fixed\n    *ngIf=\"ticketCollection.length > 0\"\n    style=\"border-top: 1px solid lightgray; border-bottom: 1px solid lightgray\">\n  <ion-row>\n    <ion-col size=\"10\" style=\"border-right: 1px solid lightgray\">\n      <ion-item>\n        <ion-label *ngIf=\"ticketCollection.length > 1\">{{ticketCollection.length}} TICKETS </ion-label>\n        <ion-label *ngIf=\"ticketCollection.length === 1\">{{ticketCollection.length}} TICKET </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"2\">\n      <ion-item>\n        <ion-icon (click)=\"presentModal()\" name=\"options-outline\"></ion-icon>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n  <ion-list>\n    <ion-item class=\"textbox \" *ngFor=\"let ticket of ticketCollection\" (click)=\"goToDetail(ticket)\">\n      <ion-icon name=\"ticket-outline\" class=\"icon-option\"></ion-icon>\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{ticket.type | titlecase}} • <span [ngClass]=\"[\n          ticket.status === 'pending' ? 'orange-500' : '',\n          ticket.status === 'in_progress' ? 'yellow-300' : '',\n          ticket.status === 'finished' ? 'green-300' : '']\">{{ticket.status | ticketStatus | titlecase}}</span></h2>\n        <ion-note>{{ticket.description}}</ion-note>\n      </ion-label>\n      <ion-icon name=\"chevron-forward-outline\" ></ion-icon>\n    </ion-item>\n  </ion-list>\n\n  <app-no-data *ngIf=\"ticketCollection.length === 0\" [title]=\"'Parece que no aún no tienes ningún ticket abierto'\"></app-no-data>\n\n</ion-content>\n";

/***/ }),

/***/ 84270:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/profile/support/ticket-filter/ticket-filter.component.html?ngResource ***!
  \*********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Filtros</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss(true)\">\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-radio-group mode=\"md\" [(ngModel)]=\"ticketStatusFilter\">\n    <ion-list-header>\n      <ion-label>Filtrar tickets por estado:</ion-label>\n    </ion-list-header>\n    <ion-item>\n      <ion-label>Pendientes </ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"pending\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>En curso</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"in_progress\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Finalizados</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"finished\"></ion-radio>\n    </ion-item>\n    <hr>\n    <ion-item>\n      <ion-label>Todos</ion-label>\n      <ion-radio slot=\"start\" color=\"dark\" value=\"all\"></ion-radio>\n    </ion-item>\n  </ion-radio-group>\n\n\n</ion-content>\n<ion-footer>\n  <ion-button (click)=\"dismiss(false)\" color=\"dark\" class=\"apply-button\" expand=\"block\" mode=\"ios\" >\n    Aplicar filtros\n  </ion-button>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_support_support_module_ts.js.map