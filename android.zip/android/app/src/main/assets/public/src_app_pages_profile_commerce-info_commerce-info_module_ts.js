"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_commerce-info_commerce-info_module_ts"],{

/***/ 12248:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-info-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceInfoPageRoutingModule": () => (/* binding */ CommerceInfoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _commerce_info_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commerce-info.page */ 67375);




const routes = [
    {
        path: '',
        component: _commerce_info_page__WEBPACK_IMPORTED_MODULE_0__.CommerceInfoPage
    },
    {
        path: 'admin-employee',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_admin-employee_admin-employee_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../admin-employee/admin-employee.module */ 17793)).then(m => m.AdminEmployeePageModule)
    },
    {
        path: 'payment-methods',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_commerce-info_payment-methods_payment-methods_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./payment-methods/payment-methods.module */ 15364)).then(m => m.PaymentMethodsPageModule)
    },
    {
        path: 'subscription',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_commerce-info_subscription_subscription_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./subscription/subscription.module */ 68916)).then(m => m.SubscriptionPageModule)
    },
    {
        path: 'commerce-data',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_format_index_js-node_modules_date-fns_esm_startOfWeek_index_js"), __webpack_require__.e("default-src_app_core_transformers_timeTable_transformer_ts-src_app_core_utils_date_service_ts"), __webpack_require__.e("src_app_pages_profile_commerce-info_commerce-data_commerce-data_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./commerce-data/commerce-data.module */ 48820)).then(m => m.CommerceDataPageModule)
    },
    {
        path: 'reviews',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_profile_commerce-info_reviews_reviews_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./reviews/reviews.module */ 34022)).then(m => m.ReviewsPageModule)
    },
];
let CommerceInfoPageRoutingModule = class CommerceInfoPageRoutingModule {
};
CommerceInfoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CommerceInfoPageRoutingModule);



/***/ }),

/***/ 98580:
/*!*********************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-info.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceInfoPageModule": () => (/* binding */ CommerceInfoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _commerce_info_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commerce-info-routing.module */ 12248);
/* harmony import */ var _commerce_info_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./commerce-info.page */ 67375);








let CommerceInfoPageModule = class CommerceInfoPageModule {
};
CommerceInfoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _commerce_info_routing_module__WEBPACK_IMPORTED_MODULE_1__.CommerceInfoPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_0__.HeaderModule
        ],
        declarations: [_commerce_info_page__WEBPACK_IMPORTED_MODULE_2__.CommerceInfoPage]
    })
], CommerceInfoPageModule);



/***/ }),

/***/ 67375:
/*!*******************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-info.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceInfoPage": () => (/* binding */ CommerceInfoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _commerce_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./commerce-info.page.html?ngResource */ 1583);
/* harmony import */ var _commerce_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./commerce-info.page.scss?ngResource */ 90736);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);





let CommerceInfoPage = class CommerceInfoPage {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.options = [
            {
                name: 'Datos del negocio',
                icon: 'storefront-outline',
                description: 'Gestiona los datos básicos de tu negocio',
                path: 'commerce-data',
                roles: ['gerente']
            },
            {
                name: 'Gestionar empleados',
                icon: 'people-outline',
                description: 'Podrás ver y gestionar a tus empleados, así como especificar su horario',
                path: 'admin-employee',
                roles: ['gerente']
            },
            {
                name: 'Comentarios del comercio',
                icon: 'chatbubbles-outline',
                description: 'Gestiona las reseñas de tu comercio',
                path: 'reviews',
                roles: ['recepcionista', 'gerente']
            },
            {
                name: 'Suscripción y facturación',
                icon: 'cash-outline',
                description: 'Consulta tu suscripción y método de pago',
                path: 'subscription',
                roles: ['gerente']
            },
            {
                name: 'Métodos de pago',
                icon: 'wallet-outline',
                description: 'Gestiona los métodos de pago que ofreces en tu negocio',
                path: 'payment-methods',
                roles: ['gerente']
            },
            /*  {
               name: 'Cambiar negocio',
               icon: 'repeat-outline',
               description: 'Cambia tu perfil de Yeasy entre tus distintos negocios',
               path: 'faq',
               roles: ['gerente']
             }, */
            /*  {
               name: 'Redes Sociales',
               icon: 'share-social-outline',
               description: 'Gestiona las redes sociales que utilizas en Yeasy',
               path: 'rrss',
               roles: ['empleado', 'recepcionista', 'gerente']
             } */
        ];
        this.optionsFiltered = [];
        this.optionsFiltered = this.options;
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }
    ngOnInit() {
    }
    goTo(path) {
        this.navCtrl.navigateForward([`tabs/profile/commerce-info/${path}`]);
    }
};
CommerceInfoPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
CommerceInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-commerce-info',
        template: _commerce_info_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_commerce_info_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CommerceInfoPage);



/***/ }),

/***/ 90736:
/*!********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-info.page.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = "h2 {\n  margin: 0;\n}\n\n.icon-option {\n  margin-top: -25px;\n  margin-right: 10px;\n}\n\n.no-shadow {\n  box-shadow: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1lcmNlLWluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBQTtBQUNGOztBQUdBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUFGOztBQUdBO0VBQ0UsZ0JBQUE7QUFBRiIsImZpbGUiOiJjb21tZXJjZS1pbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImgyIHtcbiAgbWFyZ2luOiAwO1xufVxuXG5cbi5pY29uLW9wdGlvbiB7XG4gIG1hcmdpbi10b3A6IC0yNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5uby1zaGFkb3cge1xuICBib3gtc2hhZG93OiBub25lO1xufVxuIl19 */";

/***/ }),

/***/ 1583:
/*!********************************************************************************!*\
  !*** ./src/app/pages/profile/commerce-info/commerce-info.page.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Información del negocio'\"></app-header>\n\n<ion-content>\n  <ion-list>\n    <ng-container *ngFor=\"let item of optionsFiltered\">\n      <ion-item class=\"textbox\" (click)=\"goTo(item.path)\">\n        <ion-icon [name]=\"item.icon\" class=\"icon-option\"></ion-icon>\n        <ion-label class=\"ion-text-wrap\">\n          <h2>{{item.name}}</h2>\n          <p>{{item.description}}</p>\n        </ion-label>\n        <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n      </ion-item>\n    </ng-container>\n  </ion-list>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_commerce-info_commerce-info_module_ts.js.map