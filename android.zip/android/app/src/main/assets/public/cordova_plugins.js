
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-screen-orientation.screenorientation",
          "file": "plugins/cordova-plugin-screen-orientation/www/screenorientation.js",
          "pluginId": "cordova-plugin-screen-orientation",
        "clobbers": [
          "cordova.plugins.screenorientation"
        ]
        },
      {
          "id": "onesignal-cordova-plugin.OneSignalPlugin",
          "file": "plugins/onesignal-cordova-plugin/www/OneSignalPlugin.js",
          "pluginId": "onesignal-cordova-plugin",
        "clobbers": [
          "OneSignal"
        ]
        },
      {
          "id": "cordova-plugin-native-spinner.SpinnerDialog",
          "file": "plugins/cordova-plugin-native-spinner/www/SpinnerDialog.js",
          "pluginId": "cordova-plugin-native-spinner",
        "clobbers": [
          "SpinnerDialog"
        ]
        },
      {
          "id": "es6-promise-plugin.Promise",
          "file": "plugins/es6-promise-plugin/www/promise.js",
          "pluginId": "es6-promise-plugin",
        "runs": true
        },
      {
          "id": "onesignal-cordova-plugin.NotificationReceived",
          "file": "plugins/onesignal-cordova-plugin/www/NotificationReceived.js",
          "pluginId": "onesignal-cordova-plugin"
        },
      {
          "id": "onesignal-cordova-plugin.NotificationOpened",
          "file": "plugins/onesignal-cordova-plugin/www/NotificationOpened.js",
          "pluginId": "onesignal-cordova-plugin"
        },
      {
          "id": "onesignal-cordova-plugin.InAppMessage",
          "file": "plugins/onesignal-cordova-plugin/www/InAppMessage.js",
          "pluginId": "onesignal-cordova-plugin"
        },
      {
          "id": "onesignal-cordova-plugin.Subscription",
          "file": "plugins/onesignal-cordova-plugin/www/Subscription.js",
          "pluginId": "onesignal-cordova-plugin"
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-native-spinner": "1.1.4",
      "cordova-plugin-screen-orientation": "3.0.2",
      "es6-promise-plugin": "4.2.2",
      "onesignal-cordova-plugin": "3.0.4"
    };
    // BOTTOM OF METADATA
    });
    