"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_booking-manager_booking-manager_module_ts"],{

/***/ 27269:
/*!*************************************************************************************!*\
  !*** ./node_modules/angular2-draggable/__ivy_ngcc__/fesm2015/angular2-draggable.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AngularDraggableDirective": () => (/* binding */ AngularDraggableDirective),
/* harmony export */   "AngularDraggableModule": () => (/* binding */ AngularDraggableModule),
/* harmony export */   "AngularResizableDirective": () => (/* binding */ AngularResizableDirective),
/* harmony export */   "Position": () => (/* binding */ Position)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 15810);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 51109);



/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

class Position {
    /**
     * @param {?} x
     * @param {?} y
     */
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    /**
     * @param {?} e
     * @param {?=} el
     * @return {?}
     */
    static fromEvent(e, el = null) {
        /**
         * Fix issue: Resize doesn't work on Windows10 IE11 (and on some windows 7 IE11)
         * https://github.com/xieziyu/angular2-draggable/issues/164
         * e instanceof MouseEvent check returns false on IE11
         */
        if (this.isMouseEvent(e)) {
            return new Position(e.clientX, e.clientY);
        }
        else {
            if (el === null || e.changedTouches.length === 1) {
                return new Position(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
            }
            /**
             * Fix issue: Multiple phone draggables at the same time
             * https://github.com/xieziyu/angular2-draggable/issues/128
             */
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].target === el) {
                    return new Position(e.changedTouches[i].clientX, e.changedTouches[i].clientY);
                }
            }
        }
    }
    /**
     * @param {?} e
     * @return {?}
     */
    static isMouseEvent(e) {
        return Object.prototype.toString.apply(e).indexOf('MouseEvent') === 8;
    }
    /**
     * @param {?} obj
     * @return {?}
     */
    static isIPosition(obj) {
        return !!obj && ('x' in obj) && ('y' in obj);
    }
    /**
     * @param {?} el
     * @return {?}
     */
    static getCurrent(el) {
        /** @type {?} */
        let pos = new Position(0, 0);
        if (window) {
            /** @type {?} */
            const computed = window.getComputedStyle(el);
            if (computed) {
                /** @type {?} */
                let x = parseInt(computed.getPropertyValue('left'), 10);
                /** @type {?} */
                let y = parseInt(computed.getPropertyValue('top'), 10);
                pos.x = isNaN(x) ? 0 : x;
                pos.y = isNaN(y) ? 0 : y;
            }
            return pos;
        }
        else {
            console.error('Not Supported!');
            return null;
        }
    }
    /**
     * @param {?} p
     * @return {?}
     */
    static copy(p) {
        return new Position(0, 0).set(p);
    }
    /**
     * @return {?}
     */
    get value() {
        return { x: this.x, y: this.y };
    }
    /**
     * @template THIS
     * @this {THIS}
     * @param {?} p
     * @return {THIS}
     */
    add(p) {
        (/** @type {?} */ (this)).x += p.x;
        (/** @type {?} */ (this)).y += p.y;
        return (/** @type {?} */ (this));
    }
    /**
     * @template THIS
     * @this {THIS}
     * @param {?} p
     * @return {THIS}
     */
    subtract(p) {
        (/** @type {?} */ (this)).x -= p.x;
        (/** @type {?} */ (this)).y -= p.y;
        return (/** @type {?} */ (this));
    }
    /**
     * @param {?} n
     * @return {?}
     */
    multiply(n) {
        this.x *= n;
        this.y *= n;
    }
    /**
     * @param {?} n
     * @return {?}
     */
    divide(n) {
        this.x /= n;
        this.y /= n;
    }
    /**
     * @template THIS
     * @this {THIS}
     * @return {THIS}
     */
    reset() {
        (/** @type {?} */ (this)).x = 0;
        (/** @type {?} */ (this)).y = 0;
        return (/** @type {?} */ (this));
    }
    /**
     * @template THIS
     * @this {THIS}
     * @param {?} p
     * @return {THIS}
     */
    set(p) {
        (/** @type {?} */ (this)).x = p.x;
        (/** @type {?} */ (this)).y = p.y;
        return (/** @type {?} */ (this));
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class HelperBlock {
    /**
     * @param {?} parent
     * @param {?} renderer
     */
    constructor(parent, renderer) {
        this.parent = parent;
        this.renderer = renderer;
        this._added = false;
        // generate helper div
        /** @type {?} */
        let helper = renderer.createElement('div');
        renderer.setStyle(helper, 'position', 'absolute');
        renderer.setStyle(helper, 'width', '100%');
        renderer.setStyle(helper, 'height', '100%');
        renderer.setStyle(helper, 'background-color', 'transparent');
        renderer.setStyle(helper, 'top', '0');
        renderer.setStyle(helper, 'left', '0');
        // done
        this._helper = helper;
    }
    /**
     * @return {?}
     */
    add() {
        // append div to parent
        if (this.parent && !this._added) {
            this.parent.appendChild(this._helper);
            this._added = true;
        }
    }
    /**
     * @return {?}
     */
    remove() {
        if (this.parent && this._added) {
            this.parent.removeChild(this._helper);
            this._added = false;
        }
    }
    /**
     * @return {?}
     */
    dispose() {
        this._helper = null;
        this._added = false;
    }
    /**
     * @return {?}
     */
    get el() {
        return this._helper;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class AngularDraggableDirective {
    /**
     * @param {?} el
     * @param {?} renderer
     */
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.allowDrag = true;
        this.moving = false;
        this.orignal = null;
        this.oldTrans = new Position(0, 0);
        this.tempTrans = new Position(0, 0);
        this.currTrans = new Position(0, 0);
        this.oldZIndex = '';
        this._zIndex = '';
        this.needTransform = false;
        this.draggingSub = null;
        /**
         * Bugfix: iFrames, and context unrelated elements block all events, and are unusable
         * https://github.com/xieziyu/angular2-draggable/issues/84
         */
        this._helperBlock = null;
        this.started = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.stopped = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.edge = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        /**
         * List of allowed out of bounds edges *
         */
        this.outOfBounds = {
            top: false,
            right: false,
            bottom: false,
            left: false
        };
        /**
         * Round the position to nearest grid
         */
        this.gridSize = 1;
        /**
         * Whether to limit the element stay in the bounds
         */
        this.inBounds = false;
        /**
         * Whether the element should use it's previous drag position on a new drag event.
         */
        this.trackPosition = true;
        /**
         * Input css scale transform of element so translations are correct
         */
        this.scale = 1;
        /**
         * Whether to prevent default event
         */
        this.preventDefaultEvent = false;
        /**
         * Set initial position by offsets
         */
        this.position = { x: 0, y: 0 };
        /**
         * Lock axis: 'x' or 'y'
         */
        this.lockAxis = null;
        /**
         * Emit position offsets when moving
         */
        this.movingOffset = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        /**
         * Emit position offsets when put back
         */
        this.endOffset = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this._helperBlock = new HelperBlock(el.nativeElement, renderer);
    }
    /**
     * Set z-index when not dragging
     * @param {?} setting
     * @return {?}
     */
    set zIndex(setting) {
        this.renderer.setStyle(this.el.nativeElement, 'z-index', setting);
        this._zIndex = setting;
    }
    /**
     * @param {?} setting
     * @return {?}
     */
    set ngDraggable(setting) {
        if (setting !== undefined && setting !== null && setting !== '') {
            this.allowDrag = !!setting;
            /** @type {?} */
            let element = this.getDragEl();
            if (this.allowDrag) {
                this.renderer.addClass(element, 'ng-draggable');
            }
            else {
                this.putBack();
                this.renderer.removeClass(element, 'ng-draggable');
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (this.allowDrag) {
            /** @type {?} */
            let element = this.getDragEl();
            this.renderer.addClass(element, 'ng-draggable');
        }
        this.resetPosition();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.bounds = null;
        this.handle = null;
        this.orignal = null;
        this.oldTrans = null;
        this.tempTrans = null;
        this.currTrans = null;
        this._helperBlock.dispose();
        this._helperBlock = null;
        if (this.draggingSub) {
            this.draggingSub.unsubscribe();
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['position'] && !changes['position'].isFirstChange()) {
            /** @type {?} */
            let p = changes['position'].currentValue;
            if (!this.moving) {
                if (Position.isIPosition(p)) {
                    this.oldTrans.set(p);
                }
                else {
                    this.oldTrans.reset();
                }
                this.transform();
            }
            else {
                this.needTransform = true;
            }
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        if (this.inBounds) {
            this.boundsCheck();
            this.oldTrans.add(this.tempTrans);
            this.tempTrans.reset();
        }
    }
    /**
     * @private
     * @return {?}
     */
    getDragEl() {
        return this.handle ? this.handle : this.el.nativeElement;
    }
    /**
     * @return {?}
     */
    resetPosition() {
        if (Position.isIPosition(this.position)) {
            this.oldTrans.set(this.position);
        }
        else {
            this.oldTrans.reset();
        }
        this.tempTrans.reset();
        this.transform();
    }
    /**
     * @private
     * @param {?} p
     * @return {?}
     */
    moveTo(p) {
        if (this.orignal) {
            p.subtract(this.orignal);
            this.tempTrans.set(p);
            this.tempTrans.divide(this.scale);
            this.transform();
            if (this.bounds) {
                this.edge.emit(this.boundsCheck());
            }
            this.movingOffset.emit(this.currTrans.value);
        }
    }
    /**
     * @private
     * @return {?}
     */
    transform() {
        /** @type {?} */
        let translateX = this.tempTrans.x + this.oldTrans.x;
        /** @type {?} */
        let translateY = this.tempTrans.y + this.oldTrans.y;
        if (this.lockAxis === 'x') {
            translateX = this.oldTrans.x;
            this.tempTrans.x = 0;
        }
        else if (this.lockAxis === 'y') {
            translateY = this.oldTrans.y;
            this.tempTrans.y = 0;
        }
        // Snap to grid: by grid size
        if (this.gridSize > 1) {
            translateX = Math.round(translateX / this.gridSize) * this.gridSize;
            translateY = Math.round(translateY / this.gridSize) * this.gridSize;
        }
        /** @type {?} */
        let value = `translate(${Math.round(translateX)}px, ${Math.round(translateY)}px)`;
        this.renderer.setStyle(this.el.nativeElement, 'transform', value);
        this.renderer.setStyle(this.el.nativeElement, '-webkit-transform', value);
        this.renderer.setStyle(this.el.nativeElement, '-ms-transform', value);
        this.renderer.setStyle(this.el.nativeElement, '-moz-transform', value);
        this.renderer.setStyle(this.el.nativeElement, '-o-transform', value);
        // save current position
        this.currTrans.x = translateX;
        this.currTrans.y = translateY;
    }
    /**
     * @private
     * @return {?}
     */
    pickUp() {
        // get old z-index:
        this.oldZIndex = this.el.nativeElement.style.zIndex ? this.el.nativeElement.style.zIndex : '';
        if (window) {
            this.oldZIndex = window.getComputedStyle(this.el.nativeElement, null).getPropertyValue('z-index');
        }
        if (this.zIndexMoving) {
            this.renderer.setStyle(this.el.nativeElement, 'z-index', this.zIndexMoving);
        }
        if (!this.moving) {
            this.started.emit(this.el.nativeElement);
            this.moving = true;
            /** @type {?} */
            const element = this.getDragEl();
            this.renderer.addClass(element, 'ng-dragging');
            /**
             * Fix performance issue:
             * https://github.com/xieziyu/angular2-draggable/issues/112
             */
            this.subscribeEvents();
        }
    }
    /**
     * @private
     * @return {?}
     */
    subscribeEvents() {
        this.draggingSub = (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mousemove', { passive: false }).subscribe(event => this.onMouseMove((/** @type {?} */ (event))));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchmove', { passive: false }).subscribe(event => this.onMouseMove((/** @type {?} */ (event)))));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mouseup', { passive: false }).subscribe(() => this.putBack()));
        // checking if browser is IE or Edge - https://github.com/xieziyu/angular2-draggable/issues/153
        /** @type {?} */
        let isIEOrEdge = /msie\s|trident\//i.test(window.navigator.userAgent);
        if (!isIEOrEdge) {
            this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mouseleave', { passive: false }).subscribe(() => this.putBack()));
        }
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchend', { passive: false }).subscribe(() => this.putBack()));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchcancel', { passive: false }).subscribe(() => this.putBack()));
    }
    /**
     * @private
     * @return {?}
     */
    unsubscribeEvents() {
        this.draggingSub.unsubscribe();
        this.draggingSub = null;
    }
    /**
     * @return {?}
     */
    boundsCheck() {
        if (this.bounds) {
            /** @type {?} */
            let boundary = this.bounds.getBoundingClientRect();
            /** @type {?} */
            let elem = this.el.nativeElement.getBoundingClientRect();
            /** @type {?} */
            let result = {
                'top': this.outOfBounds.top ? true : boundary.top < elem.top,
                'right': this.outOfBounds.right ? true : boundary.right > elem.right,
                'bottom': this.outOfBounds.bottom ? true : boundary.bottom > elem.bottom,
                'left': this.outOfBounds.left ? true : boundary.left < elem.left
            };
            if (this.inBounds) {
                if (!result.top) {
                    this.tempTrans.y -= (elem.top - boundary.top) / this.scale;
                }
                if (!result.bottom) {
                    this.tempTrans.y -= (elem.bottom - boundary.bottom) / this.scale;
                }
                if (!result.right) {
                    this.tempTrans.x -= (elem.right - boundary.right) / this.scale;
                }
                if (!result.left) {
                    this.tempTrans.x -= (elem.left - boundary.left) / this.scale;
                }
                this.transform();
            }
            return result;
        }
    }
    /**
     * Get current offset
     * @return {?}
     */
    getCurrentOffset() {
        return this.currTrans.value;
    }
    /**
     * @private
     * @return {?}
     */
    putBack() {
        if (this._zIndex) {
            this.renderer.setStyle(this.el.nativeElement, 'z-index', this._zIndex);
        }
        else if (this.zIndexMoving) {
            if (this.oldZIndex) {
                this.renderer.setStyle(this.el.nativeElement, 'z-index', this.oldZIndex);
            }
            else {
                this.el.nativeElement.style.removeProperty('z-index');
            }
        }
        if (this.moving) {
            this.stopped.emit(this.el.nativeElement);
            // Remove the helper div:
            this._helperBlock.remove();
            if (this.needTransform) {
                if (Position.isIPosition(this.position)) {
                    this.oldTrans.set(this.position);
                }
                else {
                    this.oldTrans.reset();
                }
                this.transform();
                this.needTransform = false;
            }
            if (this.bounds) {
                this.edge.emit(this.boundsCheck());
            }
            this.moving = false;
            this.endOffset.emit(this.currTrans.value);
            if (this.trackPosition) {
                this.oldTrans.add(this.tempTrans);
            }
            this.tempTrans.reset();
            if (!this.trackPosition) {
                this.transform();
            }
            /** @type {?} */
            const element = this.getDragEl();
            this.renderer.removeClass(element, 'ng-dragging');
            /**
             * Fix performance issue:
             * https://github.com/xieziyu/angular2-draggable/issues/112
             */
            this.unsubscribeEvents();
        }
    }
    /**
     * @param {?} target
     * @param {?} element
     * @return {?}
     */
    checkHandleTarget(target, element) {
        // Checks if the target is the element clicked, then checks each child element of element as well
        // Ignores button clicks
        // Ignore elements of type button
        if (element.tagName === 'BUTTON') {
            return false;
        }
        // If the target was found, return true (handle was found)
        if (element === target) {
            return true;
        }
        // Recursively iterate this elements children
        for (let child in element.children) {
            if (element.children.hasOwnProperty(child)) {
                if (this.checkHandleTarget(target, element.children[child])) {
                    return true;
                }
            }
        }
        // Handle was not found in this lineage
        // Note: return false is ignore unless it is the parent element
        return false;
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onMouseDown(event) {
        // 1. skip right click;
        if (event instanceof MouseEvent && event.button === 2) {
            return;
        }
        // 2. if handle is set, the element can only be moved by handle
        /** @type {?} */
        let target = event.target || event.srcElement;
        if (this.handle !== undefined && !this.checkHandleTarget(target, this.handle)) {
            return;
        }
        // 3. if allow drag is set to false, ignore the mousedown
        if (this.allowDrag === false) {
            return;
        }
        if (this.preventDefaultEvent) {
            event.stopPropagation();
            event.preventDefault();
        }
        this.orignal = Position.fromEvent(event, this.getDragEl());
        this.pickUp();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onMouseMove(event) {
        if (this.moving && this.allowDrag) {
            if (this.preventDefaultEvent) {
                event.stopPropagation();
                event.preventDefault();
            }
            // Add a transparent helper div:
            this._helperBlock.add();
            this.moveTo(Position.fromEvent(event, this.getDragEl()));
        }
    }
}
AngularDraggableDirective.ɵfac = function AngularDraggableDirective_Factory(t) { return new (t || AngularDraggableDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2)); };
AngularDraggableDirective.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: AngularDraggableDirective, selectors: [["", "ngDraggable", ""]], hostBindings: function AngularDraggableDirective_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mousedown", function AngularDraggableDirective_mousedown_HostBindingHandler($event) { return ctx.onMouseDown($event); })("touchstart", function AngularDraggableDirective_touchstart_HostBindingHandler($event) { return ctx.onMouseDown($event); });
    } }, inputs: { outOfBounds: "outOfBounds", gridSize: "gridSize", inBounds: "inBounds", trackPosition: "trackPosition", scale: "scale", preventDefaultEvent: "preventDefaultEvent", position: "position", lockAxis: "lockAxis", zIndex: "zIndex", ngDraggable: "ngDraggable", bounds: "bounds", handle: "handle", zIndexMoving: "zIndexMoving" }, outputs: { started: "started", stopped: "stopped", edge: "edge", movingOffset: "movingOffset", endOffset: "endOffset" }, exportAs: ["ngDraggable"], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]] });
/** @nocollapse */
AngularDraggableDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2 }
];
AngularDraggableDirective.propDecorators = {
    started: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    stopped: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    edge: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    handle: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    bounds: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    outOfBounds: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    gridSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    zIndexMoving: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    zIndex: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    inBounds: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    trackPosition: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    scale: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    preventDefaultEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    position: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    lockAxis: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    movingOffset: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    endOffset: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    ngDraggable: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    onMouseDown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener, args: ['mousedown', ['$event'],] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener, args: ['touchstart', ['$event'],] }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AngularDraggableDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
        args: [{
                selector: '[ngDraggable]',
                exportAs: 'ngDraggable'
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2 }]; }, { started: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], stopped: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], edge: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], outOfBounds: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], gridSize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], inBounds: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], trackPosition: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], scale: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], preventDefaultEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], position: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], lockAxis: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], movingOffset: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], endOffset: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], zIndex: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], ngDraggable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], bounds: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], handle: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], 
    /**
     * @param {?} event
     * @return {?}
     */
    onMouseDown: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener,
            args: ['mousedown', ['$event']]
        }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener,
            args: ['touchstart', ['$event']]
        }], zIndexMoving: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }] }); })();

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ResizeHandle {
    /**
     * @param {?} parent
     * @param {?} renderer
     * @param {?} type
     * @param {?} css
     * @param {?} onMouseDown
     */
    constructor(parent, renderer, type, css, onMouseDown) {
        this.parent = parent;
        this.renderer = renderer;
        this.type = type;
        this.css = css;
        this.onMouseDown = onMouseDown;
        // generate handle div
        /** @type {?} */
        let handle = renderer.createElement('div');
        renderer.addClass(handle, 'ng-resizable-handle');
        renderer.addClass(handle, css);
        // add default diagonal for se handle
        if (type === 'se') {
            renderer.addClass(handle, 'ng-resizable-diagonal');
        }
        // append div to parent
        if (this.parent) {
            parent.appendChild(handle);
        }
        // create and register event listener
        this._onResize = (event) => { onMouseDown(event, this); };
        handle.addEventListener('mousedown', this._onResize, { passive: false });
        handle.addEventListener('touchstart', this._onResize, { passive: false });
        // done
        this._handle = handle;
    }
    /**
     * @return {?}
     */
    dispose() {
        this._handle.removeEventListener('mousedown', this._onResize);
        this._handle.removeEventListener('touchstart', this._onResize);
        if (this.parent) {
            this.parent.removeChild(this._handle);
        }
        this._handle = null;
        this._onResize = null;
    }
    /**
     * @return {?}
     */
    get el() {
        return this._handle;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class Size {
    /**
     * @param {?} width
     * @param {?} height
     */
    constructor(width, height) {
        this.width = width;
        this.height = height;
    }
    /**
     * @param {?} el
     * @return {?}
     */
    static getCurrent(el) {
        /** @type {?} */
        let size = new Size(0, 0);
        if (window) {
            /** @type {?} */
            const computed = window.getComputedStyle(el);
            if (computed) {
                size.width = parseInt(computed.getPropertyValue('width'), 10);
                size.height = parseInt(computed.getPropertyValue('height'), 10);
            }
            return size;
        }
        else {
            console.error('Not Supported!');
            return null;
        }
    }
    /**
     * @param {?} s
     * @return {?}
     */
    static copy(s) {
        return new Size(0, 0).set(s);
    }
    /**
     * @template THIS
     * @this {THIS}
     * @param {?} s
     * @return {THIS}
     */
    set(s) {
        (/** @type {?} */ (this)).width = s.width;
        (/** @type {?} */ (this)).height = s.height;
        return (/** @type {?} */ (this));
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class AngularResizableDirective {
    /**
     * @param {?} el
     * @param {?} renderer
     */
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this._resizable = true;
        this._handles = {};
        this._handleType = [];
        this._handleResizing = null;
        this._direction = null;
        this._directionChanged = null;
        this._aspectRatio = 0;
        this._containment = null;
        this._origMousePos = null;
        /**
         * Original Size and Position
         */
        this._origSize = null;
        this._origPos = null;
        /**
         * Current Size and Position
         */
        this._currSize = null;
        this._currPos = null;
        /**
         * Initial Size and Position
         */
        this._initSize = null;
        this._initPos = null;
        /**
         * Snap to gird
         */
        this._gridSize = null;
        this._bounding = null;
        /**
         * Bugfix: iFrames, and context unrelated elements block all events, and are unusable
         * https://github.com/xieziyu/angular2-draggable/issues/84
         */
        this._helperBlock = null;
        this.draggingSub = null;
        this._adjusted = false;
        /**
         * Which handles can be used for resizing.
         * \@example
         * [rzHandles] = "'n,e,s,w,se,ne,sw,nw'"
         * equals to: [rzHandles] = "'all'"
         *
         *
         */
        this.rzHandles = 'e,s,se';
        /**
         * Whether the element should be constrained to a specific aspect ratio.
         *  Multiple types supported:
         *  boolean: When set to true, the element will maintain its original aspect ratio.
         *  number: Force the element to maintain a specific aspect ratio during resizing.
         */
        this.rzAspectRatio = false;
        /**
         * Constrains resizing to within the bounds of the specified element or region.
         *  Multiple types supported:
         *  Selector: The resizable element will be contained to the bounding box of the first element found by the selector.
         *            If no element is found, no containment will be set.
         *  Element: The resizable element will be contained to the bounding box of this element.
         *  String: Possible values: "parent".
         */
        this.rzContainment = null;
        /**
         * Snaps the resizing element to a grid, every x and y pixels.
         * A number for both width and height or an array values like [ x, y ]
         */
        this.rzGrid = null;
        /**
         * The minimum width the resizable should be allowed to resize to.
         */
        this.rzMinWidth = null;
        /**
         * The minimum height the resizable should be allowed to resize to.
         */
        this.rzMinHeight = null;
        /**
         * The maximum width the resizable should be allowed to resize to.
         */
        this.rzMaxWidth = null;
        /**
         * The maximum height the resizable should be allowed to resize to.
         */
        this.rzMaxHeight = null;
        /**
         * Whether to prevent default event
         */
        this.preventDefaultEvent = true;
        /**
         * emitted when start resizing
         */
        this.rzStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        /**
         * emitted when start resizing
         */
        this.rzResizing = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        /**
         * emitted when stop resizing
         */
        this.rzStop = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this._helperBlock = new HelperBlock(el.nativeElement, renderer);
    }
    /**
     * Disables the resizable if set to false.
     * @param {?} v
     * @return {?}
     */
    set ngResizable(v) {
        if (v !== undefined && v !== null && v !== '') {
            this._resizable = !!v;
            this.updateResizable();
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['rzHandles'] && !changes['rzHandles'].isFirstChange()) {
            this.updateResizable();
        }
        if (changes['rzAspectRatio'] && !changes['rzAspectRatio'].isFirstChange()) {
            this.updateAspectRatio();
        }
        if (changes['rzContainment'] && !changes['rzContainment'].isFirstChange()) {
            this.updateContainment();
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.updateResizable();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.removeHandles();
        this._containment = null;
        this._helperBlock.dispose();
        this._helperBlock = null;
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const elm = this.el.nativeElement;
        this._initSize = Size.getCurrent(elm);
        this._initPos = Position.getCurrent(elm);
        this._currSize = Size.copy(this._initSize);
        this._currPos = Position.copy(this._initPos);
        this.updateAspectRatio();
        this.updateContainment();
    }
    /**
     * A method to reset size
     * @return {?}
     */
    resetSize() {
        this._currSize = Size.copy(this._initSize);
        this._currPos = Position.copy(this._initPos);
        this.doResize();
    }
    /**
     * A method to get current status
     * @return {?}
     */
    getStatus() {
        if (!this._currPos || !this._currSize) {
            return null;
        }
        return {
            size: {
                width: this._currSize.width,
                height: this._currSize.height
            },
            position: {
                top: this._currPos.y,
                left: this._currPos.x
            }
        };
    }
    /**
     * @private
     * @return {?}
     */
    updateResizable() {
        /** @type {?} */
        const element = this.el.nativeElement;
        // clear handles:
        this.renderer.removeClass(element, 'ng-resizable');
        this.removeHandles();
        // create new ones:
        if (this._resizable) {
            this.renderer.addClass(element, 'ng-resizable');
            this.createHandles();
        }
    }
    /**
     * Use it to update aspect
     * @private
     * @return {?}
     */
    updateAspectRatio() {
        if (typeof this.rzAspectRatio === 'boolean') {
            if (this.rzAspectRatio && this._currSize.height) {
                this._aspectRatio = (this._currSize.width / this._currSize.height);
            }
            else {
                this._aspectRatio = 0;
            }
        }
        else {
            /** @type {?} */
            let r = Number(this.rzAspectRatio);
            this._aspectRatio = isNaN(r) ? 0 : r;
        }
    }
    /**
     * Use it to update containment
     * @private
     * @return {?}
     */
    updateContainment() {
        if (!this.rzContainment) {
            this._containment = null;
            return;
        }
        if (typeof this.rzContainment === 'string') {
            if (this.rzContainment === 'parent') {
                this._containment = this.el.nativeElement.parentElement;
            }
            else {
                this._containment = document.querySelector(this.rzContainment);
            }
        }
        else {
            this._containment = this.rzContainment;
        }
    }
    /**
     * Use it to create handle divs
     * @private
     * @return {?}
     */
    createHandles() {
        if (!this.rzHandles) {
            return;
        }
        /** @type {?} */
        let tmpHandleTypes;
        if (typeof this.rzHandles === 'string') {
            if (this.rzHandles === 'all') {
                tmpHandleTypes = ['n', 'e', 's', 'w', 'ne', 'se', 'nw', 'sw'];
            }
            else {
                tmpHandleTypes = this.rzHandles.replace(/ /g, '').toLowerCase().split(',');
            }
            for (let type of tmpHandleTypes) {
                // default handle theme: ng-resizable-$type.
                /** @type {?} */
                let handle = this.createHandleByType(type, `ng-resizable-${type}`);
                if (handle) {
                    this._handleType.push(type);
                    this._handles[type] = handle;
                }
            }
        }
        else {
            tmpHandleTypes = Object.keys(this.rzHandles);
            for (let type of tmpHandleTypes) {
                // custom handle theme.
                /** @type {?} */
                let handle = this.createHandleByType(type, this.rzHandles[type]);
                if (handle) {
                    this._handleType.push(type);
                    this._handles[type] = handle;
                }
            }
        }
    }
    /**
     * Use it to create a handle
     * @private
     * @param {?} type
     * @param {?} css
     * @return {?}
     */
    createHandleByType(type, css) {
        /** @type {?} */
        const _el = this.el.nativeElement;
        if (!type.match(/^(se|sw|ne|nw|n|e|s|w)$/)) {
            console.error('Invalid handle type:', type);
            return null;
        }
        return new ResizeHandle(_el, this.renderer, type, css, this.onMouseDown.bind(this));
    }
    /**
     * @private
     * @return {?}
     */
    removeHandles() {
        for (let type of this._handleType) {
            this._handles[type].dispose();
        }
        this._handleType = [];
        this._handles = {};
    }
    /**
     * @param {?} event
     * @param {?} handle
     * @return {?}
     */
    onMouseDown(event, handle) {
        // skip right click;
        if (event instanceof MouseEvent && event.button === 2) {
            return;
        }
        if (this.preventDefaultEvent) {
            // prevent default events
            event.stopPropagation();
            event.preventDefault();
        }
        if (!this._handleResizing) {
            this._origMousePos = Position.fromEvent(event);
            this.startResize(handle);
            this.subscribeEvents();
        }
    }
    /**
     * @private
     * @return {?}
     */
    subscribeEvents() {
        this.draggingSub = (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mousemove', { passive: false }).subscribe(event => this.onMouseMove((/** @type {?} */ (event))));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchmove', { passive: false }).subscribe(event => this.onMouseMove((/** @type {?} */ (event)))));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mouseup', { passive: false }).subscribe(() => this.onMouseLeave()));
        // fix for issue #164
        /** @type {?} */
        let isIEOrEdge = /msie\s|trident\//i.test(window.navigator.userAgent);
        if (!isIEOrEdge) {
            this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'mouseleave', { passive: false }).subscribe(() => this.onMouseLeave()));
        }
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchend', { passive: false }).subscribe(() => this.onMouseLeave()));
        this.draggingSub.add((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.fromEvent)(document, 'touchcancel', { passive: false }).subscribe(() => this.onMouseLeave()));
    }
    /**
     * @private
     * @return {?}
     */
    unsubscribeEvents() {
        this.draggingSub.unsubscribe();
        this.draggingSub = null;
    }
    /**
     * @return {?}
     */
    onMouseLeave() {
        if (this._handleResizing) {
            this.stopResize();
            this._origMousePos = null;
            this.unsubscribeEvents();
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onMouseMove(event) {
        if (this._handleResizing && this._resizable && this._origMousePos && this._origPos && this._origSize) {
            this.resizeTo(Position.fromEvent(event));
            this.onResizing();
        }
    }
    /**
     * @private
     * @param {?} handle
     * @return {?}
     */
    startResize(handle) {
        /** @type {?} */
        const elm = this.el.nativeElement;
        this._origSize = Size.getCurrent(elm);
        this._origPos = Position.getCurrent(elm); // x: left, y: top
        this._currSize = Size.copy(this._origSize);
        this._currPos = Position.copy(this._origPos);
        if (this._containment) {
            this.getBounding();
        }
        this.getGridSize();
        // Add a transparent helper div:
        this._helperBlock.add();
        this._handleResizing = handle;
        this.updateDirection();
        this.rzStart.emit(this.getResizingEvent());
    }
    /**
     * @private
     * @return {?}
     */
    stopResize() {
        // Remove the helper div:
        this._helperBlock.remove();
        this.rzStop.emit(this.getResizingEvent());
        this._handleResizing = null;
        this._direction = null;
        this._origSize = null;
        this._origPos = null;
        if (this._containment) {
            this.resetBounding();
        }
    }
    /**
     * @private
     * @return {?}
     */
    onResizing() {
        this.rzResizing.emit(this.getResizingEvent());
    }
    /**
     * @private
     * @return {?}
     */
    getResizingEvent() {
        return {
            host: this.el.nativeElement,
            handle: this._handleResizing ? this._handleResizing.el : null,
            size: {
                width: this._currSize.width,
                height: this._currSize.height
            },
            position: {
                top: this._currPos.y,
                left: this._currPos.x
            },
            direction: Object.assign({}, this._directionChanged),
        };
    }
    /**
     * @private
     * @return {?}
     */
    updateDirection() {
        this._direction = {
            n: !!this._handleResizing.type.match(/n/),
            s: !!this._handleResizing.type.match(/s/),
            w: !!this._handleResizing.type.match(/w/),
            e: !!this._handleResizing.type.match(/e/)
        };
        this._directionChanged = Object.assign({}, this._direction);
        // if aspect ration should be preserved:
        if (this.rzAspectRatio) {
            // if north then west (unless ne)
            if (this._directionChanged.n && !this._directionChanged.e) {
                this._directionChanged.w = true;
            }
            // if south then east (unless sw)
            if (this._directionChanged.s && !this._directionChanged.w) {
                this._directionChanged.e = true;
            }
            // if east then south (unless ne)
            if (this._directionChanged.e && !this._directionChanged.n) {
                this._directionChanged.s = true;
            }
            // if west then south (unless nw)
            if (this._directionChanged.w && !this._directionChanged.n) {
                this._directionChanged.s = true;
            }
        }
    }
    /**
     * @private
     * @param {?} p
     * @return {?}
     */
    resizeTo(p) {
        p.subtract(this._origMousePos);
        /** @type {?} */
        const tmpX = Math.round(p.x / this._gridSize.x) * this._gridSize.x;
        /** @type {?} */
        const tmpY = Math.round(p.y / this._gridSize.y) * this._gridSize.y;
        if (this._direction.n) {
            // n, ne, nw
            this._currPos.y = this._origPos.y + tmpY;
            this._currSize.height = this._origSize.height - tmpY;
        }
        else if (this._direction.s) {
            // s, se, sw
            this._currSize.height = this._origSize.height + tmpY;
        }
        if (this._direction.e) {
            // e, ne, se
            this._currSize.width = this._origSize.width + tmpX;
        }
        else if (this._direction.w) {
            // w, nw, sw
            this._currSize.width = this._origSize.width - tmpX;
            this._currPos.x = this._origPos.x + tmpX;
        }
        this.checkBounds();
        this.checkSize();
        this.adjustByRatio();
        this.doResize();
    }
    /**
     * @private
     * @return {?}
     */
    doResize() {
        /** @type {?} */
        const container = this.el.nativeElement;
        if (!this._direction || this._direction.n || this._direction.s || this._aspectRatio) {
            this.renderer.setStyle(container, 'height', this._currSize.height + 'px');
        }
        if (!this._direction || this._direction.w || this._direction.e || this._aspectRatio) {
            this.renderer.setStyle(container, 'width', this._currSize.width + 'px');
        }
        this.renderer.setStyle(container, 'left', this._currPos.x + 'px');
        this.renderer.setStyle(container, 'top', this._currPos.y + 'px');
    }
    /**
     * @private
     * @return {?}
     */
    adjustByRatio() {
        if (this._aspectRatio && !this._adjusted) {
            if (this._direction.e || this._direction.w) {
                /** @type {?} */
                const newHeight = Math.floor(this._currSize.width / this._aspectRatio);
                if (this._direction.n) {
                    this._currPos.y += this._currSize.height - newHeight;
                }
                this._currSize.height = newHeight;
            }
            else {
                /** @type {?} */
                const newWidth = Math.floor(this._aspectRatio * this._currSize.height);
                if (this._direction.n) {
                    this._currPos.x += this._currSize.width - newWidth;
                }
                this._currSize.width = newWidth;
            }
        }
    }
    /**
     * @private
     * @return {?}
     */
    checkBounds() {
        if (this._containment) {
            /** @type {?} */
            const maxWidth = this._bounding.width - this._bounding.pr - this._bounding.deltaL - this._bounding.translateX - this._currPos.x;
            /** @type {?} */
            const maxHeight = this._bounding.height - this._bounding.pb - this._bounding.deltaT - this._bounding.translateY - this._currPos.y;
            if (this._direction.n && (this._currPos.y + this._bounding.translateY < 0)) {
                this._currPos.y = -this._bounding.translateY;
                this._currSize.height = this._origSize.height + this._origPos.y + this._bounding.translateY;
            }
            if (this._direction.w && (this._currPos.x + this._bounding.translateX) < 0) {
                this._currPos.x = -this._bounding.translateX;
                this._currSize.width = this._origSize.width + this._origPos.x + this._bounding.translateX;
            }
            if (this._currSize.width > maxWidth) {
                this._currSize.width = maxWidth;
            }
            if (this._currSize.height > maxHeight) {
                this._currSize.height = maxHeight;
            }
            /**
             * Fix Issue: Additional check for aspect ratio
             * https://github.com/xieziyu/angular2-draggable/issues/132
             */
            if (this._aspectRatio) {
                this._adjusted = false;
                if ((this._direction.w || this._direction.e) &&
                    (this._currSize.width / this._aspectRatio) >= maxHeight) {
                    /** @type {?} */
                    const newWidth = Math.floor(maxHeight * this._aspectRatio);
                    if (this._direction.w) {
                        this._currPos.x += this._currSize.width - newWidth;
                    }
                    this._currSize.width = newWidth;
                    this._currSize.height = maxHeight;
                    this._adjusted = true;
                }
                if ((this._direction.n || this._direction.s) &&
                    (this._currSize.height * this._aspectRatio) >= maxWidth) {
                    /** @type {?} */
                    const newHeight = Math.floor(maxWidth / this._aspectRatio);
                    if (this._direction.n) {
                        this._currPos.y += this._currSize.height - newHeight;
                    }
                    this._currSize.width = maxWidth;
                    this._currSize.height = newHeight;
                    this._adjusted = true;
                }
            }
        }
    }
    /**
     * @private
     * @return {?}
     */
    checkSize() {
        /** @type {?} */
        const minHeight = !this.rzMinHeight ? 1 : this.rzMinHeight;
        /** @type {?} */
        const minWidth = !this.rzMinWidth ? 1 : this.rzMinWidth;
        if (this._currSize.height < minHeight) {
            this._currSize.height = minHeight;
            if (this._direction.n) {
                this._currPos.y = this._origPos.y + (this._origSize.height - minHeight);
            }
        }
        if (this._currSize.width < minWidth) {
            this._currSize.width = minWidth;
            if (this._direction.w) {
                this._currPos.x = this._origPos.x + (this._origSize.width - minWidth);
            }
        }
        if (this.rzMaxHeight && this._currSize.height > this.rzMaxHeight) {
            this._currSize.height = this.rzMaxHeight;
            if (this._direction.n) {
                this._currPos.y = this._origPos.y + (this._origSize.height - this.rzMaxHeight);
            }
        }
        if (this.rzMaxWidth && this._currSize.width > this.rzMaxWidth) {
            this._currSize.width = this.rzMaxWidth;
            if (this._direction.w) {
                this._currPos.x = this._origPos.x + (this._origSize.width - this.rzMaxWidth);
            }
        }
    }
    /**
     * @private
     * @return {?}
     */
    getBounding() {
        /** @type {?} */
        const el = this._containment;
        /** @type {?} */
        const computed = window.getComputedStyle(el);
        if (computed) {
            /** @type {?} */
            let p = computed.getPropertyValue('position');
            /** @type {?} */
            const nativeEl = window.getComputedStyle(this.el.nativeElement);
            /** @type {?} */
            let transforms = nativeEl.getPropertyValue('transform').replace(/[^-\d,]/g, '').split(',');
            this._bounding = {};
            this._bounding.width = el.clientWidth;
            this._bounding.height = el.clientHeight;
            this._bounding.pr = parseInt(computed.getPropertyValue('padding-right'), 10);
            this._bounding.pb = parseInt(computed.getPropertyValue('padding-bottom'), 10);
            this._bounding.deltaL = this.el.nativeElement.offsetLeft - this._currPos.x;
            this._bounding.deltaT = this.el.nativeElement.offsetTop - this._currPos.y;
            if (transforms.length >= 6) {
                this._bounding.translateX = parseInt(transforms[4], 10);
                this._bounding.translateY = parseInt(transforms[5], 10);
            }
            else {
                this._bounding.translateX = 0;
                this._bounding.translateY = 0;
            }
            this._bounding.position = computed.getPropertyValue('position');
            if (p === 'static') {
                this.renderer.setStyle(el, 'position', 'relative');
            }
        }
    }
    /**
     * @private
     * @return {?}
     */
    resetBounding() {
        if (this._bounding && this._bounding.position === 'static') {
            this.renderer.setStyle(this._containment, 'position', 'relative');
        }
        this._bounding = null;
    }
    /**
     * @private
     * @return {?}
     */
    getGridSize() {
        // set default value:
        this._gridSize = { x: 1, y: 1 };
        if (this.rzGrid) {
            if (typeof this.rzGrid === 'number') {
                this._gridSize = { x: this.rzGrid, y: this.rzGrid };
            }
            else if (Array.isArray(this.rzGrid)) {
                this._gridSize = { x: this.rzGrid[0], y: this.rzGrid[1] };
            }
        }
    }
}
AngularResizableDirective.ɵfac = function AngularResizableDirective_Factory(t) { return new (t || AngularResizableDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2)); };
AngularResizableDirective.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: AngularResizableDirective, selectors: [["", "ngResizable", ""]], inputs: { rzHandles: "rzHandles", rzAspectRatio: "rzAspectRatio", rzContainment: "rzContainment", rzGrid: "rzGrid", rzMinWidth: "rzMinWidth", rzMinHeight: "rzMinHeight", rzMaxWidth: "rzMaxWidth", rzMaxHeight: "rzMaxHeight", preventDefaultEvent: "preventDefaultEvent", ngResizable: "ngResizable" }, outputs: { rzStart: "rzStart", rzResizing: "rzResizing", rzStop: "rzStop" }, exportAs: ["ngResizable"], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]] });
/** @nocollapse */
AngularResizableDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2 }
];
AngularResizableDirective.propDecorators = {
    ngResizable: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzHandles: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzAspectRatio: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzContainment: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzGrid: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzMinWidth: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzMinHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzMaxWidth: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzMaxHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    preventDefaultEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    rzStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    rzResizing: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    rzStop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }]
};
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AngularResizableDirective, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
        args: [{
                selector: '[ngResizable]',
                exportAs: 'ngResizable'
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2 }]; }, { rzHandles: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzAspectRatio: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzContainment: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzGrid: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzMinWidth: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzMinHeight: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzMaxWidth: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzMaxHeight: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], preventDefaultEvent: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }], rzStart: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], rzResizing: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], rzStop: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
        }], ngResizable: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
        }] }); })();

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class AngularDraggableModule {
}
AngularDraggableModule.ɵfac = function AngularDraggableModule_Factory(t) { return new (t || AngularDraggableModule)(); };
AngularDraggableModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AngularDraggableModule });
AngularDraggableModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [[]] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AngularDraggableModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
        args: [{
                imports: [],
                declarations: [
                    AngularDraggableDirective,
                    AngularResizableDirective
                ],
                exports: [
                    AngularDraggableDirective,
                    AngularResizableDirective
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AngularDraggableModule, { declarations: [AngularDraggableDirective, AngularResizableDirective], exports: [AngularDraggableDirective, AngularResizableDirective] }); })();

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */





/***/ }),

/***/ 29348:
/*!*****************************************************************!*\
  !*** ./node_modules/date-fns/esm/_lib/roundingMethods/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getRoundingMethod": () => (/* binding */ getRoundingMethod)
/* harmony export */ });
var roundingMap = {
  ceil: Math.ceil,
  round: Math.round,
  floor: Math.floor,
  trunc: function (value) {
    return value < 0 ? Math.ceil(value) : Math.floor(value);
  } // Math.trunc is not supported by IE

};
var defaultRoundingMethod = 'trunc';
function getRoundingMethod(method) {
  return method ? roundingMap[method] : roundingMap[defaultRoundingMethod];
}

/***/ }),

/***/ 5868:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/addDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addDays
 * @category Day Helpers
 * @summary Add the specified number of days to the given date.
 *
 * @description
 * Add the specified number of days to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} - the new date with the days added
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // Add 10 days to 1 September 2014:
 * const result = addDays(new Date(2014, 8, 1), 10)
 * //=> Thu Sep 11 2014 00:00:00
 */

function addDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyAmount);

  if (isNaN(amount)) {
    return new Date(NaN);
  }

  if (!amount) {
    // If 0 days, no-op to avoid changing times in the hour before end of DST
    return date;
  }

  date.setDate(date.getDate() + amount);
  return date;
}

/***/ }),

/***/ 97807:
/*!*******************************************************!*\
  !*** ./node_modules/date-fns/esm/addMinutes/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addMinutes)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addMilliseconds/index.js */ 78089);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



var MILLISECONDS_IN_MINUTE = 60000;
/**
 * @name addMinutes
 * @category Minute Helpers
 * @summary Add the specified number of minutes to the given date.
 *
 * @description
 * Add the specified number of minutes to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of minutes to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the minutes added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 30 minutes to 10 July 2014 12:00:00:
 * const result = addMinutes(new Date(2014, 6, 10, 12, 0), 30)
 * //=> Thu Jul 10 2014 12:30:00
 */

function addMinutes(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, amount * MILLISECONDS_IN_MINUTE);
}

/***/ }),

/***/ 37584:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/addWeeks/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addWeeks)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addWeeks
 * @category Week Helpers
 * @summary Add the specified number of weeks to the given date.
 *
 * @description
 * Add the specified number of week to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of weeks to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the weeks added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 4 weeks to 1 September 2014:
 * const result = addWeeks(new Date(2014, 8, 1), 4)
 * //=> Mon Sep 29 2014 00:00:00
 */

function addWeeks(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  var days = amount * 7;
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, days);
}

/***/ }),

/***/ 38776:
/*!********************************************************************!*\
  !*** ./node_modules/date-fns/esm/areIntervalsOverlapping/index.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ areIntervalsOverlapping)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name areIntervalsOverlapping
 * @category Interval Helpers
 * @summary Is the given time interval overlapping with another time interval?
 *
 * @description
 * Is the given time interval overlapping with another time interval? Adjacent intervals do not count as overlapping.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * - The function was renamed from `areRangesOverlapping` to `areIntervalsOverlapping`.
 *   This change was made to mirror the use of the word "interval" in standard ISO 8601:2004 terminology:
 *
 *   ```
 *   2.1.3
 *   time interval
 *   part of the time axis limited by two instants
 *   ```
 *
 *   Also, this function now accepts an object with `start` and `end` properties
 *   instead of two arguments as an interval.
 *   This function now throws `RangeError` if the start of the interval is after its end
 *   or if any date in the interval is `Invalid Date`.
 *
 *   ```javascript
 *   // Before v2.0.0
 *
 *   areRangesOverlapping(
 *     new Date(2014, 0, 10), new Date(2014, 0, 20),
 *     new Date(2014, 0, 17), new Date(2014, 0, 21)
 *   )
 *
 *   // v2.0.0 onward
 *
 *   areIntervalsOverlapping(
 *     { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *     { start: new Date(2014, 0, 17), end: new Date(2014, 0, 21) }
 *   )
 *   ```
 *
 * @param {Interval} intervalLeft - the first interval to compare. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Interval} intervalRight - the second interval to compare. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Object} [options] - the object with options
 * @param {Boolean} [options.inclusive=false] - whether the comparison is inclusive or not
 * @returns {Boolean} whether the time intervals are overlapping
 * @throws {TypeError} 2 arguments required
 * @throws {RangeError} The start of an interval cannot be after its end
 * @throws {RangeError} Date in interval cannot be `Invalid Date`
 *
 * @example
 * // For overlapping time intervals:
 * areIntervalsOverlapping(
 *   { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *   { start: new Date(2014, 0, 17), end: new Date(2014, 0, 21) }
 * )
 * //=> true
 *
 * @example
 * // For non-overlapping time intervals:
 * areIntervalsOverlapping(
 *   { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *   { start: new Date(2014, 0, 21), end: new Date(2014, 0, 22) }
 * )
 * //=> false
 *
 * @example
 * // For adjacent time intervals:
 * areIntervalsOverlapping(
 *   { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *   { start: new Date(2014, 0, 20), end: new Date(2014, 0, 30) }
 * )
 * //=> false
 *
 * @example
 * // Using the inclusive option:
 * areIntervalsOverlapping(
 *   { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *   { start: new Date(2014, 0, 20), end: new Date(2014, 0, 24) }
 * )
 * //=> false
 * areIntervalsOverlapping(
 *   { start: new Date(2014, 0, 10), end: new Date(2014, 0, 20) },
 *   { start: new Date(2014, 0, 20), end: new Date(2014, 0, 24) },
 *   { inclusive: true }
 * )
 * //=> true
 */

function areIntervalsOverlapping(dirtyIntervalLeft, dirtyIntervalRight) {
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
    inclusive: false
  };
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var intervalLeft = dirtyIntervalLeft || {};
  var intervalRight = dirtyIntervalRight || {};
  var leftStartTime = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(intervalLeft.start).getTime();
  var leftEndTime = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(intervalLeft.end).getTime();
  var rightStartTime = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(intervalRight.start).getTime();
  var rightEndTime = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(intervalRight.end).getTime(); // Throw an exception if start date is after end date or if any date is `Invalid Date`

  if (!(leftStartTime <= leftEndTime && rightStartTime <= rightEndTime)) {
    throw new RangeError('Invalid interval');
  }

  if (options.inclusive) {
    return leftStartTime <= rightEndTime && rightStartTime <= leftEndTime;
  }

  return leftStartTime < rightEndTime && rightStartTime < leftEndTime;
}

/***/ }),

/***/ 27869:
/*!*********************************************************************!*\
  !*** ./node_modules/date-fns/esm/differenceInMilliseconds/index.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ differenceInMilliseconds)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name differenceInMilliseconds
 * @category Millisecond Helpers
 * @summary Get the number of milliseconds between the given dates.
 *
 * @description
 * Get the number of milliseconds between the given dates.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} dateLeft - the later date
 * @param {Date|Number} dateRight - the earlier date
 * @returns {Number} the number of milliseconds
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // How many milliseconds are between
 * // 2 July 2014 12:30:20.600 and 2 July 2014 12:30:21.700?
 * const result = differenceInMilliseconds(
 *   new Date(2014, 6, 2, 12, 30, 21, 700),
 *   new Date(2014, 6, 2, 12, 30, 20, 600)
 * )
 * //=> 1100
 */

function differenceInMilliseconds(dateLeft, dateRight) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  return (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dateLeft).getTime() - (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dateRight).getTime();
}

/***/ }),

/***/ 81942:
/*!****************************************************************!*\
  !*** ./node_modules/date-fns/esm/differenceInMinutes/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ differenceInMinutes)
/* harmony export */ });
/* harmony import */ var _constants_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/index.js */ 97889);
/* harmony import */ var _differenceInMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../differenceInMilliseconds/index.js */ 27869);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _lib_roundingMethods_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_lib/roundingMethods/index.js */ 29348);




/**
 * @name differenceInMinutes
 * @category Minute Helpers
 * @summary Get the number of minutes between the given dates.
 *
 * @description
 * Get the signed number of full (rounded towards 0) minutes between the given dates.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} dateLeft - the later date
 * @param {Date|Number} dateRight - the earlier date
 * @param {Object} [options] - an object with options.
 * @param {String} [options.roundingMethod='trunc'] - a rounding method (`ceil`, `floor`, `round` or `trunc`)
 * @returns {Number} the number of minutes
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // How many minutes are between 2 July 2014 12:07:59 and 2 July 2014 12:20:00?
 * const result = differenceInMinutes(
 *   new Date(2014, 6, 2, 12, 20, 0),
 *   new Date(2014, 6, 2, 12, 7, 59)
 * )
 * //=> 12
 *
 * @example
 * // How many minutes are between 10:01:59 and 10:00:00
 * const result = differenceInMinutes(
 *   new Date(2000, 0, 1, 10, 0, 0),
 *   new Date(2000, 0, 1, 10, 1, 59)
 * )
 * //=> -1
 */

function differenceInMinutes(dateLeft, dateRight, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var diff = (0,_differenceInMilliseconds_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dateLeft, dateRight) / _constants_index_js__WEBPACK_IMPORTED_MODULE_2__.millisecondsInMinute;
  return (0,_lib_roundingMethods_index_js__WEBPACK_IMPORTED_MODULE_3__.getRoundingMethod)(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

/***/ }),

/***/ 56066:
/*!*****************************************************************!*\
  !*** ./node_modules/date-fns/esm/eachMinuteOfInterval/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eachMinuteOfInterval)
/* harmony export */ });
/* harmony import */ var _addMinutes_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../addMinutes/index.js */ 97807);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _startOfMinute_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../startOfMinute/index.js */ 98517);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);





/**
 * @name eachMinuteOfInterval
 * @category Interval Helpers
 * @summary Return the array of minutes within the specified time interval.
 *
 * @description
 * Returns the array of minutes within the specified time interval.
 *
 * @param {Interval} interval - the interval. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Object} [options] - an object with options.
 * @param {Number} [options.step=1] - the step to increment by. The starts of minutes from the hour of the interval start to the hour of the interval end
 * @throws {TypeError} 1 argument requie value should be more than 1.
 * @returns {Date[]} the array withred
 * @throws {RangeError} `options.step` must be a number equal or greater than 1
 * @throws {RangeError} The start of an interval cannot be after its end
 * @throws {RangeError} Date in interval cannot be `Invalid Date`
 *
 * @example
 * // Each minute between 14 October 2020, 13:00 and 14 October 2020, 13:03
 * const result = eachMinuteOfInterval({
 *   start: new Date(2014, 9, 14, 13),
 *   end: new Date(2014, 9, 14, 13, 3)
 * })
 * //=> [
 * //   Wed Oct 14 2014 13:00:00,
 * //   Wed Oct 14 2014 13:01:00,
 * //   Wed Oct 14 2014 13:02:00,
 * //   Wed Oct 14 2014 13:03:00
 * // ]
 */
function eachMinuteOfInterval(interval, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var startDate = (0,_startOfMinute_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])((0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(interval.start));
  var endDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(interval.end);
  var startTime = startDate.getTime();
  var endTime = endDate.getTime();

  if (startTime >= endTime) {
    throw new RangeError('Invalid interval');
  }

  var dates = [];
  var currentDate = startDate;
  var step = options && 'step' in options ? Number(options.step) : 1;
  if (step < 1 || isNaN(step)) throw new RangeError('`options.step` must be a number equal or greater than 1');

  while (currentDate.getTime() <= endTime) {
    dates.push((0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(currentDate));
    currentDate = (0,_addMinutes_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(currentDate, step);
  }

  return dates;
}

/***/ }),

/***/ 76905:
/*!*********************************************************!*\
  !*** ./node_modules/date-fns/esm/endOfISOWeek/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ endOfISOWeek)
/* harmony export */ });
/* harmony import */ var _endOfWeek_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../endOfWeek/index.js */ 37899);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name endOfISOWeek
 * @category ISO Week Helpers
 * @summary Return the end of an ISO week for the given date.
 *
 * @description
 * Return the end of an ISO week for the given date.
 * The result will be in the local timezone.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @returns {Date} the end of an ISO week
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // The end of an ISO week for 2 September 2014 11:55:00:
 * var result = endOfISOWeek(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Sun Sep 07 2014 23:59:59.999
 */

function endOfISOWeek(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  return (0,_endOfWeek_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate, {
    weekStartsOn: 1
  });
}

/***/ }),

/***/ 37899:
/*!******************************************************!*\
  !*** ./node_modules/date-fns/esm/endOfWeek/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ endOfWeek)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




/**
 * @name endOfWeek
 * @category Week Helpers
 * @summary Return the end of a week for the given date.
 *
 * @description
 * Return the end of a week for the given date.
 * The result will be in the local timezone.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @returns {Date} the end of a week
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 *
 * @example
 * // The end of a week for 2 September 2014 11:55:00:
 * const result = endOfWeek(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Sat Sep 06 2014 23:59:59.999
 *
 * @example
 * // If the week starts on Monday, the end of the week for 2 September 2014 11:55:00:
 * const result = endOfWeek(new Date(2014, 8, 2, 11, 55, 0), { weekStartsOn: 1 })
 * //=> Sun Sep 07 2014 23:59:59.999
 */
function endOfWeek(dirtyDate, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var locale = options.locale;
  var localeWeekStartsOn = locale && locale.options && locale.options.weekStartsOn;
  var defaultWeekStartsOn = localeWeekStartsOn == null ? 0 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(localeWeekStartsOn);
  var weekStartsOn = options.weekStartsOn == null ? defaultWeekStartsOn : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.weekStartsOn); // Test if weekStartsOn is between 0 and 6 _and_ is not NaN

  if (!(weekStartsOn >= 0 && weekStartsOn <= 6)) {
    throw new RangeError('weekStartsOn must be between 0 and 6 inclusively');
  }

  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate);
  var day = date.getDay();
  var diff = (day < weekStartsOn ? -7 : 0) + 6 - (day - weekStartsOn);
  date.setDate(date.getDate() + diff);
  date.setHours(23, 59, 59, 999);
  return date;
}

/***/ }),

/***/ 81916:
/*!**********************************************************!*\
  !*** ./node_modules/date-fns/esm/formatISO9075/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ formatISO9075)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _isValid_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isValid/index.js */ 77628);
/* harmony import */ var _lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/addLeadingZeros/index.js */ 24362);




/**
 * @name formatISO9075
 * @category Common Helpers
 * @summary Format the date according to the ISO 9075 standard (https://dev.mysql.com/doc/refman/5.7/en/date-and-time-functions.html#function_get-format).
 *
 * @description
 * Return the formatted date string in ISO 9075 format. Options may be passed to control the parts and notations of the date.
 *
 * @param {Date|Number} date - the original date
 * @param {Object} [options] - an object with options.
 * @param {'extended'|'basic'} [options.format='extended'] - if 'basic', hide delimiters between date and time values.
 * @param {'complete'|'date'|'time'} [options.representation='complete'] - format date, time, or both.
 * @returns {String} the formatted date string
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `date` must not be Invalid Date
 * @throws {RangeError} `options.format` must be 'extended' or 'basic'
 * @throws {RangeError} `options.represenation` must be 'date', 'time' or 'complete'
 *
 * @example
 * // Represent 18 September 2019 in ISO 9075 format:
 * const result = formatISO9075(new Date(2019, 8, 18, 19, 0, 52))
 * //=> '2019-09-18 19:00:52'
 *
 * @example
 * // Represent 18 September 2019 in ISO 9075, short format:
 * const result = formatISO9075(new Date(2019, 8, 18, 19, 0, 52), { format: 'basic' })
 * //=> '20190918 190052'
 *
 * @example
 * // Represent 18 September 2019 in ISO 9075 format, date only:
 * const result = formatISO9075(new Date(2019, 8, 18, 19, 0, 52), { representation: 'date' })
 * //=> '2019-09-18'
 *
 * @example
 * // Represent 18 September 2019 in ISO 9075 format, time only:
 * const result = formatISO9075(new Date(2019, 8, 18, 19, 0, 52), { representation: 'time' })
 * //=> '19:00:52'
 */
function formatISO9075(dirtyDate, dirtyOptions) {
  if (arguments.length < 1) {
    throw new TypeError("1 argument required, but only ".concat(arguments.length, " present"));
  }

  var originalDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(dirtyDate);

  if (!(0,_isValid_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(originalDate)) {
    throw new RangeError('Invalid time value');
  }

  var options = dirtyOptions || {};
  var format = options.format == null ? 'extended' : String(options.format);
  var representation = options.representation == null ? 'complete' : String(options.representation);

  if (format !== 'extended' && format !== 'basic') {
    throw new RangeError("format must be 'extended' or 'basic'");
  }

  if (representation !== 'date' && representation !== 'time' && representation !== 'complete') {
    throw new RangeError("representation must be 'date', 'time', or 'complete'");
  }

  var result = '';
  var dateDelimiter = format === 'extended' ? '-' : '';
  var timeDelimiter = format === 'extended' ? ':' : ''; // Representation is either 'date' or 'complete'

  if (representation !== 'time') {
    var day = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getDate(), 2);
    var month = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getMonth() + 1, 2);
    var year = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getFullYear(), 4); // yyyyMMdd or yyyy-MM-dd.

    result = "".concat(year).concat(dateDelimiter).concat(month).concat(dateDelimiter).concat(day);
  } // Representation is either 'time' or 'complete'


  if (representation !== 'date') {
    var hour = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getHours(), 2);
    var minute = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getMinutes(), 2);
    var second = (0,_lib_addLeadingZeros_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(originalDate.getSeconds(), 2); // If there's also date, separate it with time with a space

    var separator = result === '' ? '' : ' '; // HHmmss or HH:mm:ss.

    result = "".concat(result).concat(separator).concat(hour).concat(timeDelimiter).concat(minute).concat(timeDelimiter).concat(second);
  }

  return result;
}

/***/ }),

/***/ 92783:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/getDate/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getDate)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getDate
 * @category Day Helpers
 * @summary Get the day of the month of the given date.
 *
 * @description
 * Get the day of the month of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the day of month
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Which day of the month is 29 February 2012?
 * const result = getDate(new Date(2012, 1, 29))
 * //=> 29
 */

function getDate(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var dayOfMonth = date.getDate();
  return dayOfMonth;
}

/***/ }),

/***/ 60745:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/getHours/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getHours)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getHours
 * @category Hour Helpers
 * @summary Get the hours of the given date.
 *
 * @description
 * Get the hours of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the hours
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Get the hours of 29 February 2012 11:45:00:
 * const result = getHours(new Date(2012, 1, 29, 11, 45))
 * //=> 11
 */

function getHours(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var hours = date.getHours();
  return hours;
}

/***/ }),

/***/ 86118:
/*!*******************************************************!*\
  !*** ./node_modules/date-fns/esm/getMinutes/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getMinutes)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getMinutes
 * @category Minute Helpers
 * @summary Get the minutes of the given date.
 *
 * @description
 * Get the minutes of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the minutes
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Get the minutes of 29 February 2012 11:45:05:
 * const result = getMinutes(new Date(2012, 1, 29, 11, 45, 5))
 * //=> 45
 */

function getMinutes(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var minutes = date.getMinutes();
  return minutes;
}

/***/ }),

/***/ 82129:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/getMonth/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getMonth)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getMonth
 * @category Month Helpers
 * @summary Get the month of the given date.
 *
 * @description
 * Get the month of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the month
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Which month is 29 February 2012?
 * const result = getMonth(new Date(2012, 1, 29))
 * //=> 1
 */

function getMonth(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var month = date.getMonth();
  return month;
}

/***/ }),

/***/ 49145:
/*!********************************************************!*\
  !*** ./node_modules/date-fns/esm/getWeekYear/index.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getWeekYear)
/* harmony export */ });
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);





/**
 * @name getWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Get the local week-numbering year of the given date.
 *
 * @description
 * Get the local week-numbering year of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Number} the local week-numbering year
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // Which week numbering year is 26 December 2004 with the default settings?
 * const result = getWeekYear(new Date(2004, 11, 26))
 * //=> 2005
 *
 * @example
 * // Which week numbering year is 26 December 2004 if week starts on Saturday?
 * const result = getWeekYear(new Date(2004, 11, 26), { weekStartsOn: 6 })
 * //=> 2004
 *
 * @example
 * // Which week numbering year is 26 December 2004 if the first week contains 4 January?
 * const result = getWeekYear(new Date(2004, 11, 26), { firstWeekContainsDate: 4 })
 * //=> 2004
 */
function getWeekYear(dirtyDate, options) {
  var _options$locale, _options$locale$optio;

  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var year = date.getFullYear();
  var localeFirstWeekContainsDate = options === null || options === void 0 ? void 0 : (_options$locale = options.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate;
  var defaultFirstWeekContainsDate = localeFirstWeekContainsDate == null ? 1 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(localeFirstWeekContainsDate);
  var firstWeekContainsDate = (options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) == null ? defaultFirstWeekContainsDate : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(options.firstWeekContainsDate); // Test if weekStartsOn is between 1 and 7 _and_ is not NaN

  if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
    throw new RangeError('firstWeekContainsDate must be between 1 and 7 inclusively');
  }

  var firstWeekOfNextYear = new Date(0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  var startOfNextYear = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeekOfNextYear, options);
  var firstWeekOfThisYear = new Date(0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  var startOfThisYear = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeekOfThisYear, options);

  if (date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}

/***/ }),

/***/ 33719:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/getWeek/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getWeek)
/* harmony export */ });
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _startOfWeekYear_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeekYear/index.js */ 77131);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




var MILLISECONDS_IN_WEEK = 604800000;
/**
 * @name getWeek
 * @category Week Helpers
 * @summary Get the local week index of the given date.
 *
 * @description
 * Get the local week index of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Number} the week
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // Which week of the local week numbering year is 2 January 2005 with default options?
 * const result = getWeek(new Date(2005, 0, 2))
 * //=> 2
 *
 * // Which week of the local week numbering year is 2 January 2005,
 * // if Monday is the first day of the week,
 * // and the first week of the year always contains 4 January?
 * const result = getWeek(new Date(2005, 0, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> 53
 */

function getWeek(dirtyDate, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var diff = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(date, options).getTime() - (0,_startOfWeekYear_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(date, options).getTime(); // Round the number of days to the nearest integer
  // because the number of milliseconds in a week is not constant
  // (e.g. it's different in the week of the daylight saving time clock shift)

  return Math.round(diff / MILLISECONDS_IN_WEEK) + 1;
}

/***/ }),

/***/ 17940:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/getYear/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getYear)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name getYear
 * @category Year Helpers
 * @summary Get the year of the given date.
 *
 * @description
 * Get the year of the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @returns {Number} the year
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // Which year is 2 July 2014?
 * const result = getYear(new Date(2014, 6, 2))
 * //=> 2014
 */

function getYear(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  return (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate).getFullYear();
}

/***/ }),

/***/ 45816:
/*!******************************************************!*\
  !*** ./node_modules/date-fns/esm/isSameDay/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ isSameDay)
/* harmony export */ });
/* harmony import */ var _startOfDay_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../startOfDay/index.js */ 33841);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name isSameDay
 * @category Day Helpers
 * @summary Are the given dates in the same day (and year and month)?
 *
 * @description
 * Are the given dates in the same day (and year and month)?
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} dateLeft - the first date to check
 * @param {Date|Number} dateRight - the second date to check
 * @returns {Boolean} the dates are in the same day (and year and month)
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Are 4 September 06:00:00 and 4 September 18:00:00 in the same day?
 * var result = isSameDay(new Date(2014, 8, 4, 6, 0), new Date(2014, 8, 4, 18, 0))
 * //=> true
 * 
 * @example
 * // Are 4 September and 4 October in the same day?
 * var result = isSameDay(new Date(2014, 8, 4), new Date(2014, 9, 4))
 * //=> false
 * 
 * @example
 * // Are 4 September, 2014 and 4 September, 2015 in the same day?
 * var result = isSameDay(new Date(2014, 8, 4), new Date(2015, 8, 4))
 * //=> false
 */

function isSameDay(dirtyDateLeft, dirtyDateRight) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var dateLeftStartOfDay = (0,_startOfDay_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDateLeft);
  var dateRightStartOfDay = (0,_startOfDay_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDateRight);
  return dateLeftStartOfDay.getTime() === dateRightStartOfDay.getTime();
}

/***/ }),

/***/ 50927:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/isToday/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ isToday)
/* harmony export */ });
/* harmony import */ var _isSameDay_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isSameDay/index.js */ 45816);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name isToday
 * @category Day Helpers
 * @summary Is the given date today?
 * @pure false
 *
 * @description
 * Is the given date today?
 *
 * > ⚠️ Please note that this function is not present in the FP submodule as
 * > it uses `Date.now()` internally hence impure and can't be safely curried.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to check
 * @returns {Boolean} the date is today
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // If today is 6 October 2014, is 6 October 14:00:00 today?
 * var result = isToday(new Date(2014, 9, 6, 14, 0))
 * //=> true
 */

function isToday(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  return (0,_isSameDay_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate, Date.now());
}

/***/ }),

/***/ 12777:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/nextDay/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ nextDay)
/* harmony export */ });
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _getDay_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../getDay/index.js */ 38902);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name nextDay
 * @category Weekday Helpers
 * @summary When is the next day of the week?
 *
 * @description
 * When is the next day of the week? 0-6 the day of the week, 0 represents Sunday.
 *
 * @param {Date | number} date - the date to check
 * @param {Day} day - day of the week
 * @returns {Date} - the date is the next day of week
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // When is the next Monday after Mar, 20, 2020?
 * const result = nextDay(new Date(2020, 2, 20), 1)
 * //=> Mon Mar 23 2020 00:00:00
 *
 * @example
 * // When is the next Tuesday after Mar, 21, 2020?
 * const result = nextDay(new Date(2020, 2, 21), 2)
 * //=> Tue Mar 24 2020 00:00:00
 */

function nextDay(date, day) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var delta = day - (0,_getDay_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(date);
  if (delta <= 0) delta += 7;
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(date, delta);
}

/***/ }),

/***/ 71798:
/*!********************************************************!*\
  !*** ./node_modules/date-fns/esm/previousDay/index.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ previousDay)
/* harmony export */ });
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);
/* harmony import */ var _getDay_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../getDay/index.js */ 38902);
/* harmony import */ var _subDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../subDays/index.js */ 72292);




/**
 * @name previousDay
 * @category Weekday Helpers
 * @summary When is the previous day of the week?
 *
 * @description
 * When is the previous day of the week? 0-6 the day of the week, 0 represents Sunday.
 *
 * @param {Date | number} date - the date to check
 * @param {number} day - day of the week
 * @returns {Date} - the date is the previous day of week
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // When is the previous Monday before Mar, 20, 2020?
 * const result = previousDay(new Date(2020, 2, 20), 1)
 * //=> Mon Mar 16 2020 00:00:00
 *
 * @example
 * // When is the previous Tuesday before Mar, 21, 2020?
 * const result = previousDay(new Date(2020, 2, 21), 2)
 * //=> Tue Mar 17 2020 00:00:00
 */
function previousDay(date, day) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var delta = (0,_getDay_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(date) - day;
  if (delta <= 0) delta += 7;
  return (0,_subDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(date, delta);
}

/***/ }),

/***/ 33841:
/*!*******************************************************!*\
  !*** ./node_modules/date-fns/esm/startOfDay/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ startOfDay)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name startOfDay
 * @category Day Helpers
 * @summary Return the start of a day for the given date.
 *
 * @description
 * Return the start of a day for the given date.
 * The result will be in the local timezone.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @returns {Date} the start of a day
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // The start of a day for 2 September 2014 11:55:00:
 * const result = startOfDay(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Tue Sep 02 2014 00:00:00
 */

function startOfDay(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  date.setHours(0, 0, 0, 0);
  return date;
}

/***/ }),

/***/ 43677:
/*!***********************************************************!*\
  !*** ./node_modules/date-fns/esm/startOfISOWeek/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ startOfISOWeek)
/* harmony export */ });
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name startOfISOWeek
 * @category ISO Week Helpers
 * @summary Return the start of an ISO week for the given date.
 *
 * @description
 * Return the start of an ISO week for the given date.
 * The result will be in the local timezone.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @returns {Date} the start of an ISO week
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // The start of an ISO week for 2 September 2014 11:55:00:
 * var result = startOfISOWeek(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Mon Sep 01 2014 00:00:00
 */

function startOfISOWeek(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  return (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate, {
    weekStartsOn: 1
  });
}

/***/ }),

/***/ 98517:
/*!**********************************************************!*\
  !*** ./node_modules/date-fns/esm/startOfMinute/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ startOfMinute)
/* harmony export */ });
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);


/**
 * @name startOfMinute
 * @category Minute Helpers
 * @summary Return the start of a minute for the given date.
 *
 * @description
 * Return the start of a minute for the given date.
 * The result will be in the local timezone.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @returns {Date} the start of a minute
 * @throws {TypeError} 1 argument required
 *
 * @example
 * // The start of a minute for 1 December 2014 22:15:45.400:
 * const result = startOfMinute(new Date(2014, 11, 1, 22, 15, 45, 400))
 * //=> Mon Dec 01 2014 22:15:00
 */

function startOfMinute(dirtyDate) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  date.setSeconds(0, 0);
  return date;
}

/***/ }),

/***/ 77131:
/*!************************************************************!*\
  !*** ./node_modules/date-fns/esm/startOfWeekYear/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ startOfWeekYear)
/* harmony export */ });
/* harmony import */ var _getWeekYear_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../getWeekYear/index.js */ 49145);
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);





/**
 * @name startOfWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Return the start of a local week-numbering year for the given date.
 *
 * @description
 * Return the start of a local week-numbering year.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Date} the start of a week-numbering year
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // The start of an a week-numbering year for 2 July 2005 with default settings:
 * const result = startOfWeekYear(new Date(2005, 6, 2))
 * //=> Sun Dec 26 2004 00:00:00
 *
 * @example
 * // The start of a week-numbering year for 2 July 2005
 * // if Monday is the first day of week
 * // and 4 January is always in the first week of the year:
 * const result = startOfWeekYear(new Date(2005, 6, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> Mon Jan 03 2005 00:00:00
 */
function startOfWeekYear(dirtyDate, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var locale = options.locale;
  var localeFirstWeekContainsDate = locale && locale.options && locale.options.firstWeekContainsDate;
  var defaultFirstWeekContainsDate = localeFirstWeekContainsDate == null ? 1 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(localeFirstWeekContainsDate);
  var firstWeekContainsDate = options.firstWeekContainsDate == null ? defaultFirstWeekContainsDate : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.firstWeekContainsDate);
  var year = (0,_getWeekYear_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, dirtyOptions);
  var firstWeek = new Date(0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  var date = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeek, dirtyOptions);
  return date;
}

/***/ }),

/***/ 72292:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/subDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ subDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name subDays
 * @category Day Helpers
 * @summary Subtract the specified number of days from the given date.
 *
 * @description
 * Subtract the specified number of days from the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be subtracted. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the days subtracted
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Subtract 10 days from 1 September 2014:
 * const result = subDays(new Date(2014, 8, 1), 10)
 * //=> Fri Aug 22 2014 00:00:00
 */

function subDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, -amount);
}

/***/ }),

/***/ 62001:
/*!*******************************************************!*\
  !*** ./node_modules/date-fns/esm/subMinutes/index.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ subMinutes)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addMinutes_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addMinutes/index.js */ 97807);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name subMinutes
 * @category Minute Helpers
 * @summary Subtract the specified number of minutes from the given date.
 *
 * @description
 * Subtract the specified number of minutes from the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of minutes to be subtracted. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the minutes subtracted
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Subtract 30 minutes from 10 July 2014 12:00:00:
 * const result = subMinutes(new Date(2014, 6, 10, 12, 0), 30)
 * //=> Thu Jul 10 2014 11:30:00
 */

function subMinutes(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addMinutes_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, -amount);
}

/***/ }),

/***/ 12058:
/*!******************************************************!*\
  !*** ./node_modules/date-fns/esm/subMonths/index.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ subMonths)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addMonths_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addMonths/index.js */ 25277);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name subMonths
 * @category Month Helpers
 * @summary Subtract the specified number of months from the given date.
 *
 * @description
 * Subtract the specified number of months from the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of months to be subtracted. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the months subtracted
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Subtract 5 months from 1 February 2015:
 * const result = subMonths(new Date(2015, 1, 1), 5)
 * //=> Mon Sep 01 2014 00:00:00
 */

function subMonths(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addMonths_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, -amount);
}

/***/ }),

/***/ 43991:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/subWeeks/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ subWeeks)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addWeeks_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addWeeks/index.js */ 37584);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name subWeeks
 * @category Week Helpers
 * @summary Subtract the specified number of weeks from the given date.
 *
 * @description
 * Subtract the specified number of weeks from the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of weeks to be subtracted. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the weeks subtracted
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Subtract 4 weeks from 1 September 2014:
 * const result = subWeeks(new Date(2014, 8, 1), 4)
 * //=> Mon Aug 04 2014 00:00:00
 */

function subWeeks(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  return (0,_addWeeks_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, -amount);
}

/***/ }),

/***/ 29647:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/observable/interval.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "interval": () => (/* binding */ interval)
/* harmony export */ });
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scheduler/async */ 84154);
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timer */ 30606);


function interval(period = 0, scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.asyncScheduler) {
  if (period < 0) {
    period = 0;
  }

  return (0,_timer__WEBPACK_IMPORTED_MODULE_1__.timer)(period, period, scheduler);
}

/***/ }),

/***/ 27573:
/*!***************************************************!*\
  !*** ./src/app/core/builder/timetable.builder.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableBuilder": () => (/* binding */ TimeTableBuilder)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns */ 81942);
/* harmony import */ var _models_reservation_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../models/reservation.model */ 27601);
/* harmony import */ var _models_time_table_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/time-table.model */ 89055);



class TimeTableBuilder extends _models_time_table_model__WEBPACK_IMPORTED_MODULE_1__.TimeTable {
    setTimeFrames(newTimeFrames) {
        this.timeFrames = newTimeFrames;
        return this;
    }
    setEmployees(newEmployees) {
        this.employees = newEmployees;
        return this;
    }
    setBookings(newBookings) {
        this.bookings = newBookings;
        return this;
    }
    setFreeTime(newFreeTime) {
        this.freeTime = this.setNonAvaliabilityAsBooking(newFreeTime);
        return this;
    }
    setNonAvailability(newNonAvailability) {
        this.bookings = this.bookings.concat(this.setNonAvaliabilityAsBooking(newNonAvailability));
        return this;
    }
    build() {
        const newTimetable = new _models_time_table_model__WEBPACK_IMPORTED_MODULE_1__.TimeTable();
        newTimetable.timeFrames = this.timeFrames;
        newTimetable.employees = this.employees;
        newTimetable.freeTime = this.calculateBookingPosition(this.freeTime, this.employees);
        newTimetable.bookings = this.calculateBookingPosition(this.bookings, this.employees);
        return newTimetable;
    }
    setNonAvaliabilityAsBooking(nonAvailability) {
        const newBookingCollection = [];
        nonAvailability.forEach((nonAva) => {
            const nonAvaTimeTable = JSON.parse(nonAva.timetable);
            const newBook = new _models_reservation_model__WEBPACK_IMPORTED_MODULE_0__.Booking();
            newBook.uuid = nonAva.uuid;
            if (nonAva.uuid.includes('fake-')) {
                newBook.isFreetime = true;
            }
            else {
                newBook.isFreetime = false;
            }
            newBook.asignedTo = nonAva.employee;
            newBook.commerce = nonAva.commerce;
            newBook.customer = null;
            newBook.message = nonAva.message;
            newBook.startsHour = nonAvaTimeTable.start.hour;
            newBook.startsMinute = nonAvaTimeTable.start.minute;
            newBook.isBooking = false;
            newBook.mobileSize = {
                width: 0,
                height: 0,
            };
            newBook.mobilePosition = {
                x: 0,
                y: 0,
            };
            newBook.startsDay = nonAva.date;
            newBook.duration = this.setNonAvailabilityDuration(nonAva);
            newBookingCollection.push(newBook);
        });
        return newBookingCollection;
    }
    getEmployeeById(employee, uuid) {
        const employeeSelected = employee.find((emp) => emp.uuid === uuid);
        return employeeSelected;
    }
    calculateBookingPosition(booking, employee) {
        return booking.map((bookItem) => {
            bookItem.mobilePosition = {
                x: this.getEmployeeIndexToAsignColumn(bookItem, employee),
                y: this.calcVerticalDistanceFromBookingHour(bookItem, this.timeFrames),
            };
            return bookItem;
        });
    }
    getEmployeeIndexToAsignColumn(booking, employee) {
        const index = employee.findIndex((employeeItem) => employeeItem.uuid === booking.asignedTo.uuid);
        return index * parseInt(localStorage.getItem('columnWidth'), 10); // TODO
    }
    calcVerticalDistanceFromBookingHour(booking, timeFrames) {
        const [firsFrame] = timeFrames;
        const hourAndMinuteSplitted = firsFrame.split(':');
        const hour = parseInt(hourAndMinuteSplitted[0], 10);
        const minute = parseInt(hourAndMinuteSplitted[1], 10);
        const bookingHour = booking.startsHour;
        const bookingMinute = booking.startsMinute;
        const hourDiff = (bookingHour - hour) * 60;
        const minuteDiff = bookingMinute - minute;
        let totalMinutes;
        if (minuteDiff > 0) {
            if (booking.uuid === '2d620ad4-ac4b-407c-ab65-9657edf673b5') {
                console.log('entra +');
            }
            totalMinutes = hourDiff + minuteDiff;
        }
        else {
            if (booking.uuid === '2d620ad4-ac4b-407c-ab65-9657edf673b5') {
                console.log('entra -');
            }
            totalMinutes = hourDiff - (minuteDiff * (-1));
        }
        const pixelsHeightOfEachFiveMinutes = 8;
        const rowInMinutes = 5;
        const totalPixels = (totalMinutes / rowInMinutes) * pixelsHeightOfEachFiveMinutes;
        if (booking.uuid === '2d620ad4-ac4b-407c-ab65-9657edf673b5') {
            console.log({ firsFrame });
            console.log({ hourAndMinuteSplitted });
            console.log({ hour });
            console.log({ minute });
            console.log({ bookingHour });
            console.log({ bookingMinute });
            console.log({ hourDiff });
            console.log({ minuteDiff });
            console.log({ totalMinutes });
            console.log({ totalPixels });
        }
        return totalPixels;
    }
    setNonAvailabilityDuration(nonAvailability) {
        const nonAvaTimeTable = JSON.parse(nonAvailability.timetable);
        const nonAvaStartDate = new Date(2022, 1, 1, nonAvaTimeTable.start.hour, nonAvaTimeTable.start.minute);
        const nonAvaEndDate = new Date(2022, 1, 1, nonAvaTimeTable.end.hour, nonAvaTimeTable.end.minute);
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_2__["default"])(nonAvaEndDate, nonAvaStartDate);
    }
}


/***/ }),

/***/ 58061:
/*!*******************************************!*\
  !*** ./src/app/core/enums/colors.enum.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EColors": () => (/* binding */ EColors)
/* harmony export */ });
var EColors;
(function (EColors) {
    EColors["#F29A44"] = "#F7C28F";
    EColors["#E4B55E"] = "#EFD39E";
    EColors["#F4B98C"] = "#F8D5BA";
    EColors["#FFDD98"] = "#FFEBC1";
    EColors["#ECAA6E"] = "#F4CCA8";
    EColors["#F9EF74"] = "#FBF5AC";
    EColors["#FFFEA5"] = "#FFFEC9";
    EColors["#FCDD43"] = "#FDEB8E";
    EColors["#E9D274"] = "#F2E4AC";
    EColors["#FFF7BE"] = "#FFFAD8";
    EColors["#91FFEA"] = "#BDFFF2";
    EColors["#B0F5FA"] = "#D0F9FC";
    EColors["#37CCC7"] = "#87E0DD";
    EColors["#8ED9CF"] = "#BBE8E2";
    EColors["#BEF4F3"] = "#D8F8F8";
    EColors["#75F93E"] = "#ACFB8B";
    EColors["#8DD86C"] = "#BBE8A7";
    EColors["#CDFFBA"] = "#E1FFD6";
    EColors["#B6FF93"] = "#D3FFBE";
    EColors["#88BC71"] = "#B8D7AA";
    EColors["#894DA4"] = "#B894C8";
    EColors["#AE6ED6"] = "#CEA8E6";
    EColors["#DCBEFF"] = "#EAD8FF";
    EColors["#C795FF"] = "#DDBFFF";
    EColors["#AC73BB"] = "#CDABD6";
    EColors["#4D51A0"] = "#9497C6";
    EColors["#6F7FD3"] = "#A9B2E5";
    EColors["#C0C6FF"] = "#D9DDFF";
    EColors["#9897FF"] = "#C1C1FF";
    EColors["#7276B7"] = "#AAADD4";
    EColors["#9B4E56"] = "#C3959A";
    EColors["#D36F7A"] = "#E5A9AF";
    EColors["#FFC3CF"] = "#FFDBE2";
    EColors["#FF99A8"] = "#FFC2CB";
    EColors["#B5717A"] = "#D3AAAF";
})(EColors || (EColors = {}));
/* export enum EColors {
        '#C53E59' = '#D8858C',
        '#C15C7C' = '#D596A7',
        '#A61C6D' = '#C1709A',
        '#B21B82' = '#C975AE',
        '#9A358B' = '#B97CB4',
        '#926299' = '#B496BD',
        '#9170AF' = '#B4A0CD',
        '#7A7DA3' = '#A7A7C1',
        '#157DA3' = '#7DA4C1',
        '#164B7F' = '#6A7CA5',
        '#2274A1' = '#7D9EC0',
        '#587C99' = '#94A5BA',
        '#6397A2' = '#9DB8C0',
        '#38644C' = '#7B907D',
        '#617C63' = '#96A391',
        '#4E8A32' = '#92AD6E',
        '#8EAD25' = '#B9C772',
        '#BACF16' = '#D4DF7A',
        '#D1C73E' = '#E1D989',
        '#EBDA3D' = '#F2E68D',
        '#DCB31D' = '#EACC76',
        '#EEB214' = '#F5CB75',
        '#C58C24' = '#DAB16F',
        '#B64E2B' = '#CE8969',
        '#964B4D' = '#B6837F',
        '#5EB9C2' = '#A2D1D8',
        '#62C0BA' = '#A4D6D2',
        '#7AC4AA' = '#AFD9C8',
        '#9BCC96' = '#C2DEBC',
        '#F4EB75' = '#F8F2AC',
} */ 


/***/ }),

/***/ 62518:
/*!***************************************************************!*\
  !*** ./src/app/core/interfaces/card-reservation.interface.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CardsPosition": () => (/* binding */ CardsPosition)
/* harmony export */ });
class CardsPosition {
}


/***/ }),

/***/ 43356:
/*!******************************************!*\
  !*** ./src/app/core/models/day.model.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DayModel": () => (/* binding */ DayModel)
/* harmony export */ });
class DayModel {
}


/***/ }),

/***/ 73437:
/*!*******************************************************!*\
  !*** ./src/app/core/models/non-availability.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonAvailability": () => (/* binding */ NonAvailability)
/* harmony export */ });
class NonAvailability {
}


/***/ }),

/***/ 89055:
/*!*************************************************!*\
  !*** ./src/app/core/models/time-table.model.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTable": () => (/* binding */ TimeTable)
/* harmony export */ });
class TimeTable {
}


/***/ }),

/***/ 19109:
/*!********************************************!*\
  !*** ./src/app/core/utils/date.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateService": () => (/* binding */ DateService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! date-fns */ 60745);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns */ 86118);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! date-fns */ 62001);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! date-fns */ 33719);



let DateService = class DateService {
    addZeroToMinutesAndHours(hourString) {
        const hourSplitted = hourString.split(':');
        let hours = hourSplitted[0];
        let minutes = hourSplitted[1];
        if (hours.length < 2) {
            hours = `0${hours}`;
        }
        if (minutes.length < 2) {
            minutes = `0${minutes}`;
        }
        return `${hours}:${minutes}`;
    }
    addZeroToMinutes(str) {
        const strSplitted = str.split(':');
        const minutes = strSplitted[1];
        if (minutes.length < 2 && minutes !== '5') {
            return str + '0';
        }
        if (minutes.length < 2 && minutes === '5') {
            return strSplitted[0] + ':' + '0' + minutes;
        }
        return str;
    }
    formatBookingTimetable(startHour, startMinute, duration) {
        const newDate = new Date(2022, 1, 1, startHour, startMinute);
        const endDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_0__["default"])(newDate, duration);
        const ending = this.addZeroToMinutes((0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(endDate) + ':' + (0,date_fns__WEBPACK_IMPORTED_MODULE_2__["default"])(endDate));
        const starting = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_3__["default"])(endDate, duration)) +
            ':' +
            (0,date_fns__WEBPACK_IMPORTED_MODULE_2__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_3__["default"])(endDate, duration));
        return this.addZeroToMinutes(starting) + '-' + ending;
    }
    formatDate(date) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_4__["default"])(date, 'yyyy-MM-dd');
    }
    getWeekNumberByDate(date) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_5__["default"])(date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        });
    }
    getHoursAndMinuteFromDate(date) {
        const hour = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(date);
        const minute = (0,date_fns__WEBPACK_IMPORTED_MODULE_2__["default"])(date);
        return hour + ':' + minute;
    }
    formatDateLanguage(date, locale) {
        if (date) {
            const datefor = (0,date_fns__WEBPACK_IMPORTED_MODULE_4__["default"])(new Date(date), 'dd MMM yyyy', { locale });
            return datefor;
        }
    }
};
DateService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
        providedIn: 'root',
    })
], DateService);



/***/ }),

/***/ 24097:
/*!***************************************************!*\
  !*** ./src/app/core/utils/editBooking.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditBooking": () => (/* binding */ EditBooking)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76027);



let EditBooking = class EditBooking {
    constructor() {
        this.editBookingConfirm = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
        this.modalOppened = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
};
EditBooking = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], EditBooking);



/***/ }),

/***/ 67223:
/*!*************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-manager-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingManagerPageRoutingModule": () => (/* binding */ BookingManagerPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _booking_manager_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-manager.page */ 40477);




const routes = [
    {
        path: '',
        component: _booking_manager_page__WEBPACK_IMPORTED_MODULE_0__.BookingManagerPage,
    },
    {
        path: 'new-booking',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"), __webpack_require__.e("default-src_app_pages_booking-manager_new-booking_new-booking_module_ts"), __webpack_require__.e("src_app_shared_components_alert_alert_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./new-booking/new-booking.module */ 41072)).then((m) => m.NewBookingPageModule),
    },
    {
        path: 'non-availability',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("src_app_pages_booking-manager_non-availability_non-availability_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./non-availability/non-availability.module */ 87308)).then((m) => m.NonAvailabilityPageModule),
    },
    {
        path: 'booking/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_booking-manager_booking-item_booking-item_module_ts"), __webpack_require__.e("common")]).then(__webpack_require__.bind(__webpack_require__, /*! ./booking-item/booking-item.module */ 61046)).then((m) => m.BookingItemPageModule),
    },
    {
        path: 'non-availability/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("src_app_pages_booking-manager_non-availability_non-availability_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./non-availability/non-availability.module */ 87308)).then((m) => m.NonAvailabilityPageModule),
    },
    {
        path: 'new-booking/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"), __webpack_require__.e("default-src_app_pages_booking-manager_new-booking_new-booking_module_ts"), __webpack_require__.e("src_app_shared_components_alert_alert_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./new-booking/new-booking.module */ 41072)).then((m) => m.NewBookingPageModule),
    },
];
let BookingManagerPageRoutingModule = class BookingManagerPageRoutingModule {
};
BookingManagerPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BookingManagerPageRoutingModule);



/***/ }),

/***/ 78505:
/*!*****************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-manager.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingManagerPageModule": () => (/* binding */ BookingManagerPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _booking_manager_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-manager-routing.module */ 67223);
/* harmony import */ var _booking_manager_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./booking-manager.page */ 40477);
/* harmony import */ var src_app_shared_components_time_table_time_table_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/time-table/time-table.module */ 4477);
/* harmony import */ var src_app_shared_components_datetime_datetime_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/datetime/datetime.module */ 73306);
/* harmony import */ var src_app_shared_components_employee_employee_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/employee/employee.module */ 27525);
/* harmony import */ var src_app_shared_components_action_sheet_action_sheet_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/action-sheet/action-sheet.module */ 49722);
/* harmony import */ var src_app_shared_components_employee_list_employee_list_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/employee-list/employee-list.module */ 93560);
/* harmony import */ var src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/no-data/no-data.module */ 98360);













let BookingManagerPageModule = class BookingManagerPageModule {
};
BookingManagerPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule,
            _booking_manager_routing_module__WEBPACK_IMPORTED_MODULE_0__.BookingManagerPageRoutingModule,
            src_app_shared_components_time_table_time_table_module__WEBPACK_IMPORTED_MODULE_2__.TimeTableModule,
            src_app_shared_components_datetime_datetime_module__WEBPACK_IMPORTED_MODULE_3__.DatetimeModule,
            src_app_shared_components_employee_employee_module__WEBPACK_IMPORTED_MODULE_4__.EmployeeModule,
            src_app_shared_components_action_sheet_action_sheet_module__WEBPACK_IMPORTED_MODULE_5__.ActionSheetModule,
            src_app_shared_components_employee_list_employee_list_module__WEBPACK_IMPORTED_MODULE_6__.EmployeeListModule,
            src_app_shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_7__.NoDataModule
        ],
        declarations: [_booking_manager_page__WEBPACK_IMPORTED_MODULE_1__.BookingManagerPage],
    })
], BookingManagerPageModule);



/***/ }),

/***/ 40477:
/*!***************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-manager.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingManagerPage": () => (/* binding */ BookingManagerPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _booking_manager_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-manager.page.html?ngResource */ 76557);
/* harmony import */ var _booking_manager_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./booking-manager.page.scss?ngResource */ 41664);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ 85566);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 9892);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! date-fns */ 33719);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! date-fns */ 41766);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! date-fns */ 81916);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! date-fns */ 56066);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! date-fns */ 17940);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! date-fns */ 82129);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! date-fns */ 92783);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! date-fns */ 50927);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! date-fns */ 81942);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! date-fns */ 25277);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! date-fns */ 12058);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! date-fns */ 43677);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! date-fns */ 12777);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! date-fns */ 76905);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! date-fns */ 37584);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! date-fns */ 43991);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! date-fns */ 71798);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! date-fns */ 60745);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! date-fns */ 86118);
/* harmony import */ var date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! date-fns/locale/es */ 36956);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 33646);
/* harmony import */ var src_app_core_app_settings_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/app-settings.service */ 3475);
/* harmony import */ var src_app_core_builder_timetable_builder__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/builder/timetable.builder */ 27573);
/* harmony import */ var src_app_core_enums_days_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/enums/days.enum */ 77639);
/* harmony import */ var src_app_core_models_day_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/models/day.model */ 43356);
/* harmony import */ var src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/models/non-availability.model */ 73437);
/* harmony import */ var src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/booking/booking.service */ 70065);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);
/* harmony import */ var src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/non-availability/non-availability.service */ 30371);
/* harmony import */ var src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/timeTable/time-table.service */ 79223);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/utils/editBooking.service */ 24097);
/* harmony import */ var src_app_shared_components_action_sheet_action_sheet_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/shared/components/action-sheet/action-sheet.component */ 88664);
/* harmony import */ var src_app_shared_components_employee_list_employee_list_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/components/employee-list/employee-list.component */ 42279);
/* harmony import */ var src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/dto/non-availability.dto */ 57394);




/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/quotes */





















let BookingManagerPage = class BookingManagerPage {
    constructor(bookingService, employeeService, timetableService, dateService, nonAvailabilityService, navCtrl, modalController, routerOutlet, editBookingService, appSetting, activatedRoute, cd) {
        this.bookingService = bookingService;
        this.employeeService = employeeService;
        this.timetableService = timetableService;
        this.dateService = dateService;
        this.nonAvailabilityService = nonAvailabilityService;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.editBookingService = editBookingService;
        this.appSetting = appSetting;
        this.activatedRoute = activatedRoute;
        this.cd = cd;
        this.availableHours = [];
        this.timetable = [];
        this.employeeCollection = [];
        this.filteredEmployees = [];
        this.today = new Date();
        this.weekNumber = 0;
        this.isToday = true;
        this.editBooking = false;
        this.isIOS = false;
        this.isModalOpenned = false;
        this.indexSelected = 0;
        this.overscroll = false;
        this.isAnimating = false;
        this.actualDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(new Date(), 'iii., d  MMM', {
            locale: date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__["default"],
        });
        this.isIOS = (0,_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.isPlatform)('android') ? false : true;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ionViewWillEnter() {
        this.isReady = false;
        this.editBooking = false;
        this.filteredEmployees =
            localStorage.getItem('filteredEmployee') !== ''
                ? JSON.parse(localStorage.getItem('filteredEmployee'))
                : [];
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
    }
    ionViewDidEnter() {
        this.isReady = true;
    }
    ngOnInit() {
        setTimeout(() => {
            this.dateslide.lockSwipes(true);
        }, 150);
        this.weekNumber = (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.today, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        });
        [this.selectedDay] = this.formatDateToDays([this.today]);
        this.indexSelected = this.selectedDay.date.getDay();
        [this.todayDay] = this.formatDateToDays([this.today]);
        this.getThisWeekDays();
    }
    doRefresh(event) {
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }), event);
    }
    openActionSheet(data = null) {
        const selectedDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(this.selectedDay.date, 'yyyy-MM-dd', {
            locale: date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__["default"],
        });
        this.actionSheet.presentActionSheet(data, selectedDay);
    }
    returnDaysOfWeek(startDay, endDate) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_21__["default"])({
            start: startDay,
            end: endDate,
        });
    }
    checkIsToday(date) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(date, 'yyyy-MM-dd') === (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(new Date(), 'yyyy-MM-dd');
    }
    goToToday() {
        this.getThisWeekDays();
        this.getTodayWeek();
        if ((0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }) !==
            (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.todayDay.date, { weekStartsOn: 1, firstWeekContainsDate: 4 })) {
            this.selectDate(this.todayDay);
            this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
                weekStartsOn: 1,
                firstWeekContainsDate: 4,
            }));
        }
        else {
            this.selectDate(this.todayDay);
        }
    }
    formatHoursOfInterval(interval) {
        const newHours = interval.map((item) => (0,date_fns__WEBPACK_IMPORTED_MODULE_22__["default"])(item, {
            format: 'extended',
            representation: 'time',
        }).substring(0, (0,date_fns__WEBPACK_IMPORTED_MODULE_22__["default"])(item, { format: 'extended', representation: 'time' })
            .length - 3));
        return newHours;
    }
    formatDate(date) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(date, 'yyyy-MM-dd');
    }
    buildFrames(startDateFrame, endDateFrame, step) {
        const availableHoursInterval = (0,date_fns__WEBPACK_IMPORTED_MODULE_23__["default"])({
            start: new Date(startDateFrame.year, startDateFrame.month, startDateFrame.day, startDateFrame.hour, startDateFrame.minute),
            end: new Date(endDateFrame.year, endDateFrame.month, endDateFrame.day, endDateFrame.hour, endDateFrame.minute),
        }, { step });
        return this.formatHoursOfInterval(availableHoursInterval);
    }
    concatRequiredRequest(commerce, week, event) {
        (0,rxjs__WEBPACK_IMPORTED_MODULE_24__.forkJoin)([
            this.findAllBookingByWeek(commerce, week),
            this.findCommerceTimeTable(commerce),
            this.findEmployees(commerce),
            this.findAllNonAvailabilityByWeek(commerce, week),
        ]).subscribe((res) => {
            this.timetable = [];
            const [booking, commerceRes, employee, nonAva] = res;
            this.commerce = commerceRes;
            employee.map((emp) => (emp.services = (0,lodash__WEBPACK_IMPORTED_MODULE_2__.intersectionBy)(this.commerce.services, emp.services, 'uuid')));
            this.employeeCollection = employee.filter((item) => item.services && item.services.length > 0);
            this.setColumnWidthByEmployee();
            Object.keys(booking).forEach((key, index) => {
                this.bookingCollection = booking[key];
                this.nonAvailabilityCollection = nonAva[key];
                this.bookingCollection = [
                    ...this.filterBookingByEmployee(booking[key]),
                ];
                this.nonAvailabilityCollection = this.filterNonAvailabilityByEmployee(nonAva[key]);
                const weekDay = src_app_core_enums_days_enum__WEBPACK_IMPORTED_MODULE_5__.EDays[index];
                // Get day timetable
                const timetableDay = JSON.parse(commerceRes.timetable[weekDay]);
                const startDateFrame = {
                    year: (0,date_fns__WEBPACK_IMPORTED_MODULE_25__["default"])(this.today),
                    month: (0,date_fns__WEBPACK_IMPORTED_MODULE_26__["default"])(this.today),
                    day: (0,date_fns__WEBPACK_IMPORTED_MODULE_27__["default"])(this.today),
                    hour: timetableDay.start.hour !== null
                        ? timetableDay.start.hour - 1
                        : 0,
                    minute: timetableDay.start.minute !== null
                        ? timetableDay.start.minute
                        : 0,
                };
                const endDateFrame = {
                    year: (0,date_fns__WEBPACK_IMPORTED_MODULE_25__["default"])(this.today),
                    month: (0,date_fns__WEBPACK_IMPORTED_MODULE_26__["default"])(this.today),
                    day: (0,date_fns__WEBPACK_IMPORTED_MODULE_27__["default"])(this.today),
                    hour: timetableDay.end.hour !== null ? timetableDay.end.hour : 24,
                    minute: timetableDay.end.minute !== null
                        ? timetableDay.end.minute + 45
                        : 0,
                };
                this.timeFrames = this.buildFrames(startDateFrame, endDateFrame, 15);
                this.timetable.push(this.buildTimetable(this.timeFrames, this.bookingCollection, this.employeeCollection.sort((a, b) => a.createdAtCustom < b.createdAtCustom ? -1 : 1), this.nonAvailabilityCollection, this.filterFreeTimeByEmployee(this.employeeCollection.sort((a, b) => a.createdAtCustom < b.createdAtCustom ? -1 : 1), this.nonAvailabilityCollection, index)));
                this.isAnimating = false;
                this.overscroll = false;
                event === null || event === void 0 ? void 0 : event.target.complete();
            });
            this.overscroll = false;
            this.cd.detectChanges();
        });
    }
    setColumnWidthByEmployee() {
        if (this.employeeCollection.length === 1) {
            const width = window.innerWidth - 41;
            localStorage.setItem('columnWidth', width.toString());
            localStorage.setItem('tableWidth', window.innerWidth + 'px');
            localStorage.setItem('draggableWidth', window.innerWidth + 'px');
        }
        else if (this.employeeCollection.length === 2) {
            const width = (window.innerWidth - 41) / 2;
            const dragWidth = window.innerWidth - 41;
            localStorage.setItem('columnWidth', width.toString());
            localStorage.setItem('tableWidth', window.innerWidth + 'px');
            localStorage.setItem('draggableWidth', dragWidth + 'px');
        }
        else {
            localStorage.setItem('columnWidth', '150');
            localStorage.setItem('tableWidth', '100%');
            localStorage.setItem('draggableWidth', this.employeeCollection.length * 150 + 'px');
        }
    }
    findAllBookingByWeek(commerce, week) {
        return this.bookingService.findAllBookingByWeek(commerce, week);
    }
    findAllBookingByDay(commerce, date) {
        return this.bookingService.findAllBookingByDay(commerce, date);
    }
    findAllNonAvailabilityByDay(commerce, date) {
        return this.nonAvailabilityService.findAllNonAvailabilityByDay(commerce, date);
    }
    findAllNonAvailabilityByWeek(commerce, week) {
        return this.nonAvailabilityService.findAllNonAvailabilityByWeek(commerce, week);
    }
    findCommerceTimeTable(commerce) {
        return this.timetableService.findTimetableByCommerce(commerce);
    }
    findEmployees(commerce) {
        return this.employeeService.findEmployees(commerce);
    }
    selectDate(date) {
        this.isToday = (0,date_fns__WEBPACK_IMPORTED_MODULE_28__["default"])(date.date);
        this.selectedDay = date;
        this.indexSelected = this.selectedDay.date.getDay();
    }
    /*  requestBookingAndNonAvailability(date: string, commerce: string) {
       forkJoin([
         this.findAllBookingByDay(commerce, date),
         this.findAllNonAvailabilityByDay(commerce, date),
       ]).subscribe((res: [Booking[], NonAvailability[]]) => {
         this.timetable = null;
         this.timetable.push(this.buildTimetable(
           this.timeFrames,
           this.filterBookingByEmployee(res[0]),
           this.employeeCollection.sort((a: Employee, b: Employee) => a.createdAt < b.createdAt ? -1 : 1),
           this.filterNonAvailabilityByEmployee(res[1]),
           this.filterFreeTimeByEmployee()
         ));
       });
     } */
    presentEmployeeModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_29__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_shared_components_employee_list_employee_list_component__WEBPACK_IMPORTED_MODULE_15__.EmployeeListComponent,
                cssClass: 'my-custom-class',
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    selectedEmployeeCompo: this.filteredEmployees,
                },
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data.employee !== undefined) {
                // localStorage.setItem('filteredEmployee', JSON.stringify(data.employee));
                this.filteredEmployees = [...data.employee];
                this.employeeCollection = [...data.employee];
                this.selectDate(this.selectedDay);
            }
        });
    }
    filterBookingByEmployee(booking) {
        if (booking.length === 0) {
            return booking;
        }
        const newBook = [];
        this.employeeCollection.forEach((emp) => {
            booking.forEach((book) => {
                if (book.asignedTo.uuid === emp.uuid) {
                    newBook.push(book);
                }
            });
        });
        return newBook;
    }
    filterNonAvailabilityByEmployee(booking) {
        const newBook = [];
        this.employeeCollection.forEach((emp) => {
            booking.forEach((book) => {
                if (book.employee.uuid === emp.uuid) {
                    newBook.push(book);
                }
            });
        });
        return newBook;
    }
    filterFreeTimeByEmployee(employeeCollection, nonAvailabilityCollection, index) {
        const newBook = [];
        employeeCollection.forEach((emp) => {
            const nonAva = this.addNonAvailabilityEmployeeRest(emp, nonAvailabilityCollection, index);
            nonAva.map((item) => newBook.push(item));
        });
        return newBook;
    }
    addNonAvailabilityEmployeeRest(employee, nonAvailabilityCollection, index) {
        const isOnHolidays = nonAvailabilityCollection.filter((item) => item.employee.uuid === employee.uuid && item.message === 'Vacaciones');
        if (isOnHolidays.length === 0) {
            const newBook = [];
            const weekDay = src_app_core_enums_days_enum__WEBPACK_IMPORTED_MODULE_5__.EDays[index];
            const timetableDayEmployee = JSON.parse(employee.timetable[weekDay]);
            const timetableDayCommerce = JSON.parse(this.commerce.timetable[weekDay]);
            const startHourEmployee = new Date(2022, 1, 1, timetableDayEmployee.start.hour, timetableDayEmployee.start.minute);
            const startHourCommerce = new Date(2022, 1, 1, timetableDayCommerce.start.hour, timetableDayCommerce.start.minute);
            const endHourEmployee = new Date(2022, 1, 1, timetableDayEmployee.end.hour, timetableDayEmployee.end.minute);
            const endHourCommerce = new Date(2022, 1, 1, timetableDayCommerce.end.hour, timetableDayCommerce.end.minute);
            const startDifferenceMinutes = (0,date_fns__WEBPACK_IMPORTED_MODULE_30__["default"])(startHourEmployee, startHourCommerce);
            const endDifferenceMinutes = (0,date_fns__WEBPACK_IMPORTED_MODULE_30__["default"])(endHourCommerce, endHourEmployee);
            if (timetableDayEmployee.start.hour === null &&
                timetableDayCommerce.start.hour !== null) {
                const nonAva = new src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__.NonAvailability();
                nonAva.date = this.formatDate(this.selectedDay.date);
                nonAva.duration = startDifferenceMinutes;
                nonAva.employee = employee;
                nonAva.startHour = timetableDayCommerce.start.hour;
                nonAva.startMinute = timetableDayCommerce.start.minute;
                const rangeTable = {
                    start: {
                        hour: timetableDayCommerce.start.hour,
                        minute: timetableDayCommerce.start.minute,
                    },
                    end: {
                        hour: timetableDayCommerce.end.hour - 1,
                        minute: timetableDayCommerce.end.minute,
                    },
                };
                nonAva.timetable = JSON.stringify(rangeTable);
                nonAva.message = 'Libre';
                nonAva.uuid =
                    'fake-' +
                        Date.now().toString(36) +
                        Math.random().toString(36).substr(2);
                newBook.push(nonAva);
            }
            if (timetableDayEmployee.start.hour === null &&
                timetableDayCommerce.start.hour === null) {
                const nonAva = new src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__.NonAvailability();
                nonAva.date = this.formatDate(this.selectedDay.date);
                nonAva.duration = startDifferenceMinutes;
                nonAva.employee = employee;
                nonAva.startHour = timetableDayCommerce.start.hour;
                nonAva.startMinute = timetableDayCommerce.start.minute;
                const rangeTable = {
                    start: {
                        hour: 0,
                        minute: 0,
                    },
                    end: {
                        hour: 23,
                        minute: 59,
                    },
                };
                nonAva.timetable = JSON.stringify(rangeTable);
                nonAva.message = 'Libre';
                nonAva.uuid =
                    'fake-' +
                        Date.now().toString(36) +
                        Math.random().toString(36).substr(2);
                newBook.push(nonAva);
            }
            if (startDifferenceMinutes > 0) {
                const nonAva = new src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__.NonAvailability();
                nonAva.date = this.formatDate(this.selectedDay.date);
                nonAva.duration = startDifferenceMinutes;
                nonAva.employee = employee;
                nonAva.startHour = timetableDayCommerce.start.hour;
                nonAva.startMinute = timetableDayCommerce.start.minute;
                const rangeTable = {
                    start: {
                        hour: timetableDayCommerce.start.hour,
                        minute: timetableDayCommerce.start.minute,
                    },
                    end: {
                        hour: timetableDayEmployee.start.hour,
                        minute: timetableDayEmployee.start.minute,
                    },
                };
                nonAva.timetable = JSON.stringify(rangeTable);
                nonAva.message = 'Libre';
                nonAva.uuid =
                    'fake-' +
                        Date.now().toString(36) +
                        Math.random().toString(36).substr(2);
                newBook.push(nonAva);
            }
            if (endDifferenceMinutes > 0) {
                const nonAva = new src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__.NonAvailability();
                nonAva.date = this.formatDate(this.selectedDay.date);
                nonAva.duration = endDifferenceMinutes;
                nonAva.employee = employee;
                nonAva.startHour = timetableDayCommerce.start.hour;
                nonAva.startMinute = timetableDayCommerce.start.minute;
                const rangeTable = {
                    start: {
                        hour: timetableDayEmployee.end.hour,
                        minute: timetableDayEmployee.end.minute,
                    },
                    end: {
                        hour: timetableDayCommerce.end.hour,
                        minute: timetableDayCommerce.end.minute,
                    },
                };
                nonAva.timetable = JSON.stringify(rangeTable);
                nonAva.message = 'Libre';
                nonAva.uuid =
                    'fake-' +
                        Date.now().toString(36) +
                        Math.random().toString(36).substr(2);
                newBook.push(nonAva);
            }
            if (timetableDayEmployee.rest) {
                const nonAva = new src_app_core_models_non_availability_model__WEBPACK_IMPORTED_MODULE_7__.NonAvailability();
                nonAva.date = this.formatDate(this.selectedDay.date);
                nonAva.duration = startDifferenceMinutes;
                nonAva.employee = employee;
                nonAva.startHour = timetableDayCommerce.start.hour;
                nonAva.startMinute = timetableDayCommerce.start.minute;
                const rangeTable = {
                    start: {
                        hour: timetableDayEmployee.rest.start.hour,
                        minute: timetableDayEmployee.rest.start.minute,
                    },
                    end: {
                        hour: timetableDayEmployee.rest.end.hour,
                        minute: timetableDayEmployee.rest.end.minute,
                    },
                };
                nonAva.timetable = JSON.stringify(rangeTable);
                nonAva.message = 'Descanso';
                nonAva.uuid =
                    'fake-' +
                        Date.now().toString(36) +
                        Math.random().toString(36).substr(2);
                newBook.push(nonAva);
            }
            return newBook;
        }
        return [];
    }
    nextMonth() {
        [this.selectedDay] = this.formatDateToDays([
            (0,date_fns__WEBPACK_IMPORTED_MODULE_31__["default"])(this.selectedDay.date, 1),
        ]);
        this.selectDate(this.selectedDay);
        this.getThisWeekDays();
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
    }
    prevMonth() {
        [this.selectedDay] = this.formatDateToDays([
            (0,date_fns__WEBPACK_IMPORTED_MODULE_32__["default"])(this.selectedDay.date, 1),
        ]);
        this.selectDate(this.selectedDay);
        this.getThisWeekDays();
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
    }
    displayMonthAndYear() {
        const month = (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(this.selectedDay.date, 'LLLL', {
            locale: date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__["default"],
        }).toUpperCase();
        return month;
    }
    dateChanged(value) {
        const date = new Date(value);
        this.selectDate(this.formatDateToDays([date])[0]);
        const startDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])(this.selectedDay.date);
        const nextDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_34__["default"])(startDay, 0));
        const lastDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])(nextDayWeek);
        this.days = this.formatDateToDays(this.returnDaysOfWeek(nextDayWeek, lastDayWeek));
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
        this.dismissModal('open-modal-calendar');
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    getTodayWeek() {
        const startDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])(new Date());
        const nextDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_34__["default"])(startDay, 0));
        const lastDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])(nextDayWeek);
        this.days = this.formatDateToDays(this.returnDaysOfWeek(nextDayWeek, lastDayWeek));
    }
    getThisWeekDays() {
        const startDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])(this.selectedDay.date);
        const nextDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_34__["default"])(startDay, 0));
        const lastDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])(nextDayWeek);
        this.days = this.formatDateToDays(this.returnDaysOfWeek(nextDayWeek, lastDayWeek));
    }
    getNextWeekDays() {
        const endDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_36__["default"])(this.selectedDay.date, 0));
        const nextDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_34__["default"])(endDay, 0));
        const lastDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])(nextDayWeek);
        const collection = this.returnDaysOfWeek(nextDayWeek, lastDayWeek);
        this.days = this.formatDateToDays(collection);
        this.selectedDay = this.days[0];
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
        this.selectDate(this.selectedDay);
    }
    getPreviousWeekDays() {
        const startDay = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_37__["default"])(this.selectedDay.date, 0));
        const nextDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_33__["default"])((0,date_fns__WEBPACK_IMPORTED_MODULE_38__["default"])(startDay, 0));
        const lastDayWeek = (0,date_fns__WEBPACK_IMPORTED_MODULE_35__["default"])(nextDayWeek);
        const collection = this.returnDaysOfWeek(nextDayWeek, lastDayWeek);
        this.days = this.formatDateToDays(collection);
        this.selectedDay = this.days[0];
        this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
            weekStartsOn: 1,
            firstWeekContainsDate: 4,
        }));
        this.selectDate(this.selectedDay);
    }
    formatDateToDays(weekDays) {
        const daysCollection = [];
        weekDays.forEach((day) => {
            const newDay = new src_app_core_models_day_model__WEBPACK_IMPORTED_MODULE_6__.DayModel();
            newDay.date = day;
            newDay.dayNumber = (0,date_fns__WEBPACK_IMPORTED_MODULE_27__["default"])(day);
            newDay.name = (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(day, 'EEEEE', { locale: date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__["default"] });
            newDay.shortName = (0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(day, 'EEE', { locale: date_fns_locale_es__WEBPACK_IMPORTED_MODULE_18__["default"] });
            newDay.month = (0,date_fns__WEBPACK_IMPORTED_MODULE_26__["default"])(day);
            daysCollection.push(newDay);
        });
        return daysCollection;
    }
    openBooking(value) {
        if (value.book.isBooking) {
            this.navCtrl.navigateForward([`booking/${value.book.uuid}`], {
                relativeTo: this.activatedRoute,
            });
        }
        else {
            if (open) {
                this.navCtrl.navigateForward([`non-availability/${value.book.uuid}`], {
                    relativeTo: this.activatedRoute,
                });
            }
        }
    }
    updateBooking(booking) {
        console.log(booking);
        const indexEmployee = booking.mobilePosition.x /
            parseInt(localStorage.getItem('columnWidth'), 10);
        const employee = this.employeeCollection[indexEmployee];
        booking.asignedTo = employee;
        if (booking.isBooking) {
            this.bookingService.updateBooking(booking).subscribe((response) => {
                if (response) {
                    this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
                        weekStartsOn: 1,
                        firstWeekContainsDate: 4,
                    }));
                }
            });
        }
        else {
            const nonAva = new src_app_core_dto_non_availability_dto__WEBPACK_IMPORTED_MODULE_16__.NonAvailabilityDto();
            nonAva.uuid = booking.uuid;
            nonAva.date = booking.startsDay;
            nonAva.commerce = booking.commerce;
            const scheduleHourStart = {
                hour: booking.startsHour,
                minute: booking.startsMinute
            };
            const startDate = new Date(2022, 1, 1, booking.startsHour, booking.startsMinute);
            const endDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_39__["default"])(startDate, booking.duration);
            const scheduleHourEnd = {
                hour: (0,date_fns__WEBPACK_IMPORTED_MODULE_40__["default"])(endDate),
                minute: (0,date_fns__WEBPACK_IMPORTED_MODULE_41__["default"])(endDate)
            };
            const timetable = {
                start: scheduleHourStart,
                end: scheduleHourEnd
            };
            nonAva.timetable = JSON.stringify(timetable);
            nonAva.employee = booking.asignedTo;
            nonAva.message = booking.message;
            nonAva.week = booking.week;
            console.log(nonAva);
            this.nonAvailabilityService.editNonAvailability(nonAva).subscribe((response) => {
                if (response) {
                    this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
                        weekStartsOn: 1,
                        firstWeekContainsDate: 4,
                    }));
                }
            });
        }
    }
    buildTimetable(timeframes, bookings, employee, nonAvailability, freeTime) {
        const newTimeTable = new src_app_core_builder_timetable_builder__WEBPACK_IMPORTED_MODULE_4__.TimeTableBuilder()
            .setEmployees(employee)
            .setTimeFrames(timeframes)
            .setBookings(bookings)
            .setNonAvailability(nonAvailability)
            .setFreeTime(freeTime)
            .build();
        return newTimeTable;
    }
    editBookingProcess(event) {
        if (event) {
            this.editBooking = true;
        }
        else {
            this.editBooking = false;
        }
    }
    editBookingConfirmation(action) {
        if (action) {
            this.editBookingService.editBookingConfirm.next(true);
        }
        else {
            this.editBookingService.editBookingConfirm.next(false);
            this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
                weekStartsOn: 1,
                firstWeekContainsDate: 4,
            }));
        }
    }
    overScrollEmitted(event) {
        if (event && !this.isAnimating) {
            this.overscroll = true;
            this.isAnimating = true;
            this.overmsg = 'Suelta para actualizar';
        }
    }
    overscrollEndEmitter(event) {
        this.overmsg = 'Actualizando...';
        this.cd.detectChanges();
        setTimeout(() => {
            this.concatRequiredRequest(this.commerceLogged, (0,date_fns__WEBPACK_IMPORTED_MODULE_20__["default"])(this.selectedDay.date, {
                weekStartsOn: 1,
                firstWeekContainsDate: 4,
            }));
        }, 2000);
    }
    ngOnDestroy() {
        this.timetable = null;
    }
};
BookingManagerPage.ctorParameters = () => [
    { type: src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_8__.BookingService },
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_9__.EmployeeService },
    { type: src_app_core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_11__.TimeTableService },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_12__.DateService },
    { type: src_app_core_services_non_availability_non_availability_service__WEBPACK_IMPORTED_MODULE_10__.NonAvailabilityService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_42__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_42__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_42__.IonRouterOutlet },
    { type: src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_13__.EditBooking },
    { type: src_app_core_app_settings_service__WEBPACK_IMPORTED_MODULE_3__.AppSettingsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_43__.ActivatedRoute },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_44__.ChangeDetectorRef }
];
BookingManagerPage.propDecorators = {
    dateslide: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_44__.ViewChild, args: ['slideDate',] }],
    actionSheet: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_44__.ViewChild, args: [src_app_shared_components_action_sheet_action_sheet_component__WEBPACK_IMPORTED_MODULE_14__.ActionSheetComponent,] }]
};
BookingManagerPage = (0,tslib__WEBPACK_IMPORTED_MODULE_29__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_44__.Component)({
        selector: 'app-booking-manager',
        template: _booking_manager_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_44__.ChangeDetectionStrategy.OnPush,
        styles: [_booking_manager_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BookingManagerPage);



/***/ }),

/***/ 88664:
/*!**************************************************************************!*\
  !*** ./src/app/shared/components/action-sheet/action-sheet.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionSheetComponent": () => (/* binding */ ActionSheetComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _action_sheet_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./action-sheet.component.html?ngResource */ 23903);
/* harmony import */ var _action_sheet_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./action-sheet.component.scss?ngResource */ 46638);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utils/editBooking.service */ 24097);







let ActionSheetComponent = class ActionSheetComponent {
    constructor(actionSheetController, modalOppened, navCtrl, activatedRoute) {
        this.actionSheetController = actionSheetController;
        this.modalOppened = modalOppened;
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
    }
    ngOnInit() { }
    presentActionSheet(bookingData, selectedDay) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const navigationExtras = {
                state: { selectedDay },
                relativeTo: this.activatedRoute
            };
            if (bookingData) {
                navigationExtras.state.bookingData = bookingData;
            }
            ;
            this.actionSheet = yield this.actionSheetController.create({
                backdropDismiss: true,
                buttons: [
                    {
                        text: 'Crear cita',
                        role: 'booking',
                        data: bookingData,
                        handler: () => {
                            this.navCtrl.navigateForward(['new-booking'], navigationExtras);
                        },
                    },
                    {
                        text: 'Reserva de tiempo',
                        role: 'non-availability',
                        data: bookingData,
                        handler: () => {
                            this.navCtrl.navigateForward(['non-availability'], navigationExtras);
                        },
                    },
                    {
                        text: 'Cancelar',
                        icon: 'close',
                        role: 'destructive',
                        handler: () => {
                            this.modalOppened.modalOppened.next(false);
                        },
                    },
                ],
            });
            yield this.actionSheet.present();
            yield this.actionSheet.onDidDismiss().then(() => this.modalOppened.modalOppened.next(false));
            this.modalOppened.modalOppened.next(true);
        });
    }
};
ActionSheetComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ActionSheetController },
    { type: src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_2__.EditBooking },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute }
];
ActionSheetComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-action-sheet',
        template: _action_sheet_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_action_sheet_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ActionSheetComponent);



/***/ }),

/***/ 49722:
/*!***********************************************************************!*\
  !*** ./src/app/shared/components/action-sheet/action-sheet.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionSheetModule": () => (/* binding */ ActionSheetModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _action_sheet_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./action-sheet.component */ 88664);




let ActionSheetModule = class ActionSheetModule {
};
ActionSheetModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_action_sheet_component__WEBPACK_IMPORTED_MODULE_0__.ActionSheetComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_action_sheet_component__WEBPACK_IMPORTED_MODULE_0__.ActionSheetComponent],
    })
], ActionSheetModule);



/***/ }),

/***/ 35781:
/*!******************************************************************!*\
  !*** ./src/app/shared/components/datetime/datetime.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatetimeComponent": () => (/* binding */ DatetimeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _datetime_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datetime.component.html?ngResource */ 50002);
/* harmony import */ var _datetime_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datetime.component.scss?ngResource */ 84294);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let DatetimeComponent = class DatetimeComponent {
    constructor() {
        this.viewDateTime = false;
    }
    ngOnInit() { }
    toogle() {
        this.viewDateTime = !this.viewDateTime;
    }
};
DatetimeComponent.ctorParameters = () => [];
DatetimeComponent.propDecorators = {
    actualDate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
DatetimeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-datetime',
        template: _datetime_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_datetime_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DatetimeComponent);



/***/ }),

/***/ 73306:
/*!***************************************************************!*\
  !*** ./src/app/shared/components/datetime/datetime.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatetimeModule": () => (/* binding */ DatetimeModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _datetime_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datetime.component */ 35781);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let DatetimeModule = class DatetimeModule {
};
DatetimeModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_datetime_component__WEBPACK_IMPORTED_MODULE_0__.DatetimeComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule],
        exports: [_datetime_component__WEBPACK_IMPORTED_MODULE_0__.DatetimeComponent],
    })
], DatetimeModule);



/***/ }),

/***/ 42279:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/employee-list/employee-list.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeListComponent": () => (/* binding */ EmployeeListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _employee_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-list.component.html?ngResource */ 96951);
/* harmony import */ var _employee_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-list.component.scss?ngResource */ 71808);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/employee/employee.service */ 86075);






let EmployeeListComponent = class EmployeeListComponent {
    constructor(employeeService, modalCtrl) {
        this.employeeService = employeeService;
        this.modalCtrl = modalCtrl;
        this.employeeCollection = [];
        this.employeeCollectionFiltered = [];
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
    }
    ngOnInit() {
        this.getAllemployee();
    }
    getAllemployee() {
        this.employeeService
            .findEmployees(this.commerceLogged)
            .subscribe((res) => {
            if (res && res.length > 0) {
                this.employeeCollection = res.filter(item => item.services && item.services.length > 0);
                this.employeeCollectionFiltered = this.employeeCollection;
            }
        });
    }
    selectEmployee(item) {
        if (!this.selectedEmployeeCompo.some((itemEmp) => itemEmp.uuid === item.uuid)) {
            this.selectedEmployeeCompo.push(item);
        }
        else {
            this.selectedEmployeeCompo = this.selectedEmployeeCompo.filter((itemEmp) => itemEmp.uuid !== item.uuid);
        }
    }
    searchEmployee(event) {
        const value = event.target.value;
        this.employeeCollectionFiltered = this.employeeCollection;
        if (value.length >= 3) {
            this.employeeCollectionFiltered = this.employeeCollectionFiltered.filter((customer) => customer.name.toLowerCase().includes(value.toLowerCase()));
        }
    }
    dismiss() {
        this.modalCtrl.dismiss({
            employee: this.selectedEmployeeCompo
        });
    }
    checkIfSelected(employee) {
        return this.selectedEmployeeCompo.some((emp) => emp.uuid === employee.uuid);
    }
};
EmployeeListComponent.ctorParameters = () => [
    { type: src_app_core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_2__.EmployeeService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController }
];
EmployeeListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-employee-list',
        template: _employee_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeListComponent);



/***/ }),

/***/ 93560:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/employee-list/employee-list.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeListModule": () => (/* binding */ EmployeeListModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _employee_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-list.component */ 42279);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let EmployeeListModule = class EmployeeListModule {
};
EmployeeListModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_employee_list_component__WEBPACK_IMPORTED_MODULE_0__.EmployeeListComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ]
    })
], EmployeeListModule);



/***/ }),

/***/ 17404:
/*!******************************************************************!*\
  !*** ./src/app/shared/components/employee/employee.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeComponent": () => (/* binding */ EmployeeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _employee_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee.component.html?ngResource */ 39954);
/* harmony import */ var _employee_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee.component.scss?ngResource */ 17941);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let EmployeeComponent = class EmployeeComponent {
    constructor() {
        const value = localStorage.getItem('columnWidth');
        this.columnWidth = value + 'px';
    }
    ngOnInit() { }
};
EmployeeComponent.ctorParameters = () => [];
EmployeeComponent.propDecorators = {
    employee: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
EmployeeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-employee',
        template: _employee_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeComponent);



/***/ }),

/***/ 27525:
/*!***************************************************************!*\
  !*** ./src/app/shared/components/employee/employee.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeModule": () => (/* binding */ EmployeeModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _employee_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee.component */ 17404);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let EmployeeModule = class EmployeeModule {
};
EmployeeModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_employee_component__WEBPACK_IMPORTED_MODULE_0__.EmployeeComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule],
        exports: [_employee_component__WEBPACK_IMPORTED_MODULE_0__.EmployeeComponent],
    })
], EmployeeModule);



/***/ }),

/***/ 78243:
/*!**********************************************************************************!*\
  !*** ./src/app/shared/components/reservation-card/reservation-card.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReservationCardComponent": () => (/* binding */ ReservationCardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _reservation_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reservation-card.component.html?ngResource */ 87932);
/* harmony import */ var _reservation_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reservation-card.component.scss?ngResource */ 9439);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 78394);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! date-fns */ 60745);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! date-fns */ 86118);






let ReservationCardComponent = class ReservationCardComponent {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    calc(duration) {
        const height = ((duration / 15) * 100) / this.rowspan;
        return height + '%';
    }
    addZeroToMinutes(str) {
        const strSplitted = str.split(':');
        const minutes = strSplitted[1];
        if (minutes.length < 2) {
            return str + '0';
        }
        return str;
    }
    formatBookingTimetable(booking) {
        const newDate = new Date(2022, 1, 1, booking.startsHour, booking.startsMinute);
        const endDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_2__["default"])(newDate, booking.duration);
        const starting = this.addZeroToMinutes(booking.startsHour + ':' + booking.startsMinute);
        const ending = this.addZeroToMinutes((0,date_fns__WEBPACK_IMPORTED_MODULE_3__["default"])(endDate) + ':' + (0,date_fns__WEBPACK_IMPORTED_MODULE_4__["default"])(endDate));
        return starting + '-' + ending;
    }
};
ReservationCardComponent.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.DomSanitizer }
];
ReservationCardComponent.propDecorators = {
    reservation: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }],
    rowspan: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
ReservationCardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-reservation-card',
        template: _reservation_card_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_reservation_card_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReservationCardComponent);



/***/ }),

/***/ 3201:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/reservation-card/reservation-card.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReservationCardModule": () => (/* binding */ ReservationCardModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _reservation_card_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reservation-card.component */ 78243);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let ReservationCardModule = class ReservationCardModule {
};
ReservationCardModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_reservation_card_component__WEBPACK_IMPORTED_MODULE_0__.ReservationCardComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule],
        exports: [_reservation_card_component__WEBPACK_IMPORTED_MODULE_0__.ReservationCardComponent],
    })
], ReservationCardModule);



/***/ }),

/***/ 95022:
/*!******************************************************************************************************!*\
  !*** ./src/app/shared/components/time-table-header-employee/time-table-header-employee.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableHeaderEmployeeComponent": () => (/* binding */ TimeTableHeaderEmployeeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _time_table_header_employee_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./time-table-header-employee.component.html?ngResource */ 94773);
/* harmony import */ var _time_table_header_employee_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./time-table-header-employee.component.scss?ngResource */ 74357);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);




let TimeTableHeaderEmployeeComponent = class TimeTableHeaderEmployeeComponent {
    constructor() { }
};
TimeTableHeaderEmployeeComponent.ctorParameters = () => [];
TimeTableHeaderEmployeeComponent.propDecorators = {
    employeeCollection: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
TimeTableHeaderEmployeeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-time-table-header-employee',
        template: _time_table_header_employee_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_time_table_header_employee_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TimeTableHeaderEmployeeComponent);



/***/ }),

/***/ 2602:
/*!***************************************************************************************************!*\
  !*** ./src/app/shared/components/time-table-header-employee/time-table-header-employee.module.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableHeaderEmployeeModule": () => (/* binding */ TimeTableHeaderEmployeeModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _time_table_header_employee_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./time-table-header-employee.component */ 95022);




let TimeTableHeaderEmployeeModule = class TimeTableHeaderEmployeeModule {
};
TimeTableHeaderEmployeeModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_time_table_header_employee_component__WEBPACK_IMPORTED_MODULE_0__.TimeTableHeaderEmployeeComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_time_table_header_employee_component__WEBPACK_IMPORTED_MODULE_0__.TimeTableHeaderEmployeeComponent],
    })
], TimeTableHeaderEmployeeModule);



/***/ }),

/***/ 6293:
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/time-table/time-table.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableComponent": () => (/* binding */ TimeTableComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _time_table_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./time-table.component.html?ngResource */ 89113);
/* harmony import */ var _time_table_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./time-table.component.scss?ngResource */ 89757);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_app_core_models_reservation_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/reservation.model */ 27601);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 76027);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 30606);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/cdk/scrolling */ 43970);
/* harmony import */ var src_app_core_interfaces_card_reservation_interface__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/interfaces/card-reservation.interface */ 62518);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! date-fns */ 60745);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! date-fns */ 86118);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! date-fns */ 9165);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! date-fns */ 38776);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_core_enums_colors_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/enums/colors.enum */ 58061);
/* harmony import */ var src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utils/editBooking.service */ 24097);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! gsap */ 43867);
/* harmony import */ var gsap_Draggable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! gsap/Draggable */ 82032);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ 85566);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);



/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable prefer-arrow/prefer-arrow-functions */
/* eslint-disable max-len */













gsap__WEBPACK_IMPORTED_MODULE_8__.gsap.registerPlugin(gsap_Draggable__WEBPACK_IMPORTED_MODULE_9__.Draggable);
let TimeTableComponent = class TimeTableComponent {
    constructor(scroll, dateService, editBookingService, cdr, platform, renderer) {
        this.scroll = scroll;
        this.dateService = dateService;
        this.editBookingService = editBookingService;
        this.cdr = cdr;
        this.platform = platform;
        this.renderer = renderer;
        this.navigateTo = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.updateBooking = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.longPressAction = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.editBooking = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.overscrollEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.overscrollEndEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
        this.dragPosition = [];
        this.$reservations = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject([]);
        this.$freeTime = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject([]);
        this.$editedBookingPosition = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject(null);
        this.$actualHour = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject(0);
        this.allOverlappedBookingsCollection = [];
        this.isGhosting = false;
        this.ghostingData = null;
        this.isOverlapCollection = [];
        this.isReady = false;
        this.sharedColumn = [];
        this.draggableItem = null;
        this.isEditting = false;
        this.eColor = src_app_core_enums_colors_enum__WEBPACK_IMPORTED_MODULE_5__.EColors;
        this.isScrolling = false;
        this.touchduration = 500; //length of time we want the user to touch before we do something
        this.oldOverlap = [];
        this.isBeingAutoScrolled = false;
        this.bookingTimeCollection = [];
        this.isDragging = false;
        this.draggingBooking = null;
        this.isHorizontal = true;
        this.isVertical = true;
        this.event = null;
        if (this.platform.is('ios')) {
            this.containerHeight = window.innerHeight - 273.5;
            this.leftByPlatform = '39px';
        }
        else {
            this.containerHeight = window.innerHeight - 198.5;
            this.leftByPlatform = '30px';
        }
        this.first = {
            delta: {
                x: 0,
                y: 0,
            },
            distance: {
                x: 0,
                y: 0,
            },
            id: null,
        };
        this.$position = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject(this.first);
        this.dragPosition = [];
        this.deviceHieght = this.platform.height();
    }
    onTouchStart(ev) {
        this.event = ev;
        this.overscroll = false;
        this.startY = ev.touches[0].pageY;
    }
    onScroll(e) {
        this.isScrolling = true;
        const y = e.touches[0].pageY;
        if (this.event) {
            if (!this.isHorizontal ||
                e.touches[0].pageY > this.event.touches[0].pageY + 100 ||
                e.changedTouches[0].pageY < this.event.changedTouches[0].pageY - 100) {
                this.isVertical = true;
                this.isHorizontal = false;
            }
            else if (!this.isVertical ||
                e.touches[0].pageX > this.event.touches[0].pageX + 50 ||
                e.changedTouches[0].pageX < this.event.changedTouches[0].pageX - 50) {
                this.isVertical = false;
                this.isHorizontal = true;
            }
        }
        if (document.querySelector('#container').scrollTop === 0 &&
            y > this.startY + 100 && this.draggableItem === null && !this.isGhosting) {
            this.overscroll = true;
            this.overscrollEmitter.emit(this.overscroll);
        }
    }
    onTouchEnd() {
        this.isScrolling = false;
        this.event = null;
        this.isVertical = true;
        this.isHorizontal = true;
        if (this.overscroll && this.draggableItem === null && !this.isGhosting) {
            this.overscrollEndEmitter.emit(true);
            this.overscroll = false;
        }
    }
    scrollLeft(value) {
        const elem = document.getElementById('container');
        elem.scrollLeft = value;
    }
    scrollToTimeline(value) {
        const elem = document.getElementById('container');
        elem.scrollTop = value - 150;
    }
    ionViewVillEnter() { }
    ngOnInit() {
        this.editBookingConfirmation();
        this.modalOpened();
        this.draggableItem = null;
        this.isGhosting = false;
    }
    ngAfterViewInit() {
        this.setEqualHeightForDivs();
    }
    ngOnChanges(changes) {
        var _a, _b, _c, _d;
        if (((_a = changes.timetable) === null || _a === void 0 ? void 0 : _a.currentValue) !== null) {
            this.tableWidth = localStorage.getItem('tableWidth');
            this.dragWidth = localStorage.getItem('draggableWidth');
            this.columnWidth = parseInt(localStorage.getItem('columnWidth'), 10);
            this.isGhosting = false;
            console.log((_b = changes.timetable) === null || _b === void 0 ? void 0 : _b.currentValue);
            this.draggableItem = null;
            this.draggableInstance = null;
            this.fillCardsPosition((_c = this.timetable) === null || _c === void 0 ? void 0 : _c.bookings);
            this.fillFreetimePosition((_d = this.timetable) === null || _d === void 0 ? void 0 : _d.freeTime);
            this.setFirstSize(this.timetable.bookings);
            this.setFirstFreeTimeSize(this.timetable.freeTime);
            const minute = 60000;
            const $timer = (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.timer)(0, minute);
            this.$actualHour.next(null);
            this.$actualHour.next(this.setActualTimeInPixels(this.timetable));
            $timer.subscribe((value) => {
                if (value < 1) {
                    if (this.isToday) {
                        this.scrollToTimeline(this.$actualHour.value);
                    }
                }
            });
            this.setEqualHeightForDivs();
        }
    }
    modalOpened() {
        this.editBookingService.modalOppened.subscribe((res) => {
            if (!res && this.isGhosting) {
                this.removeGhost();
                this.isGhosting = false;
                this.isEditting = false;
                this.draggableItem = null;
            }
        });
    }
    removeGhost() {
        this.$reservations.next(this.$reservations.value.filter((item) => item.uuid !== 'ghost_'));
    }
    createDraggable(isGhost) {
        const self = this;
        const gridWidth = this.columnWidth;
        const gridHeight = 8;
        const gridRows = this.timetable.timeFrames.length * 3;
        const gridColumns = this.timetable.employees.length;
        const liveSnap = true;
        this.draggableInstance = gsap_Draggable__WEBPACK_IMPORTED_MODULE_9__.Draggable.create('.draggableItem', {
            bounds: {
                minX: 0,
                minY: 0,
                maxX: this.columnWidth * this.timetable.employees.length - this.columnWidth,
                maxY: this.timetable.timeFrames.length * 24 -
                    this.draggingBooking.mobileSize.height,
            },
            edgeResistance: 1,
            type: 'x,y',
            allowNativeTouchScrolling: true,
            zIndexBoost: false,
            inertia: true,
            autoScroll: 1,
            liveSnap: true,
            dragClickables: false,
            onDragStart(start) {
                self.draggingBooking.mobileSize.width = this.columnWidth;
                gsap__WEBPACK_IMPORTED_MODULE_8__.gsap.set(`._${self.draggingBooking.uuid}`, {
                    width: gridWidth,
                    left: 0,
                });
            },
            onDrag(move) {
                if (self.draggingBooking !== undefined) {
                    self.isDragging = true;
                    self.draggingData = self.realTimeHourByPostion(this.endY);
                    self.cdr.detectChanges();
                }
            },
            onDragEnd(e) {
                self.isDragging = false;
                const newCardPosition = new src_app_core_interfaces_card_reservation_interface__WEBPACK_IMPORTED_MODULE_3__.CardsPosition();
                const uuid = isGhost ? 'ghost_' : e.target.id;
                const elem = document.getElementById(uuid);
                const style = window.getComputedStyle(elem);
                const matrix = new WebKitCSSMatrix(style.transform);
                newCardPosition.uuid = uuid;
                const position = {
                    x: matrix.m41,
                    y: this.endY,
                };
                if (this.endY >= 0) {
                    self.newhourByPosition(uuid, this.endY, isGhost);
                }
                newCardPosition.position = position;
                self.setNewPositionFGhost(newCardPosition);
                if (isGhost) {
                    const index = matrix.m41 / self.columnWidth;
                    self.ghostingData.employee = self.timetable.employees[index];
                    self.longPressAction.emit(self.ghostingData);
                }
                self.cdr.detectChanges();
            },
            snap: {
                x(endValue) {
                    return liveSnap
                        ? Math.round(endValue / gridWidth) * gridWidth
                        : endValue;
                },
                y(endValue) {
                    return liveSnap
                        ? Math.round(endValue / gridHeight) * gridHeight
                        : endValue;
                },
            },
        });
    }
    getDraggableInstanceIndexByUuid(uuid) {
        return this.draggableInstance.findIndex((instance) => instance.target.id === uuid);
    }
    setEqualHeightForDivs() {
        const cardsDiv = document.getElementById('draggableZone');
        const containerDiv = document.getElementById('container');
        const timeline = document.getElementById('timeline');
        if (timeline) {
            timeline.style.width = `${this.timetable.employees.length * this.columnWidth}px`;
        }
        if (cardsDiv) {
            cardsDiv.style.height = `${this.timetable.timeFrames.length * 24}px`;
            this.viewHeight = this.timetable.timeFrames.length * 24;
        }
    }
    formatDate(date) {
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_13__["default"])(date, 'yyyy-MM-dd');
    }
    realTimeHourByPostion(yValue) {
        if (this.draggingBooking) {
            let time;
            if (yValue === 0) {
                time = {
                    hours: parseInt(this.timetable.timeFrames[0].split(':')[0], 10),
                    minutes: parseInt(this.timetable.timeFrames[0].split(':')[1], 10),
                };
            }
            else {
                time = this.calculateHourByPixel(yValue / 24, this.timetable);
            }
            const bookingTime = {
                uuid: this.draggingBooking.uuid,
                time,
            };
            const timeStr = this.dateService.formatBookingTimetable(bookingTime.time.hours, bookingTime.time.minutes, this.draggingBooking.duration);
            return { uuid: this.draggingBooking.uuid, time: timeStr };
        }
    }
    newhourByPosition(uuid, yValue, isGhost) {
        const time = this.calculateHourByPixel(yValue / 24, this.timetable);
        const bookingTime = {
            uuid,
            time,
        };
        if (isGhost) {
            this.ghostingData.selectedHour = {
                hours: bookingTime.time.hours,
                minutes: bookingTime.time.minutes,
            };
        }
        this.$reservations.value.map((book) => {
            if (book.uuid === uuid) {
                book.startsHour = bookingTime.time.hours;
                book.startsMinute = bookingTime.time.minutes;
                return book;
            }
        });
    }
    hourByPosition(uuid) {
        const elementChild = document.getElementById(uuid);
        const elementParent = document.getElementById('draggableZone');
        const domRectChild = elementChild === null || elementChild === void 0 ? void 0 : elementChild.getBoundingClientRect();
        const domRectParent = elementParent === null || elementParent === void 0 ? void 0 : elementParent.getBoundingClientRect();
        const relativePos = domRectChild.top - domRectParent.top;
        const time = this.calculateHourByPixel(relativePos / 24, this.timetable);
        const bookingTime = {
            uuid,
            time,
        };
        this.$reservations.value.map((book) => {
            if (book.uuid === uuid) {
                book.startsHour = bookingTime.time.hours;
                book.startsMinute = bookingTime.time.minutes;
                return book;
            }
        });
    }
    openBooking(booking, isBooking) {
        if (this.draggableItem === null && !booking.isGhost) {
            this.navigateTo.emit({ book: booking, isBooking });
        }
    }
    calculateHourByPixel(value, timetable) {
        const time = {
            hours: 0,
            minutes: 0,
        };
        if (value >= 0) {
            const index = parseInt(value.toString().split('.')[0], 10);
            const hour = timetable.timeFrames[index];
            time.hours = parseInt(hour.split(':')[0], 10);
            time.minutes =
                parseInt(hour.split(':')[1], 10) +
                    Math.round((value - Math.floor(value)) / 0.3) * 5;
            if (time.minutes === 60) {
                time.hours === 23 ? (time.hours = 0) : (time.hours += 1);
                time.minutes = 0;
            }
        }
        return time;
    }
    setActualTimeInPixels(timetable) {
        const initialTimetableHour = parseInt(timetable.timeFrames[0].split(':')[0], 10);
        const initialTimetableMinute = parseInt(timetable.timeFrames[0].split(':')[1], 10);
        const actualHour = (0,date_fns__WEBPACK_IMPORTED_MODULE_14__["default"])(new Date());
        const actualMin = (0,date_fns__WEBPACK_IMPORTED_MODULE_15__["default"])(new Date());
        const pixelsInHour = (actualHour - initialTimetableHour) * 96;
        const pixelsInMin = (Math.ceil(actualMin - initialTimetableMinute) * 96) / 60;
        const totalPixels = pixelsInHour + pixelsInMin;
        return totalPixels + 50;
    }
    newCheckOverlap(id) {
        const bookingSelected = this.$reservations.value.find((item) => item.uuid === id);
        if (bookingSelected) {
            const y2 = bookingSelected.mobilePosition.y;
            const h2 = bookingSelected.mobileSize.height;
            const t2 = y2 + h2;
            const bookingOverlap = this.$reservations.value.filter((item) => {
                const h1 = item.mobileSize.height;
                const y1 = item.mobilePosition.y;
                const t1 = h1 + y1;
                if (item.uuid !== bookingSelected.uuid &&
                    item.mobilePosition.x === bookingSelected.mobilePosition.x) {
                    if (y1 <= y2 && y2 < t1) {
                        item.isOverlapped = true;
                        return true;
                    }
                    else if (y1 > y2 && y1 < t2) {
                        item.isOverlapped = true;
                        return true;
                    }
                }
                return false;
            });
            const elementSelected = document.getElementById(bookingSelected.uuid);
            if (bookingOverlap.some((item) => this.oldOverlap.includes(item))) {
                this.oldOverlap = bookingOverlap;
                this.oldOverlap.push(bookingSelected);
                if (elementSelected) {
                    elementSelected.style.width =
                        this.columnWidth / this.oldOverlap.length + 'px';
                }
                this.sortByID(this.oldOverlap).forEach((item, index) => {
                    item.isOverlapped = true;
                    this.resizeCards(item, index, this.oldOverlap);
                });
            }
            else if (bookingOverlap.length > 0) {
                this.oldOverlap = bookingOverlap;
                this.oldOverlap.push(bookingSelected);
                this.allOverlappedBookingsCollection.push(this.oldOverlap);
                this.sortByID(this.oldOverlap).forEach((item, index) => {
                    item.isOverlapped = true;
                    this.resizeCards(item, index, bookingOverlap);
                });
                if (elementSelected) {
                    elementSelected.style.width =
                        this.columnWidth / this.oldOverlap.length + 'px';
                }
                this.sortByID(bookingOverlap).forEach((item, index) => {
                    item.isOverlapped = true;
                    this.resizeCards(item, index, bookingOverlap);
                });
            }
            else {
                if (elementSelected) {
                    elementSelected.style.width = this.columnWidth + 'px';
                    elementSelected.style.left = 0 + 'px';
                }
                this.oldOverlap = this.oldOverlap.filter((item) => item.uuid !== bookingSelected.uuid);
                this.allOverlappedBookingsCollection.push(this.oldOverlap);
                this.oldOverlap.forEach((item, index) => {
                    item.isOverlapped = true;
                    this.resizeCards(item, index, this.oldOverlap);
                });
            }
        }
        this.allOverlappedBookingsCollection = (0,lodash__WEBPACK_IMPORTED_MODULE_7__.uniqWith)(this.allOverlappedBookingsCollection, lodash__WEBPACK_IMPORTED_MODULE_7__.isEqual);
        this.cdr.detectChanges();
    }
    sortByID(array) {
        return array.sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
    }
    resizeCards(item, index, array) {
        const elem = document.getElementById(item.uuid);
        if (elem) {
            if (array.length === 1) {
                item.mobileSize.width = this.columnWidth;
                elem.style.width = this.columnWidth + 'px';
                elem.style.left = 0 + 'px';
            }
            else {
                item.mobileSize.width = this.columnWidth / array.length;
                elem.style.width = this.columnWidth / array.length + 'px';
                elem.style.left = (this.columnWidth / array.length) * index + 'px';
            }
        }
    }
    setNewPositionFGhost(newPos) {
        this.$reservations.value.map((item) => {
            if (item.uuid === newPos.uuid) {
                item.mobilePosition = Object.assign(item.mobilePosition, newPos.position);
            }
        });
    }
    preventDefault(e) {
        e.preventDefault();
    }
    createBlankCard(position, time, event) {
        this.isGhosting = true;
        const newBooking = new src_app_core_models_reservation_model__WEBPACK_IMPORTED_MODULE_2__.Booking();
        newBooking.uuid = 'ghost_';
        newBooking.isBooking = true;
        newBooking.duration = 60;
        newBooking.startsHour = time.hours;
        newBooking.startsMinute = time.minutes;
        newBooking.mobilePosition = {
            x: position.x,
            y: position.y - 48,
            id: newBooking.uuid,
        };
        newBooking.mobileSize = {
            width: this.columnWidth,
            height: this.setHeightByDuration(60),
        };
        newBooking.service = [];
        newBooking.startsDay = '2030-01-01';
        newBooking.isGhost = true;
        this.$reservations.value.push(newBooking);
        this.fillCardsPosition(this.$reservations.value);
        this.draggableItem = newBooking.uuid;
        this.draggingBooking = Object.assign({}, newBooking);
        this.cdr.detectChanges();
        this.createDraggable(true);
        const instanceGhostIndex = this.getDraggableInstanceIndexByUuid(newBooking.uuid);
        const ghost = this.draggableInstance[instanceGhostIndex];
        ghost.startDrag(event);
        this.cdr.detectChanges();
    }
    logLongPress(event, uuid) {
        if (!uuid && !this.isScrolling) {
            const elementParent = document.getElementById('draggableZone');
            const domRectParent = elementParent === null || elementParent === void 0 ? void 0 : elementParent.getBoundingClientRect();
            const relativePos = event.startY - domRectParent.top;
            const relativeColumn = (event.startX - domRectParent.left) / this.columnWidth;
            const employeeIndex = relativeColumn.toString().charAt(0);
            const time = this.calculateHourByPixel(relativePos / 24, this.timetable);
            const newPos = {
                x: parseInt(employeeIndex, 10) * this.columnWidth,
                y: relativePos,
            };
            const timeGhost = this.calculateHourByPixel((relativePos - 48) / 24, this.timetable);
            if (!this.isGhosting && this.draggableItem === null) {
                const data = { selectedDay: this.selectedDate, selectedHour: timeGhost, employee: this.timetable.employees[employeeIndex] };
                this.ghostingData = data;
                this.createBlankCard(newPos, timeGhost, event.event);
                this.isGhosting = true;
            }
        }
        else if (uuid && !this.isScrolling && !uuid.includes('ghos')) {
            this.draggableItem = uuid;
            this.draggingBooking = this.$reservations.value.find((book) => book.uuid === uuid);
            this.createDraggable(false);
            const i = this.draggableInstance[this.getDraggableInstanceIndexByUuid(uuid)];
            console.log(this.draggingBooking);
            i.startDrag(event.event);
            this.isEditting = true;
            const el1 = document.getElementById(uuid);
            if (el1 !== null) {
                this.draggableItem = uuid;
                this.editBooking.emit(true);
                el1.classList.add('selectedCardMoveable');
            }
        }
    }
    getPosition(e) {
        const rect = e.target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        return {
            x,
            y,
        };
    }
    fillCardsPosition(reservationCollection) {
        this.$reservations.next(null);
        this.$reservations.next(reservationCollection);
    }
    fillFreetimePosition(reservationCollection) {
        this.$freeTime.next(null);
        this.$freeTime.next(reservationCollection);
    }
    setFirstSize(reservationCollection) {
        reservationCollection.forEach((item, index) => {
            item.mobileSize = {
                width: this.columnWidth,
                height: this.setHeightByDuration(item.duration),
            };
            setTimeout(() => {
                this.newCheckOverlap(item.uuid);
            }, 0);
        });
        this.isReady = true;
    }
    setFirstFreeTimeSize(reservationCollection) {
        reservationCollection.forEach((item, index) => {
            item.mobileSize = {
                width: this.columnWidth,
                height: this.setHeightByDuration(item.duration),
            };
        });
        this.isReady = true;
    }
    removeOverlap(item) {
        this.isOverlapCollection.map((overlapItem) => {
            if (overlapItem.booking) {
                overlapItem.booking = overlapItem.booking.filter((book) => book.uuid !== item.uuid);
            }
        });
    }
    onResize(event, uuid) {
        this.draggableInstance.map((item) => item.kill());
        this.hourByPosition(uuid);
        if (this.draggableDiv) {
            this.draggableDiv.removeEventListener('touchend', this.preventDefault, true); // mobile
            this.draggableDiv.removeEventListener('touchmove', this.preventDefault, true); // mobile
            this.draggableDiv = undefined;
        }
        const [book] = this.$reservations.value.filter((bookItem) => bookItem.uuid === uuid);
        book.duration = (event.size.height / 24) * 15;
        book.mobileSize.height = event.size.height;
        this.newCheckOverlap(uuid);
    }
    onResizeStop(uuid) {
        this.createDraggable(this.isGhosting);
        this.hourByPosition(uuid);
        const [booking] = this.$reservations.value.filter((item) => item.uuid === uuid);
        if (!booking.isGhost) {
            this.editBooking.emit(true);
        }
        else {
            this.longPressAction.emit(this.ghostingData);
        }
        this.newCheckOverlap(uuid);
    }
    setHeightByDuration(duration) {
        return duration * 2 >= 24 ? (duration * 24) / 15 : 24;
    }
    isNotPayed(booking) {
        const splittedDate = booking.startsDay.split('-');
        const year = parseInt(splittedDate[0], 10);
        const month = parseInt(splittedDate[1], 10) - 1;
        const day = parseInt(splittedDate[2], 10);
        const date = new Date(year, month, day, booking.startsHour, booking.startsMinute);
        const reservationEndDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_16__["default"])(date, booking.duration);
        return ((0,date_fns__WEBPACK_IMPORTED_MODULE_17__["default"])(reservationEndDate) &&
            booking.payment === null &&
            !booking.paymentSettedUuid &&
            booking.status !== 'No asistida');
    }
    editBookingConfirmation() {
        this.editBookingService.editBookingConfirm
            .asObservable()
            .subscribe((res) => {
            var _a;
            this.isEditting = false;
            if (this.draggableInstance) {
                this.draggableInstance.map((item) => item.kill());
            }
            const el1 = document.getElementById(this.draggableItem);
            if (el1 !== null) {
                el1.classList.remove('selectedCardMoveable');
            }
            this.editBooking.emit(false);
            if (res) {
                const findBooking = this.$reservations.value.find((item) => item.uuid === this.draggableItem);
                this.updateBooking.emit(findBooking);
                this.$reservations.value.map((book) => this.newCheckOverlap(book.uuid));
                //  this.newCheckOverlap(this.draggableItem);
                this.draggableItem = null;
            }
            else {
                this.dragPosition = [];
                this.fillCardsPosition((_a = this.timetable) === null || _a === void 0 ? void 0 : _a.bookings);
                this.setFirstSize(this.timetable.bookings);
                this.draggableItem = null;
            }
        });
    }
    isInsideTimetable() {
        const date = new Date();
        const lastFrame = this.timetable.timeFrames[this.timetable.timeFrames.length - 1];
        const firstFrame = this.timetable.timeFrames[0];
        /*  const timetableClose: Date = new Date(
           date.getFullYear(),
           date.getMonth(),
           date.getDate(),
           parseInt(lastFrame.split(':')[0], 10),
           parseInt(lastFrame.split(':')[1], 10)
         ); */
        const timetableOpen = new Date(date.getFullYear(), date.getMonth(), date.getDate(), parseInt(firstFrame.split(':')[0], 10), parseInt(firstFrame.split(':')[1], 10));
        const timetableClose = new Date(date.getFullYear(), date.getMonth(), date.getDate(), parseInt(lastFrame.split(':')[0], 10), parseInt(lastFrame.split(':')[1], 10));
        return (0,date_fns__WEBPACK_IMPORTED_MODULE_18__["default"])({
            start: date,
            end: date,
        }, {
            start: timetableOpen,
            end: timetableClose,
        }, {
            inclusive: false,
        });
    }
};
TimeTableComponent.ctorParameters = () => [
    { type: _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_19__.ScrollDispatcher },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__.DateService },
    { type: src_app_core_utils_editBooking_service__WEBPACK_IMPORTED_MODULE_6__.EditBooking },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.Platform },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Renderer2 }
];
TimeTableComponent.propDecorators = {
    timetable: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input }],
    selectedDate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input }],
    isToday: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input }],
    navigateTo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    updateBooking: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    longPressAction: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    editBooking: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    overscrollEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    overscrollEndEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output }],
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonContent, { static: false },] }],
    draggableZone: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild, args: ['draggableZone', { static: true },] }],
    headEmployee: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewChild, args: ['headEmployee',] }],
    onTouchStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.HostListener, args: ['touchstart', ['$event'], // prevent long press on scroll
            ] }],
    onScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.HostListener, args: ['touchmove', ['$event'],] }],
    onTouchEnd: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.HostListener, args: ['touchend', ['$event'], // set
            ] }]
};
TimeTableComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-time-table',
        template: _time_table_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectionStrategy.OnPush,
        styles: [_time_table_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TimeTableComponent);



/***/ }),

/***/ 4477:
/*!*******************************************************************!*\
  !*** ./src/app/shared/components/time-table/time-table.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeTableModule": () => (/* binding */ TimeTableModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _time_table_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./time-table.component */ 6293);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _time_table_header_employee_time_table_header_employee_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../time-table-header-employee/time-table-header-employee.module */ 2602);
/* harmony import */ var _reservation_card_reservation_card_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../reservation-card/reservation-card.module */ 3201);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 69594);
/* harmony import */ var _directives_longpress_longpress_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../directives/longpress/longpress.module */ 70444);
/* harmony import */ var angular2_draggable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! angular2-draggable */ 27269);
/* harmony import */ var _directives_toColumnMove_to_column_move_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../directives/toColumnMove/to-column-move.module */ 62319);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/scrolling */ 43970);
/* harmony import */ var _employee_employee_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../employee/employee.module */ 27525);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/grid-list */ 68566);
/* harmony import */ var _pipes_timeframe_timeframe_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pipes/timeframe/timeframe.module */ 53084);















let TimeTableModule = class TimeTableModule {
};
TimeTableModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_time_table_component__WEBPACK_IMPORTED_MODULE_0__.TimeTableComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _time_table_header_employee_time_table_header_employee_module__WEBPACK_IMPORTED_MODULE_1__.TimeTableHeaderEmployeeModule,
            _reservation_card_reservation_card_module__WEBPACK_IMPORTED_MODULE_2__.ReservationCardModule,
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_11__.DragDropModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ScrollingModule,
            _directives_longpress_longpress_module__WEBPACK_IMPORTED_MODULE_3__.LongpressModule,
            angular2_draggable__WEBPACK_IMPORTED_MODULE_13__.AngularDraggableModule,
            _directives_toColumnMove_to_column_move_module__WEBPACK_IMPORTED_MODULE_4__.ToColumnMoveModule,
            _employee_employee_module__WEBPACK_IMPORTED_MODULE_5__.EmployeeModule,
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_14__.MatGridListModule,
            _pipes_timeframe_timeframe_module__WEBPACK_IMPORTED_MODULE_6__.TimeframeModule
        ],
        exports: [_time_table_component__WEBPACK_IMPORTED_MODULE_0__.TimeTableComponent],
    })
], TimeTableModule);



/***/ }),

/***/ 48653:
/*!********************************************************************!*\
  !*** ./src/app/shared/directives/longpress/longpress.directive.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LongPressDirective": () => (/* binding */ LongPressDirective)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 95472);



let LongPressDirective = class LongPressDirective {
    constructor(el, gestureCtrl, zone) {
        this.el = el;
        this.gestureCtrl = gestureCtrl;
        this.zone = zone;
        this.mouseLongPress = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.delay = 500;
        this.longPressActive = false;
    }
    ngAfterViewInit() {
        this.loadLongPressOnElement();
    }
    loadLongPressOnElement() {
        const gesture = this.gestureCtrl.create({
            el: this.el.nativeElement,
            threshold: 0,
            gestureName: 'long-press',
            onStart: ev => {
                this.longPressActive = true;
                this.longPressAction(ev);
            },
            onEnd: ev => {
                this.longPressActive = false;
            }
        });
        gesture.enable(true);
    }
    longPressAction(event) {
        if (this.action) {
            clearInterval(this.action);
        }
        this.action = setTimeout(() => {
            this.zone.run(() => {
                if (this.longPressActive === true) {
                    this.longPressActive = false;
                    this.mouseLongPress.emit(event);
                }
            });
        }, this.delay);
    }
};
LongPressDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.GestureController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone }
];
LongPressDirective.propDecorators = {
    mouseLongPress: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output }],
    delay: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }]
};
LongPressDirective = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive)({
        selector: '[appLongPress]',
    })
], LongPressDirective);



/***/ }),

/***/ 70444:
/*!*****************************************************************!*\
  !*** ./src/app/shared/directives/longpress/longpress.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LongpressModule": () => (/* binding */ LongpressModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _longpress_directive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./longpress.directive */ 48653);




let LongpressModule = class LongpressModule {
};
LongpressModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_longpress_directive__WEBPACK_IMPORTED_MODULE_0__.LongPressDirective],
        exports: [_longpress_directive__WEBPACK_IMPORTED_MODULE_0__.LongPressDirective],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
    })
], LongpressModule);



/***/ }),

/***/ 22553:
/*!****************************************************************************!*\
  !*** ./src/app/shared/directives/toColumnMove/to-column-move.directive.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToColumnMoveDirective": () => (/* binding */ ToColumnMoveDirective)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 51109);


let ToColumnMoveDirective = class ToColumnMoveDirective {
    constructor(element) {
        this.element = element;
    }
    get grow() {
        return { value: this.pulse, params: { left: this.left, top: this.top } };
    }
    ngOnChanges() {
        this.pulse = !this.pulse;
    }
};
ToColumnMoveDirective.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef }
];
ToColumnMoveDirective.propDecorators = {
    left: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    top: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input }],
    grow: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostBinding, args: ['@toColumnsAnimation',] }]
};
ToColumnMoveDirective = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive)({
        selector: '[appToColumnMove]',
    })
], ToColumnMoveDirective);



/***/ }),

/***/ 62319:
/*!*************************************************************************!*\
  !*** ./src/app/shared/directives/toColumnMove/to-column-move.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToColumnMoveModule": () => (/* binding */ ToColumnMoveModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _to_column_move_directive__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./to-column-move.directive */ 22553);




let ToColumnMoveModule = class ToColumnMoveModule {
};
ToColumnMoveModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_to_column_move_directive__WEBPACK_IMPORTED_MODULE_0__.ToColumnMoveDirective],
        exports: [_to_column_move_directive__WEBPACK_IMPORTED_MODULE_0__.ToColumnMoveDirective],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
    })
], ToColumnMoveModule);



/***/ }),

/***/ 53084:
/*!************************************************************!*\
  !*** ./src/app/shared/pipes/timeframe/timeframe.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeframeModule": () => (/* binding */ TimeframeModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _timeframe_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./timeframe.pipe */ 45403);




let TimeframeModule = class TimeframeModule {
};
TimeframeModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_timeframe_pipe__WEBPACK_IMPORTED_MODULE_0__.TimeframePipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule
        ],
        exports: [_timeframe_pipe__WEBPACK_IMPORTED_MODULE_0__.TimeframePipe]
    })
], TimeframeModule);



/***/ }),

/***/ 45403:
/*!**********************************************************!*\
  !*** ./src/app/shared/pipes/timeframe/timeframe.pipe.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeframePipe": () => (/* binding */ TimeframePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let TimeframePipe = class TimeframePipe {
    transform(value, ...args) {
        if (value.substring(3, value.length) !== '00') {
            return value.slice(3);
        }
        return value;
    }
};
TimeframePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'timeframe'
    })
], TimeframePipe);



/***/ }),

/***/ 41664:
/*!****************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-manager.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "ion-header {\n  --tw-bg-opacity: 1;\n  background-color: rgb(255 255 255 / var(--tw-bg-opacity));\n}\n\n.main-content .swiper {\n  width: 100%;\n  height: 100%;\n}\n\n.main-content .swiper-slide {\n  text-align: center;\n  font-size: 18px;\n  opacity: 0.25;\n  transition: opacity 0.3s ease;\n  /* Center slide text vertically */\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.main-content .swiper-slide-active {\n  opacity: 1;\n  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\n\n.main-content .calender {\n  background-color: white;\n}\n\n.main-content .calender .month ion-row {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.main-content .calender .month ion-row ion-label {\n  font-size: 18px;\n  font-weight: 600;\n  padding: 0px 20px;\n}\n\n.main-content .calender .select-date {\n  text-align: center;\n  border-radius: 10px;\n  padding: 0px 20px 0px 10px;\n}\n\n.main-content .calender .select-date .row_cal {\n  width: 100%;\n}\n\n.main-content .calender .select-date ion-icon {\n  margin-top: 30px;\n}\n\n.main-content .calender .select-date .disabled {\n  color: #ababab !important;\n}\n\n.main-content .calender .select-date .lbl_day {\n  display: block;\n  margin-bottom: 0px;\n  font-size: 13px;\n  padding-top: 10px;\n}\n\n.main-content .calender .select-date .lbl_date {\n  display: block;\n  position: relative;\n  z-index: 1;\n  font-size: 14px;\n  padding: 30px 5px 10px 5px;\n}\n\n.main-content .calender .select-date .selectedDay {\n  background: var(--ion-color-primary);\n  color: white !important;\n  border-radius: 10px;\n  font-weight: bold;\n}\n\n.main-content .calender .select-date .todayDay {\n  color: black;\n  border-radius: 10px;\n  font-weight: bold;\n  outline: 1px solid #ababab;\n}\n\n.main-content .slot-name {\n  padding: 10px 15px;\n  font-weight: 600;\n  font-size: 18px;\n}\n\n.main-content .slot {\n  padding: 5px 14px;\n}\n\n.main-content .slot ion-chip {\n  background-color: white;\n  border: 2px solid lightgray;\n  border-radius: 8px;\n  padding: 5px 8px;\n  font-weight: 500;\n  font-size: 13px;\n}\n\n.main-content .slot-active {\n  background-color: black !important;\n  color: white;\n  border: 2px solid black !important;\n  border-radius: 8px;\n  padding: 5px 8px;\n  font-weight: 500;\n  font-size: 13px;\n}\n\n.header-with-padding-top-ios {\n  padding-top: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJvb2tpbmctbWFuYWdlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFBQSxrQkFBQTtFQUFBO0FBQUE7O0FBR0E7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBRUUsa0JBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBRUEsaUNBQUE7RUFJQSxhQUFBO0VBSUEsdUJBQUE7RUFJQSxtQkFBQTtBQURGOztBQUlBO0VBQ0UsVUFBQTtFQUNBLCtFQUFBO0VBQUEsbUdBQUE7RUFBQSx1R0FBQTtBQUZGOztBQUtFO0VBQ0UsdUJBQUE7QUFISjs7QUFLTTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSFI7O0FBSVE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUZWOztBQU1JO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0FBSk47O0FBTU07RUFDRSxXQUFBO0FBSlI7O0FBTU07RUFDRSxnQkFBQTtBQUpSOztBQU9NO0VBQ0UseUJBQUE7QUFMUjs7QUFPTTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUxSOztBQU9NO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSwwQkFBQTtBQUxSOztBQVFNO0VBQ0Usb0NBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFOUjs7QUFRTTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsMEJBQUE7QUFOUjs7QUFVRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBUko7O0FBVUU7RUFDRSxpQkFBQTtBQVJKOztBQVNJO0VBQ0UsdUJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFQTjs7QUFVRTtFQUNFLGtDQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQVJKOztBQVlBO0VBQ0UsaUJBQUE7QUFURiIsImZpbGUiOiJib29raW5nLW1hbmFnZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgQGFwcGx5IGJnLXdoaXRlO1xyXG59XHJcbi5tYWluLWNvbnRlbnQge1xyXG4gIC5zd2lwZXIge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLnN3aXBlci1zbGlkZSB7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlciAhaW1wb3J0YW50O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgb3BhY2l0eTogMC4yNTtcclxuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuM3MgZWFzZTtcclxuXHJcbiAgLyogQ2VudGVyIHNsaWRlIHRleHQgdmVydGljYWxseSAqL1xyXG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xyXG4gIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xyXG4gIGRpc3BsYXk6IC13ZWJraXQtZmxleDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIC13ZWJraXQtYm94LXBhY2s6IGNlbnRlcjtcclxuICAtbXMtZmxleC1wYWNrOiBjZW50ZXI7XHJcbiAgLXdlYmtpdC1qdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAtd2Via2l0LWJveC1hbGlnbjogY2VudGVyO1xyXG4gIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XHJcbiAgLXdlYmtpdC1hbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zd2lwZXItc2xpZGUtYWN0aXZlIHtcclxuICBvcGFjaXR5OiAxO1xyXG4gIEBhcHBseSBzaGFkb3ctbGc7XHJcbn1cclxuXHJcbiAgLmNhbGVuZGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgLm1vbnRoIHtcclxuICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgcGFkZGluZzogMHB4IDIwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuc2VsZWN0LWRhdGUge1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDBweCAyMHB4IDBweCAxMHB4O1xyXG5cclxuICAgICAgLnJvd19jYWwge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcbiAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZGlzYWJsZWQge1xyXG4gICAgICAgIGNvbG9yOiAjYWJhYmFiICFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgICAgLmxibF9kYXkge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICAgIH1cclxuICAgICAgLmxibF9kYXRlIHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgei1pbmRleDogMTtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgcGFkZGluZzogMzBweCA1cHggMTBweCA1cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5zZWxlY3RlZERheSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgIH1cclxuICAgICAgLnRvZGF5RGF5IHtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBvdXRsaW5lOiAxcHggc29saWQgI2FiYWJhYjtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAuc2xvdC1uYW1lIHtcclxuICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgfVxyXG4gIC5zbG90IHtcclxuICAgIHBhZGRpbmc6IDVweCAxNHB4O1xyXG4gICAgaW9uLWNoaXAge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgICAgYm9yZGVyOiAycHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgIHBhZGRpbmc6IDVweCA4cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIH1cclxuICB9XHJcbiAgLnNsb3QtYWN0aXZlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjayAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgcGFkZGluZzogNXB4IDhweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgfVxyXG59XHJcblxyXG4uaGVhZGVyLXdpdGgtcGFkZGluZy10b3AtaW9zIHtcclxuICBwYWRkaW5nLXRvcDogNDBweDtcclxufVxyXG5cclxuIl19 */";

/***/ }),

/***/ 46638:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/action-sheet/action-sheet.component.scss?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY3Rpb24tc2hlZXQuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 84294:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/datetime/datetime.component.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRldGltZS5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 71808:
/*!*****************************************************************************************!*\
  !*** ./src/app/shared/components/employee-list/employee-list.component.scss?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "/* .customer-card {\n  padding: 0;\n  max-height: 93.5px;\n  padding-bottom: 10px;\n  .customer-row {\n    border-radius: 15px;\n\n    .customer-image {\n      background-color: rgb(228, 228, 228);\n      padding: 0;\n      height: 100%;\n    }\n\n    .icon-container {\n      margin-top: 190%;\n      text-align: center;\n    }\n\n    .customer-label {\n      display: block;\n      margin-top: 15%;\n      margin-left: 5%;\n    }\n  }\n} */\n.customer-card {\n  padding: 0;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #efefef;\n  padding: 0;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 110%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  float: left;\n  position: relative;\n  top: 40%;\n  left: 20%;\n}\nion-content {\n  --background: rgb(255, 255, 255);\n}\nion-item {\n  --inner-border-width: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQUFBO0FBMkJBO0VBQ0UsVUFBQTtBQURGO0FBRUU7RUFDRSxtQkFBQTtBQUFKO0FBQ0k7RUFDRSx5QkFBQTtFQUNBLFVBQUE7QUFDTjtBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUNOO0FBQ0k7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtBQUNOO0FBSUE7RUFDRSxnQ0FBQTtBQURGO0FBSUE7RUFDRSx5QkFBQTtBQURGIiwiZmlsZSI6ImVtcGxveWVlLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiAuY3VzdG9tZXItY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxuICBtYXgtaGVpZ2h0OiA5My41cHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgLmN1c3RvbWVyLXJvdyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG5cclxuICAgIC5jdXN0b21lci1pbWFnZSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE5MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgICAuY3VzdG9tZXItbGFiZWwge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgbWFyZ2luLXRvcDogMTUlO1xyXG4gICAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB9XHJcbiAgfVxyXG59ICovXHJcblxyXG5cclxuLmN1c3RvbWVyLWNhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgLmN1c3RvbWVyLXJvdyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgLmN1c3RvbWVyLWltYWdlIHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzOSwgMjM5LCAyMzkpO1xyXG4gICAgICBwYWRkaW5nOiAwO1xyXG4gICAgfVxyXG4gICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgbWFyZ2luLXRvcDogMTEwJTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmN1c3RvbWVyLWxhYmVsIHtcclxuICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdG9wOiA0MCU7XHJcbiAgICAgIGxlZnQ6IDIwJTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwcHg7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 17941:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/employee/employee.component.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "ion-item {\n  display: flex;\n  align-items: center;\n  padding: 5px 0px 0px 0px;\n  font-weight: 200;\n}\nion-item img {\n  width: 40px;\n  height: 40px;\n  border-radius: 15px;\n  margin: 5px 5px 5px 0px;\n}\nion-item h5 {\n  margin: 0px;\n  font-weight: bold;\n  padding-left: 10px;\n}\nion-item p {\n  margin: 3px;\n  padding-left: 10px;\n  font-size: 14px;\n  font-weight: 600;\n  color: var(--ion-color-medium);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0Esd0JBQUE7RUFDQSxnQkFBQTtBQUNGO0FBQUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFFSjtBQUFFO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFFSjtBQUFFO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7QUFFSiIsImZpbGUiOiJlbXBsb3llZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogNXB4IDBweCAwcHggMHB4O1xuICBmb250LXdlaWdodDogMjAwO1xuICBpbWcge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICAgIG1hcmdpbjogNXB4IDVweCA1cHggMHB4O1xuICB9XG4gIGg1IHtcbiAgICBtYXJnaW46IDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbiAgcCB7XG4gICAgbWFyZ2luOiAzcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgfVxufVxuIl19 */";

/***/ }),

/***/ 9439:
/*!***********************************************************************************************!*\
  !*** ./src/app/shared/components/reservation-card/reservation-card.component.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = ".reservationCard {\n  background-color: bisque;\n  padding: 0.25em;\n  border-radius: 5px;\n  margin: 0.1em;\n  width: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc2VydmF0aW9uLWNhcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx3QkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBQ0YiLCJmaWxlIjoicmVzZXJ2YXRpb24tY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZXNlcnZhdGlvbkNhcmQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJpc3F1ZTtcclxuICBwYWRkaW5nOiAwLjI1ZW07XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIG1hcmdpbjogMC4xZW07XHJcbiAgd2lkdGg6IDIwMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 74357:
/*!*******************************************************************************************************************!*\
  !*** ./src/app/shared/components/time-table-header-employee/time-table-header-employee.component.scss?ngResource ***!
  \*******************************************************************************************************************/
/***/ ((module) => {

module.exports = ".head-employee {\n  min-width: 150px;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpbWUtdGFibGUtaGVhZGVyLWVtcGxveWVlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQUNGIiwiZmlsZSI6InRpbWUtdGFibGUtaGVhZGVyLWVtcGxveWVlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWQtZW1wbG95ZWUge1xyXG4gIG1pbi13aWR0aDogMTUwcHg7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 89757:
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/time-table/time-table.component.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = ".container-calendar {\n  overflow-x: scroll;\n  overflow-y: overlay;\n  overscroll-behavior-x: none;\n  height: 100%;\n}\n\n.newTable {\n  max-width: 40em;\n  overflow: scroll;\n  position: relative;\n  overscroll-behavior-x: none;\n}\n\n.ng-resizable-n {\n  height: 10px !important;\n  width: 6% !important;\n  left: 45% !important;\n  border: solid grey;\n  border-width: 0 3px 3px 0;\n  display: inline-block;\n  padding: 3px;\n  transform: rotate(-135deg);\n  -webkit-transform: rotate(-135deg);\n  top: -10px;\n}\n\n.ng-resizable-s {\n  height: 10px !important;\n  width: 6% !important;\n  left: 45% !important;\n  border: solid grey;\n  border-width: 0 3px 3px 0;\n  display: inline-block;\n  padding: 3px;\n  transform: rotate(45deg);\n  -webkit-transform: rotate(45deg);\n  bottom: -10px;\n}\n\n/* table {\n  position: relative;\n  table-layout: fixed;\n  border-collapse: collapse;\n}\n\ntr{\n  height: 24px;\n}\ntd,\nth {\n  padding: 0.25em;\n}\n\nthead th {\n  position: -webkit-sticky; \n  position: sticky;\n  top: 0;\n  background: #fff;\n  color: #FFF;\n  z-index: 99999;\n}\n\nthead th:first-child {\n  left: 0;\n  z-index: 99999;\n}\n\ntbody th {\n  position: -webkit-sticky; \n  position: sticky;\n  left: 0;\n  background: #FFF;\n  border-right: 1px solid #CCC;\n}\n\n.sticky-col {\n  @apply text-xs;\nposition: sticky;\n\n    left: -1px;\n    z-index: 99;\n    margin-top: -11px;\n\n    text-align: end;\n\n} */\n\ntable {\n  position: relative;\n  border-collapse: collapse;\n}\n\ntbody {\n  height: 100%;\n  font-size: 10px;\n  position: relative;\n}\n\n.header {\n  background: white;\n  border-bottom: 4px solid transparent;\n}\n\ntr.red th {\n  color: white;\n  z-index: 9999;\n}\n\ntd,\nth {\n  padding-top: 6.5px;\n  height: 24px;\n}\n\nth {\n  z-index: 99;\n  position: sticky;\n  top: 0;\n}\n\ntd {\n  height: 15px;\n  vertical-align: top;\n}\n\ntd div:first-child {\n  vertical-align: top;\n}\n\ntbody th {\n  left: 0;\n  text-align: end;\n  border-right: 5px solid #fff;\n  border-left: 5px solid #fff;\n}\n\nthead th {\n  color: #fff;\n}\n\n.sticky-col {\n  position: sticky;\n  left: -1px;\n  z-index: 99;\n  margin-top: -27px;\n  text-align: end;\n}\n\ntr {\n  border-bottom: 1px dotted lightgray;\n}\n\ntr:nth-child(4n) {\n  border-bottom: 1px solid lightgray;\n}\n\ntbody tr:nth-child(-n+4) {\n  border-bottom: 0px solid lightgray;\n  background-color: #e5e5f7;\n  opacity: 1;\n  background-size: 5px 5px;\n  background-image: repeating-linear-gradient(45deg, #fff 0, #f4f4f4 1px, #fff 0, #f4f4f4 50%);\n}\n\ntbody tr:nth-last-child(-n+4) {\n  border-bottom: 0px solid lightgray;\n  background-color: #e5e5f7;\n  opacity: 1;\n  background-size: 5px 5px;\n  background-image: repeating-linear-gradient(45deg, #fff 0, #f4f4f4 1px, #fff 0, #f4f4f4 50%);\n}\n\n.background-white {\n  background-color: white;\n  border: 2px solid white;\n  margin-left: -3px;\n}\n\n.frame {\n  margin-top: -25px;\n  position: absolute;\n  background-color: white;\n}\n\n.head-employee {\n  min-width: 150px;\n  text-align: left;\n}\n\n.z-indexHead {\n  z-index: 11 !important;\n}\n\n.not-available {\n  background-color: #e5e5f7;\n  opacity: 1;\n  background-size: 5px 5px;\n  background-image: repeating-linear-gradient(45deg, #fff 0, #f4f4f4 1px, #fff 0, #f4f4f4 50%);\n}\n\n.fix-column {\n  background-color: white;\n  z-index: 100;\n}\n\n.selectedCardMoveable {\n  outline: 2px dashed darkgrey;\n  resize: vertical;\n  z-index: 99;\n}\n\n.reservationWrapper {\n  position: absolute;\n  width: 100%;\n  height: 100vh;\n}\n\n.reservation {\n  position: absolute;\n  padding: 0.25em;\n  border: 2px white solid;\n  box-shadow: 1px 0px 0px 0px white, 1px 0px 0px 0px white;\n  border-radius: 7px 10px 10px 7px;\n  z-index: 11;\n}\n\n.non-availability {\n  position: absolute;\n  border: 2px white solid;\n  box-shadow: 1px 0px 0px 0px white, 1px 0px 0px 0px white;\n  padding: 0.25em;\n  background-color: #f4f4f4;\n  opacity: 1;\n  z-index: 10;\n  background-size: 5px 5px;\n  /*   background-image: repeating-linear-gradient(\n    45deg,\n      #fff 0,\n      #f4f4f4 1px,\n      #fff 0,\n      #f4f4f4 50%\n    ); */\n}\n\n.freetime {\n  border: 2px white solid;\n  box-shadow: 1px 0px 0px 0px white, 1px 0px 0px 0px white;\n  position: absolute;\n  padding: 0.25em;\n  background-color: #f4f4f4;\n  opacity: 1;\n  background-size: 5px 5px;\n  /*  background-image: repeating-linear-gradient(\n   45deg,\n     #fff 0,\n     #f4f4f4 1px,\n     #fff 0,\n     #f4f4f4 50%\n   ); */\n}\n\n.opacity {\n  opacity: 0.5;\n}\n\n.calendar-container-draggable-zone {\n  top: 47px;\n  position: absolute;\n  height: 100%;\n  display: inline-block;\n  vertical-align: top;\n  z-index: 10;\n}\n\n.example-list {\n  border: solid 1px #ccc;\n  width: 150px;\n  height: 100%;\n  border-radius: 4px;\n  overflow: hidden;\n  display: inline-block;\n}\n\n.cdk-drag-preview {\n  box-sizing: border-box;\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.columndrop {\n  width: 150px;\n  height: 100%;\n}\n\n.isGhost {\n  border-width: 2px;\n  border-style: dashed;\n  --tw-border-opacity: 1;\n  border-color: rgb(163 163 163 / var(--tw-border-opacity));\n  --tw-bg-opacity: 1;\n  background-color: rgb(255 255 255 / var(--tw-bg-opacity));\n}\n\n.time {\n  position: absolute;\n  width: 98%;\n  height: 1px;\n  background-color: green;\n  left: 30px;\n  z-index: 10;\n  display: flex;\n  align-items: center;\n}\n\n.no-click {\n  pointer-events: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpbWUtdGFibGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUM7RUFFRyxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0E7RUFDRSxlQUFBO0VBRUEsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0FBREY7O0FBR0E7RUFDRSx1QkFBQTtFQUNGLG9CQUFBO0VBQ0Esb0JBQUE7RUFDRyxrQkFBQTtFQUNELHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0VBQ0UsMEJBQUE7RUFDRixrQ0FBQTtFQUNBLFVBQUE7QUFBRjs7QUFFQTtFQUNFLHVCQUFBO0VBRUYsb0JBQUE7RUFDQSxvQkFBQTtFQUNHLGtCQUFBO0VBQ0QseUJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtFQUNBLGdDQUFBO0VBQ0YsYUFBQTtBQUFBOztBQUlBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBQUE7O0FBK0NDO0VBQ0Msa0JBQUE7RUFDQSx5QkFBQTtBQURGOztBQUtBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFFRSxrQkFBQTtBQUhKOztBQUtBO0VBQ0UsaUJBQUE7RUFDRSxvQ0FBQTtBQUZKOztBQUtBO0VBRUUsWUFBQTtFQUNBLGFBQUE7QUFIRjs7QUFLQTs7RUFFRSxrQkFBQTtFQUNBLFlBQUE7QUFGRjs7QUFJQTtFQUNDLFdBQUE7RUFDQyxnQkFBQTtFQUNBLE1BQUE7QUFERjs7QUFJQTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtBQURGOztBQUlBO0VBRUUsbUJBQUE7QUFGRjs7QUFJQTtFQUNFLE9BQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSwyQkFBQTtBQURGOztBQUlBO0VBQ0UsV0FBQTtBQURGOztBQUlBO0VBQ0EsZ0JBQUE7RUFFSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQUZKOztBQU1BO0VBQ0UsbUNBQUE7QUFIRjs7QUFLQTtFQUNFLGtDQUFBO0FBRkY7O0FBSUE7RUFDRSxrQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0VBQ0EsNEZBQUE7QUFERjs7QUFXQTtFQUNFLGtDQUFBO0VBQ0EseUJBQUE7RUFDQSxVQUFBO0VBQ0Esd0JBQUE7RUFDQSw0RkFBQTtBQVJGOztBQXFCQTtFQUNFLHVCQUFBO0VBQ0EsdUJBQUE7RUFDSSxpQkFBQTtBQWxCTjs7QUFzQkE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFuQkY7O0FBd0JBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQXJCRjs7QUF1QkE7RUFDRSxzQkFBQTtBQXBCRjs7QUF5QkE7RUFDRSx5QkFBQTtFQUNBLFVBQUE7RUFDQSx3QkFBQTtFQUNBLDRGQUFBO0FBdEJGOztBQThCQTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQTNCRjs7QUErQkE7RUFDRSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQTVCRjs7QUErQkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBNUJGOztBQThCQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0Usd0RBQUE7RUFDRixnQ0FBQTtFQUNBLFdBQUE7QUEzQkY7O0FBOEJBO0VBQ0Usa0JBQUE7RUFFQSx1QkFBQTtFQUNFLHdEQUFBO0VBQ0gsZUFBQTtFQUNELHlCQUFBO0VBQ0UsVUFBQTtFQUNFLFdBQUE7RUFDRix3QkFBQTtFQUNGOzs7Ozs7UUFBQTtBQXRCQTs7QUErQkE7RUFDRSx1QkFBQTtFQUNHLHdEQUFBO0VBQ0gsa0JBQUE7RUFDRCxlQUFBO0VBQ0QseUJBQUE7RUFDRSxVQUFBO0VBQ0Esd0JBQUE7RUFDRDs7Ozs7O09BQUE7QUF0QkQ7O0FBK0JBO0VBQ0UsWUFBQTtBQTVCRjs7QUErQkE7RUFDQSxTQUFBO0VBQ0ksa0JBQUE7RUFFRCxZQUFBO0VBQ0MscUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUE3Qko7O0FBaUNBO0VBQ0Usc0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtBQTlCRjs7QUFtQ0E7RUFDRSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUhBQUE7QUFoQ0Y7O0FBb0NBO0VBQ0UsVUFBQTtBQWpDRjs7QUFvQ0E7RUFDRSxzREFBQTtBQWpDRjs7QUFxQ0E7RUFDRSxZQUFBO0VBQ0EsWUFBQTtBQWxDRjs7QUFxQ0U7RUFBQSxpQkFBQTtFQUFBLG9CQUFBO0VBQUEsc0JBQUE7RUFBQSx5REFBQTtFQUFBLGtCQUFBO0VBQUE7QUFBQTs7QUFFRjtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBaENGOztBQXVDQTtFQUNHLG9CQUFBO0FBcENIIiwiZmlsZSI6InRpbWUtdGFibGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgLmNvbnRhaW5lci1jYWxlbmRhciB7XHJcblxyXG4gICAgb3ZlcmZsb3cteDogc2Nyb2xsO1xyXG4gICAgb3ZlcmZsb3cteTogb3ZlcmxheTtcclxuICAgIG92ZXJzY3JvbGwtYmVoYXZpb3IteDogbm9uZTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICBcclxufSBcclxuLm5ld1RhYmxlIHtcclxuICBtYXgtd2lkdGg6IDQwZW07XHJcbiBcclxuICBvdmVyZmxvdzogc2Nyb2xsO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBvdmVyc2Nyb2xsLWJlaGF2aW9yLXg6bm9uZTtcclxufVxyXG4ubmctcmVzaXphYmxlLW57XHJcbiAgaGVpZ2h0OiAxMHB4ICFpbXBvcnRhbnQ7XHJcbndpZHRoOiA2JSAhaW1wb3J0YW50O1xyXG5sZWZ0OjQ1JSAhaW1wb3J0YW50O1xyXG4gICBib3JkZXI6IHNvbGlkIGdyZXk7XHJcbiAgYm9yZGVyLXdpZHRoOiAwIDNweCAzcHggMDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgcGFkZGluZzogM3B4O1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTEzNWRlZyk7XHJcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgtMTM1ZGVnKTtcclxuICB0b3A6IC0xMHB4O1xyXG59XHJcbi5uZy1yZXNpemFibGUtc3tcclxuICBoZWlnaHQ6IDEwcHggIWltcG9ydGFudDtcclxuXHJcbndpZHRoOiA2JSAhaW1wb3J0YW50O1xyXG5sZWZ0OjQ1JSAhaW1wb3J0YW50O1xyXG4gICBib3JkZXI6IHNvbGlkIGdyZXk7XHJcbiAgYm9yZGVyLXdpZHRoOiAwIDNweCAzcHggMDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgcGFkZGluZzogM3B4O1xyXG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuYm90dG9tOiAtMTBweDtcclxufVxyXG5cclxuXHJcbi8qIHRhYmxlIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdGFibGUtbGF5b3V0OiBmaXhlZDtcclxuICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG59XHJcblxyXG50cntcclxuICBoZWlnaHQ6IDI0cHg7XHJcbn1cclxudGQsXHJcbnRoIHtcclxuICBwYWRkaW5nOiAwLjI1ZW07XHJcbn1cclxuXHJcbnRoZWFkIHRoIHtcclxuICBwb3NpdGlvbjogLXdlYmtpdC1zdGlja3k7IFxyXG4gIHBvc2l0aW9uOiBzdGlja3k7XHJcbiAgdG9wOiAwO1xyXG4gIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgY29sb3I6ICNGRkY7XHJcbiAgei1pbmRleDogOTk5OTk7XHJcbn1cclxuXHJcbnRoZWFkIHRoOmZpcnN0LWNoaWxkIHtcclxuICBsZWZ0OiAwO1xyXG4gIHotaW5kZXg6IDk5OTk5O1xyXG59XHJcblxyXG50Ym9keSB0aCB7XHJcbiAgcG9zaXRpb246IC13ZWJraXQtc3RpY2t5OyBcclxuICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gIGxlZnQ6IDA7XHJcbiAgYmFja2dyb3VuZDogI0ZGRjtcclxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjQ0NDO1xyXG59XHJcblxyXG4uc3RpY2t5LWNvbCB7XHJcbiAgQGFwcGx5IHRleHQteHM7XHJcbnBvc2l0aW9uOiBzdGlja3k7XHJcbiAgIFxyXG4gICAgbGVmdDogLTFweDtcclxuICAgIHotaW5kZXg6IDk5O1xyXG4gICAgbWFyZ2luLXRvcDogLTExcHg7XHJcblxyXG4gICAgdGV4dC1hbGlnbjogZW5kO1xyXG4gICAgXHJcbn0gKi9cclxuIHRhYmxlIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuIFxyXG59XHJcblxyXG50Ym9keSB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxuXHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLmhlYWRlciB7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItYm90dG9tOiA0cHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbnRyLnJlZCB0aCB7XHJcbiBcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgei1pbmRleDogOTk5OTtcclxufVxyXG50ZCxcclxudGgge1xyXG4gIHBhZGRpbmctdG9wOiA2LjVweDtcclxuICBoZWlnaHQ6IDI0cHg7XHJcbn1cclxudGgge1xyXG4gei1pbmRleDo5OTtcclxuICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gIHRvcDogMDsgXHJcbiAgXHJcbn1cclxudGQge1xyXG4gIGhlaWdodDogMTVweDtcclxuICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG59XHJcblxyXG50ZCBkaXY6Zmlyc3QtY2hpbGQge1xyXG4gXHJcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcclxufVxyXG50Ym9keSB0aCB7XHJcbiAgbGVmdDogMDtcclxuICB0ZXh0LWFsaWduOiBlbmQ7XHJcbiAgYm9yZGVyLXJpZ2h0OiA1cHggc29saWQgI2ZmZjtcclxuICBib3JkZXItbGVmdDogNXB4IHNvbGlkICNmZmY7XHJcbn1cclxuXHJcbnRoZWFkIHRoIHtcclxuICBjb2xvcjogI2ZmZjtcclxufSBcclxuXHJcbi5zdGlja3ktY29sIHtcclxucG9zaXRpb246IHN0aWNreTtcclxuXHJcbiAgICBsZWZ0OiAtMXB4O1xyXG4gICAgei1pbmRleDogOTk7XHJcbiAgICBtYXJnaW4tdG9wOiAtMjdweDtcclxuICAgIHRleHQtYWxpZ246IGVuZDtcclxuICAgIFxyXG59XHJcblxyXG50ciB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IGRvdHRlZCBsaWdodGdyYXk7XHJcbn1cclxudHI6bnRoLWNoaWxkKDRuKSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxufVxyXG50Ym9keSB0cjpudGgtY2hpbGQoLW4gKyA0KSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTVlNWY3O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgYmFja2dyb3VuZC1zaXplOiA1cHggNXB4O1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHJlcGVhdGluZy1saW5lYXItZ3JhZGllbnQoXHJcbiAgNDVkZWcsXHJcbiAgICAjZmZmIDAsXHJcbiAgICAjZjRmNGY0IDFweCxcclxuICAgICNmZmYgMCxcclxuICAgICNmNGY0ZjQgNTAlXHJcbiAgKTtcclxuICBcclxuXHJcbn1cclxudGJvZHkgdHI6bnRoLWxhc3QtY2hpbGQoLW4gKyA0KSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTVlNWY3O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgYmFja2dyb3VuZC1zaXplOiA1cHggNXB4O1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHJlcGVhdGluZy1saW5lYXItZ3JhZGllbnQoXHJcbiAgICA0NWRlZyxcclxuICAgICNmZmYgMCxcclxuICAgICNmNGY0ZjQgMXB4LFxyXG4gICAgI2ZmZiAwLFxyXG4gICAgI2Y0ZjRmNCA1MCVcclxuICApO1xyXG4gXHJcbn0gXHJcblxyXG5cclxuXHJcblxyXG4uYmFja2dyb3VuZC13aGl0ZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAtM3B4O1xyXG59XHJcblxyXG5cclxuLmZyYW1lIHtcclxuICBtYXJnaW4tdG9wOiAtMjVweDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcblxyXG5cclxuLmhlYWQtZW1wbG95ZWUge1xyXG4gIG1pbi13aWR0aDogMTUwcHg7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4uei1pbmRleEhlYWQge1xyXG4gIHotaW5kZXg6IDExICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG5cclxuLm5vdC1hdmFpbGFibGUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNlNWU1Zjc7XHJcbiAgb3BhY2l0eTogMTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDVweCA1cHg7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogcmVwZWF0aW5nLWxpbmVhci1ncmFkaWVudChcclxuICA0NWRlZyxcclxuICAgICNmZmYgMCxcclxuICAgICNmNGY0ZjQgMXB4LFxyXG4gICAgI2ZmZiAwLFxyXG4gICAgI2Y0ZjRmNCA1MCVcclxuICApO1xyXG59XHJcbi5maXgtY29sdW1uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICB6LWluZGV4OiAxMDA7XHJcbn1cclxuXHJcblxyXG4uc2VsZWN0ZWRDYXJkTW92ZWFibGUge1xyXG4gIG91dGxpbmU6IDJweCBkYXNoZWQgZGFya2dyZXk7XHJcbiAgcmVzaXplOiB2ZXJ0aWNhbDtcclxuICB6LWluZGV4OiA5OTtcclxuXHJcbn1cclxuLnJlc2VydmF0aW9uV3JhcHBlciB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwdmg7XHJcbn1cclxuLnJlc2VydmF0aW9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcGFkZGluZzogMC4yNWVtO1xyXG4gIGJvcmRlcjogMnB4IHdoaXRlIHNvbGlkO1xyXG4gICAgYm94LXNoYWRvdzogMXB4IDBweCAwcHggMHB4IHdoaXRlLCAxcHggMHB4IDBweCAwcHggd2hpdGU7XHJcbiAgYm9yZGVyLXJhZGl1czogN3B4IDEwcHggMTBweCA3cHg7XHJcbiAgei1pbmRleDogMTE7XHJcbiBcclxufVxyXG4ubm9uLWF2YWlsYWJpbGl0eSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG5cclxuICBib3JkZXI6IDJweCB3aGl0ZSBzb2xpZDtcclxuICAgIGJveC1zaGFkb3c6IDFweCAwcHggMHB4IDBweCB3aGl0ZSwgMXB4IDBweCAwcHggMHB4IHdoaXRlO1xyXG4gcGFkZGluZzogMC4yNWVtO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjZjRmNGY0IDsgXHJcbiAgb3BhY2l0eTogMTtcclxuICAgIHotaW5kZXg6IDEwO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogNXB4IDVweDtcclxuLyogICBiYWNrZ3JvdW5kLWltYWdlOiByZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KFxyXG4gIDQ1ZGVnLFxyXG4gICAgI2ZmZiAwLFxyXG4gICAgI2Y0ZjRmNCAxcHgsXHJcbiAgICAjZmZmIDAsXHJcbiAgICAjZjRmNGY0IDUwJVxyXG4gICk7ICovXHJcbn1cclxuXHJcbi5mcmVldGltZSB7XHJcbiAgYm9yZGVyOiAycHggd2hpdGUgc29saWQ7XHJcbiAgICAgYm94LXNoYWRvdzogMXB4IDBweCAwcHggMHB4IHdoaXRlLCAxcHggMHB4IDBweCAwcHggd2hpdGU7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gcGFkZGluZzogMC4yNWVtO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjZjRmNGY0IDtcclxuICBvcGFjaXR5OiAxO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogNXB4IDVweDtcclxuIC8qICBiYWNrZ3JvdW5kLWltYWdlOiByZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KFxyXG4gIDQ1ZGVnLFxyXG4gICAgI2ZmZiAwLFxyXG4gICAgI2Y0ZjRmNCAxcHgsXHJcbiAgICAjZmZmIDAsXHJcbiAgICAjZjRmNGY0IDUwJVxyXG4gICk7ICovXHJcbn1cclxuXHJcbi5vcGFjaXR5IHtcclxuICBvcGFjaXR5OiAwLjU7XHJcbn1cclxuXHJcbi5jYWxlbmRhci1jb250YWluZXItZHJhZ2dhYmxlLXpvbmUge1xyXG50b3A6IDQ3cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcblxyXG4gICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG4gICAgei1pbmRleDogMTA7XHJcbn1cclxuLy8vLy8vL1xyXG5cclxuLmV4YW1wbGUtbGlzdCB7XHJcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2NjYztcclxuICB3aWR0aDogMTUwcHg7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxuXHJcblxyXG4uY2RrLWRyYWctcHJldmlldyB7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgYm94LXNoYWRvdzogMCA1cHggNXB4IC0zcHggcmdiYSgwLCAwLCAwLCAwLjIpLFxyXG4gICAgMCA4cHggMTBweCAxcHggcmdiYSgwLCAwLCAwLCAwLjE0KSwgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxufVxyXG5cclxuLmNkay1kcmFnLXBsYWNlaG9sZGVyIHtcclxuICBvcGFjaXR5OiAwO1xyXG59XHJcblxyXG4uY2RrLWRyYWctYW5pbWF0aW5nIHtcclxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbn1cclxuXHJcblxyXG4uY29sdW1uZHJvcCB7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIGhlaWdodDogMTAwJTtcclxufVxyXG4uaXNHaG9zdCB7XHJcbiAgQGFwcGx5IGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1uZXV0cmFsLTQwMCBib3JkZXItZGFzaGVkXHJcbn1cclxuLnRpbWUge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogOTglO1xyXG4gIGhlaWdodDogMXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xyXG4gIGxlZnQ6IDMwcHg7XHJcbiAgei1pbmRleDogMTA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuLm5vLWNsaWNrIHtcclxuICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuXHJcblxyXG4iXX0= */";

/***/ }),

/***/ 76557:
/*!****************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-manager.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "\r\n <ion-header>\r\n  <div class=\"main-content\">\r\n    <!--  <div class=\"absolute right-px pr-4\" (click)=\"presentEmployeeModal()\">\r\n   <ion-icon size=\"large\" name=\"filter-outline\"></ion-icon>\r\n    </div> -->\r\n    <div style=\"margin-top: 20px\" class=\"calender\">\r\n      <div [ngClass]=\"[isIOS ? 'header-with-padding-top-ios' : '']\" class=\"month\">\r\n        <ion-row>\r\n          <ion-col size=\"1\" (click)=\"prevMonth()\">\r\n            <ion-icon name=\"chevron-back-outline\"> </ion-icon>\r\n          </ion-col>\r\n\r\n          <ion-label id=\"open-start-day\" [innerText]=\"displayMonthAndYear()\"></ion-label>\r\n\r\n          <ion-col size=\"1\" (click)=\"nextMonth()\">\r\n            <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n\r\n\r\n      <ion-modal id=\"open-modal-calendar\" [initialBreakpoint]=\"0.5\"\r\n        [backdropDismiss]=\"true\" trigger=\"open-start-day\">\r\n        <ng-template>\r\n          <ion-content>\r\n            <ion-datetime #datetime first-day-of-week=\"1\" locale=\"es-ES\" [value]=\"selectedDay.date.toISOString()\" (ionChange)=\"dateChanged(datetime.value)\"\r\n              presentation=\"date\" size=\"cover\">\r\n            </ion-datetime>\r\n          </ion-content>\r\n        </ng-template>\r\n      </ion-modal>\r\n\r\n\r\n      <div class=\"select-date\">\r\n        <ion-slides #slideDate>\r\n          <ion-slide>\r\n            <ion-row class=\"row_cal\">\r\n              <ion-col size=\"0.75\" (click)=\"getPreviousWeekDays()\">\r\n                <ion-icon name=\"chevron-back-outline\" *ngIf=\"weekNumber !== 0\">\r\n                </ion-icon>\r\n              </ion-col>\r\n              <ion-col *ngFor=\"let day of days\" size=\"1.5\" (click)=\"selectDate(day)\">\r\n                <ion-label class=\"lbl_day\" [class.selectedDay]=\"day.dayNumber === selectedDay.dayNumber \"\r\n                  [class.todayDay]=\"checkIsToday(day.date)\">{{ day.shortName }}\r\n                  <ion-label class=\"lbl_date\" [class.selectedDate]=\"day.dayNumber === selectedDay.dayNumber\">{{\r\n                    day.dayNumber }}\r\n                  </ion-label>\r\n                </ion-label>\r\n              </ion-col>\r\n              <ion-col size=\"0.75\" (click)=\"getNextWeekDays()\">\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-slide>\r\n        </ion-slides>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ion-header>\r\n<ion-content>\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n    <ion-refresher-content\r\n      pullingIcon=\"chevron-down-circle-outline\"\r\n      pullingText=\"Arrastra para actualizar\"\r\n      refreshingSpinner=\"circles\"\r\n      refreshingText=\"Cargando...\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n  <div [hidden]=\"!overscroll\" >\r\n    <div  class=\" w-full flex h-24 flex-col-reverse  items-center\">\r\n      <ion-label class=\"py-2\">{{overmsg}}</ion-label>\r\n      <ion-spinner name=\"circles\"></ion-spinner>\r\n    </div>\r\n  </div>\r\n \r\n  <ion-list style=\"overflow-x: scroll;\">\r\n    <ng-container *ngIf=\"timetable; else skeleton\">\r\n      <ng-container *ngIf=\"employeeCollection?.length > 0; else noEmployee\">\r\n         <app-time-table *ngIf=\"timetable\" [isToday]=\"isToday\" [timetable]=\"timetable[indexSelected]\" [selectedDate]=\"selectedDay\"\r\n        (navigateTo)=\"openBooking($event)\" (updateBooking)=\"updateBooking($event)\"\r\n        (overscrollEmitter)=\"overScrollEmitted($event)\"\r\n        (overscrollEndEmitter)=\"overscrollEndEmitter($event)\"\r\n        (longPressAction)=\"openActionSheet($event)\" (editBooking)=\"editBookingProcess($event)\"></app-time-table>\r\n      </ng-container>\r\n    </ng-container>\r\n  </ion-list>\r\n\r\n</ion-content>\r\n<ion-fab *ngIf=\"!editBooking\" vertical=\"bottom\r\n  \" horizontal=\"end\" slot=\"fixed\">\r\n  <ion-fab-button (click)=\"openActionSheet()\">\r\n    <ion-icon name=\"add\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n<ion-fab *ngIf=\"editBooking\" vertical=\"bottom\r\n  \" horizontal=\"end\" slot=\"fixed\">\r\n  <ion-fab-button (click)=\"editBookingConfirmation(true)\">\r\n    <ion-icon name=\"checkmark-outline\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n\r\n<ion-fab *ngIf=\"editBooking\" vertical=\"bottom\r\n  \" horizontal=\"start\" slot=\"fixed\">\r\n  <ion-fab-button (click)=\"editBookingConfirmation(false)\">\r\n    <ion-icon name=\"close\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n<ion-fab *ngIf=\"!isToday && !editBooking\" (click)=\"goToToday()\" vertical=\"bottom\r\n  \" horizontal=\"center\" slot=\"fixed\">\r\n  <ion-fab-button> HOY </ion-fab-button>\r\n</ion-fab>\r\n<app-action-sheet></app-action-sheet>\r\n\r\n<ng-template #noEmployee >\r\n  <app-no-data class=\"ion-text-center\" [title]=\"'No hay empleados disponibles'\" [content]=\"false\"></app-no-data>\r\n</ng-template>\r\n\r\n<ng-template #skeleton>\r\n  <div class=\"p-4\">\r\n    <div class=\"h-12\r\n     p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  </div>\r\n  <div class=\"flex p-4\">\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n\r\n  </div>\r\n     <div class=\"flex p-4\">\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n\r\n  </div>\r\n     <div class=\"flex p-4\">\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n\r\n  </div>\r\n     <div class=\"flex p-4\">\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n\r\n  </div>\r\n     <div class=\"flex p-4\">\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n  <div class=\"h-24 w-1/2 p-2\">\r\n    <ion-skeleton-text animated  ></ion-skeleton-text>\r\n  </div>\r\n\r\n  </div>\r\n\r\n</ng-template>\r\n";

/***/ }),

/***/ 23903:
/*!***************************************************************************************!*\
  !*** ./src/app/shared/components/action-sheet/action-sheet.component.html?ngResource ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ }),

/***/ 50002:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/datetime/datetime.component.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<div (click)=\"toogle()\">{{ actualDate }}</div>\r\n<ng-container *ngIf=\"viewDateTime\">\r\n  <ion-datetime\r\n    locale=\"es-ES\"\r\n    first-day-of-week=\"1\"\r\n    size=\"cover\"\r\n    presentation=\"date\"\r\n  ></ion-datetime>\r\n</ng-container>\r\n";

/***/ }),

/***/ 96951:
/*!*****************************************************************************************!*\
  !*** ./src/app/shared/components/employee-list/employee-list.component.html?ngResource ***!
  \*****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Empleados</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"dismiss()\">\n        <ion-icon color=\"dark\" slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content >\n  <ion-searchbar\n    (ionInput)=\"searchEmployee($event)\"\n    showCancelButton=\"focus\"\n    placeholder=\"Buscar\"\n    cancelButtonText=\"Cancelar\"\n    animated>\n  </ion-searchbar>\n\n  <ion-card *ngFor=\"let employee of employeeCollectionFiltered\" (click)=\"selectEmployee(employee)\" button=\"true\" [ngClass]=\"{'selectedCard': checkIfSelected(employee)}\">\n    <ion-grid class=\"customer-card\">\n      <ion-row class=\"customer-row\">\n        <ion-col class=\"customer-image\" size=\"3\">\n          <img [src]=\"employee.image\" />\n        </ion-col>\n        <ion-col size=\"8\">\n          <ion-label class=\"customer-label\">{{employee.name}} {{employee.surname}}</ion-label>\n        </ion-col>\n        <ion-col size=\"1\">\n          <div class=\"icon-container\">\n            <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n</ion-content>\n<ion-footer>\n  <ion-button\n    [disabled]=\"selectedEmployeeCompo.length < 1\"\n    color=\"dark\"\n    (click)=\"dismiss()\"\n    class=\"apply-button\"\n    expand=\"block\"\n    mode=\"ios\">\n    Seleccionar empleado\n  </ion-button>\n</ion-footer>\n";

/***/ }),

/***/ 39954:
/*!*******************************************************************************!*\
  !*** ./src/app/shared/components/employee/employee.component.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<div *ngIf=\"employee\" [style.width]=\"columnWidth\" no-lines lines=\"none\" class=\"bg-white flex items-center p-2 \">\r\n <div class=\"w-8 h-8 rounded-full\">\r\n <img [src]=\"employee.image\" />\r\n </div>\r\n<div>\r\n    <p class=\"ml-2 text-xs text-gray-600 m-0\">{{employee.name}} {{employee.surname}}</p>\r\n</div>\r\n  \r\n  \r\n \r\n  \r\n</div>\r\n";

/***/ }),

/***/ 87932:
/*!***********************************************************************************************!*\
  !*** ./src/app/shared/components/reservation-card/reservation-card.component.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<div\r\n  ngResizable\r\n  class=\"reservationCard drag-block resizable-widget\"\r\n  [style.height]=\"reservation.mobileSize.height + 'px'\"\r\n  [style.width]=\"reservation.mobileSize.width + 'px'\"\r\n>\r\n  <p [innerText]=\"formatBookingTimetable(reservation)\"></p>\r\n  {{ reservation.service }}\r\n  {{ reservation.customer }}\r\n</div>\r\n";

/***/ }),

/***/ 94773:
/*!*******************************************************************************************************************!*\
  !*** ./src/app/shared/components/time-table-header-employee/time-table-header-employee.component.html?ngResource ***!
  \*******************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ng-container *ngFor=\"let employee of employeeCollection\">\r\n  <th class=\"head-employee\">{{ employee.name }}</th>\r\n</ng-container>\r\n";

/***/ }),

/***/ 89113:
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/time-table/time-table.component.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"bg-white p-0 top-[-1px] w-8 h-10 absolute z-[999]\"></div>\r\n\r\n<div\r\n  class=\"newTable\"\r\n  [style.maxHeight]=\"containerHeight + 'px'\"\r\n  id=\"container\"\r\n  *ngIf=\"timetable && isReady\"\r\n>\r\n  <table class=\"bg-white\">\r\n    <thead class=\"bg-white\">\r\n      <tr>\r\n        <th></th>\r\n        <ng-container *ngFor=\"let employee of timetable.employees\">\r\n          <th class=\"p-0\">\r\n            <app-employee [employee]=\"employee\"></app-employee>\r\n          </th>\r\n        </ng-container>\r\n      </tr>\r\n    </thead>\r\n\r\n    <tbody id=\"tbody\">\r\n      <tr *ngFor=\"let frame of timetable.timeFrames\">\r\n        <th>\r\n          <div class=\"sticky-col background-white\">\r\n            <span>{{ frame | timeframe }}</span>\r\n          </div>\r\n        </th>\r\n        <td *ngFor=\"let employee of timetable.employees\"></td>\r\n      </tr>\r\n    </tbody>\r\n\r\n    <div\r\n      class=\"calendar-container-draggable-zone text-xs\"\r\n      [style.left]=\"leftByPlatform\"\r\n      id=\"draggableZone\"\r\n      #draggableZone\r\n      [style.width]=\"dragWidth\"\r\n      appLongPress\r\n      (mouseLongPress)=\"logLongPress($event)\"\r\n    >\r\n      <ng-container\r\n        *ngFor=\"let reservation of $reservations | async; let i = index\"\r\n      >\r\n        <div\r\n          *ngIf=\"reservation.isBooking\"\r\n          (click)=\"openBooking(reservation, true)\"\r\n          [id]=\"reservation.uuid\"\r\n          [class]=\"'_' + reservation.uuid\"\r\n          [ngResizable]=\"draggableItem === reservation.uuid\"\r\n          [preventDefaultEvent]=\"true\"\r\n          [rzGrid]=\"[0, 8]\"\r\n          [rzMinHeight]=\"24\"\r\n          rzHandles=\"n,s\"\r\n          (rzResizing)=\"onResize($event, reservation.uuid)\"\r\n          (rzStop)=\"onResizeStop(reservation.uuid)\"\r\n          [ngStyle]=\"{\r\n            'border-left': '5px solid' + reservation?.service[0]?.color,\r\n            transform:\r\n              'translate3d(' +\r\n              reservation.mobilePosition?.x +\r\n              'px,' +\r\n              reservation.mobilePosition?.y +\r\n              'px,' +\r\n              '0px )'\r\n          }\"\r\n          [style.background-color]=\"\r\n            reservation.isBooking ? eColor[reservation.service[0]?.color] : ''\r\n          \"\r\n          appLongPress\r\n          (mouseLongPress)=\"logLongPress($event, reservation.uuid)\"\r\n          [style.height]=\"reservation.mobileSize?.height + 'px'\"\r\n          [style.width]=\"columnWidth + 'px'\"\r\n          [ngClass]=\"[\r\n            draggableItem !== reservation.uuid && draggableItem !== null\r\n              ? 'opacity'\r\n              : '',\r\n            reservation?.isGhost ? 'isGhost' : '',\r\n            isEditting && draggableItem === reservation.uuid\r\n              ? 'bg-white z-50'\r\n              : 'overflow-hidden',\r\n            isEditting &&\r\n            draggableItem !== reservation.uuid &&\r\n            draggableItem !== null\r\n              ? 'no-click'\r\n              : '',\r\n            reservation.isBooking\r\n              ? 'reservation draggableItem'\r\n              : 'non-availability',\r\n            isNotPayed(reservation) && !isEditting ? 'animate-pulse' : ''\r\n          ]\"\r\n        >\r\n          <div\r\n          *ngIf=\"reservation.isOverlapped \"\r\n            class=\"grid grid-cols-12 leading-none no-click\"\r\n          >\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-6' : 'col-span-6'\r\n              \"\r\n            >\r\n              <ng-container>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    ).length > 2\r\n                      ? (dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        ) | slice: 0:draggableItem === reservation.uuid ? 8 :4) + \"...\"\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time \r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        ) \r\n                  }}\r\n                </p>\r\n              </ng-container>\r\n\r\n              <ng-template #noEllipsys>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n              </ng-template>\r\n            </div>\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21\r\n                  ? 'col-span-6 order-last float-right'\r\n                  : 'float-right col-span-6'\r\n              \"\r\n            >\r\n               <ng-container [ngSwitch]=\"reservation.status\">\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'No asistida'\"\r\n                  name=\"close-circle-outline\"\r\n                  class=\"text-sm float-right bg-red-400 rounded-full\"\r\n                ></ion-icon>\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'Realizada'\"\r\n                  name=\"checkmark-done-circle-outline\"\r\n                  class=\"text-sm float-right bg-green-500 rounded-full text-white\"\r\n                ></ion-icon>\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'Pendiente de pago'\"\r\n                  name=\"alert-circle-outline\"\r\n                  class=\"text-sm float-right bg-orange-400 rounded-full\"\r\n                ></ion-icon>\r\n                <span *ngSwitchDefault></span>\r\n                <!--  <ion-icon\r\n                *ngIf=\"reservation.note && reservation.status === 'Pending'\"\r\n                name=\"chatbox-outline\"\r\n                class=\"text-xs float-right bg-white rounded-full\"\r\n              ></ion-icon>\r\n              <ion-icon\r\n                *ngIf=\"reservation.message  && reservation.status === 'Pending'\"\r\n                name=\"chatbubble-outline\"\r\n                class=\"text-xs float-right bg-white rounded-full\"\r\n              ></ion-icon> -->\r\n              </ng-container>\r\n             \r\n           \r\n            </div>\r\n            <div\r\n              *ngIf=\"\r\n                reservation.duration > 21 &&\r\n                reservation.mobileSize?.width > columnWidth / 3\r\n              \"\r\n              [ngClass]=\"\r\n                reservation.duration > 21 ? 'col-span-12' : 'col-span-6'\r\n              \"\r\n            >\r\n              <p class=\"\">\r\n                <span>\r\n                  {{ reservation?.customer?.name }}\r\n                  {{\r\n                    reservation.service[0].name.length > 5\r\n                      ? (reservation.service[0].name | slice: 0:5)\r\n                      : reservation.service[0].name\r\n                  }}\r\n                </span>\r\n              </p>\r\n            </div>\r\n          </div>\r\n          <div\r\n            *ngIf=\"!reservation.isOverlapped\"\r\n            class=\"grid grid-cols-12 break-all leading-none no-click\"\r\n          >\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-4' : 'col-span-6'\r\n              \"\r\n            >\r\n              <ng-container *ngIf=\"reservation.duration < 21; else noEllipsys\">\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    ).length > 8\r\n                      ? (dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        ) | slice: 0:7) + \"...\"\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? (draggingData?.time | slice: 0:7) + \"...\"\r\n                      : (dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        ) | slice: 0:7) + \"...\"\r\n                  }}\r\n                </p>\r\n              </ng-container>\r\n\r\n              <ng-template #noEllipsys>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n              </ng-template>\r\n            </div>\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-4' : 'col-span-6'\r\n              \"\r\n              *ngIf=\"reservation.duration < 21\"\r\n            >\r\n              <p class=\"\">\r\n                <span class=\"\">\r\n                  {{\r\n                    reservation?.service[0]?.name.length > 8\r\n                      ? (reservation?.service[0]?.name | slice: 0:8) + \"...\"\r\n                      : reservation?.service[0]?.name\r\n                  }}\r\n                </span>\r\n              </p>\r\n            </div>\r\n\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-4' : 'col-span-6'\r\n              \"\r\n            >\r\n              <ion-icon\r\n                *ngIf=\"reservation.note\"\r\n                name=\"chatbox-outline\"\r\n                class=\"text-xs float-right bg-white rounded-full\"\r\n              ></ion-icon>\r\n              <ion-icon\r\n                *ngIf=\"reservation.message\"\r\n                name=\"chatbubble-outline\"\r\n                class=\"text-xs float-right bg-white rounded-full\"\r\n              ></ion-icon>\r\n              <ng-container [ngSwitch]=\"reservation.status\">\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'No asistida'\"\r\n                  name=\"close-circle-outline\"\r\n                  class=\"text-sm float-right bg-red-400 rounded-full\"\r\n                ></ion-icon>\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'Realizada'\"\r\n                  name=\"checkmark-done-circle-outline\"\r\n                  class=\"text-sm float-right bg-green-500 rounded-full text-white\"\r\n                ></ion-icon>\r\n                <ion-icon\r\n                  *ngSwitchCase=\"'Pendiente de pago'\"\r\n                  name=\"alert-circle-outline\"\r\n                  class=\"text-sm float-right bg-orange-400 rounded-full\"\r\n                ></ion-icon>\r\n                <span *ngSwitchDefault></span>\r\n              </ng-container>\r\n            </div>\r\n          </div>\r\n          <ng-container *ngIf=\"reservation.isBooking\">\r\n            <p\r\n              class=\"no-click leading-none\"\r\n              *ngIf=\"\r\n                reservation.duration >= 21 &&\r\n                reservation.mobileSize?.height >= 24 &&\r\n                !reservation.isOverlapped\r\n              \"\r\n            >\r\n              {{ reservation?.customer?.name }}\r\n              <span *ngFor=\"let service of reservation.service\">\r\n                {{\r\n                  service?.name?.length > 20\r\n                    ? (service.name | slice: 0:20) + \"..\"\r\n                    : service.name\r\n                }}\r\n              </span>\r\n            </p>\r\n          </ng-container>\r\n        </div>\r\n\r\n        <div\r\n          *ngIf=\"!reservation.isBooking\"\r\n          (click)=\"openBooking(reservation, true)\"\r\n          [id]=\"reservation.uuid\"\r\n          [class]=\"'_' + reservation.uuid\"\r\n          [ngResizable]=\"draggableItem === reservation.uuid\"\r\n          [preventDefaultEvent]=\"true\"\r\n          [rzGrid]=\"[0, 8]\"\r\n          [rzMinHeight]=\"24\"\r\n          rzHandles=\"n,s\"\r\n          (rzResizing)=\"onResize($event, reservation.uuid)\"\r\n          (rzStop)=\"onResizeStop(reservation.uuid)\"\r\n          [ngStyle]=\"{\r\n            transform:\r\n              'translate3d(' +\r\n              reservation.mobilePosition?.x +\r\n              'px,' +\r\n              reservation.mobilePosition?.y +\r\n              'px,' +\r\n              '0px )'\r\n          }\"\r\n          [style.height]=\"reservation.mobileSize?.height + 'px'\"\r\n          [style.width]=\"reservation.mobileSize?.width + 'px'\"\r\n          class=\"drag-block resizable-widget draggableItem\"\r\n          appLongPress\r\n          (mouseLongPress)=\"logLongPress($event, reservation.uuid)\"\r\n          [ngClass]=\"[\r\n            draggableItem !== reservation.uuid && draggableItem !== null\r\n              ? 'opacity'\r\n              : '',\r\n            reservation.isBooking ? 'reservation' : 'non-availability'\r\n          ]\"\r\n        >\r\n          <div class=\"grid grid-cols-12 break-all leading-none no-click\">\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-12' : 'col-span-12'\r\n              \"\r\n            >\r\n              <ng-container>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )                     \r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time \r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        ) \r\n                  }}\r\n                </p>\r\n              </ng-container>\r\n\r\n              <ng-template #noEllipsys>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n              </ng-template>\r\n            </div>\r\n\r\n            <div class=\"col-span-6\" *ngIf=\"reservation.duration > 21\">\r\n              <span class=\"text-xs m-0 leading-none\">{{\r\n                reservation.message\r\n              }}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </ng-container>\r\n      <!--  FREE TIME CARDS TO AVOID OF OVERLAP -->\r\n      <ng-container *ngFor=\"let reservation of timetable.freeTime\">\r\n        <div\r\n          [id]=\"reservation.uuid\"\r\n          [ngStyle]=\"{\r\n            transform:\r\n              'translate3d(' +\r\n              reservation.mobilePosition?.x +\r\n              'px,' +\r\n              reservation.mobilePosition?.y +\r\n              'px,' +\r\n              '0px )'\r\n          }\"\r\n          [style.height]=\"reservation.mobileSize?.height + 'px'\"\r\n          [style.width]=\"reservation.mobileSize?.width + 'px'\"\r\n          class=\"drag-block resizable-widget\"\r\n          [ngClass]=\"[reservation.isBooking ? 'reservation' : 'freetime']\"\r\n        >\r\n          <!--   <div class=\"grid grid-cols-12 break-all leading-none no-click\">\r\n            <div\r\n              [ngClass]=\"\r\n                reservation.duration < 21 ? 'col-span-6' : 'col-span-10'\r\n              \"\r\n            >\r\n              <ng-container *ngIf=\"reservation.duration < 21; else noEllipsys\">\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n              </ng-container>\r\n\r\n              <ng-template #noEllipsys>\r\n                <p *ngIf=\"!isDragging\" class=\"text-xs m-0 leading-none\">\r\n                  {{\r\n                    dateService.formatBookingTimetable(\r\n                      reservation.startsHour,\r\n                      reservation.startsMinute,\r\n                      reservation.duration\r\n                    )\r\n                  }}\r\n                </p>\r\n                <p class=\"text-xs m-0 leading-none\" *ngIf=\"isDragging\">\r\n                  {{\r\n                    draggingData?.uuid === reservation.uuid\r\n                      ? draggingData?.time\r\n                      : dateService.formatBookingTimetable(\r\n                          reservation.startsHour,\r\n                          reservation.startsMinute,\r\n                          reservation.duration\r\n                        )\r\n                  }}\r\n                </p>\r\n              </ng-template>\r\n            </div>\r\n\r\n            <div class=\"col-span-6\" *ngIf=\"reservation.duration < 21\">\r\n              <span class=\"text-xs m-0 leading-none\">{{\r\n                reservation.message\r\n              }}</span>\r\n            </div>\r\n          </div> -->\r\n        </div>\r\n      </ng-container>\r\n    </div>\r\n  </table>\r\n\r\n  <div\r\n    id=\"timeline\"\r\n    class=\"time\"\r\n    *ngIf=\"isInsideTimetable() && isToday\"\r\n    [style.top]=\"$actualHour.value + 'px'\"\r\n  >\r\n    <div class=\"relative h-2 w-2 rounded-full bg-green-900\"></div>\r\n  </div>\r\n\r\n  <!--  <table [style.width]=\"tableWidth\">\r\n    <thead>\r\n      <tr class=\"red\">\r\n        <th class=\"header\"></th>\r\n        <ng-container *ngFor=\"let employee of timetable.employees\">\r\n          <th class=\"header\">\r\n            <app-employee [employee]=\"employee\"></app-employee>\r\n          </th>\r\n        </ng-container>\r\n      </tr>\r\n    </thead>\r\n    <tbody id=\"tbody\" appLongPress (mouseLongPress)=\"logLongPress($event)\">\r\n      <tr *ngFor=\"let frame of timetable.timeFrames\">\r\n        <div class=\"sticky-col background-white\">\r\n          <span>{{ frame | timeframe }}</span>\r\n        </div>\r\n        <th *ngFor=\"let employee of timetable.employees\"></th>\r\n      </tr>\r\n\r\n       <div class=\"sticky-col background-white h-2\">\r\n        \r\n        </div>\r\n\r\n    </tbody>\r\n  </table> -->\r\n</div>\r\n";

/***/ }),

/***/ 69594:
/*!**********************************************************!*\
  !*** ./node_modules/@angular/cdk/fesm2015/drag-drop.mjs ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CDK_DRAG_CONFIG": () => (/* binding */ CDK_DRAG_CONFIG),
/* harmony export */   "CDK_DRAG_HANDLE": () => (/* binding */ CDK_DRAG_HANDLE),
/* harmony export */   "CDK_DRAG_PARENT": () => (/* binding */ CDK_DRAG_PARENT),
/* harmony export */   "CDK_DRAG_PLACEHOLDER": () => (/* binding */ CDK_DRAG_PLACEHOLDER),
/* harmony export */   "CDK_DRAG_PREVIEW": () => (/* binding */ CDK_DRAG_PREVIEW),
/* harmony export */   "CDK_DROP_LIST": () => (/* binding */ CDK_DROP_LIST),
/* harmony export */   "CDK_DROP_LIST_GROUP": () => (/* binding */ CDK_DROP_LIST_GROUP),
/* harmony export */   "CdkDrag": () => (/* binding */ CdkDrag),
/* harmony export */   "CdkDragHandle": () => (/* binding */ CdkDragHandle),
/* harmony export */   "CdkDragPlaceholder": () => (/* binding */ CdkDragPlaceholder),
/* harmony export */   "CdkDragPreview": () => (/* binding */ CdkDragPreview),
/* harmony export */   "CdkDropList": () => (/* binding */ CdkDropList),
/* harmony export */   "CdkDropListGroup": () => (/* binding */ CdkDropListGroup),
/* harmony export */   "DragDrop": () => (/* binding */ DragDrop),
/* harmony export */   "DragDropModule": () => (/* binding */ DragDropModule),
/* harmony export */   "DragDropRegistry": () => (/* binding */ DragDropRegistry),
/* harmony export */   "DragRef": () => (/* binding */ DragRef),
/* harmony export */   "DropListRef": () => (/* binding */ DropListRef),
/* harmony export */   "copyArrayItem": () => (/* binding */ copyArrayItem),
/* harmony export */   "moveItemInArray": () => (/* binding */ moveItemInArray),
/* harmony export */   "transferArrayItem": () => (/* binding */ transferArrayItem)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/cdk/platform */ 44168);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/coercion */ 40526);
/* harmony import */ var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/a11y */ 10197);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 46991);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 89365);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 29647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 97378);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 3918);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 1753);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 55231);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 12733);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 64736);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 83358);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 77724);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 76327);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/scrolling */ 43970);
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/cdk/bidi */ 96142);











/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Shallow-extends a stylesheet object with another stylesheet-like object.
 * Note that the keys in `source` have to be dash-cased.
 * @docs-private
 */

function extendStyles(dest, source, importantProperties) {
  for (let key in source) {
    if (source.hasOwnProperty(key)) {
      const value = source[key];

      if (value) {
        dest.setProperty(key, value, (importantProperties === null || importantProperties === void 0 ? void 0 : importantProperties.has(key)) ? 'important' : '');
      } else {
        dest.removeProperty(key);
      }
    }
  }

  return dest;
}
/**
 * Toggles whether the native drag interactions should be enabled for an element.
 * @param element Element on which to toggle the drag interactions.
 * @param enable Whether the drag interactions should be enabled.
 * @docs-private
 */


function toggleNativeDragInteractions(element, enable) {
  const userSelect = enable ? '' : 'none';
  extendStyles(element.style, {
    'touch-action': enable ? '' : 'none',
    '-webkit-user-drag': enable ? '' : 'none',
    '-webkit-tap-highlight-color': enable ? '' : 'transparent',
    'user-select': userSelect,
    '-ms-user-select': userSelect,
    '-webkit-user-select': userSelect,
    '-moz-user-select': userSelect
  });
}
/**
 * Toggles whether an element is visible while preserving its dimensions.
 * @param element Element whose visibility to toggle
 * @param enable Whether the element should be visible.
 * @param importantProperties Properties to be set as `!important`.
 * @docs-private
 */


function toggleVisibility(element, enable, importantProperties) {
  extendStyles(element.style, {
    position: enable ? '' : 'fixed',
    top: enable ? '' : '0',
    opacity: enable ? '' : '0',
    left: enable ? '' : '-999em'
  }, importantProperties);
}
/**
 * Combines a transform string with an optional other transform
 * that exited before the base transform was applied.
 */


function combineTransforms(transform, initialTransform) {
  return initialTransform && initialTransform != 'none' ? transform + ' ' + initialTransform : transform;
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Parses a CSS time value to milliseconds. */


function parseCssTimeUnitsToMs(value) {
  // Some browsers will return it in seconds, whereas others will return milliseconds.
  const multiplier = value.toLowerCase().indexOf('ms') > -1 ? 1 : 1000;
  return parseFloat(value) * multiplier;
}
/** Gets the transform transition duration, including the delay, of an element in milliseconds. */


function getTransformTransitionDurationInMs(element) {
  const computedStyle = getComputedStyle(element);
  const transitionedProperties = parseCssPropertyValue(computedStyle, 'transition-property');
  const property = transitionedProperties.find(prop => prop === 'transform' || prop === 'all'); // If there's no transition for `all` or `transform`, we shouldn't do anything.

  if (!property) {
    return 0;
  } // Get the index of the property that we're interested in and match
  // it up to the same index in `transition-delay` and `transition-duration`.


  const propertyIndex = transitionedProperties.indexOf(property);
  const rawDurations = parseCssPropertyValue(computedStyle, 'transition-duration');
  const rawDelays = parseCssPropertyValue(computedStyle, 'transition-delay');
  return parseCssTimeUnitsToMs(rawDurations[propertyIndex]) + parseCssTimeUnitsToMs(rawDelays[propertyIndex]);
}
/** Parses out multiple values from a computed style into an array. */


function parseCssPropertyValue(computedStyle, name) {
  const value = computedStyle.getPropertyValue(name);
  return value.split(',').map(part => part.trim());
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Gets a mutable version of an element's bounding `ClientRect`. */


function getMutableClientRect(element) {
  const clientRect = element.getBoundingClientRect(); // We need to clone the `clientRect` here, because all the values on it are readonly
  // and we need to be able to update them. Also we can't use a spread here, because
  // the values on a `ClientRect` aren't own properties. See:
  // https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect#Notes

  return {
    top: clientRect.top,
    right: clientRect.right,
    bottom: clientRect.bottom,
    left: clientRect.left,
    width: clientRect.width,
    height: clientRect.height,
    x: clientRect.x,
    y: clientRect.y
  };
}
/**
 * Checks whether some coordinates are within a `ClientRect`.
 * @param clientRect ClientRect that is being checked.
 * @param x Coordinates along the X axis.
 * @param y Coordinates along the Y axis.
 */


function isInsideClientRect(clientRect, x, y) {
  const {
    top,
    bottom,
    left,
    right
  } = clientRect;
  return y >= top && y <= bottom && x >= left && x <= right;
}
/**
 * Updates the top/left positions of a `ClientRect`, as well as their bottom/right counterparts.
 * @param clientRect `ClientRect` that should be updated.
 * @param top Amount to add to the `top` position.
 * @param left Amount to add to the `left` position.
 */


function adjustClientRect(clientRect, top, left) {
  clientRect.top += top;
  clientRect.bottom = clientRect.top + clientRect.height;
  clientRect.left += left;
  clientRect.right = clientRect.left + clientRect.width;
}
/**
 * Checks whether the pointer coordinates are close to a ClientRect.
 * @param rect ClientRect to check against.
 * @param threshold Threshold around the ClientRect.
 * @param pointerX Coordinates along the X axis.
 * @param pointerY Coordinates along the Y axis.
 */


function isPointerNearClientRect(rect, threshold, pointerX, pointerY) {
  const {
    top,
    right,
    bottom,
    left,
    width,
    height
  } = rect;
  const xThreshold = width * threshold;
  const yThreshold = height * threshold;
  return pointerY > top - yThreshold && pointerY < bottom + yThreshold && pointerX > left - xThreshold && pointerX < right + xThreshold;
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Keeps track of the scroll position and dimensions of the parents of an element. */


class ParentPositionTracker {
  constructor(_document) {
    this._document = _document;
    /** Cached positions of the scrollable parent elements. */

    this.positions = new Map();
  }
  /** Clears the cached positions. */


  clear() {
    this.positions.clear();
  }
  /** Caches the positions. Should be called at the beginning of a drag sequence. */


  cache(elements) {
    this.clear();
    this.positions.set(this._document, {
      scrollPosition: this.getViewportScrollPosition()
    });
    elements.forEach(element => {
      this.positions.set(element, {
        scrollPosition: {
          top: element.scrollTop,
          left: element.scrollLeft
        },
        clientRect: getMutableClientRect(element)
      });
    });
  }
  /** Handles scrolling while a drag is taking place. */


  handleScroll(event) {
    const target = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getEventTarget)(event);

    const cachedPosition = this.positions.get(target);

    if (!cachedPosition) {
      return null;
    }

    const scrollPosition = cachedPosition.scrollPosition;
    let newTop;
    let newLeft;

    if (target === this._document) {
      const viewportScrollPosition = this.getViewportScrollPosition();
      newTop = viewportScrollPosition.top;
      newLeft = viewportScrollPosition.left;
    } else {
      newTop = target.scrollTop;
      newLeft = target.scrollLeft;
    }

    const topDifference = scrollPosition.top - newTop;
    const leftDifference = scrollPosition.left - newLeft; // Go through and update the cached positions of the scroll
    // parents that are inside the element that was scrolled.

    this.positions.forEach((position, node) => {
      if (position.clientRect && target !== node && target.contains(node)) {
        adjustClientRect(position.clientRect, topDifference, leftDifference);
      }
    });
    scrollPosition.top = newTop;
    scrollPosition.left = newLeft;
    return {
      top: topDifference,
      left: leftDifference
    };
  }
  /**
   * Gets the scroll position of the viewport. Note that we use the scrollX and scrollY directly,
   * instead of going through the `ViewportRuler`, because the first value the ruler looks at is
   * the top/left offset of the `document.documentElement` which works for most cases, but breaks
   * if the element is offset by something like the `BlockScrollStrategy`.
   */


  getViewportScrollPosition() {
    return {
      top: window.scrollY,
      left: window.scrollX
    };
  }

}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Creates a deep clone of an element. */


function deepCloneNode(node) {
  const clone = node.cloneNode(true);
  const descendantsWithId = clone.querySelectorAll('[id]');
  const nodeName = node.nodeName.toLowerCase(); // Remove the `id` to avoid having multiple elements with the same id on the page.

  clone.removeAttribute('id');

  for (let i = 0; i < descendantsWithId.length; i++) {
    descendantsWithId[i].removeAttribute('id');
  }

  if (nodeName === 'canvas') {
    transferCanvasData(node, clone);
  } else if (nodeName === 'input' || nodeName === 'select' || nodeName === 'textarea') {
    transferInputData(node, clone);
  }

  transferData('canvas', node, clone, transferCanvasData);
  transferData('input, textarea, select', node, clone, transferInputData);
  return clone;
}
/** Matches elements between an element and its clone and allows for their data to be cloned. */


function transferData(selector, node, clone, callback) {
  const descendantElements = node.querySelectorAll(selector);

  if (descendantElements.length) {
    const cloneElements = clone.querySelectorAll(selector);

    for (let i = 0; i < descendantElements.length; i++) {
      callback(descendantElements[i], cloneElements[i]);
    }
  }
} // Counter for unique cloned radio button names.


let cloneUniqueId = 0;
/** Transfers the data of one input element to another. */

function transferInputData(source, clone) {
  // Browsers throw an error when assigning the value of a file input programmatically.
  if (clone.type !== 'file') {
    clone.value = source.value;
  } // Radio button `name` attributes must be unique for radio button groups
  // otherwise original radio buttons can lose their checked state
  // once the clone is inserted in the DOM.


  if (clone.type === 'radio' && clone.name) {
    clone.name = `mat-clone-${clone.name}-${cloneUniqueId++}`;
  }
}
/** Transfers the data of one canvas element to another. */


function transferCanvasData(source, clone) {
  const context = clone.getContext('2d');

  if (context) {
    // In some cases `drawImage` can throw (e.g. if the canvas size is 0x0).
    // We can't do much about it so just ignore the error.
    try {
      context.drawImage(source, 0, 0);
    } catch (_a) {}
  }
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Options that can be used to bind a passive event listener. */


const passiveEventListenerOptions = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__.normalizePassiveListenerOptions)({
  passive: true
});
/** Options that can be used to bind an active event listener. */

const activeEventListenerOptions = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__.normalizePassiveListenerOptions)({
  passive: false
});
/**
 * Time in milliseconds for which to ignore mouse events, after
 * receiving a touch event. Used to avoid doing double work for
 * touch devices where the browser fires fake mouse events, in
 * addition to touch events.
 */

const MOUSE_EVENT_IGNORE_TIME = 800;
/** Inline styles to be set as `!important` while dragging. */

const dragImportantProperties = new Set([// Needs to be important, because some `mat-table` sets `position: sticky !important`. See #22781.
'position']);
/**
 * Reference to a draggable item. Used to manipulate or dispose of the item.
 */

class DragRef {
  constructor(element, _config, _document, _ngZone, _viewportRuler, _dragDropRegistry) {
    this._config = _config;
    this._document = _document;
    this._ngZone = _ngZone;
    this._viewportRuler = _viewportRuler;
    this._dragDropRegistry = _dragDropRegistry;
    /**
     * CSS `transform` applied to the element when it isn't being dragged. We need a
     * passive transform in order for the dragged element to retain its new position
     * after the user has stopped dragging and because we need to know the relative
     * position in case they start dragging again. This corresponds to `element.style.transform`.
     */

    this._passiveTransform = {
      x: 0,
      y: 0
    };
    /** CSS `transform` that is applied to the element while it's being dragged. */

    this._activeTransform = {
      x: 0,
      y: 0
    };
    /**
     * Whether the dragging sequence has been started. Doesn't
     * necessarily mean that the element has been moved.
     */

    this._hasStartedDragging = false;
    /** Emits when the item is being moved. */

    this._moveEvents = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Subscription to pointer movement events. */

    this._pointerMoveSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription.EMPTY;
    /** Subscription to the event that is dispatched when the user lifts their pointer. */

    this._pointerUpSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription.EMPTY;
    /** Subscription to the viewport being scrolled. */

    this._scrollSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription.EMPTY;
    /** Subscription to the viewport being resized. */

    this._resizeSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription.EMPTY;
    /** Cached reference to the boundary element. */

    this._boundaryElement = null;
    /** Whether the native dragging interactions have been enabled on the root element. */

    this._nativeInteractionsEnabled = true;
    /** Elements that can be used to drag the draggable item. */

    this._handles = [];
    /** Registered handles that are currently disabled. */

    this._disabledHandles = new Set();
    /** Layout direction of the item. */

    this._direction = 'ltr';
    /**
     * Amount of milliseconds to wait after the user has put their
     * pointer down before starting to drag the element.
     */

    this.dragStartDelay = 0;
    this._disabled = false;
    /** Emits as the drag sequence is being prepared. */

    this.beforeStarted = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user starts dragging the item. */

    this.started = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user has released a drag item, before any animations have started. */

    this.released = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user stops dragging an item in the container. */

    this.ended = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user has moved the item into a new container. */

    this.entered = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user removes the item its container by dragging it into another container. */

    this.exited = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user drops the item inside a container. */

    this.dropped = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Emits as the user is dragging the item. Use with caution,
     * because this event will fire for every pixel that the user has dragged.
     */

    this.moved = this._moveEvents;
    /** Handler for the `mousedown`/`touchstart` events. */

    this._pointerDown = event => {
      this.beforeStarted.next(); // Delegate the event based on whether it started from a handle or the element itself.

      if (this._handles.length) {
        const targetHandle = this._getTargetHandle(event);

        if (targetHandle && !this._disabledHandles.has(targetHandle) && !this.disabled) {
          this._initializeDragSequence(targetHandle, event);
        }
      } else if (!this.disabled) {
        this._initializeDragSequence(this._rootElement, event);
      }
    };
    /** Handler that is invoked when the user moves their pointer after they've initiated a drag. */


    this._pointerMove = event => {
      const pointerPosition = this._getPointerPositionOnPage(event);

      if (!this._hasStartedDragging) {
        const distanceX = Math.abs(pointerPosition.x - this._pickupPositionOnPage.x);
        const distanceY = Math.abs(pointerPosition.y - this._pickupPositionOnPage.y);
        const isOverThreshold = distanceX + distanceY >= this._config.dragStartThreshold; // Only start dragging after the user has moved more than the minimum distance in either
        // direction. Note that this is preferrable over doing something like `skip(minimumDistance)`
        // in the `pointerMove` subscription, because we're not guaranteed to have one move event
        // per pixel of movement (e.g. if the user moves their pointer quickly).

        if (isOverThreshold) {
          const isDelayElapsed = Date.now() >= this._dragStartTime + this._getDragStartDelay(event);

          const container = this._dropContainer;

          if (!isDelayElapsed) {
            this._endDragSequence(event);

            return;
          } // Prevent other drag sequences from starting while something in the container is still
          // being dragged. This can happen while we're waiting for the drop animation to finish
          // and can cause errors, because some elements might still be moving around.


          if (!container || !container.isDragging() && !container.isReceiving()) {
            // Prevent the default action as soon as the dragging sequence is considered as
            // "started" since waiting for the next event can allow the device to begin scrolling.
            event.preventDefault();
            this._hasStartedDragging = true;

            this._ngZone.run(() => this._startDragSequence(event));
          }
        }

        return;
      } // We prevent the default action down here so that we know that dragging has started. This is
      // important for touch devices where doing this too early can unnecessarily block scrolling,
      // if there's a dragging delay.


      event.preventDefault();

      const constrainedPointerPosition = this._getConstrainedPointerPosition(pointerPosition);

      this._hasMoved = true;
      this._lastKnownPointerPosition = pointerPosition;

      this._updatePointerDirectionDelta(constrainedPointerPosition);

      if (this._dropContainer) {
        this._updateActiveDropContainer(constrainedPointerPosition, pointerPosition);
      } else {
        const activeTransform = this._activeTransform;
        activeTransform.x = constrainedPointerPosition.x - this._pickupPositionOnPage.x + this._passiveTransform.x;
        activeTransform.y = constrainedPointerPosition.y - this._pickupPositionOnPage.y + this._passiveTransform.y;

        this._applyRootElementTransform(activeTransform.x, activeTransform.y);
      } // Since this event gets fired for every pixel while dragging, we only
      // want to fire it if the consumer opted into it. Also we have to
      // re-enter the zone because we run all of the events on the outside.


      if (this._moveEvents.observers.length) {
        this._ngZone.run(() => {
          this._moveEvents.next({
            source: this,
            pointerPosition: constrainedPointerPosition,
            event,
            distance: this._getDragDistance(constrainedPointerPosition),
            delta: this._pointerDirectionDelta
          });
        });
      }
    };
    /** Handler that is invoked when the user lifts their pointer up, after initiating a drag. */


    this._pointerUp = event => {
      this._endDragSequence(event);
    };
    /** Handles a native `dragstart` event. */


    this._nativeDragStart = event => {
      if (this._handles.length) {
        const targetHandle = this._getTargetHandle(event);

        if (targetHandle && !this._disabledHandles.has(targetHandle) && !this.disabled) {
          event.preventDefault();
        }
      } else if (!this.disabled) {
        // Usually this isn't necessary since the we prevent the default action in `pointerDown`,
        // but some cases like dragging of links can slip through (see #24403).
        event.preventDefault();
      }
    };

    this.withRootElement(element).withParent(_config.parentDragRef || null);
    this._parentPositions = new ParentPositionTracker(_document);

    _dragDropRegistry.registerDragItem(this);
  }
  /** Whether starting to drag this element is disabled. */


  get disabled() {
    return this._disabled || !!(this._dropContainer && this._dropContainer.disabled);
  }

  set disabled(value) {
    const newValue = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);

    if (newValue !== this._disabled) {
      this._disabled = newValue;

      this._toggleNativeDragInteractions();

      this._handles.forEach(handle => toggleNativeDragInteractions(handle, newValue));
    }
  }
  /**
   * Returns the element that is being used as a placeholder
   * while the current element is being dragged.
   */


  getPlaceholderElement() {
    return this._placeholder;
  }
  /** Returns the root draggable element. */


  getRootElement() {
    return this._rootElement;
  }
  /**
   * Gets the currently-visible element that represents the drag item.
   * While dragging this is the placeholder, otherwise it's the root element.
   */


  getVisibleElement() {
    return this.isDragging() ? this.getPlaceholderElement() : this.getRootElement();
  }
  /** Registers the handles that can be used to drag the element. */


  withHandles(handles) {
    this._handles = handles.map(handle => (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(handle));

    this._handles.forEach(handle => toggleNativeDragInteractions(handle, this.disabled));

    this._toggleNativeDragInteractions(); // Delete any lingering disabled handles that may have been destroyed. Note that we re-create
    // the set, rather than iterate over it and filter out the destroyed handles, because while
    // the ES spec allows for sets to be modified while they're being iterated over, some polyfills
    // use an array internally which may throw an error.


    const disabledHandles = new Set();

    this._disabledHandles.forEach(handle => {
      if (this._handles.indexOf(handle) > -1) {
        disabledHandles.add(handle);
      }
    });

    this._disabledHandles = disabledHandles;
    return this;
  }
  /**
   * Registers the template that should be used for the drag preview.
   * @param template Template that from which to stamp out the preview.
   */


  withPreviewTemplate(template) {
    this._previewTemplate = template;
    return this;
  }
  /**
   * Registers the template that should be used for the drag placeholder.
   * @param template Template that from which to stamp out the placeholder.
   */


  withPlaceholderTemplate(template) {
    this._placeholderTemplate = template;
    return this;
  }
  /**
   * Sets an alternate drag root element. The root element is the element that will be moved as
   * the user is dragging. Passing an alternate root element is useful when trying to enable
   * dragging on an element that you might not have access to.
   */


  withRootElement(rootElement) {
    const element = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(rootElement);

    if (element !== this._rootElement) {
      if (this._rootElement) {
        this._removeRootElementListeners(this._rootElement);
      }

      this._ngZone.runOutsideAngular(() => {
        element.addEventListener('mousedown', this._pointerDown, activeEventListenerOptions);
        element.addEventListener('touchstart', this._pointerDown, passiveEventListenerOptions);
        element.addEventListener('dragstart', this._nativeDragStart, activeEventListenerOptions);
      });

      this._initialTransform = undefined;
      this._rootElement = element;
    }

    if (typeof SVGElement !== 'undefined' && this._rootElement instanceof SVGElement) {
      this._ownerSVGElement = this._rootElement.ownerSVGElement;
    }

    return this;
  }
  /**
   * Element to which the draggable's position will be constrained.
   */


  withBoundaryElement(boundaryElement) {
    this._boundaryElement = boundaryElement ? (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(boundaryElement) : null;

    this._resizeSubscription.unsubscribe();

    if (boundaryElement) {
      this._resizeSubscription = this._viewportRuler.change(10).subscribe(() => this._containInsideBoundaryOnResize());
    }

    return this;
  }
  /** Sets the parent ref that the ref is nested in.  */


  withParent(parent) {
    this._parentDragRef = parent;
    return this;
  }
  /** Removes the dragging functionality from the DOM element. */


  dispose() {
    var _a, _b;

    this._removeRootElementListeners(this._rootElement); // Do this check before removing from the registry since it'll
    // stop being considered as dragged once it is removed.


    if (this.isDragging()) {
      // Since we move out the element to the end of the body while it's being
      // dragged, we have to make sure that it's removed if it gets destroyed.
      (_a = this._rootElement) === null || _a === void 0 ? void 0 : _a.remove();
    }

    (_b = this._anchor) === null || _b === void 0 ? void 0 : _b.remove();

    this._destroyPreview();

    this._destroyPlaceholder();

    this._dragDropRegistry.removeDragItem(this);

    this._removeSubscriptions();

    this.beforeStarted.complete();
    this.started.complete();
    this.released.complete();
    this.ended.complete();
    this.entered.complete();
    this.exited.complete();
    this.dropped.complete();

    this._moveEvents.complete();

    this._handles = [];

    this._disabledHandles.clear();

    this._dropContainer = undefined;

    this._resizeSubscription.unsubscribe();

    this._parentPositions.clear();

    this._boundaryElement = this._rootElement = this._ownerSVGElement = this._placeholderTemplate = this._previewTemplate = this._anchor = this._parentDragRef = null;
  }
  /** Checks whether the element is currently being dragged. */


  isDragging() {
    return this._hasStartedDragging && this._dragDropRegistry.isDragging(this);
  }
  /** Resets a standalone drag item to its initial position. */


  reset() {
    this._rootElement.style.transform = this._initialTransform || '';
    this._activeTransform = {
      x: 0,
      y: 0
    };
    this._passiveTransform = {
      x: 0,
      y: 0
    };
  }
  /**
   * Sets a handle as disabled. While a handle is disabled, it'll capture and interrupt dragging.
   * @param handle Handle element that should be disabled.
   */


  disableHandle(handle) {
    if (!this._disabledHandles.has(handle) && this._handles.indexOf(handle) > -1) {
      this._disabledHandles.add(handle);

      toggleNativeDragInteractions(handle, true);
    }
  }
  /**
   * Enables a handle, if it has been disabled.
   * @param handle Handle element to be enabled.
   */


  enableHandle(handle) {
    if (this._disabledHandles.has(handle)) {
      this._disabledHandles.delete(handle);

      toggleNativeDragInteractions(handle, this.disabled);
    }
  }
  /** Sets the layout direction of the draggable item. */


  withDirection(direction) {
    this._direction = direction;
    return this;
  }
  /** Sets the container that the item is part of. */


  _withDropContainer(container) {
    this._dropContainer = container;
  }
  /**
   * Gets the current position in pixels the draggable outside of a drop container.
   */


  getFreeDragPosition() {
    const position = this.isDragging() ? this._activeTransform : this._passiveTransform;
    return {
      x: position.x,
      y: position.y
    };
  }
  /**
   * Sets the current position in pixels the draggable outside of a drop container.
   * @param value New position to be set.
   */


  setFreeDragPosition(value) {
    this._activeTransform = {
      x: 0,
      y: 0
    };
    this._passiveTransform.x = value.x;
    this._passiveTransform.y = value.y;

    if (!this._dropContainer) {
      this._applyRootElementTransform(value.x, value.y);
    }

    return this;
  }
  /**
   * Sets the container into which to insert the preview element.
   * @param value Container into which to insert the preview.
   */


  withPreviewContainer(value) {
    this._previewContainer = value;
    return this;
  }
  /** Updates the item's sort order based on the last-known pointer position. */


  _sortFromLastPointerPosition() {
    const position = this._lastKnownPointerPosition;

    if (position && this._dropContainer) {
      this._updateActiveDropContainer(this._getConstrainedPointerPosition(position), position);
    }
  }
  /** Unsubscribes from the global subscriptions. */


  _removeSubscriptions() {
    this._pointerMoveSubscription.unsubscribe();

    this._pointerUpSubscription.unsubscribe();

    this._scrollSubscription.unsubscribe();
  }
  /** Destroys the preview element and its ViewRef. */


  _destroyPreview() {
    var _a, _b;

    (_a = this._preview) === null || _a === void 0 ? void 0 : _a.remove();
    (_b = this._previewRef) === null || _b === void 0 ? void 0 : _b.destroy();
    this._preview = this._previewRef = null;
  }
  /** Destroys the placeholder element and its ViewRef. */


  _destroyPlaceholder() {
    var _a, _b;

    (_a = this._placeholder) === null || _a === void 0 ? void 0 : _a.remove();
    (_b = this._placeholderRef) === null || _b === void 0 ? void 0 : _b.destroy();
    this._placeholder = this._placeholderRef = null;
  }
  /**
   * Clears subscriptions and stops the dragging sequence.
   * @param event Browser event object that ended the sequence.
   */


  _endDragSequence(event) {
    // Note that here we use `isDragging` from the service, rather than from `this`.
    // The difference is that the one from the service reflects whether a dragging sequence
    // has been initiated, whereas the one on `this` includes whether the user has passed
    // the minimum dragging threshold.
    if (!this._dragDropRegistry.isDragging(this)) {
      return;
    }

    this._removeSubscriptions();

    this._dragDropRegistry.stopDragging(this);

    this._toggleNativeDragInteractions();

    if (this._handles) {
      this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight;
    }

    if (!this._hasStartedDragging) {
      return;
    }

    this.released.next({
      source: this
    });

    if (this._dropContainer) {
      // Stop scrolling immediately, instead of waiting for the animation to finish.
      this._dropContainer._stopScrolling();

      this._animatePreviewToPlaceholder().then(() => {
        this._cleanupDragArtifacts(event);

        this._cleanupCachedDimensions();

        this._dragDropRegistry.stopDragging(this);
      });
    } else {
      // Convert the active transform into a passive one. This means that next time
      // the user starts dragging the item, its position will be calculated relatively
      // to the new passive transform.
      this._passiveTransform.x = this._activeTransform.x;

      const pointerPosition = this._getPointerPositionOnPage(event);

      this._passiveTransform.y = this._activeTransform.y;

      this._ngZone.run(() => {
        this.ended.next({
          source: this,
          distance: this._getDragDistance(pointerPosition),
          dropPoint: pointerPosition
        });
      });

      this._cleanupCachedDimensions();

      this._dragDropRegistry.stopDragging(this);
    }
  }
  /** Starts the dragging sequence. */


  _startDragSequence(event) {
    if (isTouchEvent(event)) {
      this._lastTouchEventTime = Date.now();
    }

    this._toggleNativeDragInteractions();

    const dropContainer = this._dropContainer;

    if (dropContainer) {
      const element = this._rootElement;
      const parent = element.parentNode;

      const placeholder = this._placeholder = this._createPlaceholderElement();

      const anchor = this._anchor = this._anchor || this._document.createComment(''); // Needs to happen before the root element is moved.


      const shadowRoot = this._getShadowRoot(); // Insert an anchor node so that we can restore the element's position in the DOM.


      parent.insertBefore(anchor, element); // There's no risk of transforms stacking when inside a drop container so
      // we can keep the initial transform up to date any time dragging starts.

      this._initialTransform = element.style.transform || ''; // Create the preview after the initial transform has
      // been cached, because it can be affected by the transform.

      this._preview = this._createPreviewElement(); // We move the element out at the end of the body and we make it hidden, because keeping it in
      // place will throw off the consumer's `:last-child` selectors. We can't remove the element
      // from the DOM completely, because iOS will stop firing all subsequent events in the chain.

      toggleVisibility(element, false, dragImportantProperties);

      this._document.body.appendChild(parent.replaceChild(placeholder, element));

      this._getPreviewInsertionPoint(parent, shadowRoot).appendChild(this._preview);

      this.started.next({
        source: this
      }); // Emit before notifying the container.

      dropContainer.start();
      this._initialContainer = dropContainer;
      this._initialIndex = dropContainer.getItemIndex(this);
    } else {
      this.started.next({
        source: this
      });
      this._initialContainer = this._initialIndex = undefined;
    } // Important to run after we've called `start` on the parent container
    // so that it has had time to resolve its scrollable parents.


    this._parentPositions.cache(dropContainer ? dropContainer.getScrollableParents() : []);
  }
  /**
   * Sets up the different variables and subscriptions
   * that will be necessary for the dragging sequence.
   * @param referenceElement Element that started the drag sequence.
   * @param event Browser event object that started the sequence.
   */


  _initializeDragSequence(referenceElement, event) {
    // Stop propagation if the item is inside another
    // draggable so we don't start multiple drag sequences.
    if (this._parentDragRef) {
      event.stopPropagation();
    }

    const isDragging = this.isDragging();
    const isTouchSequence = isTouchEvent(event);
    const isAuxiliaryMouseButton = !isTouchSequence && event.button !== 0;
    const rootElement = this._rootElement;

    const target = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getEventTarget)(event);

    const isSyntheticEvent = !isTouchSequence && this._lastTouchEventTime && this._lastTouchEventTime + MOUSE_EVENT_IGNORE_TIME > Date.now();
    const isFakeEvent = isTouchSequence ? (0,_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__.isFakeTouchstartFromScreenReader)(event) : (0,_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_4__.isFakeMousedownFromScreenReader)(event); // If the event started from an element with the native HTML drag&drop, it'll interfere
    // with our own dragging (e.g. `img` tags do it by default). Prevent the default action
    // to stop it from happening. Note that preventing on `dragstart` also seems to work, but
    // it's flaky and it fails if the user drags it away quickly. Also note that we only want
    // to do this for `mousedown` since doing the same for `touchstart` will stop any `click`
    // events from firing on touch devices.

    if (target && target.draggable && event.type === 'mousedown') {
      event.preventDefault();
    } // Abort if the user is already dragging or is using a mouse button other than the primary one.


    if (isDragging || isAuxiliaryMouseButton || isSyntheticEvent || isFakeEvent) {
      return;
    } // If we've got handles, we need to disable the tap highlight on the entire root element,
    // otherwise iOS will still add it, even though all the drag interactions on the handle
    // are disabled.


    if (this._handles.length) {
      const rootStyles = rootElement.style;
      this._rootElementTapHighlight = rootStyles.webkitTapHighlightColor || '';
      rootStyles.webkitTapHighlightColor = 'transparent';
    }

    this._hasStartedDragging = this._hasMoved = false; // Avoid multiple subscriptions and memory leaks when multi touch
    // (isDragging check above isn't enough because of possible temporal and/or dimensional delays)

    this._removeSubscriptions();

    this._pointerMoveSubscription = this._dragDropRegistry.pointerMove.subscribe(this._pointerMove);
    this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp);
    this._scrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(scrollEvent => this._updateOnScroll(scrollEvent));

    if (this._boundaryElement) {
      this._boundaryRect = getMutableClientRect(this._boundaryElement);
    } // If we have a custom preview we can't know ahead of time how large it'll be so we position
    // it next to the cursor. The exception is when the consumer has opted into making the preview
    // the same size as the root element, in which case we do know the size.


    const previewTemplate = this._previewTemplate;
    this._pickupPositionInElement = previewTemplate && previewTemplate.template && !previewTemplate.matchSize ? {
      x: 0,
      y: 0
    } : this._getPointerPositionInElement(referenceElement, event);

    const pointerPosition = this._pickupPositionOnPage = this._lastKnownPointerPosition = this._getPointerPositionOnPage(event);

    this._pointerDirectionDelta = {
      x: 0,
      y: 0
    };
    this._pointerPositionAtLastDirectionChange = {
      x: pointerPosition.x,
      y: pointerPosition.y
    };
    this._dragStartTime = Date.now();

    this._dragDropRegistry.startDragging(this, event);
  }
  /** Cleans up the DOM artifacts that were added to facilitate the element being dragged. */


  _cleanupDragArtifacts(event) {
    // Restore the element's visibility and insert it at its old position in the DOM.
    // It's important that we maintain the position, because moving the element around in the DOM
    // can throw off `NgFor` which does smart diffing and re-creates elements only when necessary,
    // while moving the existing elements in all other cases.
    toggleVisibility(this._rootElement, true, dragImportantProperties);

    this._anchor.parentNode.replaceChild(this._rootElement, this._anchor);

    this._destroyPreview();

    this._destroyPlaceholder();

    this._boundaryRect = this._previewRect = this._initialTransform = undefined; // Re-enter the NgZone since we bound `document` events on the outside.

    this._ngZone.run(() => {
      const container = this._dropContainer;
      const currentIndex = container.getItemIndex(this);

      const pointerPosition = this._getPointerPositionOnPage(event);

      const distance = this._getDragDistance(pointerPosition);

      const isPointerOverContainer = container._isOverContainer(pointerPosition.x, pointerPosition.y);

      this.ended.next({
        source: this,
        distance,
        dropPoint: pointerPosition
      });
      this.dropped.next({
        item: this,
        currentIndex,
        previousIndex: this._initialIndex,
        container: container,
        previousContainer: this._initialContainer,
        isPointerOverContainer,
        distance,
        dropPoint: pointerPosition
      });
      container.drop(this, currentIndex, this._initialIndex, this._initialContainer, isPointerOverContainer, distance, pointerPosition);
      this._dropContainer = this._initialContainer;
    });
  }
  /**
   * Updates the item's position in its drop container, or moves it
   * into a new one, depending on its current drag position.
   */


  _updateActiveDropContainer({
    x,
    y
  }, {
    x: rawX,
    y: rawY
  }) {
    // Drop container that draggable has been moved into.
    let newContainer = this._initialContainer._getSiblingContainerFromPosition(this, x, y); // If we couldn't find a new container to move the item into, and the item has left its
    // initial container, check whether the it's over the initial container. This handles the
    // case where two containers are connected one way and the user tries to undo dragging an
    // item into a new container.


    if (!newContainer && this._dropContainer !== this._initialContainer && this._initialContainer._isOverContainer(x, y)) {
      newContainer = this._initialContainer;
    }

    if (newContainer && newContainer !== this._dropContainer) {
      this._ngZone.run(() => {
        // Notify the old container that the item has left.
        this.exited.next({
          item: this,
          container: this._dropContainer
        });

        this._dropContainer.exit(this); // Notify the new container that the item has entered.


        this._dropContainer = newContainer;

        this._dropContainer.enter(this, x, y, newContainer === this._initialContainer && // If we're re-entering the initial container and sorting is disabled,
        // put item the into its starting index to begin with.
        newContainer.sortingDisabled ? this._initialIndex : undefined);

        this.entered.next({
          item: this,
          container: newContainer,
          currentIndex: newContainer.getItemIndex(this)
        });
      });
    } // Dragging may have been interrupted as a result of the events above.


    if (this.isDragging()) {
      this._dropContainer._startScrollingIfNecessary(rawX, rawY);

      this._dropContainer._sortItem(this, x, y, this._pointerDirectionDelta);

      this._applyPreviewTransform(x - this._pickupPositionInElement.x, y - this._pickupPositionInElement.y);
    }
  }
  /**
   * Creates the element that will be rendered next to the user's pointer
   * and will be used as a preview of the element that is being dragged.
   */


  _createPreviewElement() {
    const previewConfig = this._previewTemplate;
    const previewClass = this.previewClass;
    const previewTemplate = previewConfig ? previewConfig.template : null;
    let preview;

    if (previewTemplate && previewConfig) {
      // Measure the element before we've inserted the preview
      // since the insertion could throw off the measurement.
      const rootRect = previewConfig.matchSize ? this._rootElement.getBoundingClientRect() : null;
      const viewRef = previewConfig.viewContainer.createEmbeddedView(previewTemplate, previewConfig.context);
      viewRef.detectChanges();
      preview = getRootNode(viewRef, this._document);
      this._previewRef = viewRef;

      if (previewConfig.matchSize) {
        matchElementSize(preview, rootRect);
      } else {
        preview.style.transform = getTransform(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y);
      }
    } else {
      const element = this._rootElement;
      preview = deepCloneNode(element);
      matchElementSize(preview, element.getBoundingClientRect());

      if (this._initialTransform) {
        preview.style.transform = this._initialTransform;
      }
    }

    extendStyles(preview.style, {
      // It's important that we disable the pointer events on the preview, because
      // it can throw off the `document.elementFromPoint` calls in the `CdkDropList`.
      'pointer-events': 'none',
      // We have to reset the margin, because it can throw off positioning relative to the viewport.
      'margin': '0',
      'position': 'fixed',
      'top': '0',
      'left': '0',
      'z-index': `${this._config.zIndex || 1000}`
    }, dragImportantProperties);
    toggleNativeDragInteractions(preview, false);
    preview.classList.add('cdk-drag-preview');
    preview.setAttribute('dir', this._direction);

    if (previewClass) {
      if (Array.isArray(previewClass)) {
        previewClass.forEach(className => preview.classList.add(className));
      } else {
        preview.classList.add(previewClass);
      }
    }

    return preview;
  }
  /**
   * Animates the preview element from its current position to the location of the drop placeholder.
   * @returns Promise that resolves when the animation completes.
   */


  _animatePreviewToPlaceholder() {
    // If the user hasn't moved yet, the transitionend event won't fire.
    if (!this._hasMoved) {
      return Promise.resolve();
    }

    const placeholderRect = this._placeholder.getBoundingClientRect(); // Apply the class that adds a transition to the preview.


    this._preview.classList.add('cdk-drag-animating'); // Move the preview to the placeholder position.


    this._applyPreviewTransform(placeholderRect.left, placeholderRect.top); // If the element doesn't have a `transition`, the `transitionend` event won't fire. Since
    // we need to trigger a style recalculation in order for the `cdk-drag-animating` class to
    // apply its style, we take advantage of the available info to figure out whether we need to
    // bind the event in the first place.


    const duration = getTransformTransitionDurationInMs(this._preview);

    if (duration === 0) {
      return Promise.resolve();
    }

    return this._ngZone.runOutsideAngular(() => {
      return new Promise(resolve => {
        const handler = event => {
          var _a;

          if (!event || (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getEventTarget)(event) === this._preview && event.propertyName === 'transform') {
            (_a = this._preview) === null || _a === void 0 ? void 0 : _a.removeEventListener('transitionend', handler);
            resolve();
            clearTimeout(timeout);
          }
        }; // If a transition is short enough, the browser might not fire the `transitionend` event.
        // Since we know how long it's supposed to take, add a timeout with a 50% buffer that'll
        // fire if the transition hasn't completed when it was supposed to.


        const timeout = setTimeout(handler, duration * 1.5);

        this._preview.addEventListener('transitionend', handler);
      });
    });
  }
  /** Creates an element that will be shown instead of the current element while dragging. */


  _createPlaceholderElement() {
    const placeholderConfig = this._placeholderTemplate;
    const placeholderTemplate = placeholderConfig ? placeholderConfig.template : null;
    let placeholder;

    if (placeholderTemplate) {
      this._placeholderRef = placeholderConfig.viewContainer.createEmbeddedView(placeholderTemplate, placeholderConfig.context);

      this._placeholderRef.detectChanges();

      placeholder = getRootNode(this._placeholderRef, this._document);
    } else {
      placeholder = deepCloneNode(this._rootElement);
    } // Stop pointer events on the preview so the user can't
    // interact with it while the preview is animating.


    placeholder.style.pointerEvents = 'none';
    placeholder.classList.add('cdk-drag-placeholder');
    return placeholder;
  }
  /**
   * Figures out the coordinates at which an element was picked up.
   * @param referenceElement Element that initiated the dragging.
   * @param event Event that initiated the dragging.
   */


  _getPointerPositionInElement(referenceElement, event) {
    const elementRect = this._rootElement.getBoundingClientRect();

    const handleElement = referenceElement === this._rootElement ? null : referenceElement;
    const referenceRect = handleElement ? handleElement.getBoundingClientRect() : elementRect;
    const point = isTouchEvent(event) ? event.targetTouches[0] : event;

    const scrollPosition = this._getViewportScrollPosition();

    const x = point.pageX - referenceRect.left - scrollPosition.left;
    const y = point.pageY - referenceRect.top - scrollPosition.top;
    return {
      x: referenceRect.left - elementRect.left + x,
      y: referenceRect.top - elementRect.top + y
    };
  }
  /** Determines the point of the page that was touched by the user. */


  _getPointerPositionOnPage(event) {
    const scrollPosition = this._getViewportScrollPosition();

    const point = isTouchEvent(event) ? // `touches` will be empty for start/end events so we have to fall back to `changedTouches`.
    // Also note that on real devices we're guaranteed for either `touches` or `changedTouches`
    // to have a value, but Firefox in device emulation mode has a bug where both can be empty
    // for `touchstart` and `touchend` so we fall back to a dummy object in order to avoid
    // throwing an error. The value returned here will be incorrect, but since this only
    // breaks inside a developer tool and the value is only used for secondary information,
    // we can get away with it. See https://bugzilla.mozilla.org/show_bug.cgi?id=1615824.
    event.touches[0] || event.changedTouches[0] || {
      pageX: 0,
      pageY: 0
    } : event;
    const x = point.pageX - scrollPosition.left;
    const y = point.pageY - scrollPosition.top; // if dragging SVG element, try to convert from the screen coordinate system to the SVG
    // coordinate system

    if (this._ownerSVGElement) {
      const svgMatrix = this._ownerSVGElement.getScreenCTM();

      if (svgMatrix) {
        const svgPoint = this._ownerSVGElement.createSVGPoint();

        svgPoint.x = x;
        svgPoint.y = y;
        return svgPoint.matrixTransform(svgMatrix.inverse());
      }
    }

    return {
      x,
      y
    };
  }
  /** Gets the pointer position on the page, accounting for any position constraints. */


  _getConstrainedPointerPosition(point) {
    const dropContainerLock = this._dropContainer ? this._dropContainer.lockAxis : null;
    let {
      x,
      y
    } = this.constrainPosition ? this.constrainPosition(point, this) : point;

    if (this.lockAxis === 'x' || dropContainerLock === 'x') {
      y = this._pickupPositionOnPage.y;
    } else if (this.lockAxis === 'y' || dropContainerLock === 'y') {
      x = this._pickupPositionOnPage.x;
    }

    if (this._boundaryRect) {
      const {
        x: pickupX,
        y: pickupY
      } = this._pickupPositionInElement;
      const boundaryRect = this._boundaryRect;

      const {
        width: previewWidth,
        height: previewHeight
      } = this._getPreviewRect();

      const minY = boundaryRect.top + pickupY;
      const maxY = boundaryRect.bottom - (previewHeight - pickupY);
      const minX = boundaryRect.left + pickupX;
      const maxX = boundaryRect.right - (previewWidth - pickupX);
      x = clamp$1(x, minX, maxX);
      y = clamp$1(y, minY, maxY);
    }

    return {
      x,
      y
    };
  }
  /** Updates the current drag delta, based on the user's current pointer position on the page. */


  _updatePointerDirectionDelta(pointerPositionOnPage) {
    const {
      x,
      y
    } = pointerPositionOnPage;
    const delta = this._pointerDirectionDelta;
    const positionSinceLastChange = this._pointerPositionAtLastDirectionChange; // Amount of pixels the user has dragged since the last time the direction changed.

    const changeX = Math.abs(x - positionSinceLastChange.x);
    const changeY = Math.abs(y - positionSinceLastChange.y); // Because we handle pointer events on a per-pixel basis, we don't want the delta
    // to change for every pixel, otherwise anything that depends on it can look erratic.
    // To make the delta more consistent, we track how much the user has moved since the last
    // delta change and we only update it after it has reached a certain threshold.

    if (changeX > this._config.pointerDirectionChangeThreshold) {
      delta.x = x > positionSinceLastChange.x ? 1 : -1;
      positionSinceLastChange.x = x;
    }

    if (changeY > this._config.pointerDirectionChangeThreshold) {
      delta.y = y > positionSinceLastChange.y ? 1 : -1;
      positionSinceLastChange.y = y;
    }

    return delta;
  }
  /** Toggles the native drag interactions, based on how many handles are registered. */


  _toggleNativeDragInteractions() {
    if (!this._rootElement || !this._handles) {
      return;
    }

    const shouldEnable = this._handles.length > 0 || !this.isDragging();

    if (shouldEnable !== this._nativeInteractionsEnabled) {
      this._nativeInteractionsEnabled = shouldEnable;
      toggleNativeDragInteractions(this._rootElement, shouldEnable);
    }
  }
  /** Removes the manually-added event listeners from the root element. */


  _removeRootElementListeners(element) {
    element.removeEventListener('mousedown', this._pointerDown, activeEventListenerOptions);
    element.removeEventListener('touchstart', this._pointerDown, passiveEventListenerOptions);
    element.removeEventListener('dragstart', this._nativeDragStart, activeEventListenerOptions);
  }
  /**
   * Applies a `transform` to the root element, taking into account any existing transforms on it.
   * @param x New transform value along the X axis.
   * @param y New transform value along the Y axis.
   */


  _applyRootElementTransform(x, y) {
    const transform = getTransform(x, y);
    const styles = this._rootElement.style; // Cache the previous transform amount only after the first drag sequence, because
    // we don't want our own transforms to stack on top of each other.
    // Should be excluded none because none + translate3d(x, y, x) is invalid css

    if (this._initialTransform == null) {
      this._initialTransform = styles.transform && styles.transform != 'none' ? styles.transform : '';
    } // Preserve the previous `transform` value, if there was one. Note that we apply our own
    // transform before the user's, because things like rotation can affect which direction
    // the element will be translated towards.


    styles.transform = combineTransforms(transform, this._initialTransform);
  }
  /**
   * Applies a `transform` to the preview, taking into account any existing transforms on it.
   * @param x New transform value along the X axis.
   * @param y New transform value along the Y axis.
   */


  _applyPreviewTransform(x, y) {
    var _a; // Only apply the initial transform if the preview is a clone of the original element, otherwise
    // it could be completely different and the transform might not make sense anymore.


    const initialTransform = ((_a = this._previewTemplate) === null || _a === void 0 ? void 0 : _a.template) ? undefined : this._initialTransform;
    const transform = getTransform(x, y);
    this._preview.style.transform = combineTransforms(transform, initialTransform);
  }
  /**
   * Gets the distance that the user has dragged during the current drag sequence.
   * @param currentPosition Current position of the user's pointer.
   */


  _getDragDistance(currentPosition) {
    const pickupPosition = this._pickupPositionOnPage;

    if (pickupPosition) {
      return {
        x: currentPosition.x - pickupPosition.x,
        y: currentPosition.y - pickupPosition.y
      };
    }

    return {
      x: 0,
      y: 0
    };
  }
  /** Cleans up any cached element dimensions that we don't need after dragging has stopped. */


  _cleanupCachedDimensions() {
    this._boundaryRect = this._previewRect = undefined;

    this._parentPositions.clear();
  }
  /**
   * Checks whether the element is still inside its boundary after the viewport has been resized.
   * If not, the position is adjusted so that the element fits again.
   */


  _containInsideBoundaryOnResize() {
    let {
      x,
      y
    } = this._passiveTransform;

    if (x === 0 && y === 0 || this.isDragging() || !this._boundaryElement) {
      return;
    }

    const boundaryRect = this._boundaryElement.getBoundingClientRect();

    const elementRect = this._rootElement.getBoundingClientRect(); // It's possible that the element got hidden away after dragging (e.g. by switching to a
    // different tab). Don't do anything in this case so we don't clear the user's position.


    if (boundaryRect.width === 0 && boundaryRect.height === 0 || elementRect.width === 0 && elementRect.height === 0) {
      return;
    }

    const leftOverflow = boundaryRect.left - elementRect.left;
    const rightOverflow = elementRect.right - boundaryRect.right;
    const topOverflow = boundaryRect.top - elementRect.top;
    const bottomOverflow = elementRect.bottom - boundaryRect.bottom; // If the element has become wider than the boundary, we can't
    // do much to make it fit so we just anchor it to the left.

    if (boundaryRect.width > elementRect.width) {
      if (leftOverflow > 0) {
        x += leftOverflow;
      }

      if (rightOverflow > 0) {
        x -= rightOverflow;
      }
    } else {
      x = 0;
    } // If the element has become taller than the boundary, we can't
    // do much to make it fit so we just anchor it to the top.


    if (boundaryRect.height > elementRect.height) {
      if (topOverflow > 0) {
        y += topOverflow;
      }

      if (bottomOverflow > 0) {
        y -= bottomOverflow;
      }
    } else {
      y = 0;
    }

    if (x !== this._passiveTransform.x || y !== this._passiveTransform.y) {
      this.setFreeDragPosition({
        y,
        x
      });
    }
  }
  /** Gets the drag start delay, based on the event type. */


  _getDragStartDelay(event) {
    const value = this.dragStartDelay;

    if (typeof value === 'number') {
      return value;
    } else if (isTouchEvent(event)) {
      return value.touch;
    }

    return value ? value.mouse : 0;
  }
  /** Updates the internal state of the draggable element when scrolling has occurred. */


  _updateOnScroll(event) {
    const scrollDifference = this._parentPositions.handleScroll(event);

    if (scrollDifference) {
      const target = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getEventTarget)(event); // ClientRect dimensions are based on the scroll position of the page and its parent
      // node so we have to update the cached boundary ClientRect if the user has scrolled.


      if (this._boundaryRect && target !== this._boundaryElement && target.contains(this._boundaryElement)) {
        adjustClientRect(this._boundaryRect, scrollDifference.top, scrollDifference.left);
      }

      this._pickupPositionOnPage.x += scrollDifference.left;
      this._pickupPositionOnPage.y += scrollDifference.top; // If we're in free drag mode, we have to update the active transform, because
      // it isn't relative to the viewport like the preview inside a drop list.

      if (!this._dropContainer) {
        this._activeTransform.x -= scrollDifference.left;
        this._activeTransform.y -= scrollDifference.top;

        this._applyRootElementTransform(this._activeTransform.x, this._activeTransform.y);
      }
    }
  }
  /** Gets the scroll position of the viewport. */


  _getViewportScrollPosition() {
    var _a;

    return ((_a = this._parentPositions.positions.get(this._document)) === null || _a === void 0 ? void 0 : _a.scrollPosition) || this._parentPositions.getViewportScrollPosition();
  }
  /**
   * Lazily resolves and returns the shadow root of the element. We do this in a function, rather
   * than saving it in property directly on init, because we want to resolve it as late as possible
   * in order to ensure that the element has been moved into the shadow DOM. Doing it inside the
   * constructor might be too early if the element is inside of something like `ngFor` or `ngIf`.
   */


  _getShadowRoot() {
    if (this._cachedShadowRoot === undefined) {
      this._cachedShadowRoot = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getShadowRoot)(this._rootElement);
    }

    return this._cachedShadowRoot;
  }
  /** Gets the element into which the drag preview should be inserted. */


  _getPreviewInsertionPoint(initialParent, shadowRoot) {
    const previewContainer = this._previewContainer || 'global';

    if (previewContainer === 'parent') {
      return initialParent;
    }

    if (previewContainer === 'global') {
      const documentRef = this._document; // We can't use the body if the user is in fullscreen mode,
      // because the preview will render under the fullscreen element.
      // TODO(crisbeto): dedupe this with the `FullscreenOverlayContainer` eventually.

      return shadowRoot || documentRef.fullscreenElement || documentRef.webkitFullscreenElement || documentRef.mozFullScreenElement || documentRef.msFullscreenElement || documentRef.body;
    }

    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(previewContainer);
  }
  /** Lazily resolves and returns the dimensions of the preview. */


  _getPreviewRect() {
    // Cache the preview element rect if we haven't cached it already or if
    // we cached it too early before the element dimensions were computed.
    if (!this._previewRect || !this._previewRect.width && !this._previewRect.height) {
      this._previewRect = (this._preview || this._rootElement).getBoundingClientRect();
    }

    return this._previewRect;
  }
  /** Gets a handle that is the target of an event. */


  _getTargetHandle(event) {
    return this._handles.find(handle => {
      return event.target && (event.target === handle || handle.contains(event.target));
    });
  }

}
/**
 * Gets a 3d `transform` that can be applied to an element.
 * @param x Desired position of the element along the X axis.
 * @param y Desired position of the element along the Y axis.
 */


function getTransform(x, y) {
  // Round the transforms since some browsers will
  // blur the elements for sub-pixel transforms.
  return `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
}
/** Clamps a value between a minimum and a maximum. */


function clamp$1(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
/** Determines whether an event is a touch event. */


function isTouchEvent(event) {
  // This function is called for every pixel that the user has dragged so we need it to be
  // as fast as possible. Since we only bind mouse events and touch events, we can assume
  // that if the event's name starts with `t`, it's a touch event.
  return event.type[0] === 't';
}
/**
 * Gets the root HTML element of an embedded view.
 * If the root is not an HTML element it gets wrapped in one.
 */


function getRootNode(viewRef, _document) {
  const rootNodes = viewRef.rootNodes;

  if (rootNodes.length === 1 && rootNodes[0].nodeType === _document.ELEMENT_NODE) {
    return rootNodes[0];
  }

  const wrapper = _document.createElement('div');

  rootNodes.forEach(node => wrapper.appendChild(node));
  return wrapper;
}
/**
 * Matches the target element's size to the source's size.
 * @param target Element that needs to be resized.
 * @param sourceRect Dimensions of the source element.
 */


function matchElementSize(target, sourceRect) {
  target.style.width = `${sourceRect.width}px`;
  target.style.height = `${sourceRect.height}px`;
  target.style.transform = getTransform(sourceRect.left, sourceRect.top);
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Moves an item one index in an array to another.
 * @param array Array in which to move the item.
 * @param fromIndex Starting index of the item.
 * @param toIndex Index to which the item should be moved.
 */


function moveItemInArray(array, fromIndex, toIndex) {
  const from = clamp(fromIndex, array.length - 1);
  const to = clamp(toIndex, array.length - 1);

  if (from === to) {
    return;
  }

  const target = array[from];
  const delta = to < from ? -1 : 1;

  for (let i = from; i !== to; i += delta) {
    array[i] = array[i + delta];
  }

  array[to] = target;
}
/**
 * Moves an item from one array to another.
 * @param currentArray Array from which to transfer the item.
 * @param targetArray Array into which to put the item.
 * @param currentIndex Index of the item in its current array.
 * @param targetIndex Index at which to insert the item.
 */


function transferArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
  const from = clamp(currentIndex, currentArray.length - 1);
  const to = clamp(targetIndex, targetArray.length);

  if (currentArray.length) {
    targetArray.splice(to, 0, currentArray.splice(from, 1)[0]);
  }
}
/**
 * Copies an item from one array to another, leaving it in its
 * original position in current array.
 * @param currentArray Array from which to copy the item.
 * @param targetArray Array into which is copy the item.
 * @param currentIndex Index of the item in its current array.
 * @param targetIndex Index at which to insert the item.
 *
 */


function copyArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
  const to = clamp(targetIndex, targetArray.length);

  if (currentArray.length) {
    targetArray.splice(to, 0, currentArray[currentIndex]);
  }
}
/** Clamps a number between zero and a maximum. */


function clamp(value, max) {
  return Math.max(0, Math.min(max, value));
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Proximity, as a ratio to width/height, at which a
 * dragged item will affect the drop container.
 */


const DROP_PROXIMITY_THRESHOLD = 0.05;
/**
 * Proximity, as a ratio to width/height at which to start auto-scrolling the drop list or the
 * viewport. The value comes from trying it out manually until it feels right.
 */

const SCROLL_PROXIMITY_THRESHOLD = 0.05;
/**
 * Reference to a drop list. Used to manipulate or dispose of the container.
 */

class DropListRef {
  constructor(element, _dragDropRegistry, _document, _ngZone, _viewportRuler) {
    this._dragDropRegistry = _dragDropRegistry;
    this._ngZone = _ngZone;
    this._viewportRuler = _viewportRuler;
    /** Whether starting a dragging sequence from this container is disabled. */

    this.disabled = false;
    /** Whether sorting items within the list is disabled. */

    this.sortingDisabled = false;
    /**
     * Whether auto-scrolling the view when the user
     * moves their pointer close to the edges is disabled.
     */

    this.autoScrollDisabled = false;
    /** Number of pixels to scroll for each frame when auto-scrolling an element. */

    this.autoScrollStep = 2;
    /**
     * Function that is used to determine whether an item
     * is allowed to be moved into a drop container.
     */

    this.enterPredicate = () => true;
    /** Functions that is used to determine whether an item can be sorted into a particular index. */


    this.sortPredicate = () => true;
    /** Emits right before dragging has started. */


    this.beforeStarted = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Emits when the user has moved a new drag item into this container.
     */

    this.entered = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Emits when the user removes an item from the container
     * by dragging it into another container.
     */

    this.exited = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user drops an item inside the container. */

    this.dropped = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits as the user is swapping items while actively dragging. */

    this.sorted = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Whether an item in the list is being dragged. */

    this._isDragging = false;
    /** Cache of the dimensions of all the items inside the container. */

    this._itemPositions = [];
    /**
     * Keeps track of the item that was last swapped with the dragged item, as well as what direction
     * the pointer was moving in when the swap occured and whether the user's pointer continued to
     * overlap with the swapped item after the swapping occurred.
     */

    this._previousSwap = {
      drag: null,
      delta: 0,
      overlaps: false
    };
    /** Draggable items in the container. */

    this._draggables = [];
    /** Drop lists that are connected to the current one. */

    this._siblings = [];
    /** Direction in which the list is oriented. */

    this._orientation = 'vertical';
    /** Connected siblings that currently have a dragged item. */

    this._activeSiblings = new Set();
    /** Layout direction of the drop list. */

    this._direction = 'ltr';
    /** Subscription to the window being scrolled. */

    this._viewportScrollSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription.EMPTY;
    /** Vertical direction in which the list is currently scrolling. */

    this._verticalScrollDirection = 0
    /* NONE */
    ;
    /** Horizontal direction in which the list is currently scrolling. */

    this._horizontalScrollDirection = 0
    /* NONE */
    ;
    /** Used to signal to the current auto-scroll sequence when to stop. */

    this._stopScrollTimers = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Shadow root of the current element. Necessary for `elementFromPoint` to resolve correctly. */

    this._cachedShadowRoot = null;
    /** Starts the interval that'll auto-scroll the element. */

    this._startScrollInterval = () => {
      this._stopScrolling();

      (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.interval)(0, rxjs__WEBPACK_IMPORTED_MODULE_6__.animationFrameScheduler).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._stopScrollTimers)).subscribe(() => {
        const node = this._scrollNode;
        const scrollStep = this.autoScrollStep;

        if (this._verticalScrollDirection === 1
        /* UP */
        ) {
          node.scrollBy(0, -scrollStep);
        } else if (this._verticalScrollDirection === 2
        /* DOWN */
        ) {
          node.scrollBy(0, scrollStep);
        }

        if (this._horizontalScrollDirection === 1
        /* LEFT */
        ) {
          node.scrollBy(-scrollStep, 0);
        } else if (this._horizontalScrollDirection === 2
        /* RIGHT */
        ) {
          node.scrollBy(scrollStep, 0);
        }
      });
    };

    this.element = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(element);
    this._document = _document;
    this.withScrollableParents([this.element]);

    _dragDropRegistry.registerDropContainer(this);

    this._parentPositions = new ParentPositionTracker(_document);
  }
  /** Removes the drop list functionality from the DOM element. */


  dispose() {
    this._stopScrolling();

    this._stopScrollTimers.complete();

    this._viewportScrollSubscription.unsubscribe();

    this.beforeStarted.complete();
    this.entered.complete();
    this.exited.complete();
    this.dropped.complete();
    this.sorted.complete();

    this._activeSiblings.clear();

    this._scrollNode = null;

    this._parentPositions.clear();

    this._dragDropRegistry.removeDropContainer(this);
  }
  /** Whether an item from this list is currently being dragged. */


  isDragging() {
    return this._isDragging;
  }
  /** Starts dragging an item. */


  start() {
    this._draggingStarted();

    this._notifyReceivingSiblings();
  }
  /**
   * Emits an event to indicate that the user moved an item into the container.
   * @param item Item that was moved into the container.
   * @param pointerX Position of the item along the X axis.
   * @param pointerY Position of the item along the Y axis.
   * @param index Index at which the item entered. If omitted, the container will try to figure it
   *   out automatically.
   */


  enter(item, pointerX, pointerY, index) {
    this._draggingStarted(); // If sorting is disabled, we want the item to return to its starting
    // position if the user is returning it to its initial container.


    let newIndex;

    if (index == null) {
      newIndex = this.sortingDisabled ? this._draggables.indexOf(item) : -1;

      if (newIndex === -1) {
        // We use the coordinates of where the item entered the drop
        // zone to figure out at which index it should be inserted.
        newIndex = this._getItemIndexFromPointerPosition(item, pointerX, pointerY);
      }
    } else {
      newIndex = index;
    }

    const activeDraggables = this._activeDraggables;
    const currentIndex = activeDraggables.indexOf(item);
    const placeholder = item.getPlaceholderElement();
    let newPositionReference = activeDraggables[newIndex]; // If the item at the new position is the same as the item that is being dragged,
    // it means that we're trying to restore the item to its initial position. In this
    // case we should use the next item from the list as the reference.

    if (newPositionReference === item) {
      newPositionReference = activeDraggables[newIndex + 1];
    } // If we didn't find a new position reference, it means that either the item didn't start off
    // in this container, or that the item requested to be inserted at the end of the list.


    if (!newPositionReference && (newIndex == null || newIndex === -1 || newIndex < activeDraggables.length - 1) && this._shouldEnterAsFirstChild(pointerX, pointerY)) {
      newPositionReference = activeDraggables[0];
    } // Since the item may be in the `activeDraggables` already (e.g. if the user dragged it
    // into another container and back again), we have to ensure that it isn't duplicated.


    if (currentIndex > -1) {
      activeDraggables.splice(currentIndex, 1);
    } // Don't use items that are being dragged as a reference, because
    // their element has been moved down to the bottom of the body.


    if (newPositionReference && !this._dragDropRegistry.isDragging(newPositionReference)) {
      const element = newPositionReference.getRootElement();
      element.parentElement.insertBefore(placeholder, element);
      activeDraggables.splice(newIndex, 0, item);
    } else {
      (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element).appendChild(placeholder);
      activeDraggables.push(item);
    } // The transform needs to be cleared so it doesn't throw off the measurements.


    placeholder.style.transform = ''; // Note that the positions were already cached when we called `start` above,
    // but we need to refresh them since the amount of items has changed and also parent rects.

    this._cacheItemPositions();

    this._cacheParentPositions(); // Notify siblings at the end so that the item has been inserted into the `activeDraggables`.


    this._notifyReceivingSiblings();

    this.entered.next({
      item,
      container: this,
      currentIndex: this.getItemIndex(item)
    });
  }
  /**
   * Removes an item from the container after it was dragged into another container by the user.
   * @param item Item that was dragged out.
   */


  exit(item) {
    this._reset();

    this.exited.next({
      item,
      container: this
    });
  }
  /**
   * Drops an item into this container.
   * @param item Item being dropped into the container.
   * @param currentIndex Index at which the item should be inserted.
   * @param previousIndex Index of the item when dragging started.
   * @param previousContainer Container from which the item got dragged in.
   * @param isPointerOverContainer Whether the user's pointer was over the
   *    container when the item was dropped.
   * @param distance Distance the user has dragged since the start of the dragging sequence.
   */


  drop(item, currentIndex, previousIndex, previousContainer, isPointerOverContainer, distance, dropPoint) {
    this._reset();

    this.dropped.next({
      item,
      currentIndex,
      previousIndex,
      container: this,
      previousContainer,
      isPointerOverContainer,
      distance,
      dropPoint
    });
  }
  /**
   * Sets the draggable items that are a part of this list.
   * @param items Items that are a part of this list.
   */


  withItems(items) {
    const previousItems = this._draggables;
    this._draggables = items;
    items.forEach(item => item._withDropContainer(this));

    if (this.isDragging()) {
      const draggedItems = previousItems.filter(item => item.isDragging()); // If all of the items being dragged were removed
      // from the list, abort the current drag sequence.

      if (draggedItems.every(item => items.indexOf(item) === -1)) {
        this._reset();
      } else {
        this._cacheItems();
      }
    }

    return this;
  }
  /** Sets the layout direction of the drop list. */


  withDirection(direction) {
    this._direction = direction;
    return this;
  }
  /**
   * Sets the containers that are connected to this one. When two or more containers are
   * connected, the user will be allowed to transfer items between them.
   * @param connectedTo Other containers that the current containers should be connected to.
   */


  connectedTo(connectedTo) {
    this._siblings = connectedTo.slice();
    return this;
  }
  /**
   * Sets the orientation of the container.
   * @param orientation New orientation for the container.
   */


  withOrientation(orientation) {
    this._orientation = orientation;
    return this;
  }
  /**
   * Sets which parent elements are can be scrolled while the user is dragging.
   * @param elements Elements that can be scrolled.
   */


  withScrollableParents(elements) {
    const element = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element); // We always allow the current element to be scrollable
    // so we need to ensure that it's in the array.

    this._scrollableElements = elements.indexOf(element) === -1 ? [element, ...elements] : elements.slice();
    return this;
  }
  /** Gets the scrollable parents that are registered with this drop container. */


  getScrollableParents() {
    return this._scrollableElements;
  }
  /**
   * Figures out the index of an item in the container.
   * @param item Item whose index should be determined.
   */


  getItemIndex(item) {
    if (!this._isDragging) {
      return this._draggables.indexOf(item);
    } // Items are sorted always by top/left in the cache, however they flow differently in RTL.
    // The rest of the logic still stands no matter what orientation we're in, however
    // we need to invert the array when determining the index.


    const items = this._orientation === 'horizontal' && this._direction === 'rtl' ? this._itemPositions.slice().reverse() : this._itemPositions;
    return items.findIndex(currentItem => currentItem.drag === item);
  }
  /**
   * Whether the list is able to receive the item that
   * is currently being dragged inside a connected drop list.
   */


  isReceiving() {
    return this._activeSiblings.size > 0;
  }
  /**
   * Sorts an item inside the container based on its position.
   * @param item Item to be sorted.
   * @param pointerX Position of the item along the X axis.
   * @param pointerY Position of the item along the Y axis.
   * @param pointerDelta Direction in which the pointer is moving along each axis.
   */


  _sortItem(item, pointerX, pointerY, pointerDelta) {
    // Don't sort the item if sorting is disabled or it's out of range.
    if (this.sortingDisabled || !this._clientRect || !isPointerNearClientRect(this._clientRect, DROP_PROXIMITY_THRESHOLD, pointerX, pointerY)) {
      return;
    }

    const siblings = this._itemPositions;

    const newIndex = this._getItemIndexFromPointerPosition(item, pointerX, pointerY, pointerDelta);

    if (newIndex === -1 && siblings.length > 0) {
      return;
    }

    const isHorizontal = this._orientation === 'horizontal';
    const currentIndex = siblings.findIndex(currentItem => currentItem.drag === item);
    const siblingAtNewPosition = siblings[newIndex];
    const currentPosition = siblings[currentIndex].clientRect;
    const newPosition = siblingAtNewPosition.clientRect;
    const delta = currentIndex > newIndex ? 1 : -1; // How many pixels the item's placeholder should be offset.

    const itemOffset = this._getItemOffsetPx(currentPosition, newPosition, delta); // How many pixels all the other items should be offset.


    const siblingOffset = this._getSiblingOffsetPx(currentIndex, siblings, delta); // Save the previous order of the items before moving the item to its new index.
    // We use this to check whether an item has been moved as a result of the sorting.


    const oldOrder = siblings.slice(); // Shuffle the array in place.

    moveItemInArray(siblings, currentIndex, newIndex);
    this.sorted.next({
      previousIndex: currentIndex,
      currentIndex: newIndex,
      container: this,
      item
    });
    siblings.forEach((sibling, index) => {
      // Don't do anything if the position hasn't changed.
      if (oldOrder[index] === sibling) {
        return;
      }

      const isDraggedItem = sibling.drag === item;
      const offset = isDraggedItem ? itemOffset : siblingOffset;
      const elementToOffset = isDraggedItem ? item.getPlaceholderElement() : sibling.drag.getRootElement(); // Update the offset to reflect the new position.

      sibling.offset += offset; // Since we're moving the items with a `transform`, we need to adjust their cached
      // client rects to reflect their new position, as well as swap their positions in the cache.
      // Note that we shouldn't use `getBoundingClientRect` here to update the cache, because the
      // elements may be mid-animation which will give us a wrong result.

      if (isHorizontal) {
        // Round the transforms since some browsers will
        // blur the elements, for sub-pixel transforms.
        elementToOffset.style.transform = combineTransforms(`translate3d(${Math.round(sibling.offset)}px, 0, 0)`, sibling.initialTransform);
        adjustClientRect(sibling.clientRect, 0, offset);
      } else {
        elementToOffset.style.transform = combineTransforms(`translate3d(0, ${Math.round(sibling.offset)}px, 0)`, sibling.initialTransform);
        adjustClientRect(sibling.clientRect, offset, 0);
      }
    }); // Note that it's important that we do this after the client rects have been adjusted.

    this._previousSwap.overlaps = isInsideClientRect(newPosition, pointerX, pointerY);
    this._previousSwap.drag = siblingAtNewPosition.drag;
    this._previousSwap.delta = isHorizontal ? pointerDelta.x : pointerDelta.y;
  }
  /**
   * Checks whether the user's pointer is close to the edges of either the
   * viewport or the drop list and starts the auto-scroll sequence.
   * @param pointerX User's pointer position along the x axis.
   * @param pointerY User's pointer position along the y axis.
   */


  _startScrollingIfNecessary(pointerX, pointerY) {
    if (this.autoScrollDisabled) {
      return;
    }

    let scrollNode;
    let verticalScrollDirection = 0
    /* NONE */
    ;
    let horizontalScrollDirection = 0
    /* NONE */
    ; // Check whether we should start scrolling any of the parent containers.

    this._parentPositions.positions.forEach((position, element) => {
      // We have special handling for the `document` below. Also this would be
      // nicer with a  for...of loop, but it requires changing a compiler flag.
      if (element === this._document || !position.clientRect || scrollNode) {
        return;
      }

      if (isPointerNearClientRect(position.clientRect, DROP_PROXIMITY_THRESHOLD, pointerX, pointerY)) {
        [verticalScrollDirection, horizontalScrollDirection] = getElementScrollDirections(element, position.clientRect, pointerX, pointerY);

        if (verticalScrollDirection || horizontalScrollDirection) {
          scrollNode = element;
        }
      }
    }); // Otherwise check if we can start scrolling the viewport.


    if (!verticalScrollDirection && !horizontalScrollDirection) {
      const {
        width,
        height
      } = this._viewportRuler.getViewportSize();

      const clientRect = {
        width,
        height,
        top: 0,
        right: width,
        bottom: height,
        left: 0
      };
      verticalScrollDirection = getVerticalScrollDirection(clientRect, pointerY);
      horizontalScrollDirection = getHorizontalScrollDirection(clientRect, pointerX);
      scrollNode = window;
    }

    if (scrollNode && (verticalScrollDirection !== this._verticalScrollDirection || horizontalScrollDirection !== this._horizontalScrollDirection || scrollNode !== this._scrollNode)) {
      this._verticalScrollDirection = verticalScrollDirection;
      this._horizontalScrollDirection = horizontalScrollDirection;
      this._scrollNode = scrollNode;

      if ((verticalScrollDirection || horizontalScrollDirection) && scrollNode) {
        this._ngZone.runOutsideAngular(this._startScrollInterval);
      } else {
        this._stopScrolling();
      }
    }
  }
  /** Stops any currently-running auto-scroll sequences. */


  _stopScrolling() {
    this._stopScrollTimers.next();
  }
  /** Starts the dragging sequence within the list. */


  _draggingStarted() {
    const styles = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element).style;
    this.beforeStarted.next();
    this._isDragging = true; // We need to disable scroll snapping while the user is dragging, because it breaks automatic
    // scrolling. The browser seems to round the value based on the snapping points which means
    // that we can't increment/decrement the scroll position.

    this._initialScrollSnap = styles.msScrollSnapType || styles.scrollSnapType || '';
    styles.scrollSnapType = styles.msScrollSnapType = 'none';

    this._cacheItems();

    this._viewportScrollSubscription.unsubscribe();

    this._listenToScrollEvents();
  }
  /** Caches the positions of the configured scrollable parents. */


  _cacheParentPositions() {
    const element = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element);

    this._parentPositions.cache(this._scrollableElements); // The list element is always in the `scrollableElements`
    // so we can take advantage of the cached `ClientRect`.


    this._clientRect = this._parentPositions.positions.get(element).clientRect;
  }
  /** Refreshes the position cache of the items and sibling containers. */


  _cacheItemPositions() {
    const isHorizontal = this._orientation === 'horizontal';
    this._itemPositions = this._activeDraggables.map(drag => {
      const elementToMeasure = drag.getVisibleElement();
      return {
        drag,
        offset: 0,
        initialTransform: elementToMeasure.style.transform || '',
        clientRect: getMutableClientRect(elementToMeasure)
      };
    }).sort((a, b) => {
      return isHorizontal ? a.clientRect.left - b.clientRect.left : a.clientRect.top - b.clientRect.top;
    });
  }
  /** Resets the container to its initial state. */


  _reset() {
    this._isDragging = false;
    const styles = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element).style;
    styles.scrollSnapType = styles.msScrollSnapType = this._initialScrollSnap; // TODO(crisbeto): may have to wait for the animations to finish.

    this._activeDraggables.forEach(item => {
      var _a;

      const rootElement = item.getRootElement();

      if (rootElement) {
        const initialTransform = (_a = this._itemPositions.find(current => current.drag === item)) === null || _a === void 0 ? void 0 : _a.initialTransform;
        rootElement.style.transform = initialTransform || '';
      }
    });

    this._siblings.forEach(sibling => sibling._stopReceiving(this));

    this._activeDraggables = [];
    this._itemPositions = [];
    this._previousSwap.drag = null;
    this._previousSwap.delta = 0;
    this._previousSwap.overlaps = false;

    this._stopScrolling();

    this._viewportScrollSubscription.unsubscribe();

    this._parentPositions.clear();
  }
  /**
   * Gets the offset in pixels by which the items that aren't being dragged should be moved.
   * @param currentIndex Index of the item currently being dragged.
   * @param siblings All of the items in the list.
   * @param delta Direction in which the user is moving.
   */


  _getSiblingOffsetPx(currentIndex, siblings, delta) {
    const isHorizontal = this._orientation === 'horizontal';
    const currentPosition = siblings[currentIndex].clientRect;
    const immediateSibling = siblings[currentIndex + delta * -1];
    let siblingOffset = currentPosition[isHorizontal ? 'width' : 'height'] * delta;

    if (immediateSibling) {
      const start = isHorizontal ? 'left' : 'top';
      const end = isHorizontal ? 'right' : 'bottom'; // Get the spacing between the start of the current item and the end of the one immediately
      // after it in the direction in which the user is dragging, or vice versa. We add it to the
      // offset in order to push the element to where it will be when it's inline and is influenced
      // by the `margin` of its siblings.

      if (delta === -1) {
        siblingOffset -= immediateSibling.clientRect[start] - currentPosition[end];
      } else {
        siblingOffset += currentPosition[start] - immediateSibling.clientRect[end];
      }
    }

    return siblingOffset;
  }
  /**
   * Gets the offset in pixels by which the item that is being dragged should be moved.
   * @param currentPosition Current position of the item.
   * @param newPosition Position of the item where the current item should be moved.
   * @param delta Direction in which the user is moving.
   */


  _getItemOffsetPx(currentPosition, newPosition, delta) {
    const isHorizontal = this._orientation === 'horizontal';
    let itemOffset = isHorizontal ? newPosition.left - currentPosition.left : newPosition.top - currentPosition.top; // Account for differences in the item width/height.

    if (delta === -1) {
      itemOffset += isHorizontal ? newPosition.width - currentPosition.width : newPosition.height - currentPosition.height;
    }

    return itemOffset;
  }
  /**
   * Checks if pointer is entering in the first position
   * @param pointerX Position of the user's pointer along the X axis.
   * @param pointerY Position of the user's pointer along the Y axis.
   */


  _shouldEnterAsFirstChild(pointerX, pointerY) {
    if (!this._activeDraggables.length) {
      return false;
    }

    const itemPositions = this._itemPositions;
    const isHorizontal = this._orientation === 'horizontal'; // `itemPositions` are sorted by position while `activeDraggables` are sorted by child index
    // check if container is using some sort of "reverse" ordering (eg: flex-direction: row-reverse)

    const reversed = itemPositions[0].drag !== this._activeDraggables[0];

    if (reversed) {
      const lastItemRect = itemPositions[itemPositions.length - 1].clientRect;
      return isHorizontal ? pointerX >= lastItemRect.right : pointerY >= lastItemRect.bottom;
    } else {
      const firstItemRect = itemPositions[0].clientRect;
      return isHorizontal ? pointerX <= firstItemRect.left : pointerY <= firstItemRect.top;
    }
  }
  /**
   * Gets the index of an item in the drop container, based on the position of the user's pointer.
   * @param item Item that is being sorted.
   * @param pointerX Position of the user's pointer along the X axis.
   * @param pointerY Position of the user's pointer along the Y axis.
   * @param delta Direction in which the user is moving their pointer.
   */


  _getItemIndexFromPointerPosition(item, pointerX, pointerY, delta) {
    const isHorizontal = this._orientation === 'horizontal';

    const index = this._itemPositions.findIndex(({
      drag,
      clientRect
    }) => {
      // Skip the item itself.
      if (drag === item) {
        return false;
      }

      if (delta) {
        const direction = isHorizontal ? delta.x : delta.y; // If the user is still hovering over the same item as last time, their cursor hasn't left
        // the item after we made the swap, and they didn't change the direction in which they're
        // dragging, we don't consider it a direction swap.

        if (drag === this._previousSwap.drag && this._previousSwap.overlaps && direction === this._previousSwap.delta) {
          return false;
        }
      }

      return isHorizontal ? // Round these down since most browsers report client rects with
      // sub-pixel precision, whereas the pointer coordinates are rounded to pixels.
      pointerX >= Math.floor(clientRect.left) && pointerX < Math.floor(clientRect.right) : pointerY >= Math.floor(clientRect.top) && pointerY < Math.floor(clientRect.bottom);
    });

    return index === -1 || !this.sortPredicate(index, item, this) ? -1 : index;
  }
  /** Caches the current items in the list and their positions. */


  _cacheItems() {
    this._activeDraggables = this._draggables.slice();

    this._cacheItemPositions();

    this._cacheParentPositions();
  }
  /**
   * Checks whether the user's pointer is positioned over the container.
   * @param x Pointer position along the X axis.
   * @param y Pointer position along the Y axis.
   */


  _isOverContainer(x, y) {
    return this._clientRect != null && isInsideClientRect(this._clientRect, x, y);
  }
  /**
   * Figures out whether an item should be moved into a sibling
   * drop container, based on its current position.
   * @param item Drag item that is being moved.
   * @param x Position of the item along the X axis.
   * @param y Position of the item along the Y axis.
   */


  _getSiblingContainerFromPosition(item, x, y) {
    return this._siblings.find(sibling => sibling._canReceive(item, x, y));
  }
  /**
   * Checks whether the drop list can receive the passed-in item.
   * @param item Item that is being dragged into the list.
   * @param x Position of the item along the X axis.
   * @param y Position of the item along the Y axis.
   */


  _canReceive(item, x, y) {
    if (!this._clientRect || !isInsideClientRect(this._clientRect, x, y) || !this.enterPredicate(item, this)) {
      return false;
    }

    const elementFromPoint = this._getShadowRoot().elementFromPoint(x, y); // If there's no element at the pointer position, then
    // the client rect is probably scrolled out of the view.


    if (!elementFromPoint) {
      return false;
    }

    const nativeElement = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element); // The `ClientRect`, that we're using to find the container over which the user is
    // hovering, doesn't give us any information on whether the element has been scrolled
    // out of the view or whether it's overlapping with other containers. This means that
    // we could end up transferring the item into a container that's invisible or is positioned
    // below another one. We use the result from `elementFromPoint` to get the top-most element
    // at the pointer position and to find whether it's one of the intersecting drop containers.

    return elementFromPoint === nativeElement || nativeElement.contains(elementFromPoint);
  }
  /**
   * Called by one of the connected drop lists when a dragging sequence has started.
   * @param sibling Sibling in which dragging has started.
   */


  _startReceiving(sibling, items) {
    const activeSiblings = this._activeSiblings;

    if (!activeSiblings.has(sibling) && items.every(item => {
      // Note that we have to add an exception to the `enterPredicate` for items that started off
      // in this drop list. The drag ref has logic that allows an item to return to its initial
      // container, if it has left the initial container and none of the connected containers
      // allow it to enter. See `DragRef._updateActiveDropContainer` for more context.
      return this.enterPredicate(item, this) || this._draggables.indexOf(item) > -1;
    })) {
      activeSiblings.add(sibling);

      this._cacheParentPositions();

      this._listenToScrollEvents();
    }
  }
  /**
   * Called by a connected drop list when dragging has stopped.
   * @param sibling Sibling whose dragging has stopped.
   */


  _stopReceiving(sibling) {
    this._activeSiblings.delete(sibling);

    this._viewportScrollSubscription.unsubscribe();
  }
  /**
   * Starts listening to scroll events on the viewport.
   * Used for updating the internal state of the list.
   */


  _listenToScrollEvents() {
    this._viewportScrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(event => {
      if (this.isDragging()) {
        const scrollDifference = this._parentPositions.handleScroll(event);

        if (scrollDifference) {
          // Since we know the amount that the user has scrolled we can shift all of the
          // client rectangles ourselves. This is cheaper than re-measuring everything and
          // we can avoid inconsistent behavior where we might be measuring the element before
          // its position has changed.
          this._itemPositions.forEach(({
            clientRect
          }) => {
            adjustClientRect(clientRect, scrollDifference.top, scrollDifference.left);
          }); // We need two loops for this, because we want all of the cached
          // positions to be up-to-date before we re-sort the item.


          this._itemPositions.forEach(({
            drag
          }) => {
            if (this._dragDropRegistry.isDragging(drag)) {
              // We need to re-sort the item manually, because the pointer move
              // events won't be dispatched while the user is scrolling.
              drag._sortFromLastPointerPosition();
            }
          });
        }
      } else if (this.isReceiving()) {
        this._cacheParentPositions();
      }
    });
  }
  /**
   * Lazily resolves and returns the shadow root of the element. We do this in a function, rather
   * than saving it in property directly on init, because we want to resolve it as late as possible
   * in order to ensure that the element has been moved into the shadow DOM. Doing it inside the
   * constructor might be too early if the element is inside of something like `ngFor` or `ngIf`.
   */


  _getShadowRoot() {
    if (!this._cachedShadowRoot) {
      const shadowRoot = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__._getShadowRoot)((0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(this.element));

      this._cachedShadowRoot = shadowRoot || this._document;
    }

    return this._cachedShadowRoot;
  }
  /** Notifies any siblings that may potentially receive the item. */


  _notifyReceivingSiblings() {
    const draggedItems = this._activeDraggables.filter(item => item.isDragging());

    this._siblings.forEach(sibling => sibling._startReceiving(this, draggedItems));
  }

}
/**
 * Gets whether the vertical auto-scroll direction of a node.
 * @param clientRect Dimensions of the node.
 * @param pointerY Position of the user's pointer along the y axis.
 */


function getVerticalScrollDirection(clientRect, pointerY) {
  const {
    top,
    bottom,
    height
  } = clientRect;
  const yThreshold = height * SCROLL_PROXIMITY_THRESHOLD;

  if (pointerY >= top - yThreshold && pointerY <= top + yThreshold) {
    return 1
    /* UP */
    ;
  } else if (pointerY >= bottom - yThreshold && pointerY <= bottom + yThreshold) {
    return 2
    /* DOWN */
    ;
  }

  return 0
  /* NONE */
  ;
}
/**
 * Gets whether the horizontal auto-scroll direction of a node.
 * @param clientRect Dimensions of the node.
 * @param pointerX Position of the user's pointer along the x axis.
 */


function getHorizontalScrollDirection(clientRect, pointerX) {
  const {
    left,
    right,
    width
  } = clientRect;
  const xThreshold = width * SCROLL_PROXIMITY_THRESHOLD;

  if (pointerX >= left - xThreshold && pointerX <= left + xThreshold) {
    return 1
    /* LEFT */
    ;
  } else if (pointerX >= right - xThreshold && pointerX <= right + xThreshold) {
    return 2
    /* RIGHT */
    ;
  }

  return 0
  /* NONE */
  ;
}
/**
 * Gets the directions in which an element node should be scrolled,
 * assuming that the user's pointer is already within it scrollable region.
 * @param element Element for which we should calculate the scroll direction.
 * @param clientRect Bounding client rectangle of the element.
 * @param pointerX Position of the user's pointer along the x axis.
 * @param pointerY Position of the user's pointer along the y axis.
 */


function getElementScrollDirections(element, clientRect, pointerX, pointerY) {
  const computedVertical = getVerticalScrollDirection(clientRect, pointerY);
  const computedHorizontal = getHorizontalScrollDirection(clientRect, pointerX);
  let verticalScrollDirection = 0
  /* NONE */
  ;
  let horizontalScrollDirection = 0
  /* NONE */
  ; // Note that we here we do some extra checks for whether the element is actually scrollable in
  // a certain direction and we only assign the scroll direction if it is. We do this so that we
  // can allow other elements to be scrolled, if the current element can't be scrolled anymore.
  // This allows us to handle cases where the scroll regions of two scrollable elements overlap.

  if (computedVertical) {
    const scrollTop = element.scrollTop;

    if (computedVertical === 1
    /* UP */
    ) {
      if (scrollTop > 0) {
        verticalScrollDirection = 1
        /* UP */
        ;
      }
    } else if (element.scrollHeight - scrollTop > element.clientHeight) {
      verticalScrollDirection = 2
      /* DOWN */
      ;
    }
  }

  if (computedHorizontal) {
    const scrollLeft = element.scrollLeft;

    if (computedHorizontal === 1
    /* LEFT */
    ) {
      if (scrollLeft > 0) {
        horizontalScrollDirection = 1
        /* LEFT */
        ;
      }
    } else if (element.scrollWidth - scrollLeft > element.clientWidth) {
      horizontalScrollDirection = 2
      /* RIGHT */
      ;
    }
  }

  return [verticalScrollDirection, horizontalScrollDirection];
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Event options that can be used to bind an active, capturing event. */


const activeCapturingEventOptions = (0,_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__.normalizePassiveListenerOptions)({
  passive: false,
  capture: true
});
/**
 * Service that keeps track of all the drag item and drop container
 * instances, and manages global event listeners on the `document`.
 * @docs-private
 */
// Note: this class is generic, rather than referencing CdkDrag and CdkDropList directly, in order
// to avoid circular imports. If we were to reference them here, importing the registry into the
// classes that are registering themselves will introduce a circular import.

class DragDropRegistry {
  constructor(_ngZone, _document) {
    this._ngZone = _ngZone;
    /** Registered drop container instances. */

    this._dropInstances = new Set();
    /** Registered drag item instances. */

    this._dragInstances = new Set();
    /** Drag item instances that are currently being dragged. */

    this._activeDragInstances = [];
    /** Keeps track of the event listeners that we've bound to the `document`. */

    this._globalListeners = new Map();
    /**
     * Predicate function to check if an item is being dragged.  Moved out into a property,
     * because it'll be called a lot and we don't want to create a new function every time.
     */

    this._draggingPredicate = item => item.isDragging();
    /**
     * Emits the `touchmove` or `mousemove` events that are dispatched
     * while the user is dragging a drag item instance.
     */


    this.pointerMove = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Emits the `touchend` or `mouseup` events that are dispatched
     * while the user is dragging a drag item instance.
     */

    this.pointerUp = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Emits when the viewport has been scrolled while the user is dragging an item.
     * @deprecated To be turned into a private member. Use the `scrolled` method instead.
     * @breaking-change 13.0.0
     */

    this.scroll = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Event listener that will prevent the default browser action while the user is dragging.
     * @param event Event whose default action should be prevented.
     */

    this._preventDefaultWhileDragging = event => {
      if (this._activeDragInstances.length > 0) {
        event.preventDefault();
      }
    };
    /** Event listener for `touchmove` that is bound even if no dragging is happening. */


    this._persistentTouchmoveListener = event => {
      if (this._activeDragInstances.length > 0) {
        // Note that we only want to prevent the default action after dragging has actually started.
        // Usually this is the same time at which the item is added to the `_activeDragInstances`,
        // but it could be pushed back if the user has set up a drag delay or threshold.
        if (this._activeDragInstances.some(this._draggingPredicate)) {
          event.preventDefault();
        }

        this.pointerMove.next(event);
      }
    };

    this._document = _document;
  }
  /** Adds a drop container to the registry. */


  registerDropContainer(drop) {
    if (!this._dropInstances.has(drop)) {
      this._dropInstances.add(drop);
    }
  }
  /** Adds a drag item instance to the registry. */


  registerDragItem(drag) {
    this._dragInstances.add(drag); // The `touchmove` event gets bound once, ahead of time, because WebKit
    // won't preventDefault on a dynamically-added `touchmove` listener.
    // See https://bugs.webkit.org/show_bug.cgi?id=184250.


    if (this._dragInstances.size === 1) {
      this._ngZone.runOutsideAngular(() => {
        // The event handler has to be explicitly active,
        // because newer browsers make it passive by default.
        this._document.addEventListener('touchmove', this._persistentTouchmoveListener, activeCapturingEventOptions);
      });
    }
  }
  /** Removes a drop container from the registry. */


  removeDropContainer(drop) {
    this._dropInstances.delete(drop);
  }
  /** Removes a drag item instance from the registry. */


  removeDragItem(drag) {
    this._dragInstances.delete(drag);

    this.stopDragging(drag);

    if (this._dragInstances.size === 0) {
      this._document.removeEventListener('touchmove', this._persistentTouchmoveListener, activeCapturingEventOptions);
    }
  }
  /**
   * Starts the dragging sequence for a drag instance.
   * @param drag Drag instance which is being dragged.
   * @param event Event that initiated the dragging.
   */


  startDragging(drag, event) {
    // Do not process the same drag twice to avoid memory leaks and redundant listeners
    if (this._activeDragInstances.indexOf(drag) > -1) {
      return;
    }

    this._activeDragInstances.push(drag);

    if (this._activeDragInstances.length === 1) {
      const isTouchEvent = event.type.startsWith('touch'); // We explicitly bind __active__ listeners here, because newer browsers will default to
      // passive ones for `mousemove` and `touchmove`. The events need to be active, because we
      // use `preventDefault` to prevent the page from scrolling while the user is dragging.

      this._globalListeners.set(isTouchEvent ? 'touchend' : 'mouseup', {
        handler: e => this.pointerUp.next(e),
        options: true
      }).set('scroll', {
        handler: e => this.scroll.next(e),
        // Use capturing so that we pick up scroll changes in any scrollable nodes that aren't
        // the document. See https://github.com/angular/components/issues/17144.
        options: true
      }) // Preventing the default action on `mousemove` isn't enough to disable text selection
      // on Safari so we need to prevent the selection event as well. Alternatively this can
      // be done by setting `user-select: none` on the `body`, however it has causes a style
      // recalculation which can be expensive on pages with a lot of elements.
      .set('selectstart', {
        handler: this._preventDefaultWhileDragging,
        options: activeCapturingEventOptions
      }); // We don't have to bind a move event for touch drag sequences, because
      // we already have a persistent global one bound from `registerDragItem`.


      if (!isTouchEvent) {
        this._globalListeners.set('mousemove', {
          handler: e => this.pointerMove.next(e),
          options: activeCapturingEventOptions
        });
      }

      this._ngZone.runOutsideAngular(() => {
        this._globalListeners.forEach((config, name) => {
          this._document.addEventListener(name, config.handler, config.options);
        });
      });
    }
  }
  /** Stops dragging a drag item instance. */


  stopDragging(drag) {
    const index = this._activeDragInstances.indexOf(drag);

    if (index > -1) {
      this._activeDragInstances.splice(index, 1);

      if (this._activeDragInstances.length === 0) {
        this._clearGlobalListeners();
      }
    }
  }
  /** Gets whether a drag item instance is currently being dragged. */


  isDragging(drag) {
    return this._activeDragInstances.indexOf(drag) > -1;
  }
  /**
   * Gets a stream that will emit when any element on the page is scrolled while an item is being
   * dragged.
   * @param shadowRoot Optional shadow root that the current dragging sequence started from.
   *   Top-level listeners won't pick up events coming from the shadow DOM so this parameter can
   *   be used to include an additional top-level listener at the shadow root level.
   */


  scrolled(shadowRoot) {
    const streams = [this.scroll];

    if (shadowRoot && shadowRoot !== this._document) {
      // Note that this is basically the same as `fromEvent` from rjxs, but we do it ourselves,
      // because we want to guarantee that the event is bound outside of the `NgZone`. With
      // `fromEvent` it'll only happen if the subscription is outside the `NgZone`.
      streams.push(new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
        return this._ngZone.runOutsideAngular(() => {
          const eventOptions = true;

          const callback = event => {
            if (this._activeDragInstances.length) {
              observer.next(event);
            }
          };

          shadowRoot.addEventListener('scroll', callback, eventOptions);
          return () => {
            shadowRoot.removeEventListener('scroll', callback, eventOptions);
          };
        });
      }));
    }

    return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.merge)(...streams);
  }

  ngOnDestroy() {
    this._dragInstances.forEach(instance => this.removeDragItem(instance));

    this._dropInstances.forEach(instance => this.removeDropContainer(instance));

    this._clearGlobalListeners();

    this.pointerMove.complete();
    this.pointerUp.complete();
  }
  /** Clears out the global event listeners from the `document`. */


  _clearGlobalListeners() {
    this._globalListeners.forEach((config, name) => {
      this._document.removeEventListener(name, config.handler, config.options);
    });

    this._globalListeners.clear();
  }

}

DragDropRegistry.ɵfac = function DragDropRegistry_Factory(t) {
  return new (t || DragDropRegistry)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT));
};

DragDropRegistry.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjectable"]({
  token: DragDropRegistry,
  factory: DragDropRegistry.ɵfac,
  providedIn: 'root'
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](DragDropRegistry, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable,
    args: [{
      providedIn: 'root'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT]
      }]
    }];
  }, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Default configuration to be used when creating a `DragRef`. */


const DEFAULT_CONFIG = {
  dragStartThreshold: 5,
  pointerDirectionChangeThreshold: 5
};
/**
 * Service that allows for drag-and-drop functionality to be attached to DOM elements.
 */

class DragDrop {
  constructor(_document, _ngZone, _viewportRuler, _dragDropRegistry) {
    this._document = _document;
    this._ngZone = _ngZone;
    this._viewportRuler = _viewportRuler;
    this._dragDropRegistry = _dragDropRegistry;
  }
  /**
   * Turns an element into a draggable item.
   * @param element Element to which to attach the dragging functionality.
   * @param config Object used to configure the dragging behavior.
   */


  createDrag(element, config = DEFAULT_CONFIG) {
    return new DragRef(element, config, this._document, this._ngZone, this._viewportRuler, this._dragDropRegistry);
  }
  /**
   * Turns an element into a drop list.
   * @param element Element to which to attach the drop list functionality.
   */


  createDropList(element) {
    return new DropListRef(element, this._dragDropRegistry, this._document, this._ngZone, this._viewportRuler);
  }

}

DragDrop.ɵfac = function DragDrop_Factory(t) {
  return new (t || DragDrop)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ViewportRuler), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](DragDropRegistry));
};

DragDrop.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjectable"]({
  token: DragDrop,
  factory: DragDrop.ɵfac,
  providedIn: 'root'
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](DragDrop, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable,
    args: [{
      providedIn: 'root'
    }]
  }], function () {
    return [{
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone
    }, {
      type: _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ViewportRuler
    }, {
      type: DragDropRegistry
    }];
  }, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used for a `CdkDrag` to provide itself as a parent to the
 * drag-specific child directive (`CdkDragHandle`, `CdkDragPreview` etc.). Used primarily
 * to avoid circular imports.
 * @docs-private
 */


const CDK_DRAG_PARENT = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CDK_DRAG_PARENT');
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to reference instances of `CdkDropListGroup`. It serves as
 * alternative token to the actual `CdkDropListGroup` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */

const CDK_DROP_LIST_GROUP = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CdkDropListGroup');
/**
 * Declaratively connects sibling `cdkDropList` instances together. All of the `cdkDropList`
 * elements that are placed inside a `cdkDropListGroup` will be connected to each other
 * automatically. Can be used as an alternative to the `cdkDropListConnectedTo` input
 * from `cdkDropList`.
 */

class CdkDropListGroup {
  constructor() {
    /** Drop lists registered inside the group. */
    this._items = new Set();
    this._disabled = false;
  }
  /** Whether starting a dragging sequence from inside this group is disabled. */


  get disabled() {
    return this._disabled;
  }

  set disabled(value) {
    this._disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);
  }

  ngOnDestroy() {
    this._items.clear();
  }

}

CdkDropListGroup.ɵfac = function CdkDropListGroup_Factory(t) {
  return new (t || CdkDropListGroup)();
};

CdkDropListGroup.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDropListGroup,
  selectors: [["", "cdkDropListGroup", ""]],
  inputs: {
    disabled: ["cdkDropListGroupDisabled", "disabled"]
  },
  exportAs: ["cdkDropListGroup"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([{
    provide: CDK_DROP_LIST_GROUP,
    useExisting: CdkDropListGroup
  }])]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDropListGroup, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: '[cdkDropListGroup]',
      exportAs: 'cdkDropListGroup',
      providers: [{
        provide: CDK_DROP_LIST_GROUP,
        useExisting: CdkDropListGroup
      }]
    }]
  }], null, {
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListGroupDisabled']
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to configure the
 * behavior of the drag&drop-related components.
 */


const CDK_DRAG_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CDK_DRAG_CONFIG');
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Asserts that a particular node is an element.
 * @param node Node to be checked.
 * @param name Name to attach to the error message.
 */

function assertElementNode(node, name) {
  if (node.nodeType !== 1) {
    throw Error(`${name} must be attached to an element node. ` + `Currently attached to "${node.nodeName}".`);
  }
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/** Counter used to generate unique ids for drop zones. */


let _uniqueIdCounter = 0;
/**
 * Injection token that can be used to reference instances of `CdkDropList`. It serves as
 * alternative token to the actual `CdkDropList` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */

const CDK_DROP_LIST = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CdkDropList');
/** Container that wraps a set of draggable items. */

class CdkDropList {
  constructor(
  /** Element that the drop list is attached to. */
  element, dragDrop, _changeDetectorRef, _scrollDispatcher, _dir, _group, config) {
    this.element = element;
    this._changeDetectorRef = _changeDetectorRef;
    this._scrollDispatcher = _scrollDispatcher;
    this._dir = _dir;
    this._group = _group;
    /** Emits when the list has been destroyed. */

    this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /**
     * Other draggable containers that this container is connected to and into which the
     * container's items can be transferred. Can either be references to other drop containers,
     * or their unique IDs.
     */

    this.connectedTo = [];
    /**
     * Unique ID for the drop zone. Can be used as a reference
     * in the `connectedTo` of another `CdkDropList`.
     */

    this.id = `cdk-drop-list-${_uniqueIdCounter++}`;
    /**
     * Function that is used to determine whether an item
     * is allowed to be moved into a drop container.
     */

    this.enterPredicate = () => true;
    /** Functions that is used to determine whether an item can be sorted into a particular index. */


    this.sortPredicate = () => true;
    /** Emits when the user drops an item inside the container. */


    this.dropped = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /**
     * Emits when the user has moved a new drag item into this container.
     */

    this.entered = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /**
     * Emits when the user removes an item from the container
     * by dragging it into another container.
     */

    this.exited = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits as the user is swapping items while actively dragging. */

    this.sorted = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /**
     * Keeps track of the items that are registered with this container. Historically we used to
     * do this with a `ContentChildren` query, however queries don't handle transplanted views very
     * well which means that we can't handle cases like dragging the headers of a `mat-table`
     * correctly. What we do instead is to have the items register themselves with the container
     * and then we sort them based on their position in the DOM.
     */

    this._unsortedItems = new Set();

    if (typeof ngDevMode === 'undefined' || ngDevMode) {
      assertElementNode(element.nativeElement, 'cdkDropList');
    }

    this._dropListRef = dragDrop.createDropList(element);
    this._dropListRef.data = this;

    if (config) {
      this._assignDefaults(config);
    }

    this._dropListRef.enterPredicate = (drag, drop) => {
      return this.enterPredicate(drag.data, drop.data);
    };

    this._dropListRef.sortPredicate = (index, drag, drop) => {
      return this.sortPredicate(index, drag.data, drop.data);
    };

    this._setupInputSyncSubscription(this._dropListRef);

    this._handleEvents(this._dropListRef);

    CdkDropList._dropLists.push(this);

    if (_group) {
      _group._items.add(this);
    }
  }
  /** Whether starting a dragging sequence from this container is disabled. */


  get disabled() {
    return this._disabled || !!this._group && this._group.disabled;
  }

  set disabled(value) {
    // Usually we sync the directive and ref state right before dragging starts, in order to have
    // a single point of failure and to avoid having to use setters for everything. `disabled` is
    // a special case, because it can prevent the `beforeStarted` event from firing, which can lock
    // the user in a disabled state, so we also need to sync it as it's being set.
    this._dropListRef.disabled = this._disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);
  }
  /** Registers an items with the drop list. */


  addItem(item) {
    this._unsortedItems.add(item);

    if (this._dropListRef.isDragging()) {
      this._syncItemsWithRef();
    }
  }
  /** Removes an item from the drop list. */


  removeItem(item) {
    this._unsortedItems.delete(item);

    if (this._dropListRef.isDragging()) {
      this._syncItemsWithRef();
    }
  }
  /** Gets the registered items in the list, sorted by their position in the DOM. */


  getSortedItems() {
    return Array.from(this._unsortedItems).sort((a, b) => {
      const documentPosition = a._dragRef.getVisibleElement().compareDocumentPosition(b._dragRef.getVisibleElement()); // `compareDocumentPosition` returns a bitmask so we have to use a bitwise operator.
      // https://developer.mozilla.org/en-US/docs/Web/API/Node/compareDocumentPosition
      // tslint:disable-next-line:no-bitwise


      return documentPosition & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
    });
  }

  ngOnDestroy() {
    const index = CdkDropList._dropLists.indexOf(this);

    if (index > -1) {
      CdkDropList._dropLists.splice(index, 1);
    }

    if (this._group) {
      this._group._items.delete(this);
    }

    this._unsortedItems.clear();

    this._dropListRef.dispose();

    this._destroyed.next();

    this._destroyed.complete();
  }
  /** Syncs the inputs of the CdkDropList with the options of the underlying DropListRef. */


  _setupInputSyncSubscription(ref) {
    if (this._dir) {
      this._dir.change.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.startWith)(this._dir.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._destroyed)).subscribe(value => ref.withDirection(value));
    }

    ref.beforeStarted.subscribe(() => {
      const siblings = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceArray)(this.connectedTo).map(drop => {
        if (typeof drop === 'string') {
          const correspondingDropList = CdkDropList._dropLists.find(list => list.id === drop);

          if (!correspondingDropList && (typeof ngDevMode === 'undefined' || ngDevMode)) {
            console.warn(`CdkDropList could not find connected drop list with id "${drop}"`);
          }

          return correspondingDropList;
        }

        return drop;
      });

      if (this._group) {
        this._group._items.forEach(drop => {
          if (siblings.indexOf(drop) === -1) {
            siblings.push(drop);
          }
        });
      } // Note that we resolve the scrollable parents here so that we delay the resolution
      // as long as possible, ensuring that the element is in its final place in the DOM.


      if (!this._scrollableParentsResolved) {
        const scrollableParents = this._scrollDispatcher.getAncestorScrollContainers(this.element).map(scrollable => scrollable.getElementRef().nativeElement);

        this._dropListRef.withScrollableParents(scrollableParents); // Only do this once since it involves traversing the DOM and the parents
        // shouldn't be able to change without the drop list being destroyed.


        this._scrollableParentsResolved = true;
      }

      ref.disabled = this.disabled;
      ref.lockAxis = this.lockAxis;
      ref.sortingDisabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(this.sortingDisabled);
      ref.autoScrollDisabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(this.autoScrollDisabled);
      ref.autoScrollStep = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceNumberProperty)(this.autoScrollStep, 2);
      ref.connectedTo(siblings.filter(drop => drop && drop !== this).map(list => list._dropListRef)).withOrientation(this.orientation);
    });
  }
  /** Handles events from the underlying DropListRef. */


  _handleEvents(ref) {
    ref.beforeStarted.subscribe(() => {
      this._syncItemsWithRef();

      this._changeDetectorRef.markForCheck();
    });
    ref.entered.subscribe(event => {
      this.entered.emit({
        container: this,
        item: event.item.data,
        currentIndex: event.currentIndex
      });
    });
    ref.exited.subscribe(event => {
      this.exited.emit({
        container: this,
        item: event.item.data
      });

      this._changeDetectorRef.markForCheck();
    });
    ref.sorted.subscribe(event => {
      this.sorted.emit({
        previousIndex: event.previousIndex,
        currentIndex: event.currentIndex,
        container: this,
        item: event.item.data
      });
    });
    ref.dropped.subscribe(event => {
      this.dropped.emit({
        previousIndex: event.previousIndex,
        currentIndex: event.currentIndex,
        previousContainer: event.previousContainer.data,
        container: event.container.data,
        item: event.item.data,
        isPointerOverContainer: event.isPointerOverContainer,
        distance: event.distance,
        dropPoint: event.dropPoint
      }); // Mark for check since all of these events run outside of change
      // detection and we're not guaranteed for something else to have triggered it.

      this._changeDetectorRef.markForCheck();
    });
  }
  /** Assigns the default input values based on a provided config object. */


  _assignDefaults(config) {
    const {
      lockAxis,
      draggingDisabled,
      sortingDisabled,
      listAutoScrollDisabled,
      listOrientation
    } = config;
    this.disabled = draggingDisabled == null ? false : draggingDisabled;
    this.sortingDisabled = sortingDisabled == null ? false : sortingDisabled;
    this.autoScrollDisabled = listAutoScrollDisabled == null ? false : listAutoScrollDisabled;
    this.orientation = listOrientation || 'vertical';

    if (lockAxis) {
      this.lockAxis = lockAxis;
    }
  }
  /** Syncs up the registered drag items with underlying drop list ref. */


  _syncItemsWithRef() {
    this._dropListRef.withItems(this.getSortedItems().map(item => item._dragRef));
  }

}
/** Keeps track of the drop lists that are currently on the page. */


CdkDropList._dropLists = [];

CdkDropList.ɵfac = function CdkDropList_Factory(t) {
  return new (t || CdkDropList)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](DragDrop), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ScrollDispatcher), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_14__.Directionality, 8), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DROP_LIST_GROUP, 12), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DRAG_CONFIG, 8));
};

CdkDropList.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDropList,
  selectors: [["", "cdkDropList", ""], ["cdk-drop-list"]],
  hostAttrs: [1, "cdk-drop-list"],
  hostVars: 7,
  hostBindings: function CdkDropList_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵattribute"]("id", ctx.id);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("cdk-drop-list-disabled", ctx.disabled)("cdk-drop-list-dragging", ctx._dropListRef.isDragging())("cdk-drop-list-receiving", ctx._dropListRef.isReceiving());
    }
  },
  inputs: {
    connectedTo: ["cdkDropListConnectedTo", "connectedTo"],
    data: ["cdkDropListData", "data"],
    orientation: ["cdkDropListOrientation", "orientation"],
    id: "id",
    lockAxis: ["cdkDropListLockAxis", "lockAxis"],
    disabled: ["cdkDropListDisabled", "disabled"],
    sortingDisabled: ["cdkDropListSortingDisabled", "sortingDisabled"],
    enterPredicate: ["cdkDropListEnterPredicate", "enterPredicate"],
    sortPredicate: ["cdkDropListSortPredicate", "sortPredicate"],
    autoScrollDisabled: ["cdkDropListAutoScrollDisabled", "autoScrollDisabled"],
    autoScrollStep: ["cdkDropListAutoScrollStep", "autoScrollStep"]
  },
  outputs: {
    dropped: "cdkDropListDropped",
    entered: "cdkDropListEntered",
    exited: "cdkDropListExited",
    sorted: "cdkDropListSorted"
  },
  exportAs: ["cdkDropList"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([// Prevent child drop lists from picking up the same group as their parent.
  {
    provide: CDK_DROP_LIST_GROUP,
    useValue: undefined
  }, {
    provide: CDK_DROP_LIST,
    useExisting: CdkDropList
  }])]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDropList, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: '[cdkDropList], cdk-drop-list',
      exportAs: 'cdkDropList',
      providers: [// Prevent child drop lists from picking up the same group as their parent.
      {
        provide: CDK_DROP_LIST_GROUP,
        useValue: undefined
      }, {
        provide: CDK_DROP_LIST,
        useExisting: CdkDropList
      }],
      host: {
        'class': 'cdk-drop-list',
        '[attr.id]': 'id',
        '[class.cdk-drop-list-disabled]': 'disabled',
        '[class.cdk-drop-list-dragging]': '_dropListRef.isDragging()',
        '[class.cdk-drop-list-receiving]': '_dropListRef.isReceiving()'
      }
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef
    }, {
      type: DragDrop
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
    }, {
      type: _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ScrollDispatcher
    }, {
      type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_14__.Directionality,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }]
    }, {
      type: CdkDropListGroup,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DROP_LIST_GROUP]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.SkipSelf
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DRAG_CONFIG]
      }]
    }];
  }, {
    connectedTo: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListConnectedTo']
    }],
    data: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListData']
    }],
    orientation: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListOrientation']
    }],
    id: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
    }],
    lockAxis: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListLockAxis']
    }],
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListDisabled']
    }],
    sortingDisabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListSortingDisabled']
    }],
    enterPredicate: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListEnterPredicate']
    }],
    sortPredicate: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListSortPredicate']
    }],
    autoScrollDisabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListAutoScrollDisabled']
    }],
    autoScrollStep: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDropListAutoScrollStep']
    }],
    dropped: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDropListDropped']
    }],
    entered: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDropListEntered']
    }],
    exited: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDropListExited']
    }],
    sorted: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDropListSorted']
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to reference instances of `CdkDragHandle`. It serves as
 * alternative token to the actual `CdkDragHandle` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */


const CDK_DRAG_HANDLE = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CdkDragHandle');
/** Handle that can be used to drag a CdkDrag instance. */

class CdkDragHandle {
  constructor(element, parentDrag) {
    this.element = element;
    /** Emits when the state of the handle has changed. */

    this._stateChanges = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this._disabled = false;

    if (typeof ngDevMode === 'undefined' || ngDevMode) {
      assertElementNode(element.nativeElement, 'cdkDragHandle');
    }

    this._parentDrag = parentDrag;
  }
  /** Whether starting to drag through this handle is disabled. */


  get disabled() {
    return this._disabled;
  }

  set disabled(value) {
    this._disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);

    this._stateChanges.next(this);
  }

  ngOnDestroy() {
    this._stateChanges.complete();
  }

}

CdkDragHandle.ɵfac = function CdkDragHandle_Factory(t) {
  return new (t || CdkDragHandle)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DRAG_PARENT, 12));
};

CdkDragHandle.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDragHandle,
  selectors: [["", "cdkDragHandle", ""]],
  hostAttrs: [1, "cdk-drag-handle"],
  inputs: {
    disabled: ["cdkDragHandleDisabled", "disabled"]
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([{
    provide: CDK_DRAG_HANDLE,
    useExisting: CdkDragHandle
  }])]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDragHandle, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: '[cdkDragHandle]',
      host: {
        'class': 'cdk-drag-handle'
      },
      providers: [{
        provide: CDK_DRAG_HANDLE,
        useExisting: CdkDragHandle
      }]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DRAG_PARENT]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.SkipSelf
      }]
    }];
  }, {
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragHandleDisabled']
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to reference instances of `CdkDragPlaceholder`. It serves as
 * alternative token to the actual `CdkDragPlaceholder` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */


const CDK_DRAG_PLACEHOLDER = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CdkDragPlaceholder');
/**
 * Element that will be used as a template for the placeholder of a CdkDrag when
 * it is being dragged. The placeholder is displayed in place of the element being dragged.
 */

class CdkDragPlaceholder {
  constructor(templateRef) {
    this.templateRef = templateRef;
  }

}

CdkDragPlaceholder.ɵfac = function CdkDragPlaceholder_Factory(t) {
  return new (t || CdkDragPlaceholder)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.TemplateRef));
};

CdkDragPlaceholder.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDragPlaceholder,
  selectors: [["ng-template", "cdkDragPlaceholder", ""]],
  inputs: {
    data: "data"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([{
    provide: CDK_DRAG_PLACEHOLDER,
    useExisting: CdkDragPlaceholder
  }])]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDragPlaceholder, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: 'ng-template[cdkDragPlaceholder]',
      providers: [{
        provide: CDK_DRAG_PLACEHOLDER,
        useExisting: CdkDragPlaceholder
      }]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.TemplateRef
    }];
  }, {
    data: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token that can be used to reference instances of `CdkDragPreview`. It serves as
 * alternative token to the actual `CdkDragPreview` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */


const CDK_DRAG_PREVIEW = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.InjectionToken('CdkDragPreview');
/**
 * Element that will be used as a template for the preview
 * of a CdkDrag when it is being dragged.
 */

class CdkDragPreview {
  constructor(templateRef) {
    this.templateRef = templateRef;
    this._matchSize = false;
  }
  /** Whether the preview should preserve the same size as the item that is being dragged. */


  get matchSize() {
    return this._matchSize;
  }

  set matchSize(value) {
    this._matchSize = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);
  }

}

CdkDragPreview.ɵfac = function CdkDragPreview_Factory(t) {
  return new (t || CdkDragPreview)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.TemplateRef));
};

CdkDragPreview.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDragPreview,
  selectors: [["ng-template", "cdkDragPreview", ""]],
  inputs: {
    data: "data",
    matchSize: "matchSize"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([{
    provide: CDK_DRAG_PREVIEW,
    useExisting: CdkDragPreview
  }])]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDragPreview, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: 'ng-template[cdkDragPreview]',
      providers: [{
        provide: CDK_DRAG_PREVIEW,
        useExisting: CdkDragPreview
      }]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.TemplateRef
    }];
  }, {
    data: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
    }],
    matchSize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
    }]
  });
})();

const DRAG_HOST_CLASS = 'cdk-drag';
/** Element that can be moved inside a CdkDropList container. */

class CdkDrag {
  constructor(
  /** Element that the draggable is attached to. */
  element,
  /** Droppable container that the draggable is a part of. */
  dropContainer,
  /**
   * @deprecated `_document` parameter no longer being used and will be removed.
   * @breaking-change 12.0.0
   */
  _document, _ngZone, _viewContainerRef, config, _dir, dragDrop, _changeDetectorRef, _selfHandle, _parentDrag) {
    this.element = element;
    this.dropContainer = dropContainer;
    this._ngZone = _ngZone;
    this._viewContainerRef = _viewContainerRef;
    this._dir = _dir;
    this._changeDetectorRef = _changeDetectorRef;
    this._selfHandle = _selfHandle;
    this._parentDrag = _parentDrag;
    this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    /** Emits when the user starts dragging the item. */

    this.started = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits when the user has released a drag item, before any animations have started. */

    this.released = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits when the user stops dragging an item in the container. */

    this.ended = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits when the user has moved the item into a new container. */

    this.entered = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits when the user removes the item its container by dragging it into another container. */

    this.exited = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /** Emits when the user drops the item inside a container. */

    this.dropped = new _angular_core__WEBPACK_IMPORTED_MODULE_10__.EventEmitter();
    /**
     * Emits as the user is dragging the item. Use with caution,
     * because this event will fire for every pixel that the user has dragged.
     */

    this.moved = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
      const subscription = this._dragRef.moved.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(movedEvent => ({
        source: this,
        pointerPosition: movedEvent.pointerPosition,
        event: movedEvent.event,
        delta: movedEvent.delta,
        distance: movedEvent.distance
      }))).subscribe(observer);

      return () => {
        subscription.unsubscribe();
      };
    });
    this._dragRef = dragDrop.createDrag(element, {
      dragStartThreshold: config && config.dragStartThreshold != null ? config.dragStartThreshold : 5,
      pointerDirectionChangeThreshold: config && config.pointerDirectionChangeThreshold != null ? config.pointerDirectionChangeThreshold : 5,
      zIndex: config === null || config === void 0 ? void 0 : config.zIndex
    });
    this._dragRef.data = this; // We have to keep track of the drag instances in order to be able to match an element to
    // a drag instance. We can't go through the global registry of `DragRef`, because the root
    // element could be different.

    CdkDrag._dragInstances.push(this);

    if (config) {
      this._assignDefaults(config);
    } // Note that usually the container is assigned when the drop list is picks up the item, but in
    // some cases (mainly transplanted views with OnPush, see #18341) we may end up in a situation
    // where there are no items on the first change detection pass, but the items get picked up as
    // soon as the user triggers another pass by dragging. This is a problem, because the item would
    // have to switch from standalone mode to drag mode in the middle of the dragging sequence which
    // is too late since the two modes save different kinds of information. We work around it by
    // assigning the drop container both from here and the list.


    if (dropContainer) {
      this._dragRef._withDropContainer(dropContainer._dropListRef);

      dropContainer.addItem(this);
    }

    this._syncInputs(this._dragRef);

    this._handleEvents(this._dragRef);
  }
  /** Whether starting to drag this element is disabled. */


  get disabled() {
    return this._disabled || this.dropContainer && this.dropContainer.disabled;
  }

  set disabled(value) {
    this._disabled = (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceBooleanProperty)(value);
    this._dragRef.disabled = this._disabled;
  }
  /**
   * Returns the element that is being used as a placeholder
   * while the current element is being dragged.
   */


  getPlaceholderElement() {
    return this._dragRef.getPlaceholderElement();
  }
  /** Returns the root draggable element. */


  getRootElement() {
    return this._dragRef.getRootElement();
  }
  /** Resets a standalone drag item to its initial position. */


  reset() {
    this._dragRef.reset();
  }
  /**
   * Gets the pixel coordinates of the draggable outside of a drop container.
   */


  getFreeDragPosition() {
    return this._dragRef.getFreeDragPosition();
  }

  ngAfterViewInit() {
    // Normally this isn't in the zone, but it can cause major performance regressions for apps
    // using `zone-patch-rxjs` because it'll trigger a change detection when it unsubscribes.
    this._ngZone.runOutsideAngular(() => {
      // We need to wait for the zone to stabilize, in order for the reference
      // element to be in the proper place in the DOM. This is mostly relevant
      // for draggable elements inside portals since they get stamped out in
      // their original DOM position and then they get transferred to the portal.
      this._ngZone.onStable.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._destroyed)).subscribe(() => {
        this._updateRootElement();

        this._setupHandlesListener();

        if (this.freeDragPosition) {
          this._dragRef.setFreeDragPosition(this.freeDragPosition);
        }
      });
    });
  }

  ngOnChanges(changes) {
    const rootSelectorChange = changes['rootElementSelector'];
    const positionChange = changes['freeDragPosition']; // We don't have to react to the first change since it's being
    // handled in `ngAfterViewInit` where it needs to be deferred.

    if (rootSelectorChange && !rootSelectorChange.firstChange) {
      this._updateRootElement();
    } // Skip the first change since it's being handled in `ngAfterViewInit`.


    if (positionChange && !positionChange.firstChange && this.freeDragPosition) {
      this._dragRef.setFreeDragPosition(this.freeDragPosition);
    }
  }

  ngOnDestroy() {
    if (this.dropContainer) {
      this.dropContainer.removeItem(this);
    }

    const index = CdkDrag._dragInstances.indexOf(this);

    if (index > -1) {
      CdkDrag._dragInstances.splice(index, 1);
    } // Unnecessary in most cases, but used to avoid extra change detections with `zone-paths-rxjs`.


    this._ngZone.runOutsideAngular(() => {
      this._destroyed.next();

      this._destroyed.complete();

      this._dragRef.dispose();
    });
  }
  /** Syncs the root element with the `DragRef`. */


  _updateRootElement() {
    var _a;

    const element = this.element.nativeElement;
    let rootElement = element;

    if (this.rootElementSelector) {
      rootElement = element.closest !== undefined ? element.closest(this.rootElementSelector) : // Comment tag doesn't have closest method, so use parent's one.
      (_a = element.parentElement) === null || _a === void 0 ? void 0 : _a.closest(this.rootElementSelector);
    }

    if (rootElement && (typeof ngDevMode === 'undefined' || ngDevMode)) {
      assertElementNode(rootElement, 'cdkDrag');
    }

    this._dragRef.withRootElement(rootElement || element);
  }
  /** Gets the boundary element, based on the `boundaryElement` value. */


  _getBoundaryElement() {
    const boundary = this.boundaryElement;

    if (!boundary) {
      return null;
    }

    if (typeof boundary === 'string') {
      return this.element.nativeElement.closest(boundary);
    }

    return (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceElement)(boundary);
  }
  /** Syncs the inputs of the CdkDrag with the options of the underlying DragRef. */


  _syncInputs(ref) {
    ref.beforeStarted.subscribe(() => {
      if (!ref.isDragging()) {
        const dir = this._dir;
        const dragStartDelay = this.dragStartDelay;
        const placeholder = this._placeholderTemplate ? {
          template: this._placeholderTemplate.templateRef,
          context: this._placeholderTemplate.data,
          viewContainer: this._viewContainerRef
        } : null;
        const preview = this._previewTemplate ? {
          template: this._previewTemplate.templateRef,
          context: this._previewTemplate.data,
          matchSize: this._previewTemplate.matchSize,
          viewContainer: this._viewContainerRef
        } : null;
        ref.disabled = this.disabled;
        ref.lockAxis = this.lockAxis;
        ref.dragStartDelay = typeof dragStartDelay === 'object' && dragStartDelay ? dragStartDelay : (0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_3__.coerceNumberProperty)(dragStartDelay);
        ref.constrainPosition = this.constrainPosition;
        ref.previewClass = this.previewClass;
        ref.withBoundaryElement(this._getBoundaryElement()).withPlaceholderTemplate(placeholder).withPreviewTemplate(preview).withPreviewContainer(this.previewContainer || 'global');

        if (dir) {
          ref.withDirection(dir.value);
        }
      }
    }); // This only needs to be resolved once.

    ref.beforeStarted.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.take)(1)).subscribe(() => {
      var _a; // If we managed to resolve a parent through DI, use it.


      if (this._parentDrag) {
        ref.withParent(this._parentDrag._dragRef);
        return;
      } // Otherwise fall back to resolving the parent by looking up the DOM. This can happen if
      // the item was projected into another item by something like `ngTemplateOutlet`.


      let parent = this.element.nativeElement.parentElement;

      while (parent) {
        if (parent.classList.contains(DRAG_HOST_CLASS)) {
          ref.withParent(((_a = CdkDrag._dragInstances.find(drag => {
            return drag.element.nativeElement === parent;
          })) === null || _a === void 0 ? void 0 : _a._dragRef) || null);
          break;
        }

        parent = parent.parentElement;
      }
    });
  }
  /** Handles the events from the underlying `DragRef`. */


  _handleEvents(ref) {
    ref.started.subscribe(() => {
      this.started.emit({
        source: this
      }); // Since all of these events run outside of change detection,
      // we need to ensure that everything is marked correctly.

      this._changeDetectorRef.markForCheck();
    });
    ref.released.subscribe(() => {
      this.released.emit({
        source: this
      });
    });
    ref.ended.subscribe(event => {
      this.ended.emit({
        source: this,
        distance: event.distance,
        dropPoint: event.dropPoint
      }); // Since all of these events run outside of change detection,
      // we need to ensure that everything is marked correctly.

      this._changeDetectorRef.markForCheck();
    });
    ref.entered.subscribe(event => {
      this.entered.emit({
        container: event.container.data,
        item: this,
        currentIndex: event.currentIndex
      });
    });
    ref.exited.subscribe(event => {
      this.exited.emit({
        container: event.container.data,
        item: this
      });
    });
    ref.dropped.subscribe(event => {
      this.dropped.emit({
        previousIndex: event.previousIndex,
        currentIndex: event.currentIndex,
        previousContainer: event.previousContainer.data,
        container: event.container.data,
        isPointerOverContainer: event.isPointerOverContainer,
        item: this,
        distance: event.distance,
        dropPoint: event.dropPoint
      });
    });
  }
  /** Assigns the default input values based on a provided config object. */


  _assignDefaults(config) {
    const {
      lockAxis,
      dragStartDelay,
      constrainPosition,
      previewClass,
      boundaryElement,
      draggingDisabled,
      rootElementSelector,
      previewContainer
    } = config;
    this.disabled = draggingDisabled == null ? false : draggingDisabled;
    this.dragStartDelay = dragStartDelay || 0;

    if (lockAxis) {
      this.lockAxis = lockAxis;
    }

    if (constrainPosition) {
      this.constrainPosition = constrainPosition;
    }

    if (previewClass) {
      this.previewClass = previewClass;
    }

    if (boundaryElement) {
      this.boundaryElement = boundaryElement;
    }

    if (rootElementSelector) {
      this.rootElementSelector = rootElementSelector;
    }

    if (previewContainer) {
      this.previewContainer = previewContainer;
    }
  }
  /** Sets up the listener that syncs the handles with the drag ref. */


  _setupHandlesListener() {
    // Listen for any newly-added handles.
    this._handles.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.startWith)(this._handles), // Sync the new handles with the DragRef.
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.tap)(handles => {
      const childHandleElements = handles.filter(handle => handle._parentDrag === this).map(handle => handle.element); // Usually handles are only allowed to be a descendant of the drag element, but if
      // the consumer defined a different drag root, we should allow the drag element
      // itself to be a handle too.

      if (this._selfHandle && this.rootElementSelector) {
        childHandleElements.push(this.element);
      }

      this._dragRef.withHandles(childHandleElements);
    }), // Listen if the state of any of the handles changes.
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.switchMap)(handles => {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.merge)(...handles.map(item => {
        return item._stateChanges.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.startWith)(item));
      }));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this._destroyed)).subscribe(handleInstance => {
      // Enabled/disable the handle that changed in the DragRef.
      const dragRef = this._dragRef;
      const handle = handleInstance.element.nativeElement;
      handleInstance.disabled ? dragRef.disableHandle(handle) : dragRef.enableHandle(handle);
    });
  }

}

CdkDrag._dragInstances = [];

CdkDrag.ɵfac = function CdkDrag_Factory(t) {
  return new (t || CdkDrag)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DROP_LIST, 12), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewContainerRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DRAG_CONFIG, 8), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_14__.Directionality, 8), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](DragDrop), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DRAG_HANDLE, 10), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](CDK_DRAG_PARENT, 12));
};

CdkDrag.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineDirective"]({
  type: CdkDrag,
  selectors: [["", "cdkDrag", ""]],
  contentQueries: function CdkDrag_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵcontentQuery"](dirIndex, CDK_DRAG_PREVIEW, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵcontentQuery"](dirIndex, CDK_DRAG_PLACEHOLDER, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵcontentQuery"](dirIndex, CDK_DRAG_HANDLE, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx._previewTemplate = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx._placeholderTemplate = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx._handles = _t);
    }
  },
  hostAttrs: [1, "cdk-drag"],
  hostVars: 4,
  hostBindings: function CdkDrag_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("cdk-drag-disabled", ctx.disabled)("cdk-drag-dragging", ctx._dragRef.isDragging());
    }
  },
  inputs: {
    data: ["cdkDragData", "data"],
    lockAxis: ["cdkDragLockAxis", "lockAxis"],
    rootElementSelector: ["cdkDragRootElement", "rootElementSelector"],
    boundaryElement: ["cdkDragBoundary", "boundaryElement"],
    dragStartDelay: ["cdkDragStartDelay", "dragStartDelay"],
    freeDragPosition: ["cdkDragFreeDragPosition", "freeDragPosition"],
    disabled: ["cdkDragDisabled", "disabled"],
    constrainPosition: ["cdkDragConstrainPosition", "constrainPosition"],
    previewClass: ["cdkDragPreviewClass", "previewClass"],
    previewContainer: ["cdkDragPreviewContainer", "previewContainer"]
  },
  outputs: {
    started: "cdkDragStarted",
    released: "cdkDragReleased",
    ended: "cdkDragEnded",
    entered: "cdkDragEntered",
    exited: "cdkDragExited",
    dropped: "cdkDragDropped",
    moved: "cdkDragMoved"
  },
  exportAs: ["cdkDrag"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([{
    provide: CDK_DRAG_PARENT,
    useExisting: CdkDrag
  }]), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵNgOnChangesFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](CdkDrag, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Directive,
    args: [{
      selector: '[cdkDrag]',
      exportAs: 'cdkDrag',
      host: {
        'class': DRAG_HOST_CLASS,
        '[class.cdk-drag-disabled]': 'disabled',
        '[class.cdk-drag-dragging]': '_dragRef.isDragging()'
      },
      providers: [{
        provide: CDK_DRAG_PARENT,
        useExisting: CdkDrag
      }]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ElementRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DROP_LIST]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.SkipSelf
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.NgZone
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ViewContainerRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DRAG_CONFIG]
      }]
    }, {
      type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_14__.Directionality,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }]
    }, {
      type: DragDrop
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ChangeDetectorRef
    }, {
      type: CdkDragHandle,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Self
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DRAG_HANDLE]
      }]
    }, {
      type: CdkDrag,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.SkipSelf
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Inject,
        args: [CDK_DRAG_PARENT]
      }]
    }];
  }, {
    _handles: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ContentChildren,
      args: [CDK_DRAG_HANDLE, {
        descendants: true
      }]
    }],
    _previewTemplate: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ContentChild,
      args: [CDK_DRAG_PREVIEW]
    }],
    _placeholderTemplate: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.ContentChild,
      args: [CDK_DRAG_PLACEHOLDER]
    }],
    data: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragData']
    }],
    lockAxis: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragLockAxis']
    }],
    rootElementSelector: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragRootElement']
    }],
    boundaryElement: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragBoundary']
    }],
    dragStartDelay: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragStartDelay']
    }],
    freeDragPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragFreeDragPosition']
    }],
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragDisabled']
    }],
    constrainPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragConstrainPosition']
    }],
    previewClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragPreviewClass']
    }],
    previewContainer: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input,
      args: ['cdkDragPreviewContainer']
    }],
    started: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragStarted']
    }],
    released: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragReleased']
    }],
    ended: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragEnded']
    }],
    entered: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragEntered']
    }],
    exited: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragExited']
    }],
    dropped: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragDropped']
    }],
    moved: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Output,
      args: ['cdkDragMoved']
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class DragDropModule {}

DragDropModule.ɵfac = function DragDropModule_Factory(t) {
  return new (t || DragDropModule)();
};

DragDropModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineNgModule"]({
  type: DragDropModule,
  declarations: [CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder],
  exports: [_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.CdkScrollableModule, CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder]
});
DragDropModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjector"]({
  providers: [DragDrop],
  imports: [_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.CdkScrollableModule]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵsetClassMetadata"](DragDropModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule,
    args: [{
      declarations: [CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder],
      exports: [_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.CdkScrollableModule, CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder],
      providers: [DragDrop]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ }),

/***/ 68566:
/*!***************************************************************!*\
  !*** ./node_modules/@angular/material/fesm2015/grid-list.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MatGridAvatarCssMatStyler": () => (/* binding */ MatGridAvatarCssMatStyler),
/* harmony export */   "MatGridList": () => (/* binding */ MatGridList),
/* harmony export */   "MatGridListModule": () => (/* binding */ MatGridListModule),
/* harmony export */   "MatGridTile": () => (/* binding */ MatGridTile),
/* harmony export */   "MatGridTileFooterCssMatStyler": () => (/* binding */ MatGridTileFooterCssMatStyler),
/* harmony export */   "MatGridTileHeaderCssMatStyler": () => (/* binding */ MatGridTileHeaderCssMatStyler),
/* harmony export */   "MatGridTileText": () => (/* binding */ MatGridTileText),
/* harmony export */   "ɵTileCoordinator": () => (/* binding */ ɵTileCoordinator)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/core */ 43946);
/* harmony import */ var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/coercion */ 40526);
/* harmony import */ var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/bidi */ 96142);





/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Class for determining, from a list of tiles, the (row, col) position of each of those tiles
 * in the grid. This is necessary (rather than just rendering the tiles in normal document flow)
 * because the tiles can have a rowspan.
 *
 * The positioning algorithm greedily places each tile as soon as it encounters a gap in the grid
 * large enough to accommodate it so that the tiles still render in the same order in which they
 * are given.
 *
 * The basis of the algorithm is the use of an array to track the already placed tiles. Each
 * element of the array corresponds to a column, and the value indicates how many cells in that
 * column are already occupied; zero indicates an empty cell. Moving "down" to the next row
 * decrements each value in the tracking array (indicating that the column is one cell closer to
 * being free).
 *
 * @docs-private
 */

const _c0 = ["*"];
const _c1 = [[["", "mat-grid-avatar", ""], ["", "matGridAvatar", ""]], [["", "mat-line", ""], ["", "matLine", ""]], "*"];
const _c2 = ["[mat-grid-avatar], [matGridAvatar]", "[mat-line], [matLine]", "*"];
const _c3 = ".mat-grid-list{display:block;position:relative}.mat-grid-tile{display:block;position:absolute;overflow:hidden}.mat-grid-tile .mat-grid-tile-header,.mat-grid-tile .mat-grid-tile-footer{display:flex;align-items:center;height:48px;color:#fff;background:rgba(0,0,0,.38);overflow:hidden;padding:0 16px;position:absolute;left:0;right:0}.mat-grid-tile .mat-grid-tile-header>*,.mat-grid-tile .mat-grid-tile-footer>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-tile-header.mat-2-line,.mat-grid-tile .mat-grid-tile-footer.mat-2-line{height:68px}.mat-grid-tile .mat-grid-list-text{display:flex;flex-direction:column;flex:auto;box-sizing:border-box;overflow:hidden}.mat-grid-tile .mat-grid-list-text>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-list-text:empty{display:none}.mat-grid-tile .mat-grid-tile-header{top:0}.mat-grid-tile .mat-grid-tile-footer{bottom:0}.mat-grid-tile .mat-grid-avatar{padding-right:16px}[dir=rtl] .mat-grid-tile .mat-grid-avatar{padding-right:0;padding-left:16px}.mat-grid-tile .mat-grid-avatar:empty{display:none}.mat-grid-tile-content{top:0;left:0;right:0;bottom:0;position:absolute;display:flex;align-items:center;justify-content:center;height:100%;padding:0;margin:0}\n";

class TileCoordinator {
  constructor() {
    /** Index at which the search for the next gap will start. */
    this.columnIndex = 0;
    /** The current row index. */

    this.rowIndex = 0;
  }
  /** Gets the total number of rows occupied by tiles */


  get rowCount() {
    return this.rowIndex + 1;
  }
  /**
   * Gets the total span of rows occupied by tiles.
   * Ex: A list with 1 row that contains a tile with rowspan 2 will have a total rowspan of 2.
   */


  get rowspan() {
    const lastRowMax = Math.max(...this.tracker); // if any of the tiles has a rowspan that pushes it beyond the total row count,
    // add the difference to the rowcount

    return lastRowMax > 1 ? this.rowCount + lastRowMax - 1 : this.rowCount;
  }
  /**
   * Updates the tile positions.
   * @param numColumns Amount of columns in the grid.
   * @param tiles Tiles to be positioned.
   */


  update(numColumns, tiles) {
    this.columnIndex = 0;
    this.rowIndex = 0;
    this.tracker = new Array(numColumns);
    this.tracker.fill(0, 0, this.tracker.length);
    this.positions = tiles.map(tile => this._trackTile(tile));
  }
  /** Calculates the row and col position of a tile. */


  _trackTile(tile) {
    // Find a gap large enough for this tile.
    const gapStartIndex = this._findMatchingGap(tile.colspan); // Place tile in the resulting gap.


    this._markTilePosition(gapStartIndex, tile); // The next time we look for a gap, the search will start at columnIndex, which should be
    // immediately after the tile that has just been placed.


    this.columnIndex = gapStartIndex + tile.colspan;
    return new TilePosition(this.rowIndex, gapStartIndex);
  }
  /** Finds the next available space large enough to fit the tile. */


  _findMatchingGap(tileCols) {
    if (tileCols > this.tracker.length && (typeof ngDevMode === 'undefined' || ngDevMode)) {
      throw Error(`mat-grid-list: tile with colspan ${tileCols} is wider than ` + `grid with cols="${this.tracker.length}".`);
    } // Start index is inclusive, end index is exclusive.


    let gapStartIndex = -1;
    let gapEndIndex = -1; // Look for a gap large enough to fit the given tile. Empty spaces are marked with a zero.

    do {
      // If we've reached the end of the row, go to the next row.
      if (this.columnIndex + tileCols > this.tracker.length) {
        this._nextRow();

        gapStartIndex = this.tracker.indexOf(0, this.columnIndex);
        gapEndIndex = this._findGapEndIndex(gapStartIndex);
        continue;
      }

      gapStartIndex = this.tracker.indexOf(0, this.columnIndex); // If there are no more empty spaces in this row at all, move on to the next row.

      if (gapStartIndex == -1) {
        this._nextRow();

        gapStartIndex = this.tracker.indexOf(0, this.columnIndex);
        gapEndIndex = this._findGapEndIndex(gapStartIndex);
        continue;
      }

      gapEndIndex = this._findGapEndIndex(gapStartIndex); // If a gap large enough isn't found, we want to start looking immediately after the current
      // gap on the next iteration.

      this.columnIndex = gapStartIndex + 1; // Continue iterating until we find a gap wide enough for this tile. Since gapEndIndex is
      // exclusive, gapEndIndex is 0 means we didn't find a gap and should continue.
    } while (gapEndIndex - gapStartIndex < tileCols || gapEndIndex == 0); // If we still didn't manage to find a gap, ensure that the index is
    // at least zero so the tile doesn't get pulled out of the grid.


    return Math.max(gapStartIndex, 0);
  }
  /** Move "down" to the next row. */


  _nextRow() {
    this.columnIndex = 0;
    this.rowIndex++; // Decrement all spaces by one to reflect moving down one row.

    for (let i = 0; i < this.tracker.length; i++) {
      this.tracker[i] = Math.max(0, this.tracker[i] - 1);
    }
  }
  /**
   * Finds the end index (exclusive) of a gap given the index from which to start looking.
   * The gap ends when a non-zero value is found.
   */


  _findGapEndIndex(gapStartIndex) {
    for (let i = gapStartIndex + 1; i < this.tracker.length; i++) {
      if (this.tracker[i] != 0) {
        return i;
      }
    } // The gap ends with the end of the row.


    return this.tracker.length;
  }
  /** Update the tile tracker to account for the given tile in the given space. */


  _markTilePosition(start, tile) {
    for (let i = 0; i < tile.colspan; i++) {
      this.tracker[start + i] = tile.rowspan;
    }
  }

}
/**
 * Simple data structure for tile position (row, col).
 * @docs-private
 */


class TilePosition {
  constructor(row, col) {
    this.row = row;
    this.col = col;
  }

}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Injection token used to provide a grid list to a tile and to avoid circular imports.
 * @docs-private
 */


const MAT_GRID_LIST = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('MAT_GRID_LIST');
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

class MatGridTile {
  constructor(_element, _gridList) {
    this._element = _element;
    this._gridList = _gridList;
    this._rowspan = 1;
    this._colspan = 1;
  }
  /** Amount of rows that the grid tile takes up. */


  get rowspan() {
    return this._rowspan;
  }

  set rowspan(value) {
    this._rowspan = Math.round((0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceNumberProperty)(value));
  }
  /** Amount of columns that the grid tile takes up. */


  get colspan() {
    return this._colspan;
  }

  set colspan(value) {
    this._colspan = Math.round((0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceNumberProperty)(value));
  }
  /**
   * Sets the style of the grid-tile element.  Needs to be set manually to avoid
   * "Changed after checked" errors that would occur with HostBinding.
   */


  _setStyle(property, value) {
    this._element.nativeElement.style[property] = value;
  }

}

MatGridTile.ɵfac = function MatGridTile_Factory(t) {
  return new (t || MatGridTile)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](MAT_GRID_LIST, 8));
};

MatGridTile.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatGridTile,
  selectors: [["mat-grid-tile"]],
  hostAttrs: [1, "mat-grid-tile"],
  hostVars: 2,
  hostBindings: function MatGridTile_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("rowspan", ctx.rowspan)("colspan", ctx.colspan);
    }
  },
  inputs: {
    rowspan: "rowspan",
    colspan: "colspan"
  },
  exportAs: ["matGridTile"],
  ngContentSelectors: _c0,
  decls: 2,
  vars: 0,
  consts: [[1, "mat-grid-tile-content"]],
  template: function MatGridTile_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
  },
  styles: [".mat-grid-list{display:block;position:relative}.mat-grid-tile{display:block;position:absolute;overflow:hidden}.mat-grid-tile .mat-grid-tile-header,.mat-grid-tile .mat-grid-tile-footer{display:flex;align-items:center;height:48px;color:#fff;background:rgba(0,0,0,.38);overflow:hidden;padding:0 16px;position:absolute;left:0;right:0}.mat-grid-tile .mat-grid-tile-header>*,.mat-grid-tile .mat-grid-tile-footer>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-tile-header.mat-2-line,.mat-grid-tile .mat-grid-tile-footer.mat-2-line{height:68px}.mat-grid-tile .mat-grid-list-text{display:flex;flex-direction:column;flex:auto;box-sizing:border-box;overflow:hidden}.mat-grid-tile .mat-grid-list-text>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-list-text:empty{display:none}.mat-grid-tile .mat-grid-tile-header{top:0}.mat-grid-tile .mat-grid-tile-footer{bottom:0}.mat-grid-tile .mat-grid-avatar{padding-right:16px}[dir=rtl] .mat-grid-tile .mat-grid-avatar{padding-right:0;padding-left:16px}.mat-grid-tile .mat-grid-avatar:empty{display:none}.mat-grid-tile-content{top:0;left:0;right:0;bottom:0;position:absolute;display:flex;align-items:center;justify-content:center;height:100%;padding:0;margin:0}\n"],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridTile, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-grid-tile',
      exportAs: 'matGridTile',
      host: {
        'class': 'mat-grid-tile',
        // Ensures that the "rowspan" and "colspan" input value is reflected in
        // the DOM. This is needed for the grid-tile harness.
        '[attr.rowspan]': 'rowspan',
        '[attr.colspan]': 'colspan'
      },
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      template: "<div class=\"mat-grid-tile-content\">\n  <ng-content></ng-content>\n</div>\n",
      styles: [".mat-grid-list{display:block;position:relative}.mat-grid-tile{display:block;position:absolute;overflow:hidden}.mat-grid-tile .mat-grid-tile-header,.mat-grid-tile .mat-grid-tile-footer{display:flex;align-items:center;height:48px;color:#fff;background:rgba(0,0,0,.38);overflow:hidden;padding:0 16px;position:absolute;left:0;right:0}.mat-grid-tile .mat-grid-tile-header>*,.mat-grid-tile .mat-grid-tile-footer>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-tile-header.mat-2-line,.mat-grid-tile .mat-grid-tile-footer.mat-2-line{height:68px}.mat-grid-tile .mat-grid-list-text{display:flex;flex-direction:column;flex:auto;box-sizing:border-box;overflow:hidden}.mat-grid-tile .mat-grid-list-text>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-list-text:empty{display:none}.mat-grid-tile .mat-grid-tile-header{top:0}.mat-grid-tile .mat-grid-tile-footer{bottom:0}.mat-grid-tile .mat-grid-avatar{padding-right:16px}[dir=rtl] .mat-grid-tile .mat-grid-avatar{padding-right:0;padding-left:16px}.mat-grid-tile .mat-grid-avatar:empty{display:none}.mat-grid-tile-content{top:0;left:0;right:0;bottom:0;position:absolute;display:flex;align-items:center;justify-content:center;height:100%;padding:0;margin:0}\n"]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [MAT_GRID_LIST]
      }]
    }];
  }, {
    rowspan: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    colspan: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();

class MatGridTileText {
  constructor(_element) {
    this._element = _element;
  }

  ngAfterContentInit() {
    (0,_angular_material_core__WEBPACK_IMPORTED_MODULE_2__.setLines)(this._lines, this._element);
  }

}

MatGridTileText.ɵfac = function MatGridTileText_Factory(t) {
  return new (t || MatGridTileText)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef));
};

MatGridTileText.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatGridTileText,
  selectors: [["mat-grid-tile-header"], ["mat-grid-tile-footer"]],
  contentQueries: function MatGridTileText_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLine, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._lines = _t);
    }
  },
  ngContentSelectors: _c2,
  decls: 4,
  vars: 0,
  consts: [[1, "mat-grid-list-text"]],
  template: function MatGridTileText_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"](_c1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](2, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](3, 2);
    }
  },
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridTileText, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-grid-tile-header, mat-grid-tile-footer',
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      template: "<ng-content select=\"[mat-grid-avatar], [matGridAvatar]\"></ng-content>\n<div class=\"mat-grid-list-text\"><ng-content select=\"[mat-line], [matLine]\"></ng-content></div>\n<ng-content></ng-content>\n"
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }];
  }, {
    _lines: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [_angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLine, {
        descendants: true
      }]
    }]
  });
})();
/**
 * Directive whose purpose is to add the mat- CSS styling to this selector.
 * @docs-private
 */


class MatGridAvatarCssMatStyler {}

MatGridAvatarCssMatStyler.ɵfac = function MatGridAvatarCssMatStyler_Factory(t) {
  return new (t || MatGridAvatarCssMatStyler)();
};

MatGridAvatarCssMatStyler.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatGridAvatarCssMatStyler,
  selectors: [["", "mat-grid-avatar", ""], ["", "matGridAvatar", ""]],
  hostAttrs: [1, "mat-grid-avatar"]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridAvatarCssMatStyler, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[mat-grid-avatar], [matGridAvatar]',
      host: {
        'class': 'mat-grid-avatar'
      }
    }]
  }], null, null);
})();
/**
 * Directive whose purpose is to add the mat- CSS styling to this selector.
 * @docs-private
 */


class MatGridTileHeaderCssMatStyler {}

MatGridTileHeaderCssMatStyler.ɵfac = function MatGridTileHeaderCssMatStyler_Factory(t) {
  return new (t || MatGridTileHeaderCssMatStyler)();
};

MatGridTileHeaderCssMatStyler.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatGridTileHeaderCssMatStyler,
  selectors: [["mat-grid-tile-header"]],
  hostAttrs: [1, "mat-grid-tile-header"]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridTileHeaderCssMatStyler, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'mat-grid-tile-header',
      host: {
        'class': 'mat-grid-tile-header'
      }
    }]
  }], null, null);
})();
/**
 * Directive whose purpose is to add the mat- CSS styling to this selector.
 * @docs-private
 */


class MatGridTileFooterCssMatStyler {}

MatGridTileFooterCssMatStyler.ɵfac = function MatGridTileFooterCssMatStyler_Factory(t) {
  return new (t || MatGridTileFooterCssMatStyler)();
};

MatGridTileFooterCssMatStyler.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: MatGridTileFooterCssMatStyler,
  selectors: [["mat-grid-tile-footer"]],
  hostAttrs: [1, "mat-grid-tile-footer"]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridTileFooterCssMatStyler, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: 'mat-grid-tile-footer',
      host: {
        'class': 'mat-grid-tile-footer'
      }
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * RegExp that can be used to check whether a value will
 * be allowed inside a CSS `calc()` expression.
 */


const cssCalcAllowedValue = /^-?\d+((\.\d+)?[A-Za-z%$]?)+$/;
/**
 * Sets the style properties for an individual tile, given the position calculated by the
 * Tile Coordinator.
 * @docs-private
 */

class TileStyler {
  constructor() {
    this._rows = 0;
    this._rowspan = 0;
  }
  /**
   * Adds grid-list layout info once it is available. Cannot be processed in the constructor
   * because these properties haven't been calculated by that point.
   *
   * @param gutterSize Size of the grid's gutter.
   * @param tracker Instance of the TileCoordinator.
   * @param cols Amount of columns in the grid.
   * @param direction Layout direction of the grid.
   */


  init(gutterSize, tracker, cols, direction) {
    this._gutterSize = normalizeUnits(gutterSize);
    this._rows = tracker.rowCount;
    this._rowspan = tracker.rowspan;
    this._cols = cols;
    this._direction = direction;
  }
  /**
   * Computes the amount of space a single 1x1 tile would take up (width or height).
   * Used as a basis for other calculations.
   * @param sizePercent Percent of the total grid-list space that one 1x1 tile would take up.
   * @param gutterFraction Fraction of the gutter size taken up by one 1x1 tile.
   * @return The size of a 1x1 tile as an expression that can be evaluated via CSS calc().
   */


  getBaseTileSize(sizePercent, gutterFraction) {
    // Take the base size percent (as would be if evenly dividing the size between cells),
    // and then subtracting the size of one gutter. However, since there are no gutters on the
    // edges, each tile only uses a fraction (gutterShare = numGutters / numCells) of the gutter
    // size. (Imagine having one gutter per tile, and then breaking up the extra gutter on the
    // edge evenly among the cells).
    return `(${sizePercent}% - (${this._gutterSize} * ${gutterFraction}))`;
  }
  /**
   * Gets The horizontal or vertical position of a tile, e.g., the 'top' or 'left' property value.
   * @param offset Number of tiles that have already been rendered in the row/column.
   * @param baseSize Base size of a 1x1 tile (as computed in getBaseTileSize).
   * @return Position of the tile as a CSS calc() expression.
   */


  getTilePosition(baseSize, offset) {
    // The position comes the size of a 1x1 tile plus gutter for each previous tile in the
    // row/column (offset).
    return offset === 0 ? '0' : calc(`(${baseSize} + ${this._gutterSize}) * ${offset}`);
  }
  /**
   * Gets the actual size of a tile, e.g., width or height, taking rowspan or colspan into account.
   * @param baseSize Base size of a 1x1 tile (as computed in getBaseTileSize).
   * @param span The tile's rowspan or colspan.
   * @return Size of the tile as a CSS calc() expression.
   */


  getTileSize(baseSize, span) {
    return `(${baseSize} * ${span}) + (${span - 1} * ${this._gutterSize})`;
  }
  /**
   * Sets the style properties to be applied to a tile for the given row and column index.
   * @param tile Tile to which to apply the styling.
   * @param rowIndex Index of the tile's row.
   * @param colIndex Index of the tile's column.
   */


  setStyle(tile, rowIndex, colIndex) {
    // Percent of the available horizontal space that one column takes up.
    let percentWidthPerTile = 100 / this._cols; // Fraction of the vertical gutter size that each column takes up.
    // For example, if there are 5 columns, each column uses 4/5 = 0.8 times the gutter width.

    let gutterWidthFractionPerTile = (this._cols - 1) / this._cols;
    this.setColStyles(tile, colIndex, percentWidthPerTile, gutterWidthFractionPerTile);
    this.setRowStyles(tile, rowIndex, percentWidthPerTile, gutterWidthFractionPerTile);
  }
  /** Sets the horizontal placement of the tile in the list. */


  setColStyles(tile, colIndex, percentWidth, gutterWidth) {
    // Base horizontal size of a column.
    let baseTileWidth = this.getBaseTileSize(percentWidth, gutterWidth); // The width and horizontal position of each tile is always calculated the same way, but the
    // height and vertical position depends on the rowMode.

    let side = this._direction === 'rtl' ? 'right' : 'left';

    tile._setStyle(side, this.getTilePosition(baseTileWidth, colIndex));

    tile._setStyle('width', calc(this.getTileSize(baseTileWidth, tile.colspan)));
  }
  /**
   * Calculates the total size taken up by gutters across one axis of a list.
   */


  getGutterSpan() {
    return `${this._gutterSize} * (${this._rowspan} - 1)`;
  }
  /**
   * Calculates the total size taken up by tiles across one axis of a list.
   * @param tileHeight Height of the tile.
   */


  getTileSpan(tileHeight) {
    return `${this._rowspan} * ${this.getTileSize(tileHeight, 1)}`;
  }
  /**
   * Calculates the computed height and returns the correct style property to set.
   * This method can be implemented by each type of TileStyler.
   * @docs-private
   */


  getComputedHeight() {
    return null;
  }

}
/**
 * This type of styler is instantiated when the user passes in a fixed row height.
 * Example `<mat-grid-list cols="3" rowHeight="100px">`
 * @docs-private
 */


class FixedTileStyler extends TileStyler {
  constructor(fixedRowHeight) {
    super();
    this.fixedRowHeight = fixedRowHeight;
  }

  init(gutterSize, tracker, cols, direction) {
    super.init(gutterSize, tracker, cols, direction);
    this.fixedRowHeight = normalizeUnits(this.fixedRowHeight);

    if (!cssCalcAllowedValue.test(this.fixedRowHeight) && (typeof ngDevMode === 'undefined' || ngDevMode)) {
      throw Error(`Invalid value "${this.fixedRowHeight}" set as rowHeight.`);
    }
  }

  setRowStyles(tile, rowIndex) {
    tile._setStyle('top', this.getTilePosition(this.fixedRowHeight, rowIndex));

    tile._setStyle('height', calc(this.getTileSize(this.fixedRowHeight, tile.rowspan)));
  }

  getComputedHeight() {
    return ['height', calc(`${this.getTileSpan(this.fixedRowHeight)} + ${this.getGutterSpan()}`)];
  }

  reset(list) {
    list._setListStyle(['height', null]);

    if (list._tiles) {
      list._tiles.forEach(tile => {
        tile._setStyle('top', null);

        tile._setStyle('height', null);
      });
    }
  }

}
/**
 * This type of styler is instantiated when the user passes in a width:height ratio
 * for the row height.  Example `<mat-grid-list cols="3" rowHeight="3:1">`
 * @docs-private
 */


class RatioTileStyler extends TileStyler {
  constructor(value) {
    super();

    this._parseRatio(value);
  }

  setRowStyles(tile, rowIndex, percentWidth, gutterWidth) {
    let percentHeightPerTile = percentWidth / this.rowHeightRatio;
    this.baseTileHeight = this.getBaseTileSize(percentHeightPerTile, gutterWidth); // Use padding-top and margin-top to maintain the given aspect ratio, as
    // a percentage-based value for these properties is applied versus the *width* of the
    // containing block. See http://www.w3.org/TR/CSS2/box.html#margin-properties

    tile._setStyle('marginTop', this.getTilePosition(this.baseTileHeight, rowIndex));

    tile._setStyle('paddingTop', calc(this.getTileSize(this.baseTileHeight, tile.rowspan)));
  }

  getComputedHeight() {
    return ['paddingBottom', calc(`${this.getTileSpan(this.baseTileHeight)} + ${this.getGutterSpan()}`)];
  }

  reset(list) {
    list._setListStyle(['paddingBottom', null]);

    list._tiles.forEach(tile => {
      tile._setStyle('marginTop', null);

      tile._setStyle('paddingTop', null);
    });
  }

  _parseRatio(value) {
    const ratioParts = value.split(':');

    if (ratioParts.length !== 2 && (typeof ngDevMode === 'undefined' || ngDevMode)) {
      throw Error(`mat-grid-list: invalid ratio given for row-height: "${value}"`);
    }

    this.rowHeightRatio = parseFloat(ratioParts[0]) / parseFloat(ratioParts[1]);
  }

}
/**
 * This type of styler is instantiated when the user selects a "fit" row height mode.
 * In other words, the row height will reflect the total height of the container divided
 * by the number of rows.  Example `<mat-grid-list cols="3" rowHeight="fit">`
 *
 * @docs-private
 */


class FitTileStyler extends TileStyler {
  setRowStyles(tile, rowIndex) {
    // Percent of the available vertical space that one row takes up.
    let percentHeightPerTile = 100 / this._rowspan; // Fraction of the horizontal gutter size that each column takes up.

    let gutterHeightPerTile = (this._rows - 1) / this._rows; // Base vertical size of a column.

    let baseTileHeight = this.getBaseTileSize(percentHeightPerTile, gutterHeightPerTile);

    tile._setStyle('top', this.getTilePosition(baseTileHeight, rowIndex));

    tile._setStyle('height', calc(this.getTileSize(baseTileHeight, tile.rowspan)));
  }

  reset(list) {
    if (list._tiles) {
      list._tiles.forEach(tile => {
        tile._setStyle('top', null);

        tile._setStyle('height', null);
      });
    }
  }

}
/** Wraps a CSS string in a calc function */


function calc(exp) {
  return `calc(${exp})`;
}
/** Appends pixels to a CSS string if no units are given. */


function normalizeUnits(value) {
  return value.match(/([A-Za-z%]+)$/) ? value : `${value}px`;
}
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
// TODO(kara): Conditional (responsive) column count / row size.
// TODO(kara): Re-layout on window resize / media change (debounced).
// TODO(kara): gridTileHeader and gridTileFooter.


const MAT_FIT_MODE = 'fit';

class MatGridList {
  constructor(_element, _dir) {
    this._element = _element;
    this._dir = _dir;
    /** The amount of space between tiles. This will be something like '5px' or '2em'. */

    this._gutter = '1px';
  }
  /** Amount of columns in the grid list. */


  get cols() {
    return this._cols;
  }

  set cols(value) {
    this._cols = Math.max(1, Math.round((0,_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__.coerceNumberProperty)(value)));
  }
  /** Size of the grid list's gutter in pixels. */


  get gutterSize() {
    return this._gutter;
  }

  set gutterSize(value) {
    this._gutter = `${value == null ? '' : value}`;
  }
  /** Set internal representation of row height from the user-provided value. */


  get rowHeight() {
    return this._rowHeight;
  }

  set rowHeight(value) {
    const newValue = `${value == null ? '' : value}`;

    if (newValue !== this._rowHeight) {
      this._rowHeight = newValue;

      this._setTileStyler(this._rowHeight);
    }
  }

  ngOnInit() {
    this._checkCols();

    this._checkRowHeight();
  }
  /**
   * The layout calculation is fairly cheap if nothing changes, so there's little cost
   * to run it frequently.
   */


  ngAfterContentChecked() {
    this._layoutTiles();
  }
  /** Throw a friendly error if cols property is missing */


  _checkCols() {
    if (!this.cols && (typeof ngDevMode === 'undefined' || ngDevMode)) {
      throw Error(`mat-grid-list: must pass in number of columns. ` + `Example: <mat-grid-list cols="3">`);
    }
  }
  /** Default to equal width:height if rowHeight property is missing */


  _checkRowHeight() {
    if (!this._rowHeight) {
      this._setTileStyler('1:1');
    }
  }
  /** Creates correct Tile Styler subtype based on rowHeight passed in by user */


  _setTileStyler(rowHeight) {
    if (this._tileStyler) {
      this._tileStyler.reset(this);
    }

    if (rowHeight === MAT_FIT_MODE) {
      this._tileStyler = new FitTileStyler();
    } else if (rowHeight && rowHeight.indexOf(':') > -1) {
      this._tileStyler = new RatioTileStyler(rowHeight);
    } else {
      this._tileStyler = new FixedTileStyler(rowHeight);
    }
  }
  /** Computes and applies the size and position for all children grid tiles. */


  _layoutTiles() {
    if (!this._tileCoordinator) {
      this._tileCoordinator = new TileCoordinator();
    }

    const tracker = this._tileCoordinator;

    const tiles = this._tiles.filter(tile => !tile._gridList || tile._gridList === this);

    const direction = this._dir ? this._dir.value : 'ltr';

    this._tileCoordinator.update(this.cols, tiles);

    this._tileStyler.init(this.gutterSize, tracker, this.cols, direction);

    tiles.forEach((tile, index) => {
      const pos = tracker.positions[index];

      this._tileStyler.setStyle(tile, pos.row, pos.col);
    });

    this._setListStyle(this._tileStyler.getComputedHeight());
  }
  /** Sets style on the main grid-list element, given the style name and value. */


  _setListStyle(style) {
    if (style) {
      this._element.nativeElement.style[style[0]] = style[1];
    }
  }

}

MatGridList.ɵfac = function MatGridList_Factory(t) {
  return new (t || MatGridList)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_3__.Directionality, 8));
};

MatGridList.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MatGridList,
  selectors: [["mat-grid-list"]],
  contentQueries: function MatGridList_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, MatGridTile, 5);
    }

    if (rf & 2) {
      let _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx._tiles = _t);
    }
  },
  hostAttrs: [1, "mat-grid-list"],
  hostVars: 1,
  hostBindings: function MatGridList_HostBindings(rf, ctx) {
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("cols", ctx.cols);
    }
  },
  inputs: {
    cols: "cols",
    gutterSize: "gutterSize",
    rowHeight: "rowHeight"
  },
  exportAs: ["matGridList"],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([{
    provide: MAT_GRID_LIST,
    useExisting: MatGridList
  }])],
  ngContentSelectors: _c0,
  decls: 2,
  vars: 0,
  template: function MatGridList_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
  },
  styles: [_c3],
  encapsulation: 2,
  changeDetection: 0
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridList, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'mat-grid-list',
      exportAs: 'matGridList',
      host: {
        'class': 'mat-grid-list',
        // Ensures that the "cols" input value is reflected in the DOM. This is
        // needed for the grid-list harness.
        '[attr.cols]': 'cols'
      },
      providers: [{
        provide: MAT_GRID_LIST,
        useExisting: MatGridList
      }],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      template: "<div>\n  <ng-content></ng-content>\n</div>",
      styles: [".mat-grid-list{display:block;position:relative}.mat-grid-tile{display:block;position:absolute;overflow:hidden}.mat-grid-tile .mat-grid-tile-header,.mat-grid-tile .mat-grid-tile-footer{display:flex;align-items:center;height:48px;color:#fff;background:rgba(0,0,0,.38);overflow:hidden;padding:0 16px;position:absolute;left:0;right:0}.mat-grid-tile .mat-grid-tile-header>*,.mat-grid-tile .mat-grid-tile-footer>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-tile-header.mat-2-line,.mat-grid-tile .mat-grid-tile-footer.mat-2-line{height:68px}.mat-grid-tile .mat-grid-list-text{display:flex;flex-direction:column;flex:auto;box-sizing:border-box;overflow:hidden}.mat-grid-tile .mat-grid-list-text>*{margin:0;padding:0;font-weight:normal;font-size:inherit}.mat-grid-tile .mat-grid-list-text:empty{display:none}.mat-grid-tile .mat-grid-tile-header{top:0}.mat-grid-tile .mat-grid-tile-footer{bottom:0}.mat-grid-tile .mat-grid-avatar{padding-right:16px}[dir=rtl] .mat-grid-tile .mat-grid-avatar{padding-right:0;padding-left:16px}.mat-grid-tile .mat-grid-avatar:empty{display:none}.mat-grid-tile-content{top:0;left:0;right:0;bottom:0;position:absolute;display:flex;align-items:center;justify-content:center;height:100%;padding:0;margin:0}\n"]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_3__.Directionality,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }]
    }];
  }, {
    _tiles: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [MatGridTile, {
        descendants: true
      }]
    }],
    cols: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    gutterSize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    rowHeight: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */


class MatGridListModule {}

MatGridListModule.ɵfac = function MatGridListModule_Factory(t) {
  return new (t || MatGridListModule)();
};

MatGridListModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: MatGridListModule,
  declarations: [MatGridList, MatGridTile, MatGridTileText, MatGridTileHeaderCssMatStyler, MatGridTileFooterCssMatStyler, MatGridAvatarCssMatStyler],
  imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule],
  exports: [MatGridList, MatGridTile, MatGridTileText, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule, MatGridTileHeaderCssMatStyler, MatGridTileFooterCssMatStyler, MatGridAvatarCssMatStyler]
});
MatGridListModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [[_angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule], _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MatGridListModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule],
      exports: [MatGridList, MatGridTile, MatGridTileText, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatLineModule, _angular_material_core__WEBPACK_IMPORTED_MODULE_2__.MatCommonModule, MatGridTileHeaderCssMatStyler, MatGridTileFooterCssMatStyler, MatGridAvatarCssMatStyler],
      declarations: [MatGridList, MatGridTile, MatGridTileText, MatGridTileHeaderCssMatStyler, MatGridTileFooterCssMatStyler, MatGridAvatarCssMatStyler]
    }]
  }], null, null);
})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
// Privately exported for the grid-list harness.


const ɵTileCoordinator = TileCoordinator;
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

/**
 * Generated bundle index. Do not edit.
 */



/***/ })

}]);
//# sourceMappingURL=src_app_pages_booking-manager_booking-manager_module_ts.js.map