"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_admin-employee_employee-detail_employee-detail_module_ts"],{

/***/ 23309:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/employee-detail-routing.module.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeDetailPageRoutingModule": () => (/* binding */ EmployeeDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _employee_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-detail.page */ 85438);




const routes = [
    {
        path: '',
        component: _employee_detail_page__WEBPACK_IMPORTED_MODULE_0__.EmployeeDetailPage
    },
    {
        path: 'select-hour',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-node_modules_date-fns_esm_addWeeks_index_js-src_app_shared_components_select-hour_sel-6c40cf")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../../../shared/components/select-hour/select-hour.module */ 17711)).then((m) => m.SelectHourPageModule)
    },
    {
        path: 'holiday-list/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_date-fns_esm_locale_es_index_js"), __webpack_require__.e("src_app_pages_profile_admin-employee_employee-detail_holiday-list_holiday-list_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./holiday-list/holiday-list.module */ 60210)).then(m => m.HolidayListPageModule)
    },
    {
        path: 'select-role',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_admin-employee_employee-detail_select-role_select-role_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./select-role/select-role.module */ 92883)).then(m => m.SelectRolePageModule)
    }
];
let EmployeeDetailPageRoutingModule = class EmployeeDetailPageRoutingModule {
};
EmployeeDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EmployeeDetailPageRoutingModule);



/***/ }),

/***/ 1201:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/employee-detail.module.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeDetailPageModule": () => (/* binding */ EmployeeDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../../shared/header/header.module */ 57185);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _employee_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./employee-detail-routing.module */ 23309);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);
/* harmony import */ var _employee_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./employee-detail.page */ 85438);
/* harmony import */ var src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/translate-days/translate-days.module */ 84013);











let EmployeeDetailPageModule = class EmployeeDetailPageModule {
};
EmployeeDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _employee_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__.EmployeeDetailPageRoutingModule,
            _shared_header_header_module__WEBPACK_IMPORTED_MODULE_1__.HeaderModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_0__.AlertModule,
            ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__.IonIntlTelInputModule,
            src_app_core_pipes_translate_days_translate_days_module__WEBPACK_IMPORTED_MODULE_4__.TranslateDaysModule
        ],
        declarations: [_employee_detail_page__WEBPACK_IMPORTED_MODULE_3__.EmployeeDetailPage]
    })
], EmployeeDetailPageModule);



/***/ }),

/***/ 85438:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/employee-detail.page.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeDetailPage": () => (/* binding */ EmployeeDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _employee_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-detail.page.html?ngResource */ 68143);
/* harmony import */ var _employee_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-detail.page.scss?ngResource */ 92330);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var _core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../../core/services/timeTable/time-table.service */ 79223);
/* harmony import */ var _core_models_timeTable_timeTable_dto_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../../core/models/timeTable/timeTable.dto.model */ 45985);
/* harmony import */ var _core_models_employee_employee_dto_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../../core/models/employee/employee.dto.model */ 25347);
/* harmony import */ var _core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../../../core/services/employee/employee.service */ 86075);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/transformers/timeTable.transformer */ 27312);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/components/service-list/service-list.component */ 43344);
/* harmony import */ var src_app_core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/models/enums/role.enum */ 89121);
/* harmony import */ var src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/services/services.service */ 63105);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ion-intl-tel-input */ 75103);



/* eslint-disable guard-for-in */
















let EmployeeDetailPage = class EmployeeDetailPage {
    constructor(router, formBuilder, actionSheetCtrl, employeeService, timeTableService, modalController, routerOutlet, serviceService, dateService, activatedRoute, navCtrl) {
        this.router = router;
        this.formBuilder = formBuilder;
        this.actionSheetCtrl = actionSheetCtrl;
        this.employeeService = employeeService;
        this.timeTableService = timeTableService;
        this.modalController = modalController;
        this.routerOutlet = routerOutlet;
        this.serviceService = serviceService;
        this.dateService = dateService;
        this.activatedRoute = activatedRoute;
        this.navCtrl = navCtrl;
        this.defaultImage = '/assets/no-image.jpeg';
        this.serviceSelected = [];
        this.timetableText = 'Ver horario';
        this.servicesText = 'Ocultar servicios seleccionados';
        this.serviceCollection = [];
        this.weekDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        this.selectedRole = { name: 'Empleado', value: 'empleado' };
        this.selectedPermission = [];
        this.phone = {
            dialCode: '+34',
            internationalNumber: '',
            isoCode: 'es',
            nationalNumber: ''
        };
        this.formValue = { phoneNumber: this.phone };
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.initForms();
        if (this.router.getCurrentNavigation().extras.state) {
            this.isEdit = true;
            this.employee = this.router.getCurrentNavigation().extras.state.employee;
            this.serviceSelected = this.employee.services ? this.employee.services : [];
            this.getTimeTableByEmployee();
            this.initEmployeeForm();
            this.getRole();
        }
        else {
            this.getTimeTableFromCommerce();
            this.isEdit = false;
        }
        this.timeTableService.updateHourday$.subscribe(response => {
            this.setDefaultHours(response);
        });
        this.timeTableService.updateHourDayNewEmployee$.subscribe(response => {
            this.setNewHourDay(response);
        });
    }
    initForms() {
        this.initEmployeeForm();
        this.initTimeTableForm();
    }
    get phoneNumber() { return this.employeeForm.get('phone'); }
    ngOnInit() {
        this.getTimeTableFromCommerceWithoutSeHours();
        this.getAllService();
    }
    getAllService() {
        this.serviceService
            .findServiceByCommerce(this.commerceLogged)
            .subscribe((res) => {
            this.serviceCollection = res;
        });
    }
    getRole() {
        const rolesFromEnum = Object.values(src_app_core_models_enums_role_enum__WEBPACK_IMPORTED_MODULE_10__.RoleValues);
        rolesFromEnum.forEach(item => {
            if (JSON.parse(item).value === this.employee.role) {
                this.selectedRole = JSON.parse(item);
            }
        });
        this.employeeForm.get('role').setValue(this.selectedRole.value);
    }
    ionViewWillEnter() {
        const storedSelectedRole = JSON.parse(localStorage.getItem('selectedRole'));
        const storedPermissions = JSON.parse(localStorage.getItem('selectedPermission'));
        if (storedSelectedRole) {
            this.selectedRole = storedSelectedRole;
            this.employeeForm.get('role').setValue(this.selectedRole.value);
        }
        if (storedPermissions) {
            this.selectedPermission = storedPermissions;
        }
    }
    ionViewWillLeave() {
        localStorage.removeItem('selectedRole');
        localStorage.removeItem('selectedPermission');
    }
    setChekinAndDepartureHoursFromCommerce() {
        const days = Object.keys(this.openingHours);
        days.forEach(day => {
            if (this.openingHours[day].length > 0) {
                this.timeTableForm.get(`checkinTime${day}`).setValue(this.openingHours[day][0]);
                this.timeTableForm.get(`departureTime${day}`).setValue(this.openingHours[day][this.openingHours[day].length - 1]);
            }
            else {
                this.timeTableForm.get(day).setValue(false);
            }
        });
    }
    initEmployeeForm() {
        var _a;
        this.employeeForm = this.formBuilder.group({
            name: [this.employee ? this.employee.name : '', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            surname: [this.employee ? this.employee.surname : '', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            email: [this.employee ? this.employee.email : '', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            phone: [this.formValue.phoneNumber,
                [_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required,
                    ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_13__.IonIntlTelInputValidators.phone]
            ],
            position: [this.employee ? this.employee.position : '',],
            description: [this.employee ? this.employee.description : '',],
            isActive: [this.employee ? this.employee.isActive : false, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            image: [this.employee ? this.employee.image : this.defaultImage],
            role: [this.employee ? this.employee.role : this.selectedRole.value, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required]
        });
        if (this.employee) {
            const customerPhone = {
                dialCode: '+34',
                internationalNumber: '',
                isoCode: 'es',
                nationalNumber: (_a = this.employee) === null || _a === void 0 ? void 0 : _a.phone
            };
            this.phoneNumber.setValue(customerPhone);
        }
    }
    initTimeTableForm() {
        this.timeTableForm = this.formBuilder.group({
            monday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimemonday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimemonday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            tuesday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimetuesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimetuesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            wednesday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimewednesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimewednesday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            thursday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimethursday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimethursday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            friday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimefriday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimefriday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            saturday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimesaturday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimesaturday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            sunday: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            checkinTimesunday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
            departureTimesunday: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
        });
    }
    setDefaultHours(timetable) {
        this.schedule = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.toRangeTable(timetable);
        for (const day in this.schedule) {
            const checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].start.hour}:${this.schedule[day].start.minute}`);
            const departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].end.hour}:${this.schedule[day].end.minute}`);
            if (this.schedule[day].rest) {
                const checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.start.hour}:${this.schedule[day].rest.start.minute}`);
                const departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.end.hour}:${this.schedule[day].rest.end.minute}`);
                this.timeTableForm.get(`checkinTime${day}`).setValue(`${checkinHour}-${checkinRestHour} | ${departureRestHour}-${departureHour}`);
                this.timeTableForm.get(`departureTime${day}`).setValue('');
            }
            else {
                this.timeTableForm.get(`checkinTime${day}`).setValue(`${checkinHour}-`);
                this.timeTableForm.get(`departureTime${day}`).setValue(departureHour);
            }
            this.timeTableForm.get(day).setValue(!checkinHour.includes('null') ? true : false);
        }
        this.schedule.uuid = timetable.uuid;
    }
    setNewHourDay(value) {
        const newHourDay = JSON.parse(value.timetable);
        this.schedule[value.day] = newHourDay;
        const checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[value.day].start.hour}:${this.schedule[value.day].start.minute}`);
        const departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[value.day].end.hour}:${this.schedule[value.day].end.minute}`);
        if (this.schedule[value.day].rest) {
            const checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[value.day].rest.start.hour}:${this.schedule[value.day].rest.start.minute}`);
            const departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[value.day].rest.end.hour}:${this.schedule[value.day].rest.end.minute}`);
            this.timeTableForm.get(`checkinTime${value.day}`).setValue(`${checkinHour}-${checkinRestHour} | ${departureRestHour}-${departureHour}`);
            this.timeTableForm.get(`departureTime${value.day}`).setValue('');
        }
        else {
            this.timeTableForm.get(`checkinTime${value.day}`).setValue(`${checkinHour}-`);
            this.timeTableForm.get(`departureTime${value.day}`).setValue(departureHour);
        }
        this.timeTableForm.get(value.day).setValue(!checkinHour.includes('null') ? true : false);
    }
    getTimeTableByEmployee() {
        this.timeTableService.findTimetableByEmployee(this.employee.uuid).subscribe((response) => {
            this.setDefaultHours(response.timetable);
        });
    }
    getTimeTableFromCommerce() {
        this.timeTableService.findTimetableByCommerce(this.commerceLogged).subscribe((response) => {
            this.setDefaultHours(response.timetable);
            this.timeTableFromCommerce = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.toRangeTable(response.timetable);
        });
    }
    getTimeTableFromCommerceWithoutSeHours() {
        this.timeTableService.findTimetableByCommerce(this.commerceLogged).subscribe((response) => {
            this.timeTableFromCommerce = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.toRangeTable(response.timetable);
        });
    }
    saveEmployee() {
        const employee = this.transformEmployeeModel();
        if (this.employee) {
            employee.uuid = this.employee.uuid;
            employee.createdAtCustom = this.employee.createdAtCustom;
        }
        if (!this.isEdit) {
            this.employeeService.createEmployee(employee).subscribe((employeeItem) => {
                var _a;
                if (employeeItem) {
                    const timeTable = this.transformTimeTableModel(employeeItem);
                    if ((employeeItem === null || employeeItem === void 0 ? void 0 : employeeItem.uuid) === ((_a = this.employee) === null || _a === void 0 ? void 0 : _a.uuid)) {
                        timeTable.uuid = this.employee.timetable.uuid;
                    }
                    this.timeTableService.createEmployeeTimeTable(timeTable).subscribe(response => {
                        if (response) {
                            this.navCtrl.navigateBack(['tabs/profile/commerce-info/admin-employee'], { replaceUrl: true });
                        }
                    });
                }
            });
        }
        else {
            this.employeeService.updateEmployee(employee).subscribe((employeeItem) => {
                var _a;
                if (employeeItem) {
                    const timeTable = this.transformTimeTableModel(employeeItem);
                    if ((employeeItem === null || employeeItem === void 0 ? void 0 : employeeItem.uuid) === ((_a = this.employee) === null || _a === void 0 ? void 0 : _a.uuid)) {
                        timeTable.uuid = this.employee.timetable.uuid;
                    }
                    this.timeTableService.updateTimeTable(timeTable).subscribe(response => {
                        if (response) {
                            this.navCtrl.navigateBack(['tabs/profile/commerce-info/admin-employee'], { replaceUrl: true });
                        }
                    });
                }
            });
        }
    }
    transformEmployeeModel() {
        const employeeDto = new _core_models_employee_employee_dto_model__WEBPACK_IMPORTED_MODULE_5__.EmployeeDto();
        employeeDto.name = this.employeeForm.get('name').value;
        employeeDto.surname = this.employeeForm.get('surname').value;
        employeeDto.email = this.employeeForm.get('email').value;
        employeeDto.phone = this.employeeForm.get('phone').value.nationalNumber;
        employeeDto.password = this.employee ? this.employee.password : '123456';
        employeeDto.commerce = this.commerceLogged;
        employeeDto.services = this.serviceSelected;
        employeeDto.position = this.employeeForm.get('position').value;
        employeeDto.isActive = this.employeeForm.get('isActive').value;
        employeeDto.description = this.employeeForm.get('description').value;
        employeeDto.image = this.employeeForm.get('image').value;
        employeeDto.role = this.employeeForm.get('role').value;
        employeeDto.permissions = this.selectedPermission;
        employeeDto.createdAt = new Date();
        employeeDto.createdBy = '';
        employeeDto.createdAtCustom = new Date().toString();
        return employeeDto;
    }
    transformTimeTableModel(employee) {
        const timeTableDto = new _core_models_timeTable_timeTable_dto_model__WEBPACK_IMPORTED_MODULE_4__.TimeTableDto();
        delete this.schedule.uuid;
        for (const day in this.schedule) {
            if (this.timeTableForm.get(day).value) {
                if (this.schedule[day].rest) {
                    const checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].start.hour}:${this.schedule[day].start.minute}`);
                    const departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].end.hour}:${this.schedule[day].end.minute}`);
                    const checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.start.hour}:${this.schedule[day].rest.start.minute}`);
                    ;
                    const departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.end.hour}:${this.schedule[day].rest.end.minute}`);
                    ;
                    timeTableDto[day] = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.to(checkinHour, departureHour, checkinRestHour, departureRestHour);
                }
                else {
                    timeTableDto[day] = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.to(this.timeTableForm.get(`checkinTime${day}`).value, this.timeTableForm.get(`departureTime${day}`).value);
                }
            }
            else {
                timeTableDto[day] = src_app_core_transformers_timeTable_transformer__WEBPACK_IMPORTED_MODULE_7__.TimeTableTransformer.createCloseDay();
            }
        }
        timeTableDto.employee = employee;
        timeTableDto.createdAt = new Date();
        timeTableDto.updatedAt = new Date();
        timeTableDto.createdBy = '';
        return timeTableDto;
    }
    goToHourDayDetail(day) {
        const timetableId = this.schedule.uuid;
        const scheduleDay = {
            checkinHour: this.timeTableForm.get(`checkinTime${day}`).value,
            departureHour: this.timeTableForm.get(`departureTime${day}`).value,
            checkinRestHour: '',
            departureRestHour: ''
        };
        if (this.schedule[day].rest) {
            scheduleDay.checkinHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].start.hour}:${this.schedule[day].start.minute}`);
            scheduleDay.departureHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].end.hour}:${this.schedule[day].end.minute}`);
            scheduleDay.checkinRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.start.hour}:${this.schedule[day].rest.start.minute}`);
            ;
            scheduleDay.departureRestHour = this.dateService.addZeroToMinutesAndHours(`${this.schedule[day].rest.end.hour}:${this.schedule[day].rest.end.minute}`);
            ;
        }
        const navigationExtras = {
            relativeTo: this.activatedRoute,
            state: { day, scheduleDay, timetableId, newEmployee: !this.employee ? true : false }
        };
        this.navCtrl.navigateForward(['select-hour'], navigationExtras);
    }
    gotoHoliday() {
        const navigationExtras = {
            relativeTo: this.activatedRoute
        };
        this.navCtrl.navigateForward([`holiday-list/${this.employee.uuid}`], navigationExtras);
    }
    getImage() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const buttons = [
                {
                    text: 'Hacer foto',
                    icon: 'camera',
                    handler: () => {
                    }
                },
                {
                    text: 'Galería',
                    icon: 'image',
                    handler: () => {
                    }
                },
                {
                    text: 'Cancelar',
                    icon: 'close',
                    role: 'destructive',
                    handler: () => {
                    }
                }
            ];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: 'Seleccionar avatar',
                buttons
            });
            yield actionSheet.present();
        });
    }
    onFocus(event) {
        event.target.parentElement.classList.add('fill-input');
    }
    onBlur(event) {
        // Si tiene contenido el input no se la quitamos
        if (!event.target.value) {
            event.target.parentElement.classList.remove('fill-input');
        }
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    alertBox(confirm) {
        if (confirm) {
            this.deleteEmployee();
        }
    }
    presentServiceModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_shared_components_service_list_service_list_component__WEBPACK_IMPORTED_MODULE_9__.ServiceListComponent,
                swipeToClose: true,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: {
                    servicesSelected: this.serviceSelected, showPrice: false,
                    serviceCollectionFiltered: this.serviceCollection, serviceCollection: this.serviceCollection,
                    isConfigScreen: true
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if ((data === null || data === void 0 ? void 0 : data.service.length) > 0) {
                this.serviceSelected = data.service;
            }
        });
    }
    deleteEmployee() {
        this.employeeService.deleteEmployee(this.employee.uuid).subscribe((res) => {
            this.navCtrl.navigateBack(['tabs/profile/commerce-info/admin-employee'], { replaceUrl: true });
        });
    }
    deleteService(service) {
        const serviceIndex = this.serviceSelected.findIndex(item => item.uuid === service.uuid);
        this.serviceSelected.splice(serviceIndex, 1);
    }
    cancel() {
        this.navCtrl.navigateBack(['tabs/profile/commerce-info/admin-employee'], { replaceUrl: true });
    }
    changeAccordion(event, type) {
        if (type === 'timetable') {
            this.timetableText = event.detail.value ? 'Ocultar horario' : 'Horario';
        }
        else if (type === 'services') {
            this.servicesText = event.detail.value ? 'Ocultar servicios seleccionados' : 'Ver servicios seleccionados';
        }
    }
    goToSelectRole() {
        const navigationExtras = { state: { selectedRole: this.selectedRole } };
        if (this.employee) {
            navigationExtras.state.employee = this.employee;
        }
        this.navCtrl.navigateForward(['tabs/profile/commerce-info/admin-employee/employee-detail/select-role'], navigationExtras);
    }
};
EmployeeDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.ActionSheetController },
    { type: _core_services_employee_employee_service__WEBPACK_IMPORTED_MODULE_6__.EmployeeService },
    { type: _core_services_timeTable_time_table_service__WEBPACK_IMPORTED_MODULE_3__.TimeTableService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.IonRouterOutlet },
    { type: src_app_core_services_services_services_service__WEBPACK_IMPORTED_MODULE_11__.ServicesService },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_2__.DateService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_16__.NavController }
];
EmployeeDetailPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_17__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_8__.AlertComponent,] }]
};
EmployeeDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.Component)({
        selector: 'app-employee-detail',
        template: _employee_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeDetailPage);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 92330:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/employee-detail.page.scss?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = ".edit_profile_main_content {\n  padding: 16px;\n}\n.edit_profile_main_content .user_image {\n  height: 100px;\n  width: 100px;\n  border-radius: 50%;\n  margin: auto;\n  margin-top: 5%;\n  border: 1px solid lightgray;\n}\n.edit_profile_main_content .user_image img {\n  border-radius: 50%;\n  height: 98px;\n  width: 100px;\n}\n.edit_profile_main_content .input_box {\n  border: 1px solid lightgray;\n  color: grey;\n  background: white;\n  margin-bottom: 16px;\n  padding: 5px 12px;\n}\n.date-item {\n  margin-left: 0;\n  margin-right: 0;\n}\n.label-no-padding {\n  padding: 0;\n}\n.hour-list {\n  margin-top: 0 !important;\n  box-shadow: none !important;\n  border-bottom: 1px solid gray !important;\n}\n.service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-bottom: 3%;\n  font-size: 14px;\n  color: #666;\n}\n.no-padding {\n  padding: 0;\n}\n.stacked-item {\n  margin-top: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0FBQ0o7QUFBSTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFFTjtBQUVFO0VBQ0UsMkJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQUo7QUFJQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBREY7QUFJQTtFQUNFLFVBQUE7QUFERjtBQUlBO0VBQ0Usd0JBQUE7RUFDQSwyQkFBQTtFQUNBLHdDQUFBO0FBREY7QUFJQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtBQURGO0FBR0U7RUFDRSxtQkFBQTtBQURKO0FBR0k7RUFDRSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBRE47QUFJSTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFGTjtBQUtJO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FBSE47QUFRQTtFQUNFLFVBQUE7QUFMRjtBQVFBO0VBQ0UsYUFBQTtBQUxGIiwiZmlsZSI6ImVtcGxveWVlLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZWRpdF9wcm9maWxlX21haW5fY29udGVudCB7XG4gIHBhZGRpbmc6IDE2cHg7XG5cbiAgLnVzZXJfaW1hZ2Uge1xuICAgIGhlaWdodDogMTAwcHg7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgbWFyZ2luLXRvcDogNSU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgIGltZyB7XG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICBoZWlnaHQ6IDk4cHg7XG4gICAgICB3aWR0aDogMTAwcHg7XG4gICAgfVxuICB9XG5cbiAgLmlucHV0X2JveCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgIGNvbG9yOiBncmV5O1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgcGFkZGluZzogNXB4IDEycHg7XG4gIH1cbn1cblxuLmRhdGUtaXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiAwO1xuICBtYXJnaW4tcmlnaHQ6IDA7XG59XG5cbi5sYWJlbC1uby1wYWRkaW5nIHtcbiAgcGFkZGluZzogMDtcbn1cblxuLmhvdXItbGlzdCB7XG4gIG1hcmdpbi10b3A6IDAgIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgZ3JheSAhaW1wb3J0YW50O1xufVxuXG4uc2VydmljZS1jYXJkIHtcbiAgcGFkZGluZzogMDtcbiAgbWF4LWhlaWdodDogNDMuNXB4O1xuXG4gIC5zZXJ2aWNlLXJvdyB7XG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcblxuICAgIC5zZXJ2aWNlLWltYWdlIHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuXG4gICAgLmljb24tY29udGFpbmVyIHtcbiAgICAgIG1hcmdpbi10b3A6IDE5MCU7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuXG4gICAgLnNlcnZpY2UtbGFiZWwge1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBtYXJnaW4tdG9wOiAzJTtcbiAgICAgIG1hcmdpbi1ib3R0b206IDMlO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgY29sb3I6ICM2NjY7XG4gICAgfVxuICB9XG59XG5cbi5uby1wYWRkaW5nIHtcbiAgcGFkZGluZzogMDtcbn1cblxuLnN0YWNrZWQtaXRlbSB7XG4gIG1hcmdpbi10b3A6IDA7XG59XG4iXX0= */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 68143:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/profile/admin-employee/employee-detail/employee-detail.page.html?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-header\n  [backButton]=\"true\"\n  [titlePage]=\"employee ? 'Editar empleado': 'Crear empleado'\"\n></app-header>\n\n<ion-content>\n  <div class=\"edit_profile_main_content\">\n    <form [formGroup]=\"employeeForm\">\n      <div class=\"user_image bg_image\" (click)=\"getImage()\">\n        <img [src]=\"employee ? employee.image : defaultImage\" />\n      </div>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['name'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Nombre</ion-label>\n        <ion-input\n          formControlName=\"name\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"text\"\n          [value]=\"employee?.name\"\n          autocapitalize=\"true\"\n          class=\"ion-text-right\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['surname'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Apellidos</ion-label>\n        <ion-input\n          formControlName=\"surname\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"text\"\n          [value]=\"employee?.surname\"\n          autocapitalize=\"true\"\n          class=\"ion-text-right\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['email'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Email</ion-label>\n        <ion-input\n          formControlName=\"email\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"email\"\n          [value]=\"employee?.email\"\n          class=\"ion-text-right\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['phone'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Teléfono</ion-label>\n\n        <!--  <ion-input formControlName=\"phone\" (ionFocus)=\"onFocus($event)\" (ionBlur)=\"onBlur($event)\"\n        type=\"tel\" pattern=\"[0-9]{0,10}\" placeholder=\"123456789\"\n          [value]=\"employee?.phone\" class=\"ion-text-right\"></ion-input> -->\n        <ion-intl-tel-input\n          class=\"ion-text-right absolute right-[7px] float-right w-1/2\"\n          [enableAutoCountrySelect]=\"true\"\n          [defaultCountryiso]=\"'es'\"\n          [preferredCountries]=\"['es']\"\n          [modalSearchPlaceholder]=\"'Buscar...'\"\n          [modalCloseText]=\"'Cerrar'\"\n          formControlName=\"phone\"\n          [inputPlaceholder]=\"'600 123 456'\"\n          modalTitle=\"Seleccione país\"\n        ></ion-intl-tel-input>\n      </ion-item>\n\n      <div class=\"px-4\" *ngIf=\"phoneNumber.invalid && phoneNumber.touched\">\n        <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.required\">\n          <p class=\"ion-no-margin\"><sub>El teléfono es requerido</sub></p>\n        </ion-text>\n        <ion-text color=\"danger\" *ngIf=\"phoneNumber.errors.phone\">\n          <p class=\"ion-no-margin\"><sub>El teléfono no es válido.</sub></p>\n        </ion-text>\n      </div>\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['position'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Puesto</ion-label>\n        <ion-input\n          formControlName=\"position\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"text\"\n          [value]=\"employee?.position\"\n          autocapitalize=\"true\"\n          class=\"ion-text-right\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['description'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Descripción</ion-label>\n        <ion-input\n          formControlName=\"description\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          type=\"text\"\n          [value]=\"employee?.description\"\n          autocapitalize=\"true\"\n          class=\"ion-text-right\"\n        ></ion-input>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        [ngClass]=\"employeeForm.controls['isActive'].value ? 'fill-input' : ''\"\n      >\n        <ion-label>Disponible</ion-label>\n        <ion-toggle formControlName=\"isActive\" color=\"dark\"></ion-toggle>\n      </ion-item>\n\n      <ion-item\n        class=\"textbox\"\n        button=\"true\"\n        [ngClass]=\"employeeForm.controls['role'].value ? 'fill-input' : ''\"\n        (click)=\"goToSelectRole()\"\n      >\n        <ion-label>Nivel de permiso</ion-label>\n        <ion-input\n          hidden\n          type=\"text\"\n          formControlName=\"role\"\n          (ionFocus)=\"onFocus($event)\"\n          (ionBlur)=\"onBlur($event)\"\n          [value]=\"employee?.role\"\n          class=\"ion-text-right\"\n        >\n        </ion-input>\n        <ion-label slot=\"end\">{{selectedRole.name}}</ion-label>\n      </ion-item>\n\n      <ion-row style=\"align-items: center\">\n        <ion-col size=\"6\" class=\"no-padding\">\n          <ion-item (click)=\"presentServiceModal()\" class=\"textbox\">\n            <ion-label style=\"margin-right: 0\" class=\"no-padding\"\n              >Añadir servicio</ion-label\n            >\n            <ion-button fill=\"clear\">\n              <ion-icon slot=\"end\" name=\"add\"></ion-icon>\n            </ion-button>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n\n      <ion-accordion-group\n        inset=\"true\"\n        *ngIf=\"serviceSelected.length > 0\"\n        value=\"services\"\n        (ionChange)=\"changeAccordion($event, 'services')\"\n      >\n        <ion-accordion value=\"services\">\n          <ion-item class=\"textbox\" slot=\"header\">\n            <ion-label\n              >{{servicesText}}\n              <span style=\"font-size: 16px\"\n                >({{serviceSelected.length}})</span\n              ></ion-label\n            >\n          </ion-item>\n          <div slot=\"content\" *ngFor=\"let service of serviceSelected\">\n            <ion-card button=\"true\">\n              <ion-grid class=\"service-card\">\n                <ion-row class=\"service-row\">\n                  <ion-col\n                    size=\"0.1\"\n                    [style.background-color]=\"service.color\"\n                  ></ion-col>\n                  <ion-col class=\"no-padding\">\n                    <ion-item>\n                      <ion-label class=\"service-label\"\n                        >{{ service.name }}</ion-label\n                      >\n                      <ion-button fill=\"clear\" (click)=\"deleteService(service)\">\n                        <ion-icon slot=\"end\" name=\"trash-outline\"></ion-icon>\n                      </ion-button>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-card>\n          </div>\n        </ion-accordion>\n      </ion-accordion-group>\n    </form>\n\n    <ion-accordion-group (ionChange)=\"changeAccordion($event, 'timetable')\">\n      <ion-accordion value=\"timetable\">\n        <ion-item class=\"textbox\" slot=\"header\">\n          <ion-label>{{timetableText}}</ion-label>\n        </ion-item>\n\n        <form [formGroup]=\"timeTableForm\" slot=\"content\">\n          <ion-grid fixed>\n            <ion-list *ngIf=\"timeTableFromCommerce\">\n              <ion-row *ngFor=\"let day of weekDays\">\n                <ion-item\n                  class=\"textbox hour-list\"\n                  style=\"width: 100%\"\n                  [disabled]=\"timeTableFromCommerce[day]?.start?.hour === null \"\n                  (click)=\"goToHourDayDetail(day)\"\n                >\n                  <ion-col class=\"no-padding\" size=\"3\">\n                    <ion-label class=\"no-padding\"\n                      >{{day | translateDays | titlecase}}</ion-label\n                    >\n                  </ion-col>\n                  <ion-col size=\"8\">\n                    <ion-label *ngIf=\"timeTableForm.controls[day].value\">\n                      {{timeTableForm.controls['checkinTime'+day].value\n                      }}{{timeTableForm.controls['departureTime'+day].value }}\n                    </ion-label>\n                    <ion-label *ngIf=\"!timeTableForm.controls[day].value\">\n                      Cerrado\n                    </ion-label>\n                  </ion-col>\n                  <ion-col size=\"1\">\n                    <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n                  </ion-col>\n                </ion-item>\n              </ion-row>\n            </ion-list>\n          </ion-grid>\n        </form>\n      </ion-accordion>\n    </ion-accordion-group>\n    <ion-item\n      class=\"textbox\"\n      (click)=\"gotoHoliday()\"\n      slot=\"header\"\n      button=\"true\"\n    >\n      <ion-label>Vacaciones</ion-label>\n    </ion-item>\n  </div>\n</ion-content>\n\n<app-alert\n  #deleteAlert\n  [title]=\"'¿Desea borrar este empleado?'\"\n  (actionEmitter)=\"alertBox($event)\"\n></app-alert>\n<ion-footer class=\"ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col *ngIf=\"employee && !employee.isOwner\" (click)=\"openAlert()\">\n        <ion-button class=\"btn\" expand=\"block\">\n          <ion-icon icon=\"trash\"></ion-icon>\n        </ion-button>\n      </ion-col>\n\n      <ion-col>\n        <ion-button\n          class=\"btn\"\n          [disabled]=\"!employeeForm.valid || serviceSelected.length === 0\"\n          (click)=\"saveEmployee()\"\n          expand=\"block\"\n        >\n          Guardar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_admin-employee_employee-detail_employee-detail_module_ts.js.map