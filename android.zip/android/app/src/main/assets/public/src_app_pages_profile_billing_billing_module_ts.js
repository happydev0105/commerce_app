"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_billing_billing_module_ts"],{

/***/ 5868:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/addDays/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addDays)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addDays
 * @category Day Helpers
 * @summary Add the specified number of days to the given date.
 *
 * @description
 * Add the specified number of days to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of days to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} - the new date with the days added
 * @throws {TypeError} - 2 arguments required
 *
 * @example
 * // Add 10 days to 1 September 2014:
 * const result = addDays(new Date(2014, 8, 1), 10)
 * //=> Thu Sep 11 2014 00:00:00
 */

function addDays(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyAmount);

  if (isNaN(amount)) {
    return new Date(NaN);
  }

  if (!amount) {
    // If 0 days, no-op to avoid changing times in the hour before end of DST
    return date;
  }

  date.setDate(date.getDate() + amount);
  return date;
}

/***/ }),

/***/ 37584:
/*!*****************************************************!*\
  !*** ./node_modules/date-fns/esm/addWeeks/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addWeeks)
/* harmony export */ });
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _addDays_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../addDays/index.js */ 5868);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);



/**
 * @name addWeeks
 * @category Week Helpers
 * @summary Add the specified number of weeks to the given date.
 *
 * @description
 * Add the specified number of week to the given date.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the date to be changed
 * @param {Number} amount - the amount of weeks to be added. Positive decimals will be rounded using `Math.floor`, decimals less than zero will be rounded using `Math.ceil`.
 * @returns {Date} the new date with the weeks added
 * @throws {TypeError} 2 arguments required
 *
 * @example
 * // Add 4 weeks to 1 September 2014:
 * const result = addWeeks(new Date(2014, 8, 1), 4)
 * //=> Mon Sep 29 2014 00:00:00
 */

function addWeeks(dirtyDate, dirtyAmount) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(2, arguments);
  var amount = (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyAmount);
  var days = amount * 7;
  return (0,_addDays_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, days);
}

/***/ }),

/***/ 19040:
/*!***************************************************************!*\
  !*** ./node_modules/date-fns/esm/eachWeekOfInterval/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eachWeekOfInterval)
/* harmony export */ });
/* harmony import */ var _addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../addWeeks/index.js */ 37584);
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




/**
 * @name eachWeekOfInterval
 * @category Interval Helpers
 * @summary Return the array of weeks within the specified time interval.
 *
 * @description
 * Return the array of weeks within the specified time interval.
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Interval} interval - the interval. See [Interval]{@link https://date-fns.org/docs/Interval}
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @returns {Date[]} the array with starts of weeks from the week of the interval start to the week of the interval end
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be 0, 1, ..., 6
 * @throws {RangeError} The start of an interval cannot be after its end
 * @throws {RangeError} Date in interval cannot be `Invalid Date`
 *
 * @example
 * // Each week within interval 6 October 2014 - 23 November 2014:
 * var result = eachWeekOfInterval({
 *   start: new Date(2014, 9, 6),
 *   end: new Date(2014, 10, 23)
 * })
 * //=> [
 * //   Sun Oct 05 2014 00:00:00,
 * //   Sun Oct 12 2014 00:00:00,
 * //   Sun Oct 19 2014 00:00:00,
 * //   Sun Oct 26 2014 00:00:00,
 * //   Sun Nov 02 2014 00:00:00,
 * //   Sun Nov 09 2014 00:00:00,
 * //   Sun Nov 16 2014 00:00:00,
 * //   Sun Nov 23 2014 00:00:00
 * // ]
 */

function eachWeekOfInterval(dirtyInterval, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var interval = dirtyInterval || {};
  var startDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.start);
  var endDate = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(interval.end);
  var endTime = endDate.getTime(); // Throw an exception if start date is after end date or if any date is `Invalid Date`

  if (!(startDate.getTime() <= endTime)) {
    throw new RangeError('Invalid interval');
  }

  var startDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(startDate, options);
  var endDateWeek = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(endDate, options); // Some timezones switch DST at midnight, making start of day unreliable in these timezones, 3pm is a safe bet

  startDateWeek.setHours(15);
  endDateWeek.setHours(15);
  endTime = endDateWeek.getTime();
  var weeks = [];
  var currentWeek = startDateWeek;

  while (currentWeek.getTime() <= endTime) {
    currentWeek.setHours(0);
    weeks.push((0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(currentWeek));
    currentWeek = (0,_addWeeks_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(currentWeek, 1);
    currentWeek.setHours(15);
  }

  return weeks;
}

/***/ }),

/***/ 49145:
/*!********************************************************!*\
  !*** ./node_modules/date-fns/esm/getWeekYear/index.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getWeekYear)
/* harmony export */ });
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);





/**
 * @name getWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Get the local week-numbering year of the given date.
 *
 * @description
 * Get the local week-numbering year of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Number} the local week-numbering year
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // Which week numbering year is 26 December 2004 with the default settings?
 * const result = getWeekYear(new Date(2004, 11, 26))
 * //=> 2005
 *
 * @example
 * // Which week numbering year is 26 December 2004 if week starts on Saturday?
 * const result = getWeekYear(new Date(2004, 11, 26), { weekStartsOn: 6 })
 * //=> 2004
 *
 * @example
 * // Which week numbering year is 26 December 2004 if the first week contains 4 January?
 * const result = getWeekYear(new Date(2004, 11, 26), { firstWeekContainsDate: 4 })
 * //=> 2004
 */
function getWeekYear(dirtyDate, options) {
  var _options$locale, _options$locale$optio;

  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var year = date.getFullYear();
  var localeFirstWeekContainsDate = options === null || options === void 0 ? void 0 : (_options$locale = options.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate;
  var defaultFirstWeekContainsDate = localeFirstWeekContainsDate == null ? 1 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(localeFirstWeekContainsDate);
  var firstWeekContainsDate = (options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) == null ? defaultFirstWeekContainsDate : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(options.firstWeekContainsDate); // Test if weekStartsOn is between 1 and 7 _and_ is not NaN

  if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
    throw new RangeError('firstWeekContainsDate must be between 1 and 7 inclusively');
  }

  var firstWeekOfNextYear = new Date(0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  var startOfNextYear = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeekOfNextYear, options);
  var firstWeekOfThisYear = new Date(0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  var startOfThisYear = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeekOfThisYear, options);

  if (date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}

/***/ }),

/***/ 33719:
/*!****************************************************!*\
  !*** ./node_modules/date-fns/esm/getWeek/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getWeek)
/* harmony export */ });
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _startOfWeekYear_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeekYear/index.js */ 77131);
/* harmony import */ var _toDate_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toDate/index.js */ 93537);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);




var MILLISECONDS_IN_WEEK = 604800000;
/**
 * @name getWeek
 * @category Week Helpers
 * @summary Get the local week index of the given date.
 *
 * @description
 * Get the local week index of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the given date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Number} the week
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // Which week of the local week numbering year is 2 January 2005 with default options?
 * const result = getWeek(new Date(2005, 0, 2))
 * //=> 2
 *
 * // Which week of the local week numbering year is 2 January 2005,
 * // if Monday is the first day of the week,
 * // and the first week of the year always contains 4 January?
 * const result = getWeek(new Date(2005, 0, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> 53
 */

function getWeek(dirtyDate, options) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var date = (0,_toDate_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(dirtyDate);
  var diff = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(date, options).getTime() - (0,_startOfWeekYear_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(date, options).getTime(); // Round the number of days to the nearest integer
  // because the number of milliseconds in a week is not constant
  // (e.g. it's different in the week of the daylight saving time clock shift)

  return Math.round(diff / MILLISECONDS_IN_WEEK) + 1;
}

/***/ }),

/***/ 77131:
/*!************************************************************!*\
  !*** ./node_modules/date-fns/esm/startOfWeekYear/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ startOfWeekYear)
/* harmony export */ });
/* harmony import */ var _getWeekYear_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../getWeekYear/index.js */ 49145);
/* harmony import */ var _startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../startOfWeek/index.js */ 66542);
/* harmony import */ var _lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_lib/toInteger/index.js */ 39354);
/* harmony import */ var _lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_lib/requiredArgs/index.js */ 69014);





/**
 * @name startOfWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Return the start of a local week-numbering year for the given date.
 *
 * @description
 * Return the start of a local week-numbering year.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#Week_numbering
 *
 * ### v2.0.0 breaking changes:
 *
 * - [Changes that are common for the whole library](https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#Common-Changes).
 *
 * @param {Date|Number} date - the original date
 * @param {Object} [options] - an object with options.
 * @param {Locale} [options.locale=defaultLocale] - the locale object. See [Locale]{@link https://date-fns.org/docs/Locale}
 * @param {0|1|2|3|4|5|6} [options.weekStartsOn=0] - the index of the first day of the week (0 - Sunday)
 * @param {1|2|3|4|5|6|7} [options.firstWeekContainsDate=1] - the day of January, which is always in the first week of the year
 * @returns {Date} the start of a week-numbering year
 * @throws {TypeError} 1 argument required
 * @throws {RangeError} `options.weekStartsOn` must be between 0 and 6
 * @throws {RangeError} `options.firstWeekContainsDate` must be between 1 and 7
 *
 * @example
 * // The start of an a week-numbering year for 2 July 2005 with default settings:
 * const result = startOfWeekYear(new Date(2005, 6, 2))
 * //=> Sun Dec 26 2004 00:00:00
 *
 * @example
 * // The start of a week-numbering year for 2 July 2005
 * // if Monday is the first day of week
 * // and 4 January is always in the first week of the year:
 * const result = startOfWeekYear(new Date(2005, 6, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> Mon Jan 03 2005 00:00:00
 */
function startOfWeekYear(dirtyDate, dirtyOptions) {
  (0,_lib_requiredArgs_index_js__WEBPACK_IMPORTED_MODULE_0__["default"])(1, arguments);
  var options = dirtyOptions || {};
  var locale = options.locale;
  var localeFirstWeekContainsDate = locale && locale.options && locale.options.firstWeekContainsDate;
  var defaultFirstWeekContainsDate = localeFirstWeekContainsDate == null ? 1 : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(localeFirstWeekContainsDate);
  var firstWeekContainsDate = options.firstWeekContainsDate == null ? defaultFirstWeekContainsDate : (0,_lib_toInteger_index_js__WEBPACK_IMPORTED_MODULE_1__["default"])(options.firstWeekContainsDate);
  var year = (0,_getWeekYear_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(dirtyDate, dirtyOptions);
  var firstWeek = new Date(0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  var date = (0,_startOfWeek_index_js__WEBPACK_IMPORTED_MODULE_3__["default"])(firstWeek, dirtyOptions);
  return date;
}

/***/ }),

/***/ 7589:
/*!**************************************************************!*\
  !*** ./src/app/core/pipes/format-date/format-date.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatDateModule": () => (/* binding */ FormatDateModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _format_date_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./format-date.pipe */ 82479);





let FormatDateModule = class FormatDateModule {
};
FormatDateModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_format_date_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatDatePipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_format_date_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatDatePipe]
    })
], FormatDateModule);



/***/ }),

/***/ 82479:
/*!************************************************************!*\
  !*** ./src/app/core/pipes/format-date/format-date.pipe.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatDatePipe": () => (/* binding */ FormatDatePipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let FormatDatePipe = class FormatDatePipe {
    transform(value) {
        let returnValue = '';
        const actualDate = new Date(value), day = actualDate.getDate(), month = actualDate.getMonth(), monthFormatted = month.toString().length === 1 ? `0${month}` : month, year = actualDate.getFullYear(), monthString = actualDate.toLocaleString('default', { month: 'long' }), actualDateFormatted = `${year}-${monthFormatted}-${day}`;
        returnValue = `${value.split('-')[2]} ${monthString} ${year}`;
        if (value === actualDateFormatted) {
            returnValue = 'Hoy';
        }
        return returnValue;
    }
};
FormatDatePipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formatDate'
    })
], FormatDatePipe);



/***/ }),

/***/ 94623:
/*!**************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourModule": () => (/* binding */ FormatHourModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./format-hour.pipe */ 70653);





let FormatHourModule = class FormatHourModule {
};
FormatHourModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule
        ],
        exports: [_format_hour_pipe__WEBPACK_IMPORTED_MODULE_0__.FormatHourPipe]
    })
], FormatHourModule);



/***/ }),

/***/ 70653:
/*!************************************************************!*\
  !*** ./src/app/core/pipes/format-hour/format-hour.pipe.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormatHourPipe": () => (/* binding */ FormatHourPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 51109);


let FormatHourPipe = class FormatHourPipe {
    transform(hour) {
        if (hour === null || hour === undefined || hour === '') {
            return '';
        }
        ;
        let value = '';
        if (hour === 0 || hour === '0') {
            value = '00';
            return value;
        }
        if (hour && hour.toString().length === 1) {
            value = `0${hour.toString()}`;
            return value;
        }
        return '' + hour;
    }
};
FormatHourPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'formatHour'
    })
], FormatHourPipe);



/***/ }),

/***/ 47900:
/*!**********************************************************!*\
  !*** ./src/app/core/services/billing/billing.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BillingService": () => (/* binding */ BillingService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);




let BillingService = class BillingService {
    constructor(http) {
        this.http = http;
        this.API_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    getCommerceBillingFromPaymentByWeek(commerce, week) {
        return this.http.get(`${this.API_URL}/billing/calculateFromPaymentByWeek?commerce=${commerce}&week=${week}`);
    }
    getCommerceBillingFromPaymentByDay(commerce, day) {
        return this.http.get(`${this.API_URL}/billing/calculateFromPaymentByDay?commerce=${commerce}&day=${day}`);
    }
    getCommerceBillingByWeek(commerce, weekNumber) {
        return this.http.get(`${this.API_URL}/billing/calculateByWeek?commerce=${commerce}&week=${weekNumber}`);
    }
    getCommerceForecastBillingByWeek(commerce, weekNumber) {
        return this.http.get(`${this.API_URL}/billing/calculateForecastByWeek?commerce=${commerce}&week=${weekNumber}`);
    }
    getCommerceBillingByDay(commerce, day) {
        return this.http.get(`${this.API_URL}/billing/calculateByDay?commerce=${commerce}&day=${day}`);
    }
    getCommerceForecastBillingByDay(commerce, day) {
        return this.http.get(`${this.API_URL}/billing/calculateForecastByDay?commerce=${commerce}&day=${day}`);
    }
};
BillingService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
BillingService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], BillingService);



/***/ }),

/***/ 73372:
/*!******************************************************!*\
  !*** ./src/app/core/services/utils/utils.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UtilsService": () => (/* binding */ UtilsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! date-fns */ 19040);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! date-fns */ 39079);
/* harmony import */ var date_fns_locale__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns/locale */ 36956);




let UtilsService = class UtilsService {
    constructor() { }
    calculateToday() {
        const actualDate = new Date();
        const day = actualDate.getDate();
        const month = actualDate.getMonth() + 1;
        const monthFormatted = month.toString().length === 1 ? `0${month}` : month;
        const dayFormatted = day.toString().length === 1 ? `0${day}` : day;
        const year = actualDate.getFullYear();
        const actualDateFormatted = `${year}-${monthFormatted}-${dayFormatted}`;
        return actualDateFormatted;
    }
    capitalizeFirstLetter(text) {
        if (text.length >= 1) {
            const capitalize = text.charAt(0).toUpperCase();
            text = text.replace(text.charAt(0), capitalize);
        }
        return text;
    }
    generateRandomPassword() {
        const chars = '0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const passwordLength = 12;
        let password = '';
        for (let i = 0; i <= passwordLength; i++) {
            const randomNumber = Math.floor(Math.random() * chars.length);
            password += chars.substring(randomNumber, randomNumber + 1);
        }
        return password;
    }
    getAllDaysInMonth(year, month) {
        const date = new Date(year, month, 1);
        const dates = [];
        while (date.getMonth() === month) {
            const evaluateDay = new Date(date).getDate();
            dates.push({
                text: evaluateDay.toString(),
                value: evaluateDay,
            });
            if ((month === 3 || month === 5 || month === 8 || month === 10) && (evaluateDay === 30)) {
                dates.push({
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            if (month === 1 && evaluateDay === 28) {
                dates.push({
                    text: '29',
                    value: 29,
                    disabled: true
                }, {
                    text: '30',
                    value: 30,
                    disabled: true
                }, {
                    text: '31',
                    value: 31,
                    disabled: true
                });
            }
            date.setDate(date.getDate() + 1);
        }
        return dates;
    }
    getAllWeeks() {
        const weekFormatted = [];
        const result = (0,date_fns__WEBPACK_IMPORTED_MODULE_0__["default"])({
            start: new Date(2022, 0, 2),
            end: new Date(2023, 0, 1)
        }, { weekStartsOn: 1 });
        result.forEach((week, index) => {
            if (result[index + 1]) {
                const weekItem = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] }) + ' ' + (0,date_fns__WEBPACK_IMPORTED_MODULE_1__["default"])(result[index + 1], 'd-MMM', { locale: date_fns_locale__WEBPACK_IMPORTED_MODULE_2__["default"] });
                weekFormatted.push([weekItem, index + 1]);
            }
        });
        return weekFormatted;
    }
    getAllMonthsInYear() {
        const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        const monthCollection = [];
        months.forEach((month, index) => monthCollection.push({
            text: month,
            value: index + 1
        }));
        return monthCollection;
    }
    getYearsFromYeasyInit() {
        const yeasyYearInit = 2021;
        const currentDate = new Date();
        const actualYear = currentDate.getFullYear();
        const differenceYears = yeasyYearInit - actualYear;
        const yearCollection = [];
        if (differenceYears === 0) {
            return [{ text: '2022', value: 2022 }];
        }
        for (let i = differenceYears; i <= differenceYears; i++) {
            yearCollection.push({
                text: (yeasyYearInit - i).toString(),
                value: yeasyYearInit - i
            });
        }
        return yearCollection;
    }
    generateHours(start, end) {
        const hours = [];
        if (typeof start === 'string') {
            start = Number.parseInt(start, 10);
        }
        if (typeof end === 'string') {
            end = Number.parseInt(end, 10);
        }
        for (let i = start; i <= end; i++) {
            const hour = i.toString();
            hours.push(hour);
        }
        return hours;
    }
    generateMinutes() {
        const availableMinutes = 60;
        const minutes = [];
        for (let i = 0; i < availableMinutes; i += 5) {
            const minute = i.toString();
            minutes.push(minute);
        }
        return minutes;
    }
    transformHourStringIntoMinutes(hour) {
        let duration = 0;
        const hours = Number.parseInt(hour.split(':')[0], 10);
        const minutes = Number.parseInt(hour.split(':')[1], 10);
        duration += (hours * 60) + minutes;
        return duration;
    }
};
UtilsService.ctorParameters = () => [];
UtilsService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], UtilsService);



/***/ }),

/***/ 8420:
/*!*****************************************************************!*\
  !*** ./src/app/pages/profile/billing/billing-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BillingPageRoutingModule": () => (/* binding */ BillingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _billing_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./billing.page */ 24282);




const routes = [
    {
        path: '',
        component: _billing_page__WEBPACK_IMPORTED_MODULE_0__.BillingPage
    },
    {
        path: 'booking/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_booking-manager_booking-item_booking-item_module_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_core_utils_date_service_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../booking-manager/booking-item/booking-item.module */ 61046)).then((m) => m.BookingItemPageModule),
    },
    {
        path: 'payment-detail/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_payments_payment-detail_payment-detail_module_ts"), __webpack_require__.e("src_app_core_services_payments_payments_service_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../payments/payment-detail/payment-detail.module */ 95580)).then((m) => m.PaymentDetailPageModule),
    },
];
let BillingPageRoutingModule = class BillingPageRoutingModule {
};
BillingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BillingPageRoutingModule);



/***/ }),

/***/ 46554:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/billing/billing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BillingPageModule": () => (/* binding */ BillingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../shared/components/no-data/no-data.module */ 98360);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _billing_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./billing-routing.module */ 8420);
/* harmony import */ var _billing_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./billing.page */ 24282);
/* harmony import */ var src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/header/header.module */ 57185);
/* harmony import */ var src_app_core_pipes_format_date_format_date_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/format-date/format-date.module */ 7589);
/* harmony import */ var src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/pipes/format-hour/format-hour.module */ 94623);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);












let BillingPageModule = class BillingPageModule {
};
BillingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule,
            _billing_routing_module__WEBPACK_IMPORTED_MODULE_1__.BillingPageRoutingModule,
            src_app_shared_header_header_module__WEBPACK_IMPORTED_MODULE_3__.HeaderModule,
            _shared_components_no_data_no_data_module__WEBPACK_IMPORTED_MODULE_0__.NoDataModule,
            src_app_core_pipes_format_date_format_date_module__WEBPACK_IMPORTED_MODULE_4__.FormatDateModule,
            src_app_core_pipes_format_hour_format_hour_module__WEBPACK_IMPORTED_MODULE_5__.FormatHourModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_6__.FormatPriceModule
        ],
        declarations: [_billing_page__WEBPACK_IMPORTED_MODULE_2__.BillingPage]
    })
], BillingPageModule);



/***/ }),

/***/ 24282:
/*!*******************************************************!*\
  !*** ./src/app/pages/profile/billing/billing.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BillingPage": () => (/* binding */ BillingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _billing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./billing.page.html?ngResource */ 70238);
/* harmony import */ var _billing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./billing.page.scss?ngResource */ 40360);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../core/services/utils/utils.service */ 73372);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _core_services_billing_billing_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../core/services/billing/billing.service */ 47900);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! date-fns */ 33719);









let BillingPage = class BillingPage {
    constructor(billingService, navCtrl, utilsService, activatedRoute) {
        this.billingService = billingService;
        this.navCtrl = navCtrl;
        this.utilsService = utilsService;
        this.activatedRoute = activatedRoute;
        this.weekNumber = 0;
        this.billingCollection = [];
        this.totalAmounts = [];
        this.today = '';
        this.showDatepicker = false;
        this.selectedDate = '';
        this.searchByDay = false;
        this.commerceLogged = JSON.parse(localStorage.getItem('currentUser')).commerce;
        this.weekNumber = (0,date_fns__WEBPACK_IMPORTED_MODULE_4__["default"])(new Date(), { weekStartsOn: 1, firstWeekContainsDate: 4 });
        this.today = this.utilsService.calculateToday();
    }
    ionViewWillEnter() {
        this.totalAmounts = [];
        this.getCommerceBillingByWeek();
        this.searchByDay = false;
    }
    ngOnInit() {
    }
    getCommerceBillingByWeek() {
        this.billingService.getCommerceBillingFromPaymentByWeek(this.commerceLogged, this.weekNumber)
            .subscribe(response => {
            this.billingCollection = Object.entries(response);
            this.billingCollection.map(item => {
                this.totalAmounts.push(item[1][item[1].length - 1].totalAmount.toFixed(2));
                item[1] = item[1].filter(i => i.uuid);
            });
        });
    }
    isToday(item) {
        return item === this.today;
    }
    dismissModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.dismiss();
        }
    }
    onDismiss(event, searchDay) {
        if (searchDay) {
            this.billingService.getCommerceBillingFromPaymentByDay(this.commerceLogged, this.selectedDate)
                .subscribe(response => {
                if (response) {
                    this.totalAmounts = [];
                    const newDate = [];
                    newDate.push(this.selectedDate);
                    newDate.push(response[0]);
                    this.billingCollection = [];
                    this.billingCollection.push(newDate);
                    this.totalAmounts.push(response[1].toFixed(2));
                    this.searchByDay = true;
                }
            });
        }
        this.dismissModal('open-modal-calendar');
    }
    dateChanged(dateSelected) {
        const date = new Date(dateSelected);
        const day = date.getDate();
        const dayFormatted = day.toString().length === 1 ? `0${day}` : day;
        const month = date.getMonth() + 1;
        const monthFormatted = month.toString().length === 1 ? `0${month}` : month;
        const year = date.getFullYear();
        const dateFormatted = `${year}-${monthFormatted}-${dayFormatted}`;
        this.selectedDate = dateFormatted;
    }
    goToDetail(payment) {
        if (payment.booking) {
            this.navCtrl.navigateForward([`booking/${payment.booking.uuid}`], { relativeTo: this.activatedRoute, state: { fromBilling: true } });
        }
        else {
            this.navCtrl.navigateForward([`payment-detail/${payment.uuid}`], { relativeTo: this.activatedRoute });
        }
    }
};
BillingPage.ctorParameters = () => [
    { type: _core_services_billing_billing_service__WEBPACK_IMPORTED_MODULE_3__.BillingService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _core_services_utils_utils_service__WEBPACK_IMPORTED_MODULE_2__.UtilsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute }
];
BillingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-billing',
        template: _billing_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_billing_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BillingPage);



/***/ }),

/***/ 40360:
/*!********************************************************************!*\
  !*** ./src/app/pages/profile/billing/billing.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "h3 {\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpbGxpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBQTtBQUNGIiwiZmlsZSI6ImJpbGxpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDMge1xuICBtYXJnaW46IDA7XG59XG4iXX0= */";

/***/ }),

/***/ 70238:
/*!********************************************************************!*\
  !*** ./src/app/pages/profile/billing/billing.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [backButton]=\"true\" [titlePage]=\"'Transacciones'\"></app-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col [size]=\"billingCollection.length === 0 ? 12 : 6\">\n        <ion-button id=\"open-billing-day\"  expand=\"block\" shape=\"outline\">\n          Consultar día\n        </ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-button *ngIf=\"searchByDay\" expand=\"block\" shape=\"outline\" (click)=\"ngOnInit()\">\n          Ver semana actual\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-list>\n    <ion-item-group *ngFor=\"let item of billingCollection; let i = index\" inset=\"true\" lines=\"none\">\n      <ion-item-divider>\n        <ion-label slot=\"start\">{{item[0] | formatDate}}</ion-label>\n        <ion-label slot=\"end\">\n          <h3>Total facturado: <b>{{totalAmounts[i] ? totalAmounts[i] : 0}}€</b></h3>\n        </ion-label>\n      </ion-item-divider>\n      <ion-item class=\"textbox\" *ngFor=\"let payment of item[1]\" button=\"true\" (click)=\"goToDetail(payment)\">\n        <ion-icon slot=\"start\" name=\"cash-outline\"></ion-icon>\n        <ion-label>\n          <h3 *ngIf=\"!payment?.booking\">{{payment?.createdAt | date: 'HH:mm'}}</h3>\n          <h3 *ngIf=\"payment?.booking\">{{payment?.booking.startsHour | formatHour}}:{{payment?.booking.startsMinute | formatHour}} | {{payment?.booking.startsDay | date:'dd-MM-YYYY'}}</h3>\n          <ion-note>{{payment?.customer.name}}\n            <ng-container *ngIf=\"payment?.service.length > 0\">\n              <span *ngFor=\"let service of payment?.service\">• {{service.name}}</span>\n            </ng-container>\n            <ng-container *ngIf=\"payment?.product.length > 0\">\n              <span *ngFor=\"let product of payment?.product\">• {{product.name}}</span>\n            </ng-container>\n          </ion-note>\n        </ion-label>\n        <ion-note slot=\"end\" color=\"dark\">{{payment.amount}}<span *ngIf=\"payment.decimals !== 0\">.{{payment.decimals}}<span *ngIf=\"payment.decimals !== 0 && payment.decimals.toString().length === 1 \">0</span> </span>€</ion-note>\n      </ion-item>\n    </ion-item-group>\n  </ion-list>\n\n  <ion-modal id=\"open-modal-calendar\" initialBreakpoint=\"0.50\" trigger=\"open-billing-day\" [backdropDismiss]=\"false\">\n    <ng-template>\n      <ion-content>\n        <ion-toolbar>\n          <ion-title>Selecciona un día</ion-title>\n          <ion-buttons slot=\"start\">\n            <ion-button (click)=\"onDismiss($event, false)\">\n              Cancelar\n            </ion-button>\n          </ion-buttons>\n          <ion-buttons slot=\"end\">\n            <ion-button color=\"dark\" (click)=\"onDismiss($event, true)\">\n              Aceptar\n            </ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n        <ion-datetime #datetime first-day-of-week=\"1\" [max]=\"today\" locale=\"es-ES\" presentation=\"date\" size=\"cover\" (ionChange)=\"dateChanged(datetime.value)\">\n        </ion-datetime>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <app-no-data *ngIf=\"billingCollection.length === 0\" [title]=\"'Esta semana aún no se ha realizado ninguna transacción'\" [content]=\"false\"></app-no-data>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_billing_billing_module_ts.js.map