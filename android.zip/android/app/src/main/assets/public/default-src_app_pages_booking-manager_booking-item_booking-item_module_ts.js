"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_booking-manager_booking-item_booking-item_module_ts"],{

/***/ 3145:
/*!********************************************************!*\
  !*** ./src/app/core/models/payments/payments.model.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDto": () => (/* binding */ PaymentDto)
/* harmony export */ });
class PaymentDto {
}


/***/ }),

/***/ 29474:
/*!************************************************************!*\
  !*** ./src/app/core/services/payments/payments.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentsService": () => (/* binding */ PaymentsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 78336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let PaymentsService = class PaymentsService {
    constructor(http) {
        this.http = http;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.api;
    }
    savePaymentByCommerce(paymentDto) {
        return this.http.post(`${this.apiUrl}/payments/`, paymentDto);
    }
    deletePayment(paymentId) {
        return this.http.delete(`${this.apiUrl}/payments/${paymentId}`);
    }
    getPaymentById(paymentId) {
        return this.http.get(`${this.apiUrl}/payments/${paymentId}`);
    }
};
PaymentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PaymentsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root',
    })
], PaymentsService);



/***/ }),

/***/ 4423:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-item/booking-item-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingItemPageRoutingModule": () => (/* binding */ BookingItemPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var _booking_item_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-item.page */ 12159);




const routes = [
    {
        path: '',
        component: _booking_item_page__WEBPACK_IMPORTED_MODULE_0__.BookingItemPage
    },
    {
        path: 'payments',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"), __webpack_require__.e("default-src_app_pages_payments_payments_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../payments/payments.module */ 15795)).then((m) => m.PaymentsPageModule),
    },
    {
        path: 'booking-edit/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_shared_components_time-selector_time-selector_module_ts"), __webpack_require__.e("default-src_app_core_services_services_services_service_ts-src_app_shared_components_service--e2c6b5"), __webpack_require__.e("default-src_app_shared_components_customer-list_customer-list_component_ts-src_app_shared_com-6909dc"), __webpack_require__.e("default-node_modules_date-fns_esm_addMonths_index_js-node_modules_date-fns_esm_constants_inde-b27e6a"), __webpack_require__.e("default-src_app_pages_booking-manager_new-booking_new-booking_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../new-booking/new-booking.module */ 41072)).then((m) => m.NewBookingPageModule),
    },
];
let BookingItemPageRoutingModule = class BookingItemPageRoutingModule {
};
BookingItemPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BookingItemPageRoutingModule);



/***/ }),

/***/ 61046:
/*!***************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-item/booking-item.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingItemPageModule": () => (/* binding */ BookingItemPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 31777);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _booking_item_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-item-routing.module */ 4423);
/* harmony import */ var _booking_item_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./booking-item.page */ 12159);
/* harmony import */ var src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/alert/alert.module */ 92563);
/* harmony import */ var src_app_shared_components_alert_non_attended_alert_non_attended_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/alert-non-attended/alert-non-attended.module */ 27878);
/* harmony import */ var src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/pipes/format-price/format-price.module */ 46239);










let BookingItemPageModule = class BookingItemPageModule {
};
BookingItemPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _booking_item_routing_module__WEBPACK_IMPORTED_MODULE_0__.BookingItemPageRoutingModule,
            src_app_shared_components_alert_alert_module__WEBPACK_IMPORTED_MODULE_2__.AlertModule,
            src_app_shared_components_alert_non_attended_alert_non_attended_module__WEBPACK_IMPORTED_MODULE_3__.AlertNonAttendedModule,
            src_app_core_pipes_format_price_format_price_module__WEBPACK_IMPORTED_MODULE_4__.FormatPriceModule
        ],
        declarations: [_booking_item_page__WEBPACK_IMPORTED_MODULE_1__.BookingItemPage],
    })
], BookingItemPageModule);



/***/ }),

/***/ 12159:
/*!*************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-item/booking-item.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BookingItemPage": () => (/* binding */ BookingItemPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _booking_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./booking-item.page.html?ngResource */ 91913);
/* harmony import */ var _booking_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./booking-item.page.scss?ngResource */ 77803);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 76327);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 95472);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 65485);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! date-fns */ 97807);
/* harmony import */ var date_fns_esm__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! date-fns/esm */ 9165);
/* harmony import */ var src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/payments/payments.model */ 3145);
/* harmony import */ var src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/booking/booking.service */ 70065);
/* harmony import */ var src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utils/date.service */ 19109);
/* harmony import */ var src_app_shared_components_alert_non_attended_alert_non_attended_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/alert-non-attended/alert-non-attended.component */ 47904);
/* harmony import */ var src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/components/alert/alert.component */ 18332);
/* harmony import */ var src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/payments/payments.service */ 29474);
/* harmony import */ var src_app_core_services_toast_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/toast/toast.service */ 66791);
















let BookingItemPage = class BookingItemPage {
    constructor(bookingService, activateRoute, dateService, router, navCtrl, paymentsService, toastService, alertCtrl) {
        this.bookingService = bookingService;
        this.activateRoute = activateRoute;
        this.dateService = dateService;
        this.router = router;
        this.navCtrl = navCtrl;
        this.paymentsService = paymentsService;
        this.toastService = toastService;
        this.alertCtrl = alertCtrl;
        this.totalPrice = 0;
        this.isPayed = false;
        this.fromBillingPage = false;
        this.isFromCustomerPage = false;
        if (this.router.getCurrentNavigation().extras.state) {
            if (this.router.getCurrentNavigation().extras.state.isFromCustomerPage) {
                this.isFromCustomerPage = true;
            }
            this.fromBillingPage = this.router.getCurrentNavigation().extras.state.fromBilling;
        }
    }
    ngOnInit() {
        this.getIdParam();
    }
    checkIsPast(res) {
        const dateSplit = res.startsDay.split('-');
        const date = (0,date_fns__WEBPACK_IMPORTED_MODULE_9__["default"])(new Date(parseInt(dateSplit[0], 10), parseInt(dateSplit[1], 10) - 1, parseInt(dateSplit[2], 10), res.startsHour, res.startsMinute), res.duration);
        this.isPast = (0,date_fns_esm__WEBPACK_IMPORTED_MODULE_10__["default"])(date);
        console.log(this.isPast);
    }
    getIdParam() {
        this.activateRoute.params.subscribe((param) => {
            this.bookingId = param.id;
            this.getBookingById(this.bookingId);
        });
    }
    getBookingById(bookingId) {
        this.bookingService.findBookingById(bookingId).subscribe((res) => {
            if (res) {
                this.bookingData = res;
                if (!this.bookingData.customer.photoURL) {
                    let initials = this.bookingData.customer.name.slice(0, 2);
                    if (this.bookingData.customer.lastname) {
                        initials = `${this.bookingData.customer.name.slice(0, 1)}${this.bookingData.customer.lastname.slice(0, 1)}`;
                    }
                    this.bookingData.customer.photoURL = `https://avatars.dicebear.com/api/initials/${initials}.svg?b=%23E0DEDE`;
                }
                this.checkIsPast(res);
                console.log('this.bookingData: ', this.bookingData);
                if (this.bookingData.payment || this.bookingData.paymentSettedUuid) {
                    this.isPayed = true;
                }
                this.totalPrice = this.bookingData.payment ? this.bookingData.payment.amount :
                    this.calcTotalPriceService(this.bookingData.service);
            }
        });
    }
    goToDetail(customerSelected) {
        const navigationExtras = {
            state: { customer: customerSelected }
        };
        this.navCtrl.navigateForward(['tabs/customers/customer-detail'], navigationExtras);
    }
    editBooking() {
        this.navCtrl.navigateForward([`booking-edit/${this.bookingId}`], { relativeTo: this.activateRoute });
    }
    calcTotalPriceService(service) {
        let price = 0;
        service.forEach((item) => {
            price = price + item.price;
        });
        this.totalPrice = price;
        return this.totalPrice;
    }
    openAlert() {
        this.deleteAlert.presentAlertConfirm();
    }
    openAlertNonAttendant() {
        this.nonAttended.presentAlertConfirm();
    }
    cancel() {
        if (this.fromBillingPage) {
            this.navCtrl.navigateBack('tabs/profile/billing');
        }
        else if (this.isFromCustomerPage) {
            this.navCtrl.back();
        }
        else {
            this.navCtrl.navigateForward('tabs/home');
        }
    }
    alertBox(value) {
        if (value) {
            this.deleteItem();
        }
    }
    alertBoxNonAttended(value) {
        if (value) {
            this.setAsNonAttended();
        }
    }
    setAsNonAttended() {
        this.bookingData.status = 'No asistida';
        this.bookingService.saveBooking(this.bookingData).subscribe(res => {
        });
    }
    payBooking() {
        const newPayment = new src_app_core_models_payments_payments_model__WEBPACK_IMPORTED_MODULE_2__.PaymentDto();
        if (this.totalPrice.toString().includes('.')) {
            newPayment.amount = parseInt(this.totalPrice.toString().split('.')[0], 10);
            newPayment.decimals = parseInt(this.totalPrice.toString().split('.')[1], 10);
        }
        else {
            newPayment.amount = this.totalPrice;
            newPayment.decimals = 0;
        }
        newPayment.service = this.bookingData.service;
        newPayment.date = this.dateService.formatDate(new Date());
        newPayment.discount = 0;
        newPayment.commerce = this.bookingData.commerce;
        newPayment.booking = this.bookingData;
        newPayment.customer = this.bookingData.customer;
        const navigationExtras = {
            relativeTo: this.activateRoute,
            queryParams: {
                payment: JSON.stringify(newPayment)
            }
        };
        this.navCtrl.navigateForward(['payments'], navigationExtras);
    }
    deleteItem() {
        if (!this.isPayed) {
            this.bookingService
                .deleteBookingById(this.bookingId)
                .subscribe((res) => {
                if (res) {
                    this.cancel();
                }
            });
        }
    }
    deletePayment() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, function* () {
            let paymentId;
            if (this.bookingData.payment) {
                paymentId = this.bookingData.payment.uuid;
            }
            else {
                paymentId = this.bookingData.paymentSettedUuid;
            }
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: '¿Desea eliminar el cobro de esta reserva?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: () => { },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.paymentsService.deletePayment(paymentId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.switchMap)(response => {
                                if (response) {
                                    this.toastService.presentToast('Cobro eliminado correctamente', true);
                                    this.bookingData.status = 'Pendiente de pago';
                                    this.bookingData.payment = null;
                                    this.bookingData.paymentSettedUuid = null;
                                    return this.bookingService.updateBooking(this.bookingData);
                                }
                            })).subscribe(booking => {
                                if (booking) {
                                    this.bookingData = booking;
                                    this.isPayed = false;
                                }
                            });
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
BookingItemPage.ctorParameters = () => [
    { type: src_app_core_services_booking_booking_service__WEBPACK_IMPORTED_MODULE_3__.BookingService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute },
    { type: src_app_core_utils_date_service__WEBPACK_IMPORTED_MODULE_4__.DateService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController },
    { type: src_app_core_services_payments_payments_service__WEBPACK_IMPORTED_MODULE_7__.PaymentsService },
    { type: src_app_core_services_toast_toast_service__WEBPACK_IMPORTED_MODULE_8__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.AlertController }
];
BookingItemPage.propDecorators = {
    deleteAlert: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: [src_app_shared_components_alert_alert_component__WEBPACK_IMPORTED_MODULE_6__.AlertComponent,] }],
    nonAttended: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild, args: [src_app_shared_components_alert_non_attended_alert_non_attended_component__WEBPACK_IMPORTED_MODULE_5__.AlertNonAttendedComponent,] }]
};
BookingItemPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
        selector: 'app-booking-item',
        template: _booking_item_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_booking_item_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BookingItemPage);



/***/ }),

/***/ 47904:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/alert-non-attended/alert-non-attended.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertNonAttendedComponent": () => (/* binding */ AlertNonAttendedComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_non_attended_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert-non-attended.component.html?ngResource */ 20413);
/* harmony import */ var _alert_non_attended_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert-non-attended.component.scss?ngResource */ 8459);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertNonAttendedComponent = class AlertNonAttendedComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertNonAttendedComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertNonAttendedComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertNonAttendedComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert-non-attended',
        template: _alert_non_attended_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_non_attended_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertNonAttendedComponent);



/***/ }),

/***/ 27878:
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/alert-non-attended/alert-non-attended.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertNonAttendedModule": () => (/* binding */ AlertNonAttendedModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_non_attended_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert-non-attended.component */ 47904);




let AlertNonAttendedModule = class AlertNonAttendedModule {
};
AlertNonAttendedModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_non_attended_component__WEBPACK_IMPORTED_MODULE_0__.AlertNonAttendedComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_non_attended_component__WEBPACK_IMPORTED_MODULE_0__.AlertNonAttendedComponent],
    })
], AlertNonAttendedModule);



/***/ }),

/***/ 18332:
/*!************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertComponent": () => (/* binding */ AlertComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component.html?ngResource */ 791);
/* harmony import */ var _alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.component.scss?ngResource */ 93219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 95472);





let AlertComponent = class AlertComponent {
    constructor(alertController) {
        this.alertController = alertController;
        this.actionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    presentAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: this.title,
                message: this.message ? this.message : '',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        id: 'cancel-button',
                        handler: (blah) => {
                            this.actionEmitter.emit(false);
                        },
                    },
                    {
                        text: 'Aceptar',
                        id: 'confirm-button',
                        handler: () => {
                            this.actionEmitter.emit(true);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
};
AlertComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController }
];
AlertComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    message: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    actionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
AlertComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-alert',
        template: _alert_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_alert_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AlertComponent);



/***/ }),

/***/ 92563:
/*!*********************************************************!*\
  !*** ./src/app/shared/components/alert/alert.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertModule": () => (/* binding */ AlertModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 48163);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 51109);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 38143);
/* harmony import */ var _alert_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./alert.component */ 18332);




let AlertModule = class AlertModule {
};
AlertModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
        exports: [_alert_component__WEBPACK_IMPORTED_MODULE_0__.AlertComponent],
    })
], AlertModule);



/***/ }),

/***/ 77803:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-item/booking-item.page.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.customer-card {\n  padding: 0;\n  max-height: 93.5px;\n}\n.customer-card .customer-row {\n  border-radius: 15px;\n}\n.customer-card .customer-row .customer-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.customer-card .customer-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.customer-card .customer-row .customer-label {\n  display: block;\n  margin-top: 15%;\n  margin-left: 5%;\n}\n.service-card {\n  padding: 0;\n  max-height: 43.5px;\n}\n.service-card .service-row {\n  border-radius: 15px;\n}\n.service-card .service-row .service-image {\n  background-color: #e4e4e4;\n  padding: 0;\n  height: 100%;\n}\n.service-card .service-row .icon-container {\n  margin-top: 190%;\n  text-align: center;\n}\n.service-card .service-row .service-label {\n  display: block;\n  margin-top: 3%;\n  margin-left: 5%;\n  margin-bottom: 3%;\n}\nimg {\n  width: 100%;\n}\n.color-pending {\n  background-color: orange;\n  width: 100%;\n  height: 30vh;\n  margin-top: 0px;\n  position: absolute;\n}\n.color-status {\n  width: 100%;\n  height: 30vh;\n  position: absolute;\n}\n.status {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  margin-top: 45px;\n}\n.status .status-info {\n  font-size: 25px;\n  font-weight: bold;\n}\n.main-content .card {\n  background-color: white;\n  z-index: 9999;\n  position: absolute;\n  top: 100px;\n  width: 100%;\n  border-radius: 30px;\n  padding: 0px 10px;\n}\n.main-content .card .title {\n  display: flex;\n  justify-content: center;\n  font-size: 18px;\n  color: var(--ion-color-primary);\n  margin-top: 3rem;\n}\n.main-content .card .logo {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  margin-top: 20px;\n}\n.main-content .card .logo .logo-name {\n  font-size: 16px;\n  font-weight: bold;\n}\n.main-content .card .logo .logo-info {\n  font-size: 35px;\n  font-weight: bold;\n}\n.main-content .card .text {\n  font-size: 15px;\n  text-align: center;\n  display: flex;\n  justify-content: center;\n  margin-bottom: 20px;\n  color: gray;\n  padding: 10px 20px 0px 20px;\n}\n.main-content .card .textbox {\n  border: 2px solid var(--ion-color-light);\n  border-radius: 15px;\n  font-size: 16px;\n  margin: 10px 14px;\n}\n.main-content .card .textbox ion-input {\n  margin: 2px 0px;\n}\n.main-content .card .textbox ion-label {\n  font-size: 22px;\n  color: var(--ion-color-medium);\n  padding: 0px 10px;\n}\n.main-content .card .textbox img {\n  border-radius: 50%;\n  width: 30px;\n  height: 30px;\n}\n.main-content .card .btn {\n  margin: 15px 14px;\n}\n.main-content .card .login-heading {\n  font-size: 14px;\n  display: flex;\n  justify-content: center;\n  padding: 15px 0px;\n}\n.main-content .card .btn-row ion-row .btn-login {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border: 2px solid var(--ion-color-light);\n  border-radius: 15px;\n  font-size: 16px;\n  font-weight: 600;\n  margin: 10px 0px;\n  padding: 10px 0px;\n}\n.main-content .card .btn-row ion-row .btn-login ion-label {\n  margin: 2px 10px;\n}\n.main-content .card .btn-row ion-row .btn-login img {\n  border-radius: 50%;\n  width: 30px;\n  height: 30px;\n}\n.main-content .card .footer {\n  font-size: 14px;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  align-items: center;\n  padding: 15px 0px;\n  color: var(--ion-color-medium);\n}\n.align-end {\n  text-align: end;\n}\n.editBtn {\n  position: absolute;\n  top: 35px;\n  right: 15px;\n}\n.backBtn {\n  position: absolute;\n  top: 35px;\n  left: 15px;\n  color: #fff;\n}\n.employee-label {\n  font-family: \"product\" !important;\n  font-size: 14px !important;\n  color: #666666 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJvb2tpbmctaXRlbS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBQWhCOzs7Ozs7O0NBQUE7QUFRQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtBQUVGO0FBREU7RUFDRSxtQkFBQTtBQUdKO0FBREk7RUFDRSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBR047QUFBSTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFFTjtBQUNJO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBQ047QUFHQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtBQUFGO0FBRUU7RUFDRSxtQkFBQTtBQUFKO0FBRUk7RUFDRSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQU47QUFHSTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUFETjtBQUlJO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFGTjtBQU1BO0VBQ0UsV0FBQTtBQUhGO0FBS0E7RUFDRSx3QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRkY7QUFJQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFERjtBQUdBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBQUY7QUFFRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQUFKO0FBSUU7RUFDRSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQURKO0FBRUk7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBRUEsK0JBQUE7RUFDQSxnQkFBQTtBQUROO0FBR0k7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFETjtBQUdNO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBRFI7QUFHTTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQURSO0FBS0k7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFFQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtBQUpOO0FBT0k7RUFDRSx3Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUVBLGlCQUFBO0FBTk47QUFPTTtFQUNFLGVBQUE7QUFMUjtBQU9NO0VBQ0UsZUFBQTtFQUNBLDhCQUFBO0VBQ0EsaUJBQUE7QUFMUjtBQU9NO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUxSO0FBUUk7RUFDRSxpQkFBQTtBQU5OO0FBU0k7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUFQTjtBQVlRO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSx3Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQVZWO0FBV1U7RUFDRSxnQkFBQTtBQVRaO0FBV1U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBVFo7QUFjSTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSw4QkFBQTtBQVpOO0FBZ0JBO0VBQ0UsZUFBQTtBQWJGO0FBZ0JBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtBQWJGO0FBZ0JBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUFiRjtBQWdCQTtFQUNFLGlDQUFBO0VBQ0EsMEJBQUE7RUFDQSx5QkFBQTtBQWJGIiwiZmlsZSI6ImJvb2tpbmctaXRlbS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gIEF1dGhvcnMgOiBidW5jaGRldmVsb3BlcnMgKFJhaHVsIEpvZ3JhbmEpXHJcbiAgV2Vic2l0ZSA6IGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9cclxuICBBcHAgTmFtZSA6IGlvbmljNlRlbXBsYXRlIFBhY2tcclxuICBUaGlzIEFwcCBUZW1wbGF0ZSBTb3VyY2UgY29kZSBpcyBsaWNlbnNlZCBhcyBwZXIgdGhlXHJcbiAgdGVybXMgZm91bmQgaW4gdGhlIFdlYnNpdGUgaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL2xpY2Vuc2VcclxuICBDb3B5cmlnaHQgYW5kIEdvb2QgRmFpdGggUHVyY2hhc2VycyDCqSAyMDIxLXByZXNlbnQgYnVuY2hkZXZlbG9wZXJzLlxyXG4qL1xyXG4uY3VzdG9tZXItY2FyZCB7XHJcbiAgcGFkZGluZzogMDtcclxuICBtYXgtaGVpZ2h0OiA5My41cHg7XHJcbiAgLmN1c3RvbWVyLXJvdyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG5cclxuICAgIC5jdXN0b21lci1pbWFnZSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE5MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgICAuY3VzdG9tZXItbGFiZWwge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgbWFyZ2luLXRvcDogMTUlO1xyXG4gICAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5zZXJ2aWNlLWNhcmQge1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgbWF4LWhlaWdodDogNDMuNXB4O1xyXG5cclxuICAuc2VydmljZS1yb3cge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuXHJcbiAgICAuc2VydmljZS1pbWFnZSB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMjgsIDIyOCwgMjI4KTtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE5MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgICAuc2VydmljZS1sYWJlbCB7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBtYXJnaW4tdG9wOiAzJTtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAzJTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW1nIHtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG4uY29sb3ItcGVuZGluZyB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMzB2aDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcbi5jb2xvci1zdGF0dXMge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMzB2aDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbn1cclxuLnN0YXR1cyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWFyZ2luLXRvcDogNDVweDtcclxuXHJcbiAgLnN0YXR1cy1pbmZvIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxufVxyXG4ubWFpbi1jb250ZW50IHtcclxuICAuY2FyZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIHotaW5kZXg6IDk5OTk7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogMHB4IDEwcHg7XHJcbiAgICAudGl0bGUge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG5cclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgbWFyZ2luLXRvcDogM3JlbTtcclxuICAgIH1cclxuICAgIC5sb2dvIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcblxyXG4gICAgICAubG9nby1uYW1lIHtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgIH1cclxuICAgICAgLmxvZ28taW5mbyB7XHJcbiAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLnRleHQge1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgICBjb2xvcjogZ3JheTtcclxuICAgICAgcGFkZGluZzogMTBweCAyMHB4IDBweCAyMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIC50ZXh0Ym94IHtcclxuICAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG5cclxuICAgICAgbWFyZ2luOiAxMHB4IDE0cHg7XHJcbiAgICAgIGlvbi1pbnB1dCB7XHJcbiAgICAgICAgbWFyZ2luOiAycHggMHB4O1xyXG4gICAgICB9XHJcbiAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgICAgICBwYWRkaW5nOiAwcHggMTBweDtcclxuICAgICAgfVxyXG4gICAgICBpbWcge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICB3aWR0aDogMzBweDtcclxuICAgICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5idG4ge1xyXG4gICAgICBtYXJnaW46IDE1cHggMTRweDtcclxuICAgIH1cclxuXHJcbiAgICAubG9naW4taGVhZGluZyB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIHBhZGRpbmc6IDE1cHggMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5idG4tcm93IHtcclxuICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgLmJ0bi1sb2dpbiB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgbWFyZ2luOiAxMHB4IDBweDtcclxuICAgICAgICAgIHBhZGRpbmc6IDEwcHggMHB4O1xyXG4gICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAycHggMTBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5mb290ZXIge1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBwYWRkaW5nOiAxNXB4IDBweDtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uYWxpZ24tZW5kIHtcclxuICB0ZXh0LWFsaWduOiBlbmQ7XHJcbn1cclxuXHJcbi5lZGl0QnRuIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAzNXB4O1xyXG4gIHJpZ2h0OiAxNXB4O1xyXG59XHJcblxyXG4uYmFja0J0biB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMzVweDtcclxuICBsZWZ0OiAxNXB4O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4uZW1wbG95ZWUtbGFiZWwge1xyXG4gIGZvbnQtZmFtaWx5OiBcInByb2R1Y3RcIiAhaW1wb3J0YW50O1xyXG4gIGZvbnQtc2l6ZTogMTRweCAhaW1wb3J0YW50O1xyXG4gIGNvbG9yOiAjNjY2NjY2ICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 8459:
/*!***************************************************************************************************!*\
  !*** ./src/app/shared/components/alert-non-attended/alert-non-attended.component.scss?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC1ub24tYXR0ZW5kZWQuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 93219:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGVydC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 91913:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/booking-manager/booking-item/booking-item.page.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content *ngIf=\"bookingData\">\r\n  <div class=\"color-status\" [ngClass]=\"[\r\n  bookingData.status === 'Pendiente' ? 'bg-orange-300' : '',\r\n  bookingData.status === 'Pendiente de pago' ? 'bg-yellow-300' : '',\r\n  bookingData.status === 'Realizada' ? 'bg-green-300' : '',\r\n  bookingData.status === 'No asistida' ? 'bg-red-300' : '' ]\">\r\n    <div class=\"backBtn\">\r\n      <ion-icon name=\"arrow-back\" size=\"large\" (click)=\"cancel()\">\r\n      </ion-icon>\r\n    </div>\r\n    <div class=\"editBtn\">\r\n      <ion-icon name=\"create-outline\" size=\"large\" (click)=\"editBooking()\">\r\n      </ion-icon>\r\n    </div>\r\n    <div class=\"status\">\r\n      <ion-label class=\"status-info\">{{bookingData.status}}</ion-label>\r\n    </div>\r\n  </div>\r\n  <div class=\"main-content\">\r\n    <div class=\"card\">\r\n      <div class=\"logo\">\r\n        <ion-item class=\"textbox\" lines=\"none\">\r\n          {{dateService.formatBookingTimetable( bookingData.startsHour,\r\n          bookingData.startsMinute, bookingData.duration)}}\r\n          <ion-label>|</ion-label>\r\n          {{bookingData.startsDay | date}}\r\n        </ion-item>\r\n      </div>\r\n      <ion-card (click)=\"goToDetail(bookingData?.customer)\" button=\"true\">\r\n        <ion-grid class=\"customer-card\">\r\n          <ion-row class=\"customer-row\">\r\n            <ion-col class=\"customer-image\" size=\"3\">\r\n              <img [src]=\"bookingData?.customer?.photoURL\" />\r\n            </ion-col>\r\n            <ion-col size=\"8\">\r\n              <ion-label class=\"customer-label\">{{bookingData.customer?.name +'\r\n                '+bookingData.customer?.lastname}}\r\n              </ion-label>\r\n            </ion-col>\r\n            <ion-col size=\"1\">\r\n              <div class=\"icon-container\">\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </div>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-card>\r\n\r\n      <ng-container *ngFor=\"let service of bookingData.service\">\r\n        <ion-card button=\"true\">\r\n          <ion-grid class=\"service-card\">\r\n            <ion-row class=\"service-row\">\r\n              <ion-col size=\"0.1\" [style.background-color]=\"service?.color\"></ion-col>\r\n              <ion-col size=\"11\">\r\n                <ion-label class=\"service-label\">\r\n                  {{service.name}} · {{service.price | formatPrice}}\r\n                </ion-label>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-card>\r\n      </ng-container>\r\n\r\n      <ng-container>\r\n        <ion-item class=\"textbox\">\r\n          <ion-avatar slot=\"start\">\r\n            <img [src]=\"bookingData.asignedTo.image\" />\r\n          </ion-avatar>\r\n          <ion-label class=\"employee-label\">{{bookingData.asignedTo.name}} {{bookingData.asignedTo.surname}}</ion-label>\r\n        </ion-item>\r\n      </ng-container>\r\n\r\n      <ng-container *ngIf=\"bookingData.message\">\r\n        <ion-card button=\"true\">\r\n          <div class=\"p-4\">\r\n            <ion-label class=\"service-label\">Mensaje del cliente:\r\n            </ion-label>\r\n          </div>\r\n\r\n          <div class=\"p-4\">\r\n            <ion-label class=\"service-label ion-text-right\">{{bookingData.message}}\r\n            </ion-label>\r\n          </div>\r\n\r\n\r\n        </ion-card>\r\n      </ng-container>\r\n      <ng-container *ngIf=\"bookingData.note\">\r\n        <ion-card button=\"true\">\r\n          <ion-grid class=\"service-card\">\r\n            <ion-row class=\"service-row p-1\" style=\"align-items: baseline\">\r\n              <ion-col size=\"5\">\r\n                <ion-label class=\"service-label\">Nota del comercio:\r\n                </ion-label>\r\n              </ion-col>\r\n              <ion-col size=\"7\">\r\n                <ion-label class=\"service-label ion-text-right\">\r\n                  {{bookingData.note}}\r\n                </ion-label>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-card>\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n<app-alert #deleteAlert (actionEmitter)=\"alertBox($event)\" [title]=\"'¿Desea borrar esta reserva?'\"></app-alert>\r\n<app-alert-non-attended #NonAttended (actionEmitter)=\"alertBoxNonAttended($event)\"\r\n  [title]=\"'¿Marcar como inasistencia?'\"></app-alert-non-attended>\r\n<ion-footer class=\"ion-no-border\" *ngIf=\"bookingData\">\r\n  <ion-grid>\r\n    <ion-row class=\"ion-justify-content-end padding-right\" *ngIf=\"totalPrice !== 0\">\r\n      <ion-col size=\"6\">\r\n        <ion-item>\r\n          <ion-label>\r\n            <h3>Total: {{totalPrice  | formatPrice}} </h3>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col *ngIf=\"isPayed\">\r\n        <ion-button class=\"btn\" expand=\"block\" color=\"danger\" (click)=\"deletePayment()\">\r\n          Eliminar cobro\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col *ngIf=\"!isPayed\">\r\n        <ion-item>\r\n          <ion-label class=\"align-end\">\r\n            <h3>Pendiente: {{totalPrice | formatPrice}} </h3>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n\r\n    </ion-row>\r\n    <ion-row>\r\n\r\n      <ion-col size=\"2\" *ngIf=\"!isPayed\" (click)=\"openAlert()\">\r\n        <ion-button class=\"btn\" expand=\"block\">\r\n          <ion-icon icon=\"trash\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col size=\"4\" *ngIf=\"!isPayed && bookingData.status !== 'No asistida' && bookingData.status !== 'Finalizada' \" (click)=\"openAlertNonAttendant()\">\r\n        <ion-button class=\"btn\" expand=\"block\">\r\n          Inasistencia\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col size=\"6\" *ngIf=\"!isPayed && bookingData.status !== 'Finalizada' \">\r\n        <ion-button class=\"btn\" (click)=\"payBooking()\" expand=\"block\">\r\n          Cobrar\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-footer>\r\n";

/***/ }),

/***/ 20413:
/*!***************************************************************************************************!*\
  !*** ./src/app/shared/components/alert-non-attended/alert-non-attended.component.html?ngResource ***!
  \***************************************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ }),

/***/ 791:
/*!*************************************************************************!*\
  !*** ./src/app/shared/components/alert/alert.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_booking-manager_booking-item_booking-item_module_ts.js.map